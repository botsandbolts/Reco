# BPR + UMAP Research Patch (Steps 5 and 6)

This patch adds a **six-architecture comparison** and an interactive 2D UMAP movie map to the Hybrid Movie Recommender. Apply it at the root of `herberton777/Reco`, not inside a second nested project folder.

## What it adds

1. Existing SVD benchmark **reference** (preserved from your existing `artifacts/metrics.json`).
2. New **BPR-MF** with user and item embeddings.
3. New **BPR + PCA semantic** fusion.
4. New **BPR + UMAP semantic** fusion.
5. New **BPR + raw Sentence Transformer embedding** with a learned projection.
6. New **BPR-UMAP retrieval → LightGBM LambdaMART** reranking with first-stage candidate limits.

The first four BPR models use PyTorch, pairwise softplus/BPR loss and fresh mixed (uniform/popularity) weak-negative sampling each epoch. Semantic features are generated from MovieLens title and genre metadata only, not plots. Validation NDCG is used for early stopping. LambdaMART is trained **only** on the designated ranker-training interaction and candidates derived from the earlier interactions.

The separate **Embedding map (UMAP)** Streamlit tab displays a 2D UMAP view (primary genre colored). Choose or click movies and inspect nearest neighbors by **original 384-dimensional cosine similarity**, not misleading 2D Euclidean distance.

## Apply in GitHub Codespaces (Android friendly)

Upload `bpr_umap_research_patch.zip` to your GitHub repository via GitHub's **Add file → Upload files**. In the **Codespaces terminal**, at the repository root:

```bash
cd /workspaces/Reco
git pull origin main
unzip -o bpr_umap_research_patch.zip
python -m pip install -r requirements-experiments.txt
python -m pytest -q tests
```

If you haven't trained the recommender and generated Sentence Transformer embeddings yet:

```bash
python -m src.train --neural --epochs 15
python -m src.semantic
python -m src.benchmark_semantic
```

**Don't rerun `src.train` if your trained recommender already includes semantic embeddings!** That command replaces the serialized recommender and can erase the existing semantic vectors. `src.bpr_semantic_experiments` instead loads the existing model read-only.

### Step 5: run the six-model experiment

```bash
python -m src.bpr_semantic_experiments --epochs 12 --dim 64 --pool 250
```

For a quick smoke test before a longer experiment:

```bash
python -m src.bpr_semantic_experiments --epochs 2 --dim 16 --pool 100
```

Note: both commands update `artifacts/metrics.json` for the Benchmark tab; the original is backed up to `artifacts/metrics_before_bpr_semantic.json` on first run. Results are also saved to `artifacts/bpr_semantic_metrics.json`. Other outputs:

```text
artifacts/bpr_models.npz             # four BPR factor models, ID-aligned
artifacts/bpr_umap_ranker.joblib     # trusted reranking model
artifacts/bpr_semantic_metrics.json  # reproducible comparison/parameters
```

Running training a second time overwrites the BPR outputs and experiment metrics. Save/rename results externally if comparing configurations. **Never tune using the final test results.** The script uses the validation set for early stopping and reserves test for final reporting.

### Step 6: build and open the interactive map

```bash
python -m src.build_umap_map
streamlit run app.py --server.address 0.0.0.0 --server.port 8501
```

Open the Codespaces forwarded **8501** port and click **Embedding map (UMAP)**. The map is loaded from:

```text
artifacts/umap_movie_map.npz
```

In Codespaces, PyTorch can run on CPU. Training four ranking models and two UMAP fits may take **several minutes to considerably longer**, depending on hardware. A free GPU is not essential but can reduce neural training time. UMAP itself typically executes on CPU.

## Data and scientific caveats

- UMAP is useful for nonlinear neighborhood preservation but **does not inherently improve** retrieval or ranking. Compare with PCA and raw embeddings.
- The UMAP map is **2D visualization**, separate from the **64D UMAP factors** used as inputs to BPR.
- All semantic reduction is fitted **transductively on the complete item catalogue's metadata**; this is appropriate for a fixed known catalogue, not a strict unseen-item benchmark.
- Training negatives are **unobserved items**, not confirmed dislikes. Movies later positively rated by a user may be sampled as training negatives without using future labels to filter them.
- Per-user chronological holdouts do not eliminate global cross-user temporal leakage.
- The supervised ranker is trained using weak sampled negatives from the first-stage candidate set. The target item is forcibly included in the supervised training group even when retrieval missed it; the benchmark correctly evaluates actual candidate retrieval limits. Check `ranker_train_candidate_recall` and `candidate_recall_at_pool` to interpret bottlenecks.
- The experiment makes no claims about production uplift or superiority of BPR/UMAP. Metrics must be measured on MovieLens and documented.
- `joblib` files must be loaded only from trusted sources. Do not load externally supplied model artifacts.
- The original MovieLens license and Sentence Transformers model terms apply to data and pretrained artifacts.

## Relevant changed files

```text
app.py
requirements-experiments.txt
src/bpr_semantic_experiments.py
src/build_umap_map.py
src/bpr_semantic_ui.py
tests/test_bpr_semantic_experiments.py
BPR_UMAP_PATCH.md
```

## Troubleshooting

- `RuntimeError: Sentence Transformer vectors missing`: run `python -m src.semantic` **after** fitting the base recommender.
- `ModuleNotFoundError: umap`: run `python -m pip install -r requirements-experiments.txt`.
- `Cannot find metrics.json`: complete original `python -m src.train` first.
- Benchmark missing BPR rows: finish `python -m src.bpr_semantic_experiments` and refresh the Streamlit tab.
- Map tab says missing: finish `python -m src.build_umap_map`.
- `404` when opening the app: use the Codespaces **Ports** tab to open the currently forwarded port 8501 while Streamlit is running.
