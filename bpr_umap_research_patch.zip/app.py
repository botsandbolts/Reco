"""Streamlit recommendation app. Deploy using `streamlit run app.py`."""
import json
from pathlib import Path
import pandas as pd
import streamlit as st
from src.recommender import HybridRecommender

st.set_page_config(page_title="Hybrid Movie Recommender", page_icon="🎬", layout="wide")
st.title("🎬 Hybrid Movie Recommender")
st.caption("Research demo • MovieLens latest-small / GroupLens • No commercial use without permission")

ARTIFACT = Path("artifacts/recommender.joblib")
if not ARTIFACT.exists():
    st.error("Trained model not found: artifacts/recommender.joblib")
    st.code("python -m src.train --neural\nstreamlit run app.py", language="bash")
    st.info("To deploy: train in Codespaces, then add the trusted artifact to your "
            "GitHub repository after checking the dataset's license conditions.")
    st.stop()

@st.cache_resource(show_spinner="Loading recommendation engine …")
def load_engine():
    return HybridRecommender.load(ARTIFACT)

engine = load_engine()

# Optional BPR experiments are serialized separately; base artifact stays unchanged.
BPR_PATH = Path("artifacts/bpr_models.npz")
BPR_METHODS = ("bpr_mf", "bpr_pca", "bpr_umap", "bpr_raw")

@st.cache_resource(show_spinner="Loading BPR experiment factors …")
def load_bpr_factors(path):
    import numpy as np
    with np.load(path, allow_pickle=False) as d:
        arrays = {key: d[key].copy() for key in d.files}
    return arrays

bpr_artifacts = load_bpr_factors(str(BPR_PATH)) if BPR_PATH.exists() else None
if bpr_artifacts is not None:
    import numpy as np
    if (not np.array_equal(bpr_artifacts["movie_ids"], engine.movie_ids) or
            not np.array_equal(bpr_artifacts["user_ids"], engine.user_ids)):
        st.warning("BPR artifact and base model IDs differ. Retrain the BPR experiments.")
        bpr_artifacts = None


def recommend_bpr(user_id, k, method):
    import numpy as np
    user_index = engine.user_to_idx[int(user_id)]
    users = bpr_artifacts[f"{method}_user"]
    items = bpr_artifacts[f"{method}_item"]
    scores = items @ users[user_index]
    scores = np.array(scores, copy=True)
    seen = list(engine.seen[int(user_id)])
    scores[seen] = -np.inf
    winners = np.argsort(-scores, kind="stable")[:k]
    return engine._result(winners, scores)
explore, favorites, benchmark, methodology, embedding_map = st.tabs(
    ["Known user", "Choose favorites (cold start)", "Benchmark", "Methodology",
     "Embedding map (UMAP)"])

with explore:
    st.subheader("Recommendations for an existing MovieLens user")
    left, right = st.columns([1, 3])
    with left:
        user_id = st.selectbox("Anonymous training user", engine.user_ids.tolist())
        methods = list(engine.models)
        if bpr_artifacts is not None:
            methods.extend(BPR_METHODS)
        model_name = st.selectbox("Recommendation method", methods,
                                  index=methods.index("hybrid"))
        n = st.slider("How many recommendations?", 5, 20, 10)
    with right:
        st.write("**Movies in this user's training history**")
        seen_ids = sorted(engine.seen[int(user_id)])
        st.dataframe(engine.movies.iloc[seen_ids][["title", "genres"]].head(12),
                     hide_index=True, use_container_width=True)
    st.write("**Top recommendations**")
    if model_name in BPR_METHODS and bpr_artifacts is not None:
        recommendations = recommend_bpr(user_id, k=n, method=model_name)
    else:
        recommendations = engine.recommend(user_id, k=n, model=model_name)
    st.dataframe(recommendations, hide_index=True, use_container_width=True)
    st.caption("The training history deliberately omits ranker-training, validation "
               "and test positives, which are kept separate during evaluation.")

with favorites:
    st.subheader("Recommendations without a user account")
    st.write("Select movies you enjoyed. The system combines genre similarity, "
             "item embeddings, and a small popularity prior. It does **not** "
             "claim to use the known-user ranking model for new users.")
    labels = {f"{row.title} (ID {row.movieId})": int(row.movieId)
              for row in engine.movies.itertuples(index=False)}
    selections = st.multiselect("Favorite movies", options=list(labels),
                                default=[name for name in labels if name.startswith("Toy Story (1995)")][:1],
                                max_selections=7)
    if selections:
        st.dataframe(engine.recommend_from_favorites([labels[k] for k in selections], k=10),
                     hide_index=True, use_container_width=True)
    else:
        st.info("Choose at least one title.")

with benchmark:
    metrics_file = Path("artifacts/metrics.json")
    st.subheader("Out-of-sample ranking benchmark")
    if metrics_file.exists():
        content = json.loads(metrics_file.read_text(encoding="utf-8"))
        split = st.radio("Split", ["test", "validation"], horizontal=True)
        df = pd.DataFrame(content[split]).T
        st.dataframe(df, use_container_width=True)
        if "ndcg_at_k" in df:
            st.bar_chart(df["ndcg_at_k"])
        st.caption(f"K={content['k']}; positive rating threshold "
                   f"{content['positive_rating_threshold']}. Full-catalogue ranking.")
    else:
        st.warning("metrics.json missing. Train the recommender to generate it.")

with methodology:
    st.markdown("""
    **Models:** popularity, TruncatedSVD collaborative filtering, TF-IDF genres,
    weighted hybrid, optional PyTorch two-tower, and LightGBM LambdaMART.

    **Split:** for users with at least four positive ratings (≥4 stars), reserve
    each user's last three positives in time order for ranker training, validation,
    and test. The model only sees earlier positives.

    **Ranking:** evaluate every non-excluded catalogue item, not just sampled
    negatives. Holdouts are one positive per user, so Recall@K is hit rate@K.

    **Limitations:** ratings are not impression logs; unobserved items are not
    verified dislikes. Historical MovieLens data and per-user chronological
    splits can still exhibit popularity, selection, and cross-user temporal bias.
    Offline metrics do not measure live business uplift. Cold-start uses item
    metadata, not a learned identity for the visitor.

    **Attribution:** [MovieLens / GroupLens](https://grouplens.org/datasets/movielens/)
    at the University of Minnesota. The data's license forbids commercial or
    revenue-bearing use without permission.
    """)

with embedding_map:
    from src.bpr_semantic_ui import render_embedding_map
    render_embedding_map(engine)
