"""BPR-MF versus semantic-fusion BPR; optional retrieval->LambdaMART reranking.

Run AFTER `python -m src.semantic`:
  python -m src.bpr_semantic_experiments --epochs 12

All rating-dependent model fitting uses the *early training* partition, except
LambdaMART, which uses the designated ranker-training partition. Validation is
used for early stopping, and test is evaluated only after model selection.
"""
from __future__ import annotations

import argparse
import json
import math
import shutil
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.preprocessing import normalize, StandardScaler

from .data import ensure_dataset, chronological_split
from .evaluation import evaluate_models, union_seen
from .recommender import HybridRecommender

FEATURE_VARIANTS = ("bpr_mf", "bpr_pca", "bpr_umap", "bpr_raw")


def prepare_features(semantic, dim=64, neighbors=30, seed=42):
    """Metadata-only transforms; no rating outcomes are used to fit them."""
    vectors = normalize(np.asarray(semantic, dtype=np.float32), axis=1)
    if vectors.ndim != 2 or len(vectors) < 3 or not np.isfinite(vectors).all():
        raise ValueError("semantic_item must be a finite matrix of item embeddings")
    n_pca = min(dim, vectors.shape[1], len(vectors) - 1)
    pca = PCA(n_components=n_pca, random_state=seed)
    pca_z = normalize(StandardScaler().fit_transform(pca.fit_transform(vectors))).astype("float32")
    try:
        import umap
    except ImportError as exc:
        raise RuntimeError("Install UMAP: python -m pip install -r requirements-experiments.txt") from exc
    reducer = umap.UMAP(n_components=dim, n_neighbors=min(neighbors, len(vectors) - 1),
                        metric="cosine", min_dist=0.05, random_state=seed,
                        n_jobs=1)
    umap_z = reducer.fit_transform(vectors)
    umap_z = normalize(StandardScaler().fit_transform(umap_z)).astype("float32")
    return {"bpr_mf": None, "bpr_pca": pca_z,
            "bpr_umap": umap_z, "bpr_raw": vectors}


def triples_for_epoch(events, seen, n_items, rng, negatives_per_positive=2, popularity=None):
    """Sample weak negatives freshly each epoch, with no held-out-label information."""
    events = np.asarray(events, dtype=np.int64)
    users = np.repeat(events[:, 0], negatives_per_positive)
    pos = np.repeat(events[:, 1], negatives_per_positive)
    neg = rng.integers(n_items, size=len(users), dtype=np.int64)
    if popularity is not None:
        mask = rng.random(len(users)) < 0.5
        neg[mask] = rng.choice(n_items, size=int(mask.sum()), p=popularity)
    invalid = np.array([int(item) in seen[int(u)] for u, item in zip(users, neg)])
    tries = 0
    while invalid.any():
        if tries >= 100:
            raise RuntimeError("Could not sample an item unseen in training")
        idx = np.flatnonzero(invalid)
        samples = rng.integers(n_items, size=len(idx), dtype=np.int64)
        if popularity is not None:
            mask = rng.random(len(idx)) < 0.5
            samples[mask] = rng.choice(n_items, size=int(mask.sum()), p=popularity)
        neg[idx] = samples
        invalid[idx] = [int(item) in seen[int(u)] for u, item in zip(users[idx], samples)]
        tries += 1
    return np.stack([users, pos, neg], axis=1)


def train_bpr(events, seen, n_users, n_items, feature_vectors=None, *,
              latent_dim=64, epochs=12, negatives_per_positive=2,
              learning_rate=0.003, alpha=1.0, seed=42,
              validation=None, patience=3, eval_every=2, batch_size=2048):
    """Train BPR-MF or content-aware BPR using learned semantic projection.

    Returns user and item factors whose product yields inference ranking scores.
    Validation early stopping reads only user-specified validation positives.
    """
    import torch
    from torch import nn
    from torch.nn import functional as F

    events = np.asarray(events, dtype=np.int64)
    if events.ndim != 2 or events.shape[1] != 2 or len(events) == 0:
        raise ValueError("events must have shape (n_events, 2)")
    if epochs < 1 or negatives_per_positive < 1 or latent_dim < 1:
        raise ValueError("epochs, negatives_per_positive and latent_dim must be positive")
    if any(len(seen.get(u, set())) >= n_items for u in np.unique(events[:, 0])):
        raise ValueError("At least one user has interacted with the full catalogue")

    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    torch.set_num_threads(min(4, torch.get_num_threads()))
    semantic = None if feature_vectors is None else np.asarray(feature_vectors, dtype="float32")
    if semantic is not None and semantic.shape[0] != n_items:
        raise ValueError("Feature rows must align to all item IDs")

    class Factors(nn.Module):
        def __init__(self):
            super().__init__()
            self.user = nn.Embedding(n_users, latent_dim)
            self.item = nn.Embedding(n_items, latent_dim)
            nn.init.normal_(self.user.weight, std=0.08)
            nn.init.normal_(self.item.weight, std=0.08)
            if semantic is not None:
                self.register_buffer("features", torch.tensor(semantic, device=device))
                self.projection = nn.Linear(semantic.shape[1], latent_dim, bias=False)
                nn.init.normal_(self.projection.weight, std=0.10)
            else:
                self.projection = None

        def item_vector(self, movie):
            result = self.item(movie)
            if self.projection is not None:
                result = result + alpha * self.projection(self.features[movie])
            return result

        def score(self, users, movies):
            return (self.user(users) * self.item_vector(movies)).sum(dim=-1)

        def export(self):
            with torch.no_grad():
                ids = torch.arange(n_items, device=device)
                user = self.user.weight.detach().cpu().numpy().astype("float32").copy()
                item = self.item_vector(ids).detach().cpu().numpy().astype("float32").copy()
                return user, item

    model = Factors().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    count = np.bincount(events[:, 1], minlength=n_items).astype("float64")
    popularity = np.power(count + 0.1, 0.75)
    popularity /= popularity.sum()

    best, best_metric, stale = None, -float("inf"), 0
    for epoch in range(1, epochs + 1):
        triples = triples_for_epoch(events, seen, n_items, rng,
                                    negatives_per_positive, popularity)
        rng.shuffle(triples)
        total, batches = 0.0, 0
        model.train()
        for start in range(0, len(triples), batch_size):
            batch = torch.as_tensor(triples[start:start + batch_size], device=device)
            users, positive, negative = batch.unbind(1)
            loss = F.softplus(-(model.score(users, positive) - model.score(users, negative))).mean()
            # Explicit regularization on sampled factors (not just optimizer weight decay).
            penalty = (model.user(users).square().mean()
                       + model.item(positive).square().mean()
                       + model.item(negative).square().mean()) * 1e-4
            optimizer.zero_grad(set_to_none=True)
            (loss + penalty).backward()
            optimizer.step()
            total += float(loss.detach().cpu())
            batches += 1

        if validation is not None and (epoch % eval_every == 0 or epoch == epochs):
            model.eval()
            u_factors, i_factors = model.export()
            metric = validation(u_factors, i_factors)
            print(f"  epoch {epoch:02d}/{epochs}, loss={total/batches:.4f}, validation NDCG={metric:.5f}")
            if metric > best_metric + 1e-7:
                best_metric, best, stale = metric, (u_factors.copy(), i_factors.copy()), 0
            else:
                stale += 1
                if stale >= patience:
                    print(f"  early stopping at epoch {epoch}")
                    break
        else:
            print(f"  epoch {epoch:02d}/{epochs}, loss={total/batches:.4f}")

    if best is None:
        best = model.export()
    return best


class FactorAdapter:
    """Use exactly the existing chronological full-catalogue evaluator."""
    def __init__(self, base, name, user_factors, item_factors):
        self.models = [name]
        self.user_to_idx = base.user_to_idx
        self.movie_to_idx = base.movie_to_idx
        self.seen = base.seen
        self.movie_ids = base.movie_ids
        self.user_vectors = np.asarray(user_factors, dtype="float32")
        self.item_vectors = np.asarray(item_factors, dtype="float32")
        self.name = name
        self.semantic_items = None
        if getattr(base, "semantic_item", None) is not None:
            self.semantic_items = normalize(
                np.asarray(base.semantic_item, dtype="float32"), axis=1)

    def score_user(self, user_id, model=None):
        return self.item_vectors @ self.user_vectors[self.user_to_idx[int(user_id)]]


def _fold_score(base, model_name, users, items, valid, exclusions, k):
    """Compute early-stop NDCG from the designated validation partition."""
    adapter = FactorAdapter(base, model_name, users, items)
    out = evaluate_models(adapter, valid, exclusions, k=k)
    return out[model_name]["ndcg_at_k"] or 0.0


def _feature_matrix(engine, bpr_adapter, user_id):
    classical = engine.features_for_user(user_id)
    bpr = bpr_adapter.score_user(user_id)
    # Non-parametric semantic user profile from *early training* positives only.
    item_sem = bpr_adapter.semantic_items
    movie_indices = list(engine.seen[int(user_id)])
    semantic_profile = item_sem[movie_indices].mean(axis=0)
    norm = np.linalg.norm(semantic_profile)
    if norm > 1e-8:
        semantic_profile /= norm
    semantic_similarity = item_sem @ semantic_profile
    return np.column_stack([bpr, classical[:, 1], classical[:, 0],
                            classical[:, 2], semantic_similarity]).astype("float32")


def _eligible_candidates(base, scores, user_id, extra_seen, pool):
    excluded = set(base.seen[int(user_id)])
    excluded.update(base.movie_to_idx[int(mid)] for mid in extra_seen.get(int(user_id), set())
                    if int(mid) in base.movie_to_idx)
    masked = np.asarray(scores, dtype="float32").copy()
    if excluded:
        masked[list(excluded)] = -np.inf
    count = min(pool, np.count_nonzero(np.isfinite(masked)))
    return np.argsort(-masked, kind="stable")[:count]


def fit_second_stage(base, adapter, rank_events, pool=250, sampled=60, seed=42):
    """LambdaMART on rank_train labels and retrieval-based hard weak negatives."""
    import lightgbm as lgb
    rng = np.random.default_rng(seed)
    x, y, group, available = [], [], [], 0
    for row in rank_events.itertuples(index=False):
        uid, mid = int(row.userId), int(row.movieId)
        if uid not in base.user_to_idx or mid not in base.movie_to_idx:
            continue
        index = base.movie_to_idx[mid]
        stage1 = _eligible_candidates(base, adapter.score_user(uid), uid, {}, pool)
        available += int(index in stage1)
        negatives = stage1[stage1 != index]
        if len(negatives) == 0:
            continue
        sample = rng.choice(negatives, size=min(sampled, len(negatives)), replace=False)
        ids = np.concatenate(([index], sample))
        x.append(_feature_matrix(base, adapter, uid)[ids])
        y.extend([1] + [0] * len(sample))
        group.append(len(ids))
    if not x:
        raise RuntimeError("No ranker training groups available")
    ranker = lgb.LGBMRanker(objective="lambdarank", n_estimators=100,
                            learning_rate=0.05, num_leaves=15,
                            min_child_samples=10, random_state=seed,
                            verbosity=-1, n_jobs=2)
    ranker.fit(pd.DataFrame(np.vstack(x), columns=["bpr_score", "svd_score",
                 "popularity", "genre_score", "semantic_score"]),
               np.asarray(y, dtype=np.int32), group=group)
    rate = available / max(len(rank_events), 1)
    return ranker, rate


def evaluate_two_stage(base, adapter, ranker, holdout, exclusions, pool=250, k=10):
    """First retrieve top pool, then score ONLY the candidates with LambdaMART."""
    hits, dcg, n, retrieved = 0, 0., 0, 0
    coverage = set()
    for row in holdout.itertuples(index=False):
        uid, mid = int(row.userId), int(row.movieId)
        if uid not in base.user_to_idx or mid not in base.movie_to_idx:
            continue
        target = base.movie_to_idx[mid]
        if target in base.seen[uid] or mid in exclusions.get(uid, set()):
            raise ValueError("Holdout leaked into training/exclusion data")
        candidates = _eligible_candidates(base, adapter.score_user(uid), uid,
                                           exclusions, pool)
        retrieved += int(target in candidates)
        if not len(candidates):
            continue
        feature = _feature_matrix(base, adapter, uid)[candidates]
        scored = ranker.predict(pd.DataFrame(feature, columns=["bpr_score",
            "svd_score", "popularity", "genre_score", "semantic_score"]))
        top = candidates[np.argsort(-scored, kind="stable")[:k]]
        coverage.update(map(int, top))
        if target in top:
            hits += 1
            rank = int(np.flatnonzero(top == target)[0]) + 1
            dcg += 1.0 / np.log2(rank + 1)
        n += 1
    return {
        "users_evaluated": n,
        "recall_at_k": round(hits / n, 5) if n else None,
        "ndcg_at_k": round(dcg / n, 5) if n else None,
        "catalog_coverage_at_k": round(len(coverage) / len(base.movie_ids), 5),
        "candidate_recall_at_pool": round(retrieved / n, 5) if n else None,
    }


def run(*, data_dir="data", output_dir="artifacts", epochs=12, dim=64,
        umap_neighbors=30, k=None, pool=250, batch_size=2048,
        negatives=2, seed=42):
    output = Path(output_dir)
    existing = output / "metrics.json"
    model_path = output / "recommender.joblib"
    if not model_path.exists() or not existing.exists():
        raise FileNotFoundError("Run `python -m src.train`, then `python -m src.semantic` first")
    base = HybridRecommender.load(model_path)
    if getattr(base, "semantic_item", None) is None:
        raise RuntimeError("Sentence Transformer vectors missing. Run `python -m src.semantic`.")
    metrics = json.loads(existing.read_text(encoding="utf-8"))
    k = int(k or metrics.get("k", 10))
    ratings, movies = ensure_dataset(data_dir)
    splits = chronological_split(ratings)
    from .benchmark_semantic import _check_training_history
    _check_training_history(base, splits.train)
    if metrics.get("counts", {}).get("training_positives") != len(splits.train):
        raise ValueError("metrics.json not aligned with trained model")
    if metrics.get("catalog_size") != len(movies):
        raise ValueError("metrics.json catalogue differs")
    if k != int(metrics.get("k", 10)):
        raise ValueError("Run with the same K as the existing benchmark for fair comparison")

    print("Preparing PCA, UMAP and raw semantic representations …", flush=True)
    features = prepare_features(base.semantic_item, dim=dim,
                                neighbors=umap_neighbors, seed=seed)
    events = np.asarray([(base.user_to_idx[int(u)], base.movie_to_idx[int(m)])
                         for u, m in zip(splits.train.userId, splits.train.movieId)], dtype="int64")
    seen = {base.user_to_idx[u]: indices for u, indices in base.seen.items()}
    valid_exclusion = union_seen(splits.rank_train)
    test_exclusion = union_seen(splits.rank_train, splits.valid)
    comparisons = {}
    valid_metrics, test_metrics = {}, {}

    def validator_for(name):
        return lambda u, i: _fold_score(base, name, u, i, splits.valid,
                                        valid_exclusion, k)

    for name, vectors in features.items():
        print(f"\nTraining {name} …", flush=True)
        users, items = train_bpr(events, seen, len(base.user_ids), len(base.movie_ids),
                                 vectors, latent_dim=dim, epochs=epochs,
                                 negatives_per_positive=negatives, seed=seed,
                                 validation=validator_for(name), batch_size=batch_size)
        comparisons[name] = (users, items)
        adapter = FactorAdapter(base, name, users, items)
        valid_metrics.update(evaluate_models(adapter, splits.valid, valid_exclusion, k=k))
        test_metrics.update(evaluate_models(adapter, splits.test, test_exclusion, k=k))

    print("\nTraining BPR-UMAP retrieval + LambdaMART reranker …", flush=True)
    adapter = FactorAdapter(base, "bpr_umap", *comparisons["bpr_umap"])
    ranker, rank_train_recall = fit_second_stage(base, adapter, splits.rank_train,
                                                  pool=pool, seed=seed)
    valid_metrics["bpr_umap_lambdamart"] = evaluate_two_stage(
        base, adapter, ranker, splits.valid, valid_exclusion, pool=pool, k=k)
    test_metrics["bpr_umap_lambdamart"] = evaluate_two_stage(
        base, adapter, ranker, splits.test, test_exclusion, pool=pool, k=k)

    # Human-inspectable experiment data; the existing recommender.joblib remains intact.
    from joblib import dump
    dump(ranker, output / "bpr_umap_ranker.joblib", compress=3)
    arrays = {"user_ids": base.user_ids, "movie_ids": base.movie_ids}
    for name, (u, i) in comparisons.items():
        arrays[f"{name}_user"] = u
        arrays[f"{name}_item"] = i
    np.savez_compressed(output / "bpr_models.npz", **arrays)

    result = {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "variants": ["svd_reference", *FEATURE_VARIANTS, "bpr_umap_lambdamart"],
        "split": "Same per-user chronological MovieLens partitions as base benchmark",
        "parameters": {"epochs_max": epochs, "dim": dim, "umap_neighbors": umap_neighbors,
                       "negative_samples": negatives, "candidate_pool": pool,
                       "seed": seed, "k": k},
        "ranker_train_candidate_recall": round(rank_train_recall, 5),
        "notes": "Metadata-only transforms include all catalogue item metadata (transductive). "
                 "BPR uses weak sampled unobserved negatives, not verified dislikes. "
                 "Early stopping uses validation only. LambdaMART uses rank_train only. "
                 "No test data were used for model selection. Fixed hyperparameters otherwise.",
        "validation": {"svd": metrics["validation"].get("svd"), **valid_metrics},
        "test": {"svd": metrics["test"].get("svd"), **test_metrics},
    }
    (output / "bpr_semantic_metrics.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8")
    backup = output / "metrics_before_bpr_semantic.json"
    if not backup.exists():
        shutil.copy2(existing, backup)
    # Preserve all prior benchmark rows, including standalone semantic results.
    for split_name, rows in (("validation", valid_metrics), ("test", test_metrics)):
        metrics[split_name].update(rows)
    metrics["bpr_semantic_benchmark_notes"] = result["notes"]
    temp = output / "metrics.json.tmp"
    temp.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    temp.replace(existing)
    print("\nFinal held-out test ranking results:")
    for name, values in test_metrics.items():
        print(f"{name:23s} NDCG@{k}={values['ndcg_at_k']} "
              f"Recall@{k}={values['recall_at_k']}")
    print(f"\nSaved {output / 'bpr_semantic_metrics.json'} and updated {existing}")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", default="data")
    parser.add_argument("--output-dir", default="artifacts")
    parser.add_argument("--epochs", type=int, default=12)
    parser.add_argument("--dim", type=int, default=64)
    parser.add_argument("--umap-neighbors", type=int, default=30)
    parser.add_argument("--k", type=int, default=None)
    parser.add_argument("--pool", type=int, default=250)
    parser.add_argument("--batch-size", type=int, default=2048)
    parser.add_argument("--negatives", type=int, default=2)
    parser.add_argument("--seed", type=int, default=42)
    run(**vars(parser.parse_args()))
