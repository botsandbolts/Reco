"""Optional Streamlit chart for the 2D UMAP semantic movie map."""
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.preprocessing import normalize


def render_embedding_map(engine, map_path="artifacts/umap_movie_map.npz"):
    import plotly.express as px
    import plotly.graph_objects as go
    import streamlit as st

    st.subheader("Semantic movie embeddings · UMAP explorer")
    st.write("Explore a 2D UMAP projection of Sentence Transformer embeddings "
             "derived from movie **titles and genres**. Select or click a movie "
             "to inspect its closest neighbors in the **original embedding space**.")
    path = Path(map_path)
    if not path.is_file():
        st.info("The UMAP map hasn't been built yet. In the Codespaces terminal, run:")
        st.code("python -m pip install -r requirements-experiments.txt\n"
                "python -m src.build_umap_map", language="bash")
        return
    if engine.semantic_item is None:
        st.warning("No embeddings in the model. Run python -m src.semantic first.")
        return

    with np.load(path, allow_pickle=False) as data:
        movie_ids = np.asarray(data["movie_ids"])
        xy = np.asarray(data["xy"])
    if len(movie_ids) != len(engine.movie_ids) or not np.array_equal(movie_ids, engine.movie_ids):
        st.error("UMAP map and recommender have different movie IDs. Rebuild the map.")
        return
    if xy.shape != (len(movie_ids), 2) or not np.isfinite(xy).all():
        st.error("Invalid UMAP map artifact. Rebuild the map.")
        return

    titles = engine.movies.title.astype(str).tolist()
    select_idx = st.selectbox("Focus movie", range(len(movie_ids)),
                              format_func=lambda n: titles[n], index=0,
                              key="umap_focused_movie")
    plotted = st.slider("Movies shown on the map", min_value=300,
                        max_value=min(3500, len(movie_ids)), value=min(1500, len(movie_ids)),
                        step=100, key="umap_sample_size")
    rng = np.random.default_rng(42)
    sample = rng.choice(len(movie_ids), size=min(plotted, len(movie_ids)), replace=False)
    if select_idx not in sample:
        sample[0] = select_idx
    sample = np.sort(sample)
    items = engine.movies.iloc[sample]
    chart = pd.DataFrame({
        "x": xy[sample, 0], "y": xy[sample, 1],
        "title": items.title.astype(str).to_numpy(),
        "movieId": items.movieId.to_numpy(),
        "genre": items.genres.fillna("unknown").str.split("|").str[0].to_numpy()
    })
    fig = px.scatter(chart, x="x", y="y", color="genre", hover_name="title",
                     custom_data=["movieId"], opacity=0.7,
                     title="UMAP projection of semantic movie embeddings",
                     render_mode="webgl")
    fig.add_trace(go.Scatter(
        x=[xy[select_idx, 0]], y=[xy[select_idx, 1]],
        mode="markers", name="Selected movie", showlegend=True,
        marker=dict(symbol="star", color="red", size=18,
                    line=dict(width=1.5, color="white")),
        hovertext=[titles[select_idx]], hoverinfo="text"))
    fig.update_layout(height=570, legend_title_text="Primary genre",
                      xaxis_title="UMAP component 1", yaxis_title="UMAP component 2")
    try:
        selection = st.plotly_chart(fig, use_container_width=True,
                                    on_select="rerun", selection_mode="points",
                                    key="umap_movie_chart")
        if selection and selection.selection.points:
            clicked = selection.selection.points[0].get("customdata", [])
            if clicked:
                clicked_id = int(clicked[0])
                if clicked_id in engine.movie_to_idx:
                    select_idx = engine.movie_to_idx[clicked_id]
                    st.caption(f"Clicked movie: {titles[select_idx]}")
    except TypeError:
        # Older Streamlit versions lack native Plotly selection callbacks.
        st.plotly_chart(fig, use_container_width=True)

    semantic = normalize(np.asarray(engine.semantic_item, dtype="float32"), axis=1)
    scores = semantic @ semantic[select_idx]
    scores[select_idx] = -np.inf
    neighbor_ids = np.argsort(-scores, kind="stable")[:10]
    table = engine.movies.iloc[neighbor_ids][["title", "genres"]].copy()
    table["cosine_similarity"] = np.round(scores[neighbor_ids], 4)
    st.write(f"**Closest movies to {titles[select_idx]} (original 384D cosine similarity)**")
    st.dataframe(table, hide_index=True, use_container_width=True)
    st.caption("UMAP neighborhoods are an exploratory 2D picture, not calibrated "
               "semantic distances or proof of recommendation relevance. "
               "For meaningful plot understanding, consider richer synopsis metadata.")
