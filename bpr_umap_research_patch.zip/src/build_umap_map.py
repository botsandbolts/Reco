"""Build 2D semantic movie map for the interactive Streamlit tab.

python -m src.build_umap_map
Separate from the 64-dimensional UMAP representation used in BPR training.
"""
import argparse
from pathlib import Path
import numpy as np
from sklearn.preprocessing import normalize
from .recommender import HybridRecommender


def build_map(model_path="artifacts/recommender.joblib",
              output="artifacts/umap_movie_map.npz", neighbors=30, seed=42):
    try:
        import umap
    except ImportError as exc:
        raise RuntimeError("Install first: pip install -r requirements-experiments.txt") from exc
    rec = HybridRecommender.load(model_path)
    if rec.semantic_item is None:
        raise RuntimeError("Generate embeddings first: python -m src.semantic")
    embeddings = normalize(np.asarray(rec.semantic_item, dtype="float32"), axis=1)
    reducer = umap.UMAP(n_components=2, metric="cosine", min_dist=0.12,
                        n_neighbors=min(neighbors, len(embeddings) - 1),
                        random_state=seed, n_jobs=1)
    coords = np.asarray(reducer.fit_transform(embeddings), dtype="float32")
    if not np.isfinite(coords).all():
        raise ValueError("Nonfinite UMAP coordinates")
    Path(output).parent.mkdir(exist_ok=True, parents=True)
    np.savez_compressed(output, movie_ids=rec.movie_ids, xy=coords)
    print(f"Saved 2D semantic map of {len(coords):,} movies to {output}")
    print("Map geometry illustrates proximity; compare real 384D cosines for actual neighbors.")
    return coords


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-path", default="artifacts/recommender.joblib")
    parser.add_argument("--output", default="artifacts/umap_movie_map.npz")
    parser.add_argument("--neighbors", type=int, default=30)
    parser.add_argument("--seed", type=int, default=42)
    build_map(**vars(parser.parse_args()))
