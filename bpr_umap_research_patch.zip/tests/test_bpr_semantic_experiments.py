"""Synthetic, fast tests; no external model or MovieLens download required."""
import numpy as np
import pandas as pd
import pytest

from src.recommender import HybridRecommender
from src.data import chronological_split
from src.evaluation import evaluate_models, union_seen
from src.bpr_semantic_experiments import (
    train_bpr, FactorAdapter, triples_for_epoch, fit_second_stage,
    evaluate_two_stage, prepare_features,
)


def _dataset():
    movies = pd.DataFrame({
        "movieId": range(1, 21),
        "title": [f"Movie {i}" for i in range(1, 21)],
        "genres": (["Drama", "Comedy", "Action", "Mystery"] * 5),
    })
    rng = np.random.default_rng(12)
    events = []
    for uid in range(1, 9):
        # Each user has six observed positives, yielding rank/valid/test.
        for idx, movie_id in enumerate(rng.choice(range(1, 21), size=7, replace=False)):
            events.append((uid, int(movie_id), 5., uid * 100 + idx))
    ratings = pd.DataFrame(events, columns=["userId", "movieId", "rating", "timestamp"])
    splits = chronological_split(ratings)
    base = HybridRecommender().fit(splits.train, movies, rank=4)
    return base, splits


def test_bpr_mf_training_and_full_catalogue_metrics():
    base, splits = _dataset()
    pairs = np.asarray([(base.user_to_idx[int(u)], base.movie_to_idx[int(mid)])
                        for u, mid in zip(splits.train.userId, splits.train.movieId)])
    seen = {base.user_to_idx[u]: idx for u, idx in base.seen.items()}
    triples = triples_for_epoch(pairs, seen, len(base.movie_ids), np.random.default_rng(0))
    assert len(triples) == len(pairs) * 2
    assert all(int(j) not in seen[int(u)] for u, _, j in triples)
    users, items = train_bpr(pairs, seen, len(base.user_ids), len(base.movie_ids),
                             latent_dim=8, epochs=2, batch_size=8)
    assert users.shape == (len(base.user_ids), 8)
    assert items.shape == (len(base.movie_ids), 8)
    adapter = FactorAdapter(base, "bpr_mf", users, items)
    assert np.isfinite(adapter.score_user(1)).all()
    metrics = evaluate_models(adapter, splits.valid, union_seen(splits.rank_train), k=3)
    assert 0 <= metrics["bpr_mf"]["ndcg_at_k"] <= 1


def test_semantic_fusion_training_and_candidate_ranker():
    base, splits = _dataset()
    rng = np.random.default_rng(3)
    base.semantic_item = rng.normal(size=(len(base.movie_ids), 16)).astype("float32")
    pairs = np.asarray([(base.user_to_idx[int(u)], base.movie_to_idx[int(mid)])
                        for u, mid in zip(splits.train.userId, splits.train.movieId)])
    seen = {base.user_to_idx[u]: idx for u, idx in base.seen.items()}
    semantic = base.semantic_item / np.linalg.norm(base.semantic_item, axis=1, keepdims=True)
    users, items = train_bpr(pairs, seen, len(base.user_ids), len(base.movie_ids),
                             semantic, latent_dim=8, epochs=2, batch_size=8,
                             validation=lambda u, i: 0.1, eval_every=1)
    adapter = FactorAdapter(base, "bpr_umap", users, items)
    ranker, rate = fit_second_stage(base, adapter, splits.rank_train, pool=12, sampled=5)
    assert 0 <= rate <= 1
    test = evaluate_two_stage(base, adapter, ranker, splits.test,
                              union_seen(splits.rank_train, splits.valid),
                              pool=12, k=3)
    assert test["users_evaluated"] == len(splits.test)
    assert 0 <= test["candidate_recall_at_pool"] <= 1
    assert 0 <= test["ndcg_at_k"] <= 1


def test_preprocessors_shapes():
    pytest.importorskip("umap")
    rng = np.random.default_rng(2)
    vectors = rng.normal(size=(33, 16)).astype("float32")
    result = prepare_features(vectors, dim=5, neighbors=4)
    assert set(result) == {"bpr_mf", "bpr_pca", "bpr_umap", "bpr_raw"}
    assert result["bpr_mf"] is None
    assert result["bpr_pca"].shape == result["bpr_umap"].shape == (33, 5)
    assert result["bpr_raw"].shape == (33, 16)
    assert all(np.isfinite(v).all() for v in result.values() if v is not None)
