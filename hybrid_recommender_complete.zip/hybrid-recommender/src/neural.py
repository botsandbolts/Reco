"""Optional PyTorch two-tower recommendation model with sampled negatives.

Unlike a mere user x item factorization, the item tower also takes multi-hot
movie genres; the model learns the joint representation from positives.
"""
import numpy as np


def train_two_tower(interactions, genres, n_users, n_items, epochs=4, dim=32, seed=42):
    try:
        import torch
        from torch import nn
        from torch.utils.data import DataLoader, TensorDataset
    except ImportError as exc:
        raise RuntimeError("Install neural dependencies: pip install -r requirements-neural.txt") from exc
    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)
    torch.set_num_threads(min(4, torch.get_num_threads()))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    class TwoTower(nn.Module):
        def __init__(self):
            super().__init__()
            self.user_embedding = nn.Embedding(n_users, dim)
            self.item_embedding = nn.Embedding(n_items, dim)
            self.genre_projection = nn.Linear(genres.shape[1], dim, bias=False)
            nn.init.normal_(self.user_embedding.weight, std=0.08)
            nn.init.normal_(self.item_embedding.weight, std=0.08)

        def forward(self, user, item, genre_input):
            u = nn.functional.normalize(self.user_embedding(user), dim=1)
            v = self.item_embedding(item) + self.genre_projection(genre_input)
            v = nn.functional.normalize(v, dim=1)
            return (u * v).sum(dim=1) * 8.0

    # Interactions are indexed integer user/item pairs. Draw items not in each
    # user's TRAINING history (unobserved != verified negative).
    user_seen = {}
    for u, i in interactions:
        user_seen.setdefault(int(u), set()).add(int(i))
    positive = np.asarray(interactions, dtype=np.int64)
    if len(positive) == 0:
        raise ValueError("No positive training interactions")
    negative = np.empty_like(positive)
    for j, (u, _) in enumerate(positive):
        if len(user_seen[int(u)]) >= n_items:
            raise ValueError("Cannot sample negative: user has rated every item")
        candidate = int(rng.integers(0, n_items))
        while candidate in user_seen[int(u)]:
            candidate = int(rng.integers(0, n_items))
        negative[j] = [u, candidate]
    pairs = np.vstack([positive, negative])
    labels = np.concatenate([np.ones(len(positive)), np.zeros(len(negative))]).astype(np.float32)
    dataset = TensorDataset(torch.from_numpy(pairs), torch.from_numpy(labels))
    loader = DataLoader(dataset, batch_size=2048, shuffle=True)
    model = TwoTower().to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.003, weight_decay=1e-4)
    genres_t = torch.from_numpy(genres.astype("float32")).to(device)

    for epoch in range(epochs):
        model.train()
        total = 0.0
        for pair, y in loader:
            pair, y = pair.to(device), y.to(device)
            logits = model(pair[:, 0], pair[:, 1], genres_t[pair[:, 1]])
            loss = nn.functional.binary_cross_entropy_with_logits(logits, y)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total += float(loss.detach().cpu()) * len(y)
        print(f"Two-tower epoch {epoch+1}/{epochs} loss={total / len(dataset):.4f} device={device}")
    model.eval()
    with torch.no_grad():
        users = nn.functional.normalize(model.user_embedding.weight, dim=1).cpu().numpy()
        items = model.item_embedding.weight + model.genre_projection(genres_t)
        items = nn.functional.normalize(items, dim=1).cpu().numpy()
    return users.astype("float32"), items.astype("float32")
