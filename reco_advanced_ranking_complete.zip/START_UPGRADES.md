# Reco — advanced retrieval and LambdaMART research upgrade

The patch series is built for the installed **Temporal FM/DeepFM** Codespaces project, not the old MovieLens Small-only repo clone. No dataset, pretrained model or measured 32M score is included. Your checkpoint `fm_all_bpr` remains the control and is never overwritten by the new modules.

## Order of operations

1. **Stage 1:** extract `reco_step1_retrieval_diagnostics.zip`, run candidate-recall report for FM/popularity. No retraining.
2. **Stage 2:** extract `reco_step2_semi_hard_fm.zip`, run `python scripts/install_semi_hard.py` (safe backup + idempotent edit) and train separately labeled FM experiments. This is OPTIONAL for stage 3/4.
3. **Stage 3:** extract `reco_step3_multisource_retrieval.zip`, compare candidate recall after adding SVD/BPR, semantics, popularity (no FM retraining).
4. **Stage 4:** extract `reco_step4_lambdamart.zip`, install `requirements-advanced-ltr.txt`, fit separate LightGBM LambdaMART with train/early-stop/report users distinct, view dashboard.

**Alternative:** extract `reco_advanced_ranking_complete.zip` once, install the semi-hard hook, and run the stage commands in order. Stage 1+3 need a previously processed MovieLens 32M dataset, trained FM-BPR checkpoint, `temporal_fm.ranking` pairwise checkpoint loader, `temporal_fm.lambdamart` and shared chronological benchmark from earlier patches. If missing, use the *existing* earlier patch install guides; this ZIP does not recreate those dependencies.

## Short command sequence

```bash
cd /workspaces/Reco
# After uploading the all-in-one ZIP to GitHub main:
git fetch origin main
git show origin/main:reco_advanced_ranking_complete.zip > reco_advanced_ranking_complete.zip
unzip -o reco_advanced_ranking_complete.zip
python -m pip install -r requirements-advanced-ltr.txt
python scripts/install_semi_hard.py
python -m pytest -q tests/test_advanced_retrieval_stage1.py tests/test_semi_hard_install.py tests/test_multisource.py tests/test_advanced_retrieval.py
```

Stage 1:
```bash
python -m temporal_fm.advanced_retrieval --dataset ml-32m --backend sentence --base-model fm_all_bpr --sources fm,pop --users 300 --run-label fmpop
```
Stage 2 (controlled training): see `STEP2_SEMI_HARD_FM.md`.
Stage 3:
```bash
python -m temporal_fm.multisource --dataset ml-32m --backend sentence --base-model fm_all_bpr --users 300
```
Stage 4:
```bash
python -m temporal_fm.advanced_ltr --dataset ml-32m --backend sentence --base-model fm_all_bpr --ranker-train-users 700 --ranker-valid-users 200 --eval-users 300 --run-label lmart_v1 --device cpu --threads 2
```
Read each `STEP*.md` for recommended knobs, evaluation caveats and precise paths. This job is CPU-intensive on 32M; the code runs in your Codespace, **not** this ChatGPT runtime. If RAM is insufficient, smoke-test `ml-1m` using `--backend hash` with compatible checkpoint first.

## Model comparison policy

Never compare historical NDCG values from different train/test partitions or candidate sets. Stage 4 outputs an internally matched report (FM, SVD, BPR, popularity, semantic retrieval, LambdaMART). Its early-stopping score is conditional on retrievable positives, not final full-catalogue NDCG. The test split is for the **single final selected model**, never hyperparameter tuning.
