# Step 1 — Diagnose FM retrieval before reranking

**Prerequisites:** Your existing Temporal FM, FM-BPR ranking, chronological evaluation and initial LambdaMART patches are installed in Codespaces. You have a trained `models/ml-32m/temporal_fm/fm_all_bpr/weights.pt` checkpoint and processed MovieLens 32M files. This patch does not replace or retrain the model.

## Install

From `/workspaces/Reco`, extract this ZIP, then test:

```bash
python -m pytest -q tests/test_advanced_retrieval_stage1.py
```

## Run

```bash
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 python -u -m temporal_fm.advanced_retrieval \
  --dataset ml-32m --backend sentence --base-model fm_all_bpr \
  --sources fm,pop --users 300 --k 10 \
  --fm-candidates 500 --pop-candidates 100 \
  --run-label fmpop --device cpu --threads 2
```

Outputs:
- `reports/temporal/ml-32m/advanced_retrieval_fmpop.json`
- `reports/temporal/ml-32m/advanced_retrieval_fmpop.csv`

The report includes **full source Recall@10/100/500/1000** (scoring each source's top 1000 independently), and *union candidate recall* for the actual, smaller candidate pool. These numbers are not identical and should not be confused. Validated using MovieLens's global train cutoff and sampled users from the later validation period; no label injection. No model weights are changed.

For experiments, keep `--users`, `--seed`, `--k`, checkpoint provenance and cutoff identical across runs. Full-catalogue FM scoring on 32M is CPU intensive.
