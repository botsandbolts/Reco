# Step 2 — Train an FM-BPR model with semi-hard negatives

**Prerequisite:** Your existing strong/rating-aware/regularized FM trainer must be installed (`temporal_fm/rank_train.py`). This patch adds an optional negative sampler and an idempotent installer; it does **not** overwrite `rank_train.py` on extraction. Backups are made before patching it.

## Install

```bash
python scripts/install_semi_hard.py
python -m pytest -q tests/test_semi_hard_install.py tests/test_semi_hard_training_smoke.py
python -m temporal_fm.rank_train --help | grep hard
```

## Controlled experiment A: unchanged FM-BPR continuation (control)

```bash
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 python -u -m temporal_fm.rank_train \
  --dataset ml-32m --text-backend sentence --models fm --ablation all \
  --objective bpr --profile research --init-from fm_all_bpr \
  --run-label control_extension --epochs 10 --min-epochs 6 \
  --steps-per-epoch 800 --batch-size 256 --lr 0.00015 \
  --negatives 2 --weight-decay 0.05 --l2-factors 0.005 \
  --hard-negative-share 0 --validation-mode full --validation-users 300 \
  --validate-every 2 --device cpu --threads 2
```

## Controlled experiment B: same training + semi-hard negatives

Change only `--run-label semi25` and `--hard-negative-share 0.25 --hard-pool 8`; otherwise use the command above exactly. This saves `fm_all_semi25_bpr` without touching `fm_all_bpr`.

**Why semi-hard?** For about 25% of *negative slots*, the trainer draws a small pool of valid training-unrated movies, scores them at the **positive event timestamp** with the current FM, and chooses the second-highest-scoring. This deliberately avoids always using the absolute hardest (often a false negative). The sampler never uses validation/test labels.

**Resource warning:** The hard sampler adds extra forward passes and can increase CPU time substantially. On Codespaces start with `--hard-negative-share 0.15 --hard-pool 5` if performance suffers.

## Compare fairly

```bash
python -m temporal_fm.ranking --dataset ml-32m --backend sentence \
 --models fm_all_bpr,fm_all_control_extension_bpr,fm_all_semi25_bpr \
 --users 300 --k 10 --max-candidates 0 --device cpu
```

Prefer a paired comparison with matched candidate catalogues, user cohorts and temporal cutoffs; reserve final test interactions until configuration selection is over.
