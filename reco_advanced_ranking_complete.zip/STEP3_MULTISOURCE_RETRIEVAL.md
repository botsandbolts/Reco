# Step 3 — Add multiple independent candidate generators

Run after installing step 1. Step 3 supplies a convenient all-sources CLI. It uses your **existing** FM-BPR, plus chronological SVD/BPR baselines, frozen historical popularity and user-title semantic similarity. It never adds known future positives to the candidate list. Source overlaps are deduplicated.

```bash
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 python -u -m temporal_fm.multisource \
  --dataset ml-32m --backend sentence --base-model fm_all_bpr \
  --users 300 --k 10 --baseline-profile quick \
  --fm-candidates 500 --svd-candidates 150 --bpr-candidates 150 \
  --pop-candidates 100 --semantic-candidates 100 \
  --device cpu --threads 2
```

The first run may **train chronological SVD/BPR from training-period interactions**; later runs reuse checkpointed matching factors. These do not reuse incompatible earlier experiments.

Outputs `reports/temporal/ml-32m/advanced_retrieval_multisource.json/.csv`.

Compare its `union_candidate_recall` to the FM+pop diagnostic from Step 1. **Higher candidate recall may improve the reranking upper bound, but it does not guarantee NDCG gains.** If SVD baseline training runs out of memory on 32M, use a larger Codespace, restrict the experiment to a smaller dataset, or separate its preprocessing; this patch does not pretend to solve memory bottlenecks.
