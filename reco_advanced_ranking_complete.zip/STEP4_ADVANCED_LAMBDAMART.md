# Step 4 — Train multi-source LambdaMART with real early stopping

**Install stages 1 and 3 first**, including their `temporal_fm/advanced_retrieval.py`. Stage 4 does not overwrite your current `temporal_fm/lambdamart.py` or existing FM checkpoints. Its results are saved separately under `advanced_ltr_*`.

```bash
python -m pip install -r requirements-advanced-ltr.txt
python -m pytest -q tests/test_advanced_retrieval.py tests/test_advanced_ltr_smoke.py
```

## Initial research experiment (validation only)

```bash
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 python -u -m temporal_fm.advanced_ltr \
  --dataset ml-32m --backend sentence --base-model fm_all_bpr \
  --ranker-train-users 700 --ranker-valid-users 200 --eval-users 300 \
  --baseline-profile quick \
  --fm-candidates 500 --svd-candidates 150 --bpr-candidates 150 \
  --pop-candidates 100 --semantic-candidates 100 \
  --trees 600 --leaves 15 --learning-rate 0.03 \
  --min-child-samples 60 --reg-lambda 3.0 \
  --early-stop-rounds 40 --objective lambdarank \
  --k 10 --run-label lmart_v1 --device cpu --threads 2
```

Outputs a model checkpoint at `models/ml-32m/temporal_fm/advanced_ltr/lmart_v1_<hash>/model.txt`, and report at `reports/temporal/ml-32m/advanced_ltr_validation_lmart_v1_<hash>.json` (and `.csv`).

## Optional controlled objective comparison

Rerun with the **same user counts, seed, source quotas, base FM and cutoff**, changing only:

```bash
--objective rank_xendcg --run-label xendcg_v1
```

The patch trains on separate ranker-training users, selects the number of trees from *different* validation users, and reports quality on a **third** disjoint cohort. This is more honest than choosing the best number of trees using the reported evaluation cohort. All ranking sources are evaluated on the same user/candidate pool. A candidate retrieval comparison and paired bootstrap delta versus FM are included.

LightGBM's **early-stopping NDCG is conditional on groups containing retrieved positives**. It is not the same as full-catalogue or unconditional evaluation NDCG; do not report it as the final number. Unrated items remain unknown preferences, not verified negatives.

## Graphs (independent of older app integrations)

```bash
streamlit run temporal_fm/advanced_dashboard.py \
  --server.address 0.0.0.0 --server.port 8501
```

This displays Stage 1/3 retrieval recall, and Stage 4 LambdaMART versus FM, SVD, BPR and popularity, with per-user examples, feature importance and uncertainty. If old Streamlit is on port 8501, use 8502 instead.

## Final test (only AFTER selecting configuration)

Use the selected objective and hyperparameters, change `--eval-split test`, and use a new `--run-label finaltest`. Do **not** tune again on test results. Original FM may itself have been selected using validation, so the final test is the strongest available offline check.

## Interpretation

- If candidate Recall@1000 is low, improve retrieval before reranker complexity.
- If candidate recall is high but LambdaMART NDCG@10 trails FM, inspect labels, candidate-set shift, feature importance, calibration and generalization.
- A larger LightGBM does not guarantee improvement; `rank_xendcg` is a hypothesis, not a certain winner.
