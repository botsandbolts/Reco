"""Idempotent installation: surgical update to existing temporal_fm/rank_train.py.

Makes a timestamped backup before editing. Never changes saved FM checkpoints.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import re
import shutil
from datetime import datetime,timezone

MARKER='# SEMI_HARD_NEGATIVES_V1'


def install(path='temporal_fm/rank_train.py'):
    file=Path(path)
    if not file.exists():raise FileNotFoundError(f'Missing {file}; install the FM-BPR patch first')
    src=file.read_text()
    if MARKER in src:return False
    m=re.search(r'(def train\([\s\S]*?)(\):\n    if profile not in RANK_PROFILES)',src)
    if not m:raise ValueError('Trainer signature changed; no files altered')
    signature=m.group(0)
    modified=signature.replace('):\n    if profile',
      ',hard_negative_share=0.,hard_pool=12):\n    if profile')
    new=src.replace(signature,modified,1)
    arg_anchor="    p.add_argument('--negatives',type=int,default=2)"
    if arg_anchor not in new:raise ValueError('Expected negative CLI argument not found; no files altered')
    new=new.replace(arg_anchor,
       "    p.add_argument('--hard-negative-share',type=float,default=0.)\n"
       "    p.add_argument('--hard-pool',type=int,default=12)\n"+arg_anchor,1)
    validation_anchor="    if negatives<1 or not(0<=pop_negative_share<=1):raise ValueError('Bad negative sampling arguments')"
    if validation_anchor not in new:raise ValueError('Unknown negative validation block')
    new=new.replace(validation_anchor,validation_anchor+"\n    if not 0<=hard_negative_share<=1 or hard_pool<2:\n        raise ValueError('Hard-negative sampling requires share [0,1] and pool >=2')",1)
    anchor="neg_ts,pop_negative_share)\n                positive="
    if anchor not in new:raise ValueError('Negative draw call changed; no files altered')
    hook=("neg_ts,pop_negative_share)\n"
          f"                {MARKER}\n"
          "                if hard_negative_share > 0:\n"
          "                    from .hard_negatives import mine_semi_hard\n"
          "                    neg_movies=mine_semi_hard(model,ev,provider,generator,neg_movies,\n"
          "                          neg_ui,neg_ts,known,catalog,bank,pop_negative_share,\n"
          "                          hard_negative_share,hard_pool,device)\n"
          "                positive=")
    new=new.replace(anchor,hook,1)
    meta_anchor="           'negatives':negatives,'pop_negative_share':pop_negative_share,"
    if meta_anchor not in new:raise ValueError('Checkpoint metadata anchor changed')
    new=new.replace(meta_anchor,meta_anchor+"\n           'hard_negative_share':hard_negative_share,'hard_pool':hard_pool,",1)
    if new==src:raise RuntimeError('No modifications made')
    backup=file.with_name(file.stem+'.before_semi_hard_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+file.suffix)
    shutil.copy2(file,backup)
    file.write_text(new)
    print('Semi-hard negatives enabled. Backup:',backup)
    return True


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--file',default='temporal_fm/rank_train.py')
    install(p.parse_args().file)
