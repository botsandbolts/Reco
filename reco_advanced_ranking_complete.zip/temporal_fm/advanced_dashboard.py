"""Independent, read-only Streamlit dashboard for advanced 32M research reports.

Launch: streamlit run temporal_fm/advanced_dashboard.py --server.port 8501
No heavyweight model imports, no training inside Streamlit.
"""
from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
import streamlit as st


def render():
    st.title('MovieLens · Advanced Retrieval & LambdaMART')
    st.caption('Report-backed evaluation. No synthesized metrics, no online training.')
    root=Path('reports/temporal')
    datasets=sorted([p for p in root.iterdir() if p.is_dir()]) if root.exists() else []
    if not datasets:
        st.info('No advanced reports yet. Run the stage 1 diagnostics or stage 4 LambdaMART CLI.')
        return
    dataset=st.selectbox('Dataset', [p.name for p in datasets],index=len(datasets)-1)
    directory=root/dataset
    files=sorted(directory.glob('advanced_ltr_*.json'),key=lambda p:p.stat().st_mtime,reverse=True)
    retrieval=sorted(directory.glob('advanced_retrieval_*.json'),key=lambda p:p.stat().st_mtime,reverse=True)
    a,b=st.tabs(['LambdaMART comparison','Candidate-retrieval diagnostics'])
    with a:
        if not files:st.info('Run python -m temporal_fm.advanced_ltr first.')
        else:
            chosen=st.selectbox('Ranking report',files,format_func=lambda p:p.name)
            r=json.loads(chosen.read_text())
            st.caption(f"Split: {r['split']} · Users: {r['eval_users']} · Cutoff (Unix): {r['cutoff']} · K={r['k']}")
            st.metric('Retrieved relevant fraction',f"{r['candidate_recall']:.2%}")
            table=pd.DataFrame(r['metrics']).T
            st.dataframe(table,use_container_width=True)
            for metric in ('ndcg_at_k','recall_at_k','hit_rate_at_k','mrr_at_k','catalog_coverage_at_k'):
                if metric in table:
                    st.subheader(metric.replace('_',' ').upper());st.bar_chart(table[metric])
            st.subheader('LambdaMART feature importance (gain)')
            imp=pd.Series(r.get('feature_importance_gain',{})).sort_values(ascending=False)
            st.bar_chart(imp.head(18))
            paired=r.get('delta_vs_fm',{})
            st.write('Paired NDCG vs original FM:',paired)
            st.subheader('Examples of reranked movies')
            st.json(r.get('examples',{}))
            with st.expander('Evaluation caveats'):st.write(r.get('caveats',[]))
    with b:
        if not retrieval:st.info('Run python -m temporal_fm.advanced_retrieval first.')
        else:
            selected=st.selectbox('Retrieval report',retrieval,format_func=lambda p:p.name)
            r=json.loads(selected.read_text())
            st.metric('Union candidate recall',f"{r['summary']['union_candidate_recall']:.2%}")
            summary=pd.Series(r['summary'])
            recalls=summary[[key for key in summary.index if 'recall_at_' in key]].sort_values()
            st.bar_chart(recalls)
            st.dataframe(pd.DataFrame(r['per_user']).head(100),use_container_width=True)
            st.caption('Recall is against future held-out rated positives; no positives injected into candidate sets.')


if __name__=='__main__':
    st.set_page_config(page_title='Reco · Advanced Ranking',page_icon='🎬',layout='wide')
    render()
