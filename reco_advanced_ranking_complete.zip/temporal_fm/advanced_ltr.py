"""Multi-source retrieval followed by LightGBM LambdaMART or XE-NDCG.

A three-way *user-disjoint* split within the validation period is used:
ranker train users, early-stopping users, and final validation users. Test
holds out later interactions; do not run it while tuning configurations.

This module never adds held-out items to retrieved candidate lists.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
from pathlib import Path
import numpy as np
import torch
from .data import Events
from .ranking import _cohort, _ranking_scores
from .advanced_retrieval import (AdvancedRetriever,DEFAULT_QUOTAS,SOURCES,
     EXTRA_FEATURES,_retrieval_metrics,_best)
from .lambdamart import FEATURE_NAMES as BASE_FEATURE_NAMES, _prepare, _aggregate, _paired_bootstrap
from .ranking import _model

FEATURE_NAMES=BASE_FEATURE_NAMES+EXTRA_FEATURES


def _split_users(users,n_train,n_valid,n_eval,seed):
    ids=np.asarray(users,dtype=np.int32).copy()
    np.random.default_rng(seed+4102).shuffle(ids)
    if len(ids)<n_train+n_valid+n_eval:
        raise ValueError(f'Only {len(ids)} eligible users; require {n_train+n_valid+n_eval} '
                         'for disjoint train/early-stop/evaluation cohorts. Lower counts.')
    tr=ids[:n_train].tolist();va=ids[n_train:n_train+n_valid].tolist()
    te=ids[n_train+n_valid:n_train+n_valid+n_eval].tolist()
    return tr,va,te


def _ranker_matrix(retriever,ids,histories,truth,quotas,*,verbose=True):
    blocks=[];labels=[];groups=[];retrieved=[];all_rows=[]
    for j,u in enumerate(ids,1):
        row=retriever.query(u,histories[u],truth[u],quotas)
        if row is None:continue
        all_rows.append(row)
        retrieved.append(row['candidate_recall'])
        y=row['labels']
        if y.sum()==0 or y.sum()==len(y):continue
        blocks.append(row['features']);labels.append(y);groups.append(len(y))
        if verbose and j%50==0:print(f'  queries {j}/{len(ids)} informative={len(groups)}',flush=True)
    if not groups:raise ValueError('No informative ranker groups: increase retrieval quotas/users')
    return np.concatenate(blocks),np.concatenate(labels),groups,all_rows,retrieved


def run(dataset='ml-32m',data_dir='data',backend='sentence',base_model='fm_all_bpr',
        ranker_train_users=700,ranker_valid_users=200,eval_users=300,
        fm_candidates=500,svd_candidates=150,bpr_candidates=150,pop_candidates=100,
        semantic_candidates=100,baseline_profile='quick',threshold=4.,k=10,
        min_history=5,seed=42,eval_split='validation',device='cpu',threads=2,
        batch_size=2048,trees=600,leaves=15,learning_rate=.03,min_child_samples=60,
        reg_lambda=3.,colsample_bytree=.8,early_stop_rounds=40,
        objective='lambdarank',run_label='multisource',force_retrain=False):
    try:import lightgbm as lgb
    except ImportError as exc:raise ImportError('Install LightGBM from requirements-lambdamart.txt') from exc
    if eval_split not in ('validation','test'):raise ValueError('Bad evaluation split')
    if objective not in ('lambdarank','rank_xendcg'):raise ValueError('Unsupported objective')
    if min(ranker_train_users,ranker_valid_users,eval_users,k,trees,early_stop_rounds,leaves)<1:
        raise ValueError('User, K, training and early-stop parameters must be positive')
    quotas={'fm':fm_candidates,'svd':svd_candidates,'bpr':bpr_candidates,
            'pop':pop_candidates,'semantic':semantic_candidates}
    if min(quotas.values())<k:raise ValueError('Every source quota must be >= K to compare base ranking')
    if not run_label.replace('_','').replace('-','').isalnum():raise ValueError('Unsafe run label')
    torch.set_num_threads(max(1,threads))
    ev=Events(Path(data_dir)/'temporal'/dataset)
    if eval_split=='validation':
        ids,histories,truths,pop,cohort=_cohort(ev,'validation',threshold,
                    ranker_train_users+ranker_valid_users+eval_users,min_history,seed)
        tr,va,te=_split_users(ids,ranker_train_users,ranker_valid_users,eval_users,seed)
        train_h=valid_h=eval_h=histories;train_y=valid_y=eval_y=truths
    else:
        ids,histories,truths,pop,cohort=_cohort(ev,'validation',threshold,
                      ranker_train_users+ranker_valid_users,min_history,seed)
        tr,va,_=_split_users(ids,ranker_train_users,ranker_valid_users,0,seed)
        te,eval_h,eval_y,_,test_cohort=_cohort(ev,'test',threshold,eval_users,min_history,seed+99)
        cohort={'validation':cohort,'test':test_cohort}
        train_h=valid_h=histories;train_y=valid_y=truths
        print('WARNING: TEST MODE is for one final, frozen-configuration assessment.',flush=True)
    all_users=list(dict.fromkeys(tr+va+te))
    all_hist={**train_h,**valid_h,**eval_h}
    provider=_prepare(ev,backend)
    fm=_model(ev,provider,base_model,backend,device,seed=seed)
    retriever=AdvancedRetriever(ev,provider,fm,all_hist,all_users,pop,
                   sources=SOURCES,baseline_profile=baseline_profile,seed=seed,
                   threads=threads,threshold=threshold,device=device,batch_size=batch_size)
    print('Building ranker TRAIN groups...',flush=True)
    X,y,groups,train_rows,train_rec=_ranker_matrix(retriever,tr,train_h,train_y,quotas)
    print('Building EARLY-STOP groups...',flush=True)
    Xv,yv,gv,valid_rows,valid_rec=_ranker_matrix(retriever,va,valid_h,valid_y,quotas)
    print('Informative train/early-stop groups:',len(groups),len(gv),flush=True)
    params={'dataset':dataset,'sources':ev.meta['sources'],'cutoff':ev.meta['train_cutoff'],
            'base_model':base_model,'backend':backend,'baseline_profile':baseline_profile,
            'quotas':quotas,'seed':seed,'k':k,'threshold':threshold,'eval_split':eval_split,
            'ranker_train_users':ranker_train_users,'ranker_valid_users':ranker_valid_users,
            'eval_users':eval_users,'trees':trees,'leaves':leaves,'learning_rate':learning_rate,
            'min_child_samples':min_child_samples,'reg_lambda':reg_lambda,
            'colsample_bytree':colsample_bytree,'early_stop_rounds':early_stop_rounds,
            'objective':objective,'feature_names':FEATURE_NAMES}
    key=hashlib.sha256(json.dumps(params,sort_keys=True).encode()).hexdigest()[:12]
    dest=Path('models')/dataset/'temporal_fm'/'advanced_ltr'/f'{run_label}_{key}'
    dest.mkdir(parents=True,exist_ok=True)
    model_path=dest/'model.txt'
    if model_path.exists() and not force_retrain:
        ranker=lgb.Booster(model_file=str(model_path))
        print('Reusing checkpoint',model_path,flush=True)
    else:
        estimator=lgb.LGBMRanker(objective=objective,metric='ndcg',n_estimators=trees,
             learning_rate=learning_rate,num_leaves=leaves,
             min_child_samples=min_child_samples,colsample_bytree=colsample_bytree,
             reg_lambda=reg_lambda,random_state=seed,verbosity=-1,n_jobs=max(1,threads),
             lambdarank_truncation_level=k+5,label_gain=[0,1])
        estimator.fit(X,y,group=groups,feature_name=FEATURE_NAMES,
              eval_set=[(Xv,yv)],eval_group=[gv],eval_at=[k],
              callbacks=[lgb.early_stopping(early_stop_rounds,verbose=False)])
        ranker=estimator.booster_
        ranker.save_model(str(model_path))
    (dest/'metadata.json').write_text(json.dumps({**params,'train_informative_groups':len(groups),
       'valid_informative_groups':len(gv),'best_iteration':ranker.best_iteration},indent=2))
    print('Evaluating held-out queries...',flush=True)
    metric_data={name:[] for name in (*SOURCES,'advanced_lambdamart')}
    coverage={name:set() for name in metric_data}
    ndcgs={name:[] for name in metric_data}
    total_relevant=0;retrieved_relevant=0;rows=0;example={}
    for index,u in enumerate(te,1):
        q=retriever.query(u,eval_h[u],eval_y[u],quotas)
        if q is None:continue
        total_relevant+=q['relevant_total'];retrieved_relevant+=q['retrieved_relevant'];rows+=1
        predictions={**q['scores'], 'advanced_lambdamart':ranker.predict(q['features'],
                                            num_threads=max(1,threads))}
        for name,score in predictions.items():
            order=_best(score,k)
            movies=q['movies'][order]
            stats=_ranking_scores(movies,eval_y[u],k,ev.genre_matrix,pop,
                                 int(ev.meta['splits']['train']))
            metric_data[name].append(stats)
            coverage[name].update(map(int,movies))
            ndcgs[name].append(stats['ndcg_at_k'])
        if len(example)<4:
            ranked=_best(predictions['advanced_lambdamart'],k)
            example[str(u)]=[{'movieId':int(ev.movies.iloc[int(m)]['movieId']),
                             'title':str(ev.movies.iloc[int(m)]['title']),
                             'relevant':bool(int(m) in eval_y[u])} for m in q['movies'][ranked]]
        if index%50==0:print(f'  held-out users {index}/{len(te)}',flush=True)
    if not rows:raise ValueError('No eval queries with eligible unseen candidates')
    metrics={name:_aggregate(metric_data[name],coverage[name],len(retriever.catalog))
             for name in metric_data}
    report={'dataset':dataset,'split':eval_split,'model':base_model,
            'candidate_policy':'Multi-source FM+SVD+BPR+popularity+title semantics. No label injection.',
            'k':k,'seed':seed,'cutoff':int(ev.meta['train_cutoff']),
            'eval_users':rows,'ranker_train_users':len(tr),
            'ranker_valid_users':len(va),'informative_train_groups':len(groups),
            'informative_valid_groups':len(gv),
            'candidate_recall':float(retrieved_relevant/max(1,total_relevant)),
            'metrics':metrics,'delta_vs_fm':_paired_bootstrap(
                      ndcgs['advanced_lambdamart'],ndcgs['fm'],seed),
            'feature_importance_gain':dict(zip(FEATURE_NAMES,map(float,
                                                   ranker.feature_importance('gain')))),
            'examples':example,'ranker_path':str(model_path),'configuration':params,
            'caveats':['Unrated items are unknown, not negatives.',
                       'All retrieval features freeze at original FM train cutoff.',
                       'Early stopping users are disjoint from ranker training and report evaluation.',
                       'LightGBM early stopping NDCG is conditional on retrieved positives and '
                       'is not the same as full-catalogue NDCG.',
                       'FM checkpoint may have been selected using validation; reserve test for confirmation.',
                       'Models compared here have identical evaluation queries and candidate union.']}
    report_dir=Path('reports')/'temporal'/dataset;report_dir.mkdir(parents=True,exist_ok=True)
    path=report_dir/f'advanced_ltr_{eval_split}_{run_label}_{key}.json'
    path.write_text(json.dumps(report,indent=2))
    with path.with_suffix('.csv').open('w',newline='') as fp:
        cols=['model',*next(iter(metrics.values())).keys()];writer=csv.DictWriter(fp,fieldnames=cols)
        writer.writeheader()
        for name,m in metrics.items():writer.writerow({'model':name,**m})
    for name,m in metrics.items():
        print(f'{name:23s} NDCG@{k}={m["ndcg_at_k"]:.4f} '
              f'Recall@{k}={m["recall_at_k"]:.4f}',flush=True)
    print('Candidate recall:',report['candidate_recall'],'Report:',path,flush=True)
    return report


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset',default='ml-32m');p.add_argument('--data-dir',default='data')
    p.add_argument('--backend',choices=['sentence','hash'],default='sentence')
    p.add_argument('--base-model',default='fm_all_bpr')
    p.add_argument('--ranker-train-users',type=int,default=700)
    p.add_argument('--ranker-valid-users',type=int,default=200)
    p.add_argument('--eval-users',type=int,default=300)
    for name,quota in DEFAULT_QUOTAS.items():p.add_argument(f'--{name}-candidates',type=int,default=quota)
    p.add_argument('--baseline-profile',choices=['quick','research'],default='quick')
    p.add_argument('--threshold',type=float,default=4.);p.add_argument('--k',type=int,default=10)
    p.add_argument('--min-history',type=int,default=5);p.add_argument('--seed',type=int,default=42)
    p.add_argument('--eval-split',choices=['validation','test'],default='validation')
    p.add_argument('--device',choices=['cpu','cuda'],default='cpu');p.add_argument('--threads',type=int,default=2)
    p.add_argument('--batch-size',type=int,default=2048)
    p.add_argument('--trees',type=int,default=600);p.add_argument('--leaves',type=int,default=15)
    p.add_argument('--learning-rate',type=float,default=.03)
    p.add_argument('--min-child-samples',type=int,default=60)
    p.add_argument('--reg-lambda',type=float,default=3.)
    p.add_argument('--colsample-bytree',type=float,default=.8)
    p.add_argument('--early-stop-rounds',type=int,default=40)
    p.add_argument('--objective',choices=['lambdarank','rank_xendcg'],default='lambdarank')
    p.add_argument('--run-label',default='multisource')
    p.add_argument('--force-retrain',action='store_true')
    return run(**vars(p.parse_args(argv)))

if __name__=='__main__':main()
