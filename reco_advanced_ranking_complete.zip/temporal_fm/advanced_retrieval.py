"""Chronologically consistent candidate-recall diagnostics for MovieLens FM.

Usage: python -m temporal_fm.advanced_retrieval --dataset ml-32m --users 300
      python -m temporal_fm.advanced_retrieval --dataset ml-32m --sources fm,svd,bpr,pop,semantic
No held-out positive is injected into retrieval. Candidate metrics are computed
on the *same* sampled validation users and training-period feature snapshot.
"""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
import numpy as np
import torch
from .data import Events
from .ranking import _cohort, _model, score_candidates
from .lambdamart import Snapshot, _prepare

SOURCES = ('fm','svd','bpr','pop','semantic')
DEFAULT_QUOTAS = {'fm':500,'svd':150,'bpr':150,'pop':100,'semantic':100}
EXTRA_FEATURES = ['svd_score','bpr_score','semantic_title_score',
                  'svd_rank_percentile','bpr_rank_percentile','semantic_rank_percentile',
                  'retrieved_by_fm','retrieved_by_svd','retrieved_by_bpr',
                  'retrieved_by_pop','retrieved_by_semantic','source_agreement']


def _best(scores, n):
    """Stable finite-only top-N, no labels and no set nondeterminism."""
    a=np.asarray(scores,dtype=np.float32)
    valid=np.flatnonzero(np.isfinite(a))
    if n<=0 or not len(valid):return np.empty(0,np.int32)
    m=min(int(n),len(valid))
    if m==len(valid):return valid[np.argsort(-a[valid],kind='stable')]
    # np.argpartition avoids a full sort of 87K scores per retrieval source.
    local=np.argpartition(-a[valid],m-1)[:m]
    return valid[local[np.lexsort((valid[local],-a[valid][local]))]].astype(np.int32)


def _rank_percentile(values):
    vals=np.asarray(values,dtype=np.float32)
    order=np.argsort(-vals,kind='stable')
    ranks=np.empty(len(vals),dtype=np.float32)
    ranks[order]=np.arange(len(vals),dtype=np.float32)/max(1,len(vals)-1)
    return ranks


def _pool_union(unseen, scores, quotas, *, enabled=None):
    """Return candidate index array and membership flags, never using ground truth."""
    names=[x for x in SOURCES if x in scores and (enabled is None or x in enabled)]
    selections={name:_best(scores[name],quotas.get(name,0)) for name in names}
    local=np.unique(np.concatenate(list(selections.values()))) if names else np.array([],np.int32)
    membership={name:np.isin(local,indices).astype(np.float32) for name,indices in selections.items()}
    return np.asarray(unseen,dtype=np.int32)[local],local,membership,selections


def _retrieval_metrics(selected,truth):
    positives=set(map(int,truth))
    return float(len(positives.intersection(map(int,selected)))/len(positives)) if positives else 0.


class AdvancedRetriever:
    """Frozen feature/candidate generator shared by diagnostics and LambdaMART."""
    def __init__(self, ev, provider, model, histories, users, movie_pop, *,
                 sources=('fm','pop'),baseline_profile='quick',seed=42,threads=2,
                 threshold=4.,device='cpu',batch_size=2048):
        unknown=set(sources).difference(SOURCES)
        if unknown:raise ValueError(f'Unknown sources: {sorted(unknown)}')
        self.ev,self.provider,self.model=ev,provider,model
        self.sources=tuple(dict.fromkeys(sources))
        self.movie_pop=np.asarray(movie_pop)
        self.catalog=np.flatnonzero(ev.movie_has_train).astype(np.int32)
        self.cutoff=int(ev.meta['train_cutoff'])+1
        self.device=device;self.batch_size=batch_size
        self.snapshot=Snapshot(ev,provider,users,histories,self.movie_pop,threshold,self.cutoff)
        self.baseline={}
        if any(n in self.sources for n in ('svd','bpr')):
            from .shared_benchmark import load_or_fit_baselines
            trained,_=load_or_fit_baselines(ev,positive_threshold=threshold,
                      profile=baseline_profile,seed=seed,threads=threads)
            self.baseline={'svd':trained['svd_chrono'],'bpr':trained['bpr_chrono']}

    def query(self,u,history,truth,quotas=None,diagnostic_k=0):
        quotas={**DEFAULT_QUOTAS,**(quotas or {})}
        seen=np.asarray(sorted(history),dtype=np.int32)
        unseen=np.setdiff1d(self.catalog,seen,assume_unique=True)
        if not len(unseen):return None
        # All scores and semantic profiles refer exclusively to train cutoff.
        fm=score_candidates(self.model,self.ev,self.provider,u,unseen,self.cutoff,
                            device=self.device,batch_size=self.batch_size)
        full={'fm':fm,'pop':np.log1p(self.movie_pop[unseen]).astype(np.float32)}
        if self.baseline:
            ui=int(self.ev.user_indices(np.array([u],np.int32))[0])-1
            if ui<0:raise ValueError(f'Unknown training user: {u}')
            for name,(user_factors,movie_factors) in self.baseline.items():
                full[name]=(movie_factors[unseen]@user_factors[ui]).astype(np.float32)
        if 'semantic' in self.sources:
            full['semantic']=(self.snapshot.title[unseen] @ self.snapshot.title_affinity[int(u)]).astype(np.float32)
        mids,loc,selected,selections=_pool_union(unseen,full,quotas,enabled=self.sources)
        if not len(mids):return None
        # Rank order within retrieved union is required by the existing Snapshot.
        fm_rank=_rank_percentile(fm[loc])*max(1,len(loc)-1)
        pop_mids=unseen[selections.get('pop',np.empty(0,np.int32))]
        base=self.snapshot.features(u,mids,fm[loc],fm_rank,pop_mids)
        ext=[]
        for src in ('svd','bpr','semantic'):
            ext.append(full.get(src,np.zeros(len(unseen),np.float32))[loc])
        for src in ('svd','bpr','semantic'):
            ext.append(_rank_percentile(full[src])[loc] if src in full else np.ones(len(loc),np.float32))
        for src in SOURCES:
            ext.append(selected.get(src,np.zeros(len(loc),np.float32)))
        agreement=sum(selected.values()) if selected else np.zeros(len(loc),np.float32)
        ext.append(agreement.astype(np.float32))
        X=np.column_stack([base,*ext]).astype(np.float32)
        if not np.isfinite(X).all():raise ValueError('Nonfinite ranking feature')
        truth=set(map(int,truth))
        labels=np.isin(mids,list(truth)).astype(np.int32)
        return {'user':int(u),'movies':mids,'labels':labels,'features':X,
                'retrieval_sources':{s:unseen[idx] for s,idx in selections.items()},
                'diagnostic_sources':{s:unseen[_best(full[s],max(diagnostic_k,quotas[s]))]
                   for s in self.sources} if diagnostic_k else None,
                'scores':{s:full[s][loc] for s in full},
                'candidate_recall':_retrieval_metrics(mids,truth),
                'relevant_total':len(truth),'retrieved_relevant':int(labels.sum()),
                'eligible_catalogue_size':len(unseen)}


def prepare_run(dataset,data_dir,backend,base_model,sources,users,histories,popularity,
                threshold,baseline_profile,seed,threads,device,batch_size):
    ev=Events(Path(data_dir)/'temporal'/dataset)
    provider=_prepare(ev,backend)
    model=_model(ev,provider,base_model,backend,device,seed=seed)
    retriever=AdvancedRetriever(ev,provider,model,histories,users,popularity,sources=sources,
                   baseline_profile=baseline_profile,seed=seed,threads=threads,
                   threshold=threshold,device=device,batch_size=batch_size)
    return retriever


def diagnose(dataset='ml-32m',data_dir='data',backend='sentence',base_model='fm_all_bpr',
             sources='fm,pop',users=300,k=10,threshold=4.,min_history=5,seed=42,
             baseline_profile='quick',device='cpu',threads=2,batch_size=2048,
             fm_candidates=500,svd_candidates=150,bpr_candidates=150,
             pop_candidates=100,semantic_candidates=100,run_label='diagnostic'):
    if k<1 or users<1:raise ValueError('k and users must be positive')
    srcs=tuple(s.strip() for s in sources.split(',') if s.strip())
    if 'fm' not in srcs:raise ValueError('FM must be one retrieval source')
    ev=Events(Path(data_dir)/'temporal'/dataset)
    chosen,histories,truth,pop,stats=_cohort(ev,'validation',threshold,users,min_history,seed)
    if not chosen:raise ValueError('No eligible users')
    retriever=prepare_run(dataset,data_dir,backend,base_model,srcs,chosen,histories,pop,
                          threshold,baseline_profile,seed,threads,device,batch_size)
    quotas={'fm':fm_candidates,'svd':svd_candidates,'bpr':bpr_candidates,
            'pop':pop_candidates,'semantic':semantic_candidates}
    for name in srcs:
        if quotas[name]<k:raise ValueError(f'{name} quota must be at least K={k}')
    per_user=[]
    for idx,u in enumerate(chosen,1):
        q=retriever.query(u,histories[u],truth[u],quotas,diagnostic_k=1000)
        if q is None:continue
        record={'userId':int(u),'union_candidate_recall':q['candidate_recall'],
                'candidates':len(q['movies']),'heldout_positives':q['relevant_total']}
        for name in srcs:
            retrieved=q['diagnostic_sources'][name]
            for cut in (k,100,500,1000):
                record[f'{name}_recall_at_{cut}']=_retrieval_metrics(retrieved[:cut],truth[u])
        per_user.append(record)
        if idx%50==0:print(f'Diagnostics {idx}/{len(chosen)}',flush=True)
    if not per_user:raise ValueError('No diagnostic queries')
    numeric=[x for x in per_user[0] if x!='userId']
    report={'dataset':dataset,'base_model':base_model,'split':'validation',
            'cohort_users':len(per_user),'sources':srcs,'quotas':quotas,
            'cutoff':int(ev.meta['train_cutoff']),'seed':seed,
            'candidate_policy':'No heldout-positive injection; frozen training-only features',
            'summary':{v:float(np.mean([x[v] for x in per_user])) for v in numeric},
            'per_user':per_user,'cohort_info':stats}
    dest=Path('reports')/'temporal'/dataset
    dest.mkdir(parents=True,exist_ok=True)
    safe=''.join(c for c in run_label if c.isalnum() or c in '-_') or 'diagnostic'
    path=dest/f'advanced_retrieval_{safe}.json'
    path.write_text(json.dumps(report,indent=2))
    with path.with_suffix('.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=per_user[0].keys());writer.writeheader();writer.writerows(per_user)
    print('Candidate recall:',report['summary']['union_candidate_recall']);print('Saved:',path)
    return report


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset',default='ml-32m');p.add_argument('--data-dir',default='data')
    p.add_argument('--backend',choices=['sentence','hash'],default='sentence')
    p.add_argument('--base-model',default='fm_all_bpr')
    p.add_argument('--sources',default='fm,pop')
    p.add_argument('--users',type=int,default=300);p.add_argument('--k',type=int,default=10)
    p.add_argument('--threshold',type=float,default=4.);p.add_argument('--min-history',type=int,default=5)
    p.add_argument('--seed',type=int,default=42);p.add_argument('--baseline-profile',choices=['quick','research'],default='quick')
    p.add_argument('--device',choices=['cpu','cuda'],default='cpu');p.add_argument('--threads',type=int,default=2)
    p.add_argument('--batch-size',type=int,default=2048)
    for s,val in DEFAULT_QUOTAS.items():p.add_argument(f'--{s}-candidates',type=int,default=val)
    p.add_argument('--run-label',default='diagnostic')
    return diagnose(**vars(p.parse_args(argv)))

if __name__=='__main__': main()
