"""Semi-hard negatives for the existing FM-BPR trainer.

Scores small candidate pools at the *positive event time*. Candidate movies are
obtained by the existing _draw_unrated function, preserving the training-history
exclusion and film-release checks. Sampled unobserved items are NOT confirmed dislikes.
"""
from __future__ import annotations
import numpy as np
import torch


def choose_semi_hard(scores):
    """Choose a high-scoring but not maximally hard candidate from each row."""
    a=np.asarray(scores,dtype=np.float32)
    if a.ndim!=2 or a.shape[1]<2:
        raise ValueError('Expected [queries, at least two candidates]')
    if not np.isfinite(a).all():raise ValueError('Nonfinite negative mining scores')
    sorted_idx=np.argsort(-a,axis=1,kind='stable')
    # The second most tempting movie is usually less prone to false-negative noise.
    return sorted_idx[:,1]


def mine_semi_hard(model, ev, provider, rng, original_negatives, users, timestamps,
                   known, catalog, bank, pop_share, hard_share, pool_size, device,
                   *,chunk_size=2048):
    """Replace a random subset of standard negatives with semi-hard model negatives."""
    if not 0 <= hard_share <= 1:raise ValueError('hard_share must lie in [0,1]')
    if pool_size<2:raise ValueError('pool_size must be at least 2')
    output=np.asarray(original_negatives,dtype=np.int32).copy()
    if hard_share==0:return output
    ids=np.flatnonzero(rng.random(len(output)) < hard_share)
    if not len(ids):return output
    # Local imports avoid an import cycle with rank_train.
    from .rank_train import _draw_unrated, _batch_for_movies
    u=np.asarray(users,dtype=np.int64)[ids]
    ts=np.asarray(timestamps,dtype=np.int64)[ids]
    choices=np.empty((len(ids),pool_size),dtype=np.int32)
    choices[:,0]=output[ids]
    for j in range(1,pool_size):
        choices[:,j]=_draw_unrated(rng,u,known,catalog,len(ev.movies),bank,
                                  ev.release_year,ts,pop_share)
    flat_u=np.repeat(u,pool_size)
    flat_t=np.repeat(ts,pool_size)
    flat_m=choices.ravel()
    pred=np.empty(len(flat_m),dtype=np.float32)
    previously_training=bool(model.training)
    try:
        model.eval()  # disable stochastic dropout during mining
        with torch.no_grad():
            for a in range(0,len(flat_m),chunk_size):
                b=min(len(flat_m),a+chunk_size)
                batch=_batch_for_movies(ev,provider,flat_u[a:b],flat_m[a:b],flat_t[a:b],device)
                pred[a:b]=model(batch).detach().cpu().numpy()
    finally:
        model.train(previously_training)
    row=np.arange(len(ids))
    selected=choose_semi_hard(pred.reshape(len(ids),pool_size))
    output[ids]=choices[row,selected]
    return output
