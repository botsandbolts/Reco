"""Run full multi-source retrieval: FM + chronological SVD/BPR + popularity + semantics."""
from __future__ import annotations
import argparse
from .advanced_retrieval import diagnose


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset',default='ml-32m')
    p.add_argument('--data-dir',default='data')
    p.add_argument('--backend',choices=['sentence','hash'],default='sentence')
    p.add_argument('--base-model',default='fm_all_bpr')
    p.add_argument('--users',type=int,default=300)
    p.add_argument('--k',type=int,default=10)
    p.add_argument('--threshold',type=float,default=4.)
    p.add_argument('--min-history',type=int,default=5)
    p.add_argument('--seed',type=int,default=42)
    p.add_argument('--baseline-profile',choices=['quick','research'],default='quick')
    p.add_argument('--device',choices=['cpu','cuda'],default='cpu')
    p.add_argument('--threads',type=int,default=2)
    p.add_argument('--batch-size',type=int,default=2048)
    p.add_argument('--fm-candidates',type=int,default=500)
    p.add_argument('--svd-candidates',type=int,default=150)
    p.add_argument('--bpr-candidates',type=int,default=150)
    p.add_argument('--pop-candidates',type=int,default=100)
    p.add_argument('--semantic-candidates',type=int,default=100)
    p.add_argument('--run-label',default='multisource')
    return diagnose(sources='fm,svd,bpr,pop,semantic',**vars(p.parse_args(argv)))

if __name__=='__main__':main()
