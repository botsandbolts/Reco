"""Optional end-to-end smoke test; synthetic MovieLens file fixtures, no internet."""
import numpy as np
import pandas as pd
import pytest
from pathlib import Path


def test_synthetic_advanced_ltr(tmp_path,monkeypatch):
    pytest.importorskip('lightgbm')
    from temporal_fm.rank_train import train
    from temporal_fm.advanced_ltr import run
    raw=tmp_path/'data/raw/ml-latest-small';raw.mkdir(parents=True)
    n_users=55;n_movies=180
    pd.DataFrame({'movieId':np.arange(1,n_movies+1),
                  'title':[f'Film {i} (2000)' for i in range(n_movies)],
                  'genres':['Action|Comedy' if i%2 else 'Drama|Romance' for i in range(n_movies)]}).to_csv(raw/'movies.csv',index=False)
    rng=np.random.default_rng(441)
    rows=[]
    for i in range(6200):
        rows.append((i%n_users+1,int(rng.integers(1,n_movies+1)),
                    5. if i%5 != 0 else 2.,1_450_000_000+i*3600))
    pd.DataFrame(rows,columns=['userId','movieId','rating','timestamp']).to_csv(raw/'ratings.csv',index=False)
    pd.DataFrame({'movieId':[1,2,3,4], 'tag':['funny','romantic','dramatic','action'],
                  'timestamp':[1_450_000_000,1_450_000_300,1_450_000_600,1_450_000_900]}).to_csv(raw/'tags.csv',index=False)
    monkeypatch.chdir(tmp_path)
    train(dataset='ml-latest-small',data_dir='data',models='fm',profile='quick',
          text_backend='hash',validation_users=8,validation_candidates=30,
          tag_dims=12,threads=1,negatives=1)
    result=run(dataset='ml-latest-small',data_dir='data',backend='hash',
          base_model='fm_all_bpr',ranker_train_users=12,ranker_valid_users=6,
          eval_users=6,fm_candidates=75,svd_candidates=20,bpr_candidates=20,
          pop_candidates=15,semantic_candidates=15,trees=25,early_stop_rounds=5,
          min_child_samples=3,leaves=7,k=5,device='cpu',threads=1,batch_size=128,
          run_label='smoke')
    assert result['eval_users']==6
    assert result['informative_train_groups']>=1
    assert result['informative_valid_groups']>=1
    assert 0<=result['candidate_recall']<=1
    assert set(result['metrics'])=={'fm','svd','bpr','pop','semantic','advanced_lambdamart'}
    for metrics in result['metrics'].values():
        assert 0<=metrics['ndcg_at_k']<=1
    assert Path(result['ranker_path']).is_file()
