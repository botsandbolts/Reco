import numpy as np
from temporal_fm.advanced_retrieval import _best,_pool_union,_retrieval_metrics,EXTRA_FEATURES
from temporal_fm.advanced_ltr import _split_users,FEATURE_NAMES


def test_union_never_injects_ground_truth():
    unseen=np.arange(30,dtype=np.int32)
    fm=np.arange(30,dtype=np.float32)
    pop=-fm
    mids,ix,flags,sources=_pool_union(unseen,{'fm':fm,'pop':pop},
                                     {'fm':4,'pop':3})
    assert set(mids)==set([0,1,2,26,27,28,29])
    assert 15 not in mids
    assert _retrieval_metrics(mids,{15})==0.
    assert flags['fm'].sum()==4
    assert flags['pop'].sum()==3


def test_finite_topk_and_stable_ties():
    assert _best(np.array([2.,np.nan,2.,np.inf,4.]),3).tolist()==[4,0,2]
    assert len(_best(np.array([1.,2.]),10))==2


def test_three_way_user_split_disjoint():
    a,b,c=_split_users(list(range(40)),10,12,15,42)
    assert len(a)==10 and len(b)==12 and len(c)==15
    assert len(set(a+b+c))==37
    assert _split_users(list(range(40)),10,12,15,42)==(a,b,c)
    assert len(FEATURE_NAMES)==len(set(FEATURE_NAMES))
    assert len(EXTRA_FEATURES)==12
