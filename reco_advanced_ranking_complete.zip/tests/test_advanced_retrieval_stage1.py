import numpy as np
from temporal_fm.advanced_retrieval import _best,_pool_union,_retrieval_metrics


def test_candidate_union_without_ground_truth_injection():
    movies=np.arange(20,dtype=np.int32)
    a=np.arange(20,dtype=np.float32)
    b=-a
    selected,loc,flags,pool=_pool_union(movies,{'fm':a,'pop':b},{'fm':3,'pop':3})
    assert set(selected)=={0,1,2,17,18,19}
    assert _retrieval_metrics(selected,{12})==0
    assert flags['fm'].sum()==3 and flags['pop'].sum()==3


def test_candidate_topk_handles_nonfinite_scores():
    assert _best([1.,np.nan,10.,np.inf,2.],2).tolist()==[2,4]
