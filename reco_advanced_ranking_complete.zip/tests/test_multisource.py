import numpy as np
from temporal_fm.advanced_retrieval import _pool_union,_retrieval_metrics


def test_5_sources_union_deduplicated_and_label_free():
    unseen=np.arange(100,dtype=np.int32)
    arr=np.arange(100,dtype=np.float32)
    scores={'fm':arr,'svd':arr[::-1], 'bpr':np.roll(arr,20),
            'pop':arr.copy(), 'semantic':np.roll(arr,-20)}
    cand,_,members,_=_pool_union(unseen,scores,dict.fromkeys(scores,5))
    assert len(cand)==len(set(cand))
    assert 50 not in cand
    assert _retrieval_metrics(cand,{50})==0
    assert all(m.sum()==5 for m in members.values())
