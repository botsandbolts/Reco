import numpy as np
from pathlib import Path
from scripts.install_semi_hard import install
from temporal_fm.hard_negatives import choose_semi_hard


def test_second_hardest_not_absolute_top():
    scores=np.array([[0.,2.,5.,4.],[4.,1.,9.,0.]])
    assert choose_semi_hard(scores).tolist()==[3,0]


def test_installer_is_idempotent_and_preserves_original(tmp_path):
    src=Path(__file__).parents[1]/'temporal_fm'/'rank_train.py'
    target=tmp_path/'rank_train.py';target.write_text(src.read_text())
    if 'SEMI_HARD_NEGATIVES_V1' in target.read_text():
        assert not install(target)  # It was installed in Codespaces already.
    else:
        assert install(target)
        assert len(list(tmp_path.glob('rank_train.before_semi_hard_*.py')))==1
        assert 'SEMI_HARD_NEGATIVES_V1' in target.read_text()
        assert not install(target)
