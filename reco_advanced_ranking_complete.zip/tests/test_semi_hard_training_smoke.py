import numpy as np
import pandas as pd
from pathlib import Path
from temporal_fm.rank_train import train


def test_training_with_hard_negatives(tmp_path,monkeypatch):
    raw=tmp_path/'data/raw/ml-latest-small';raw.mkdir(parents=True)
    n_movies=80;n_users=18;n_events=1800
    pd.DataFrame({'movieId':np.arange(1,n_movies+1),
                  'title':[f'Film {i} (2000)' for i in range(n_movies)],
                  'genres':['Action|Adventure' if i%2 else 'Drama|Comedy' for i in range(n_movies)]}).to_csv(raw/'movies.csv',index=False)
    rng=np.random.default_rng(90)
    pd.DataFrame({'userId':rng.integers(1,n_users+1,size=n_events),
                  'movieId':rng.integers(1,n_movies+1,size=n_events),
                  'rating':rng.choice([2.,4.,5.],size=n_events),
                  'timestamp':1_440_000_000+np.arange(n_events,dtype=np.int64)*3600}).to_csv(raw/'ratings.csv',index=False)
    pd.DataFrame({'movieId':[1,2],'tag':['funny','sad'],
                  'timestamp':[1_440_000_000,1_440_000_001]}).to_csv(raw/'tags.csv',index=False)
    monkeypatch.chdir(tmp_path)
    r=train(dataset='ml-latest-small',data_dir='data',models='fm',profile='quick',
            text_backend='hash',validation_users=5,validation_candidates=32,
            tag_dims=8,negatives=1,threads=1,hard_negative_share=.3,hard_pool=4,
            run_label='hard_smoke')
    assert Path('models/ml-latest-small/temporal_fm/fm_all_hard_smoke_bpr/weights.pt').exists()
    assert r['models']['fm_all_hard_smoke_bpr']['checkpoint']
