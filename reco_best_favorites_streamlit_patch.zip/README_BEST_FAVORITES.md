# Reco Studio — Choose movies and get model-backed recommendations

A small, **additive** update to your existing Reco Studio. This is intended for
MovieLens latest-small, 1M and 32M in GitHub Codespaces, including mobile use.

## What changed

The first tab becomes **🎬 Choose films & recommend**. It lets you:

1. Search a title (for example `Matrix`), check matching films and tap **Add selected to favorites**.
2. Add up to eight favorites across multiple searches.
3. Select **Auto · strongest compatible saved model**, a particular saved SVD or BPR-MF source, or title/genre similarity.
4. Filter by genre and select result count.
5. Tap **🎬 Get recommended films** to generate a fresh ranked table of eligible movies, with model attribution and CSV download.

The other tabs (known-user FM/HOFM3, B+C+D, JointBCD/LambdaRank, training,
UMAP, reports and checkpoints) are preserved. The installer **does not change
trained weights, data or reports**; it creates
`reco_studio/interface.py.before_best_favorites.bak` before a surgical import/tab edit.

## What does "best" mean here?

**Known-user validation NDCG and anonymous movie selection are different tasks.**
HOFM3/JointBCD/LambdaRank were fitted for MovieLens user IDs, and cannot
honestly be called on an arbitrary new visitor whose only input is some favorite
movie IDs. This patch does not fake a user ID or claim those scores transfer to
new users.

For a new visitor, **Auto** chooses the highest-NDCG **usable** HOFM3,
FM, BPR-MF or SVD *movie-factor checkpoint*, when models have figures in
**one matched validation report**. It constructs a new temporary interest profile as the normalized
mean of the selected movie item vectors, scores unseen movies by cosine
similarity to this inferred profile, and blends 75% latent affinity with 25%
title/genre TF-IDF affinity. The blend is a heuristic, not a learned or
validated cold-start user tower. If only one item model exists, it uses that;
if no matched ranking evidence exists, Auto prefers available BPR-MF factors
without asserting they are proven superior. HOFM3 reuses the trained movie-ID
factors from both its pairwise and cubic field interactions, with separate
normalization. It does **not** execute the HOFM3 user-ID scoring function. If checkpoints are unavailable or
incompatible, it falls back visibly to title/genre similarity.

The page also **displays the best *measured existing-user* model**, as found in
one saved full-catalogue ranking/shared benchmark, to make the distinction clear.
That could be HOFM3. A LambdaRank report is displayed separately; it does not
share the candidate-pool protocol of a full-catalogue benchmark. **A higher
known-user NDCG does not establish a better anonymous recommendation experience**.

For real HOFM3 or JointBCD LambdaRank recommendations on a historical MovieLens
user, use the separate **🎯 Known-user recommendations** tab.

## Install: ZIP is already uploaded to GitHub

In **Codespaces → Terminal (not Output)**:

```bash
cd /workspaces/Reco

git fetch origin main
git show origin/main:reco_best_favorites_streamlit_patch.zip > reco_best_favorites_streamlit_patch.zip
unzip -o reco_best_favorites_streamlit_patch.zip

# Keeps your existing engines.py and app.py intact.
python scripts/install_best_favorites.py

python -m pytest -q tests/test_favorite_best_model.py tests/test_install_best_favorites.py
python -m py_compile reco_studio/favorite_models.py reco_studio/favorite_page.py reco_studio/interface.py
```

**Prerequisite:** Reco Studio from `reco_studio_complete_patch.zip` already
installed. The model-specific functionality also requires the same local
trained factor caches as your previous chronological SVD/BPR experiments;
this ZIP does **not** retrain anything.

Existing recommendations remain accessible if no item factors are saved.

### Run

Stop the old server on port 8502 with Ctrl+C, then:

```bash
streamlit run reco_studio_app.py --server.address 0.0.0.0 --server.port 8502
```

Open the forwarded Codespaces **8502** address, choose `MovieLens 32M` in the
sidebar, and open **🎬 Choose films & recommend**.

If you previously made Reco Studio the default app:

```bash
streamlit run app.py --server.address 0.0.0.0 --server.port 8502
```

### Check the availability of a saved item-factor baseline

```bash
find models/ml-32m/shared_chrono_baselines -name factors.npz -print
```

If no factors are present, the new visitor can still use the title+genre
recommender. You can also use saved
`models/ml-32m/temporal_fm/*/weights.pt` movie factors if they align with
the prepared MovieLens data and provenance metadata. Do not upload untrusted pickle
or PyTorch weights: deserializing them can execute arbitrary code.

### Restore the old interface

```bash
cp reco_studio/interface.py.before_best_favorites.bak reco_studio/interface.py
```

The added Python modules can remain; the restored interface simply won't use
them. No model/checkpoint files are changed by installation or rollback.

## Scientific limitations

- Each best-model label is supported only **within one benchmark report**. NDCG
  from different candidate pools, cohorts or dataset sizes is never pooled.
- Cold-start item-factor pooling is *not* validated by the known-user ranking
  benchmark. A separate evaluation simulating new users would be needed.
- Selected favorites are never recommended back to the visitor. Trained
  item-factor recommendations exclude movies absent from the checkpoint's
  training catalogue; actual feature/cutoff alignment is checked.
- For historical MovieLens 32M, semantic content is limited to movie titles
  and genres on this page; it does not claim to infer viewing history.
- Saved FM/HOFM3 and LightGBM continue to work in the **known-user** tab.

### Tests

The patch includes synthetic tests for trusted factor alignment, ranking,
non-recommendation of selected favorites, genre filters, fallbacks, comparable
metric evidence and a non-destructive/reversible installer. It is not a real
MovieLens 32M performance benchmark and has not been executed inside your
Codespace.
