"""Cold-start recommendations from the strongest *applicable* saved item model.

No new anonymous user is assigned a trained MovieLens user ID. In particular,
FM/HOFM3 and LambdaRank are known-user recommenders; their validation NDCG does
NOT establish cold-start quality. We use existing movie-factor representations
(BPR-MF / SVD) to construct an *inferred* profile from chosen movie examples.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from functools import lru_cache
import json
import numpy as np
import pandas as pd

from .catalog import catalog_index, content_recommendations, genre_options, movie_filter, top_results


@dataclass(frozen=True)
class ItemModel:
    method: str             # bpr / svd / small_svd / fm_item / hofm3_item
    source: Path
    name: str
    dataset: str
    ndcg: float | None = None
    evidence: str = ''


@dataclass
class FavoriteResult:
    movies: pd.DataFrame
    method: str
    evidence: str
    caution: str


def _positive(x):
    try:
        value = float(x)
        return value if np.isfinite(value) and 0 <= value <= 1 else None
    except (TypeError, ValueError):
        return None


def _metric_rows(report, kind):
    """Scores from a *single* comparable report, never merge across files."""
    metrics = report.get('metrics') if kind != 'MovieLens Small baseline' else report.get('validation')
    return metrics if isinstance(metrics,dict) else {}


def validation_evidence(root:Path, dataset:str) -> tuple[dict[str,float],str]:
    """Read the newest suitable matched ranking report; never pick a best model
    by maxing scores drawn from incompatible reports/splits/candidate pools.
    """
    from reco_research_lab.report_store import discover,load_json
    allow = ('FM/BPR top-K ranking','Shared chronology benchmark','MovieLens Small baseline')
    for ref in discover(root,dataset):
        if ref.kind not in allow:continue
        try: report=load_json(ref.path)
        except (ValueError,OSError,KeyError):continue
        if report.get('dataset') not in (None,dataset,'MovieLens latest-small (GroupLens)'):continue
        # Ignore reports with explicit sampled evaluation or conflicting time metadata.
        policy=str(report.get('candidate_policy','full')).lower()
        if 'sample' in policy and 'full' not in policy:continue
        if report.get('split')=='train':continue
        rows=_metric_rows(report,ref.kind)
        scores={str(name):value for name,row in rows.items() if isinstance(row,dict)
                if (value:=_positive(row.get('ndcg_at_k'))) is not None
                and row.get('users_evaluated',1) != 0}
        if scores:return scores,str(ref.path.relative_to(root))
    return {},'No compatible ranking validation report was found'


def observed_best_model(root:Path,dataset:str)->tuple[str | None,float|None,str]:
    """The highest-scoring name is only meaningful within one matched report."""
    scores,source=validation_evidence(root,dataset)
    if not scores:return None,None,source
    name=max(scores,key=scores.__getitem__)
    return name,scores[name],source


def _baseline_sources(root:Path,dataset:str):
    # No temporal data loaded just for discovery; manifest validated when scoring.
    from .engines import baseline_checkpoints
    return baseline_checkpoints(root,dataset)


def available_item_models(root:Path,dataset:str)->list[ItemModel]:
    """List only executable, saved item representations, not FM user-ID scores."""
    root=Path(root)
    scores,report=validation_evidence(root,dataset)
    models=[]
    if dataset=='ml-latest-small':
        artifact=root/'artifacts'/'recommender.joblib'
        if artifact.is_file():
            models.append(ItemModel('small_svd',artifact,'Small SVD item factors',dataset,
                     scores.get('svd'),report))
        return models
    for b in _baseline_sources(root,dataset):
        file=Path(b['path'])
        if not file.is_file():continue
        for method,aliases in [('bpr',('bpr_chrono','bpr_mf','bpr')),
                               ('svd',('svd_chrono','svd'))]:
            ndcg=next((scores[x] for x in aliases if x in scores),None)
            models.append(ItemModel(method,file,
                f'{method.upper()} · {b["name"]}',dataset,ndcg,report))
    # An HOFM/FM trained for known users can still provide learned movie-ID
    # *representations* for item-to-item retrieval. This does NOT apply the FM
    # forward() user-ID score, so results remain a cold-start adaptation.
    from .engines import temporal_checkpoints
    for ckpt in temporal_checkpoints(root,dataset):
        # DeepFM's item factors are usable, but avoid claiming that its MLP was
        # executed for an anonymous visitor. Its representation is not exposed here.
        if ckpt['name'].startswith('deepfm_'):continue
        order=int(ckpt.get('fm_order',2))
        if order not in (2,3):continue
        path=Path(ckpt['path'])/'weights.pt'
        method='hofm3_item' if order==3 else 'fm_item'
        ndcg=scores.get(ckpt['name'])
        models.append(ItemModel(method,path,
           f'{"HOFM3" if order==3 else "FM"} movie factors · {ckpt["name"]}',
           dataset,ndcg,report))
    return models


def choose_item_model(models:list[ItemModel], choice:str='auto')->ItemModel | None:
    """Select best *compatible* model using only comparable evidence.

    If there is no matched BPR/SVD evidence, use the deterministic BPR-first
    fallback (a preference, NOT an accuracy claim). Users can override it.
    """
    if choice!='auto':
        return next((m for m in models if m.method==choice or m.name==choice),None)
    with_scores=[m for m in models if m.ndcg is not None]
    if with_scores:return max(with_scores,key=lambda m:m.ndcg)
    return next((m for m in models if m.method in ('bpr','small_svd')),models[0] if models else None)


@lru_cache(maxsize=6)
def _factor_cache(path:str,mtime_ns:int,method:str):
    with np.load(path,allow_pickle=False) as arrays:
        key='bpr_item' if method=='bpr' else 'svd_item'
        if key not in arrays.files:raise ValueError(f'Factor archive lacks {key}')
        vectors=np.asarray(arrays[key],dtype=np.float32)
    if vectors.ndim!=2 or vectors.shape[0]<1 or vectors.shape[1]<1:
        raise ValueError('Malformed factor matrix')
    if not np.isfinite(vectors).all():raise ValueError('Nonfinite saved item embeddings')
    return vectors


@lru_cache(maxsize=4)
def _saved_fm_item_weights(path:str,mtime_ns:int,order:int):
    try:
        import torch
    except ImportError as exc:
        raise ImportError('PyTorch is required for your saved FM/HOFM3 movie vectors') from exc
    # Only load model weights YOU trained in your trusted Codespace.
    # weights_only=True prevents arbitrary object deserialization.
    try:
        state=torch.load(path,map_location='cpu',weights_only=True)
    except Exception as exc:
        raise ValueError('Unable to safely read trained FM checkpoint') from exc
    if not isinstance(state,dict) or 'movie.weight' not in state:
        raise ValueError('FM checkpoint has no movie.weight factor matrix')
    base=state['movie.weight'].detach().cpu().numpy().astype(np.float32)
    if base.ndim!=2 or base.shape[0]<2 or not np.isfinite(base).all():
        raise ValueError('Malformed FM movie vectors')
    pieces=[base]
    if order==3:
        if 'third_movie.weight' not in state:
            raise ValueError('Degree-3 metadata but missing third_movie.weight')
        higher=state['third_movie.weight'].detach().cpu().numpy().astype(np.float32)
        if higher.shape[0]!=base.shape[0] or not np.isfinite(higher).all():
            raise ValueError('Degree-3 movie factor matrix does not align')
        # Separate normalizations stop either factor order dominating by scale.
        pieces=[base/np.maximum(np.linalg.norm(base,axis=1,keepdims=True),1e-9),
                higher/np.maximum(np.linalg.norm(higher,axis=1,keepdims=True),1e-9)]
    return np.column_stack(pieces)


def _item_vectors(item_model:ItemModel,root:Path,frame:pd.DataFrame)->np.ndarray:
    if item_model.method=='small_svd':
        from src.recommender import HybridRecommender
        # Important: trusted artifact only. The owner trained this checkpoint.
        engine=HybridRecommender.load(item_model.source)
        vec=np.asarray(engine.item_latent,dtype=np.float32)
        raw_ids=np.asarray(engine.movie_ids,dtype=np.int64)
        if len(vec)!=len(raw_ids):raise ValueError('Small SVD item vectors do not match movie IDs')
    else:
        from .engines import get_events
        ev=get_events(root,item_model.dataset)
        if item_model.method in ('fm_item','hofm3_item'):
            manifest_path=item_model.source.parent/'metadata.json'
            manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
            order=3 if item_model.method=='hofm3_item' else 2
            if int(manifest.get('fm_order',2))!=order:
                raise ValueError('Saved FM degree does not match advertised checkpoint')
            cutoff_key='train_cutoff'
            if manifest.get('dataset')!=item_model.dataset or \
               manifest.get('sources')!=ev.meta.get('sources') or \
               manifest.get(cutoff_key)!=ev.meta.get('train_cutoff'):
                raise ValueError('Item vectors belong to another dataset or historical cutoff')
            vec=_saved_fm_item_weights(str(item_model.source.resolve()),
                                       item_model.source.stat().st_mtime_ns,order)
            # FM/HOFM embedding row 0 is padding; event indices are zero-based.
            vec=vec[1:]
        else:
            manifest_path=item_model.source.parent/'manifest.json'
            manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
            cutoff_key='cutoff'
            vec=_factor_cache(str(item_model.source.resolve()),
                              item_model.source.stat().st_mtime_ns,item_model.method)
        if manifest.get('dataset')!=item_model.dataset or \
           manifest.get('sources')!=ev.meta.get('sources') or \
           manifest.get(cutoff_key)!=ev.meta.get('train_cutoff'):
            raise ValueError('Item vectors belong to another dataset or historical cutoff')
        raw_ids=np.asarray(ev.movies.movieId,dtype=np.int64)
        if len(vec)!=len(raw_ids):raise ValueError('Item factor matrix does not align to MovieLens catalogue')
        if hasattr(ev,'movie_has_train'):
            warm=np.asarray(ev.movie_has_train,dtype=bool)
            vec=vec.copy();vec[~warm]=0
    # The catalogue source may have a different row order. Match by movieId.
    if np.array_equal(raw_ids,frame.movieId.to_numpy(dtype=np.int64)):
        return vec
    src={int(raw):i for i,raw in enumerate(raw_ids)}
    index=np.fromiter((src.get(int(x),-1) for x in frame.movieId),dtype=np.int64,count=len(frame))
    out=np.zeros((len(frame),vec.shape[1]),dtype=np.float32)
    ok=index>=0
    out[ok]=vec[index[ok]]
    return out


def _factor_scores(item_vectors:np.ndarray,indices:list[int])->np.ndarray:
    """Cosine item-to-profile similarity. This is an anonymous *adaptation* of
    item embeddings, not the trained matrix-factorization user tower.
    """
    mat=np.asarray(item_vectors,dtype=np.float32)
    if mat.ndim!=2:raise ValueError('Expected 2D item embeddings')
    length=np.linalg.norm(mat,axis=1)
    safe=np.maximum(length,1e-10)
    norm=mat/safe[:,None]
    accepted=[i for i in indices if length[i]>1e-8]
    if not accepted:raise ValueError('Selected favorites have no trained item factors')
    preference=norm[accepted].mean(axis=0)
    norm_pref=float(np.linalg.norm(preference))
    if norm_pref<1e-8:raise ValueError('Selected favorites cancel out in latent space')
    return (norm@(preference/norm_pref)).astype(np.float32)


def favorite_recommend(root:Path,dataset:str,frame:pd.DataFrame,favorites:list[int],
                       *,k:int=12,genre:str='All genres',strategy:str='auto',
                       content_weight:float=.25)->FavoriteResult:
    """Generate recommendations based on chosen titles and saved movie factors.

    The factor profile is built from only the chosen favorites; no held-out
    users/ratings or anonymous-user-ID substitution. The genre/title blend is
    declared, and fallback is honest about missing/incompatible checkpoints.
    """
    if not 0<=content_weight<=1:raise ValueError('content_weight must be between 0 and 1')
    frame=frame.reset_index(drop=True)
    ids=catalog_index(frame)
    fav_idx=[ids[int(v)] for v in dict.fromkeys(favorites) if int(v) in ids]
    if not fav_idx:raise ValueError('Choose at least one movie present in the catalogue')
    # Same fallback as previous working feature; returns no excluded titles.
    def fallback():
        return content_recommendations(frame,favorites,k=k,genre=genre)
    if strategy=='content':
        return FavoriteResult(fallback(),'Title + genre similarity','No trained model required',
                  'Content-based similarity only; no trained FM or LambdaRank was used.')
    models=available_item_models(root,dataset)
    model=choose_item_model(models,strategy)
    if model is None:
        return FavoriteResult(fallback(),'Title + genre similarity (fallback)',
           'No compatible factor checkpoint is available locally',
           'To use trained matrix factorization, train a chronological SVD/BPR-MF baseline. '
           'FM/HOFM3/LambdaRank require a known user profile and cannot directly score an anonymous visitor.')
    try:
        vectors=_item_vectors(model,Path(root),frame)
        factor=_factor_scores(vectors,fav_idx)
    except (ValueError,OSError,FileNotFoundError,KeyError,ImportError,RuntimeError) as exc:
        return FavoriteResult(fallback(),'Title + genre similarity (fallback)',
           f'{model.name} unavailable: {exc}',
           'A saved checkpoint could not be aligned with the current catalogue or feature data. '
           'No trained-model recommendation was claimed.')
    # Create content similarity for *all* movies, not only the previous top K.
    from sklearn.feature_extraction.text import TfidfVectorizer
    text=(frame.title.fillna('').str.replace(r'\(\d{4}\)\s*$','',regex=True)+' '+
          frame.genres.fillna('').str.replace('|',' ',regex=False)*3)
    features=TfidfVectorizer(strip_accents='unicode',ngram_range=(1,2),
             token_pattern=r'(?u)\b\w+\b',min_df=1).fit_transform(text)
    prof=np.asarray(features[fav_idx].mean(axis=0)).ravel()
    prof/=max(np.linalg.norm(prof),1e-10)
    content=np.asarray(features@prof).ravel().astype('float32')
    # Both scores are cosine-type in [-1,1]; don't min-max on unseen full catalogue.
    factor01=np.clip((factor+1)/2,0,1)
    combined=(1-content_weight)*factor01+content_weight*np.clip(content,0,1)
    eligible=movie_filter(frame,genre)
    eligible[np.array(fav_idx,dtype=int)]=False
    # Do not present latent similarity for untrained items with zero-length vectors.
    eligible &= np.linalg.norm(vectors,axis=1)>1e-8
    movies=top_results(frame,combined,eligible,k,'Recommendation score')
    if len(movies):
        lookup=catalog_index(frame)
        idx=np.array([lookup[int(i)] for i in movies.movieId],dtype=int)
        movies['Latent affinity']=np.round(factor01[idx],3)
        movies['Content affinity']=np.round(np.clip(content[idx],0,1),3)
    evidence=(f'{model.name}; validation NDCG@K={model.ndcg:.4f} '
              f'in {model.evidence}' if model.ndcg is not None else
              f'{model.name}; trained factors available, but no matched NDCG evidence')
    caution=('Anonymous preference vectors are inferred from chosen item factors. '
             'Offline known-user NDCG does NOT validate this cold-start transformation. '
             'When HOFM3 factors are selected, its trained item-ID representations are used, NOT its original user-ID forward score. '
             'JointBCD and LambdaRank remain available separately in the Known User tab.')
    return FavoriteResult(movies, f'{model.name} + title/genre blend',evidence,caution)
