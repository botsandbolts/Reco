"""Movie-first, mobile-friendly recommendation page.

Installed additively; the original Reco Studio application and models stay intact.
"""
from __future__ import annotations
from .catalog import genre_options, favorites_matching
from .favorite_models import (available_item_models, observed_best_model,
                              favorite_recommend)

def render_favorites(st,root,dataset):
    st.subheader('Discover movies from your favorites')
    from .interface import _catalog, _display_recs
    df=_catalog(st,root,dataset)
    if df is None:return
    st.caption(f'{len(df):,} films · Choose titles you enjoyed, then get new movie recommendations')
    query=st.text_input('Search for favorite movies',value='',placeholder='Type part of a title, e.g. Matrix',key='favorite_search')
    options=favorites_matching(df,query,limit=70)
    choices={f'{row.title} · #{int(row.movieId)}':int(row.movieId)
             for row in options.itertuples(index=False)}
    found=st.multiselect('Choose favorites from search results',list(choices),
                         key=f'fav_select_{dataset}',max_selections=8)
    # Preserve prior favorites across search queries and reruns.
    key=f'favorite_ids_{dataset}';st.session_state.setdefault(key,[])
    if st.button('Add selected to favorites',key='add_favorites'):
        st.session_state[key]=list(dict.fromkeys(st.session_state[key]+[choices[n] for n in found]))
    selected=st.session_state[key]
    if selected:
        mapping=df.set_index('movieId')
        st.write('**Selected favorites:** ', ', '.join(str(mapping.loc[x].title) for x in selected if x in mapping.index))
        if st.button('Clear favorites',key='clear_favs'):st.session_state[key]=[];st.rerun()
    factors=available_item_models(root,dataset)
    best,winner_score,evidence=observed_best_model(root,dataset)
    if best is not None:
        st.caption(f'Best measured known-user model in a single benchmark: **{best}** '
                   f'(NDCG@K {winner_score:.4f}; {evidence}). '
                   'This is not a measured score for anonymous favorite-based recommendations.')
    else:
        st.caption('No matched known-user benchmark found. Only models actually saved in '
                   'your Codespace can be used for movie recommendations.')
    mode_names=['Auto · strongest compatible saved model',
                *[f'{m.name}' for m in factors],
                'Title / genre similarity (no checkpoint)']
    mode=st.selectbox('Recommendation engine',mode_names,key=f'fav_engine_{dataset}')
    strategy=('auto' if mode==mode_names[0] else
              'content' if mode==mode_names[-1] else mode)
    controls=st.columns([2,1])
    with controls[0]:g=st.selectbox('Optional genre',genre_options(df),key='fav_genre')
    with controls[1]:k=st.slider('How many?',5,40,12,key='fav_k')
    st.caption('The auto engine uses locally trained HOFM3, FM, BPR-MF or SVD movie factors when '
               'available. A new viewer has no known user ID, so the original FM/HOFM3 and '
               'LambdaRank user-ID scoring models cannot directly serve this page. '
               'Those are available under Recommendations for known users.')
    if st.button('🎬 Get recommended films',type='primary',key='find_similar'):
        if not selected: st.warning('First add at least one favorite movie.')
        else:
            with st.spinner('Ranking the catalogue using your chosen movies...'):
                result=favorite_recommend(root,dataset,df,selected,k=k,genre=g,strategy=strategy)
            st.session_state['fav_last']=(dataset,tuple(selected),k,g,strategy,result)
    past=st.session_state.get('fav_last')
    if past and past[:5]==(dataset,tuple(selected),k,g,strategy):
        output=past[5]
        st.markdown(f'**Recommendation method:** {output.method}')
        st.caption(output.evidence)
        st.info(output.caution)
        _display_recs(st,output.movies,'Movies you might enjoy','favorites')
    st.divider()
    with st.expander('Browse and filter the movie catalogue'):
        filter_text=st.text_input('Filter titles',key='browse_title')
        selection=favorites_matching(df,filter_text,limit=120)
        st.dataframe(selection,hide_index=True,use_container_width=True)

