"""Reversible integration of best-compatible favorite-based recommendations.

Only adjusts import and tab wiring. Does NOT replace Reco Studio interface,
FM/HOFM3/JointBCD ranker loader, checkpoints, reports or datasets.
"""
from __future__ import annotations
from pathlib import Path
import ast
import argparse

IMPORT='from .favorite_page import render_favorites\n'
OLD_TABS="tabs=st.tabs(['🎯 Recommendations','❤️ Favorite-based discovery','📊 Compare models',"
NEW_TABS="tabs=st.tabs(['🎬 Choose films & recommend','🎯 Known-user recommendations','📊 Compare models',"
OLD_FUNCS='funcs=(_known_user,_discover_movies,_model_comparisons,_training,_retrieval,_umap,_setup)'
NEW_FUNCS='funcs=(render_favorites,_known_user,_model_comparisons,_training,_retrieval,_umap,_setup)'


def install(root:Path=Path('.')):
    root=Path(root).resolve()
    target=root/'reco_studio/interface.py'
    if not (root/'reco_studio/favorite_models.py').is_file() or not (root/'reco_studio/favorite_page.py').is_file():
        raise FileNotFoundError('Extract this ZIP into /workspaces/Reco before installing')
    if not target.is_file():
        raise FileNotFoundError('Reco Studio missing. First install reco_studio_complete_patch.zip')
    original=target.read_text(encoding='utf-8')
    if NEW_FUNCS in original and IMPORT in original:
        print('Already installed. No files changed.')
        return False
    if original.count(OLD_FUNCS)!=1 or original.count(OLD_TABS)!=1:
        raise ValueError('Unknown Reco Studio interface version. Refusing to overwrite your custom UI. '
                         'Check the README and share your interface.py if you need a tailored installer.')
    if IMPORT in original:
        raise ValueError('Partial previous install; refusing automatic changes')
    lines=original.splitlines(keepends=True)
    spot=next((i for i,line in enumerate(lines) if line.startswith('def _css(')),None)
    if spot is None:raise ValueError('Expected Reco Studio _css entry point not found')
    lines.insert(spot,IMPORT+'\n')
    updated=''.join(lines).replace(OLD_TABS,NEW_TABS,1).replace(OLD_FUNCS,NEW_FUNCS,1)
    ast.parse(updated)
    backup=target.with_name('interface.py.before_best_favorites.bak')
    if backup.exists():
        if backup.read_bytes()!=target.read_bytes():
            raise FileExistsError('A different prior backup exists; refusing to replace it')
    else:
        backup.write_text(original,encoding='utf-8')
    # A minimal atomic replacement avoids an interrupted Streamlit script.
    pending=target.with_name('interface.py.best_favorites.pending')
    pending.write_text(updated,encoding='utf-8')
    pending.replace(target)
    print(f'Installed 🎬 Choose films & recommend as the first Reco Studio tab. Backup: {backup}')
    return True


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,default=Path('.'))
    args=p.parse_args()
    install(args.root)
