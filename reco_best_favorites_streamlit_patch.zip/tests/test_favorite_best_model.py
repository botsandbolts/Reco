"""Offline tests for anonymous movie choice and trained-factor adaptation."""
import json
import numpy as np
import pandas as pd
import pytest
from reco_studio import favorite_models as fm


def movies():
    return pd.DataFrame({'movieId':[11,12,13,14,15,16],
      'title':['Galaxy One (2001)','Galaxy Two (2002)','Forest (1990)',
               'Love (1998)','Galaxy Three (2003)','Comet (2010)'],
      'genres':['Sci-Fi','Sci-Fi','Drama','Romance','Sci-Fi','Sci-Fi']})


def write_json(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj),encoding='utf-8')


def test_report_winner_cannot_merge_incompatible_reports(tmp_path):
    r=tmp_path/'reports/temporal/ml-32m'
    write_json(r/'ranking_a.json',{'dataset':'ml-32m','split':'validation',
      'candidate_policy':'full','metrics':{'bpr_chrono':{'ndcg_at_k':.09},
                    'svd_chrono':{'ndcg_at_k':.08},'fm_all_hofm3semi25_bpr':{'ndcg_at_k':.12}}})
    write_json(r/'ranking_b.json',{'dataset':'ml-32m','split':'validation',
      'candidate_policy':'sampled','metrics':{'bpr_chrono':{'ndcg_at_k':.999}}})
    # Recency is controlled by filename mtime, not lexical order.
    import os,time
    os.utime(r/'ranking_a.json',(time.time()-10,time.time()-10))
    os.utime(r/'ranking_b.json',(time.time(),time.time()))
    scores,report=fm.validation_evidence(tmp_path,'ml-32m')
    assert scores['bpr_chrono']==.09
    assert 'ranking_a.json' in report
    winner,score,_=fm.observed_best_model(tmp_path,'ml-32m')
    assert winner=='fm_all_hofm3semi25_bpr' and score==.12


def test_auto_selects_best_usable_not_hofm_checkpoint(tmp_path,monkeypatch):
    a=fm.ItemModel('svd',tmp_path/'a.npz','SVD','ml-32m',.12,'matched')
    b=fm.ItemModel('bpr',tmp_path/'b.npz','BPR','ml-32m',.14,'matched')
    assert fm.choose_item_model([a,b]).name=='BPR'
    assert fm.choose_item_model([a,b],'svd').name=='SVD'
    assert fm.choose_item_model([a,b],'content') is None
    unmeasured=fm.ItemModel('svd',tmp_path/'a.npz','SVD','ml-32m')
    assert fm.choose_item_model([unmeasured,b]).name=='BPR'


def test_factors_use_favorite_embeddings_and_exclude_favorites(tmp_path,monkeypatch):
    df=movies()
    vectors=np.array([[1,0],[.95,.05],[-1,0],[0,-1],[.85,.15],[.75,.25]],dtype='float32')
    model=fm.ItemModel('bpr',tmp_path/'factors.npz','BPR-MF trained','ml-32m',.08)
    monkeypatch.setattr(fm,'available_item_models',lambda *a:[model])
    monkeypatch.setattr(fm,'_item_vectors',lambda *a:vectors)
    rec=fm.favorite_recommend(tmp_path,'ml-32m',df,[11],k=3,content_weight=0)
    assert rec.method.startswith('BPR-MF trained')
    assert rec.movies.iloc[0].movieId==12
    assert 11 not in rec.movies.movieId.to_list()
    assert {'Latent affinity','Content affinity','Recommendation score'}.issubset(rec.movies)
    assert len(rec.movies)==3
    assert 'known-user NDCG' in rec.caution


def test_filter_and_no_backfill(tmp_path,monkeypatch):
    df=movies();vectors=np.ones((6,3),dtype='float32')
    monkeypatch.setattr(fm,'available_item_models',lambda *a:[fm.ItemModel('svd',tmp_path/'svd.npz','SVD','ml-32m')])
    monkeypatch.setattr(fm,'_item_vectors',lambda *a:vectors)
    rec=fm.favorite_recommend(tmp_path,'ml-32m',df,[11,12,15],k=20,genre='Sci-Fi')
    assert set(rec.movies.movieId)=={16}


def test_no_factors_fallback_never_claims_hofm(tmp_path,monkeypatch):
    monkeypatch.setattr(fm,'available_item_models',lambda *a:[])
    out=fm.favorite_recommend(tmp_path,'ml-32m',movies(),[11],k=4)
    assert 'fallback' in out.method
    assert 'HOFM3' in out.caution
    assert 11 not in out.movies.movieId.to_list()


def test_mismatch_factors_produces_honest_fallback(tmp_path,monkeypatch):
    model=fm.ItemModel('bpr',tmp_path/'missing.npz','BPR','ml-32m')
    monkeypatch.setattr(fm,'available_item_models',lambda *a:[model])
    monkeypatch.setattr(fm,'_item_vectors',lambda *a: (_ for _ in ()).throw(ValueError('bad checksum')))
    rec=fm.favorite_recommend(tmp_path,'ml-32m',movies(),[11],k=3)
    assert 'fallback' in rec.method
    assert 'bad checksum' in rec.evidence
    assert 'No trained-model recommendation' in rec.caution


def test_factor_function_is_cosine_and_handles_zero():
    data=np.array([[3,0],[1,0],[0,2]],dtype='float32')
    scores=fm._factor_scores(data,[0])
    assert scores[1]==pytest.approx(1.0)
    assert scores[2]==pytest.approx(0)
    with pytest.raises(ValueError,match='no trained'):fm._factor_scores(np.zeros((2,2)),[0])


def test_checkpoint_manifest_alignment_is_strict(tmp_path,monkeypatch):
    dataset='ml-32m'
    file=tmp_path/'models/ml-32m/shared_chrono_baselines/abc/factors.npz'
    file.parent.mkdir(parents=True)
    np.savez_compressed(file,bpr_item=np.ones((2,2),dtype='float32'))
    write_json(file.parent/'manifest.json',{'dataset':dataset,'sources':{'ratings':'a'},'cutoff':42})
    class EV:
        meta={'sources':{'ratings':'b'},'train_cutoff':42}
        movies=pd.DataFrame({'movieId':[11,12]})
    from reco_studio import engines
    monkeypatch.setattr(engines,'get_events',lambda *a:EV())
    with pytest.raises(ValueError,match='another dataset'):
        fm._item_vectors(fm.ItemModel('bpr',file,'BPR',dataset),tmp_path,
                         pd.DataFrame({'movieId':[11,12]}))


def test_small_artifact_absent_uses_catalog_only(tmp_path):
    out=fm.favorite_recommend(tmp_path,'ml-latest-small',movies(),[11],k=5)
    assert not out.movies.empty
    assert 'fallback' in out.method


def test_real_npz_item_factors_drive_favorite_recommendation(tmp_path,monkeypatch):
    """Full disk-to-results smoke without substituting a fake item-vector loader."""
    frame=movies().iloc[[2,0,5,1,4,3]].reset_index(drop=True)
    dataset='ml-32m'
    # Model's original event catalogue order deliberately differs from UI order.
    event_movies=movies()
    class EV:
        movies=event_movies
        meta={'sources':{'r':'sha256:abc'},'train_cutoff':123}
        movie_has_train=np.ones(len(event_movies),dtype=bool)
    from reco_studio import engines
    monkeypatch.setattr(engines,'get_events',lambda *a:EV())
    folder=tmp_path/'models/ml-32m/shared_chrono_baselines/run1'
    folder.mkdir(parents=True)
    path=folder/'factors.npz'
    vec=np.array([[1,0],[.99,.01],[-1,0],[0,-1],[.92,.08],[.8,.2]],dtype=np.float32)
    np.savez_compressed(path,bpr_item=vec,svd_item=-vec)
    write_json(folder/'manifest.json',{
        'dataset':dataset,'sources':{'r':'sha256:abc'},'cutoff':123})
    monkeypatch.setattr(fm,'validation_evidence',lambda *args:({'bpr_chrono':.071,'svd_chrono':.042},'shared.json'))
    out=fm.favorite_recommend(tmp_path,dataset,frame,[11],k=4,content_weight=0)
    assert out.movies.iloc[0].movieId==12
    assert 11 not in set(out.movies.movieId)
    assert out.method.startswith('BPR')
    assert 'NDCG' in out.evidence
    assert 'trained' not in out.method.lower() or out.method.startswith('BPR')


def test_hofm3_item_embeddings_are_read_from_real_degree_three_weights(tmp_path,monkeypatch):
    """Use the actual learned movie-ID parameters; never fake FM forward scores."""
    import torch
    frame=movies().iloc[[3,2,0,5,4,1]].reset_index(drop=True)
    dataset='ml-32m'
    folder=tmp_path/'models/ml-32m/temporal_fm/fm_all_hofm3semi25_bpr'
    folder.mkdir(parents=True)
    # Embedding row 0 is padding; row i+1 represents event movie i.
    item=np.array([[0,0],[1,0],[.98,.02],[-1,0],[0,-1],[.9,.1],[.8,.2]],dtype=np.float32)
    third=np.array([[0,0],[1,0],[.95,.05],[-1,0],[0,-1],[.8,.2],[.7,.3]],dtype=np.float32)
    torch.save({'movie.weight':torch.from_numpy(item),
                'third_movie.weight':torch.from_numpy(third)},folder/'weights.pt')
    write_json(folder/'metadata.json',{'fm_order':3,'dataset':dataset,
                                     'sources':{'r':'hash'},'train_cutoff':42})
    class EV:
        movies=movies()
        movie_has_train=np.ones(6,dtype=bool)
        meta={'sources':{'r':'hash'},'train_cutoff':42}
    from reco_studio import engines
    monkeypatch.setattr(engines,'get_events',lambda *a:EV())
    monkeypatch.setattr(fm,'validation_evidence',lambda *a:({
       'fm_all_hofm3semi25_bpr':.10,'bpr_chrono':.07},'matched.json'))
    # Other SVD/BPR sources omitted so HOFM3 is the winning *compatible* item model.
    out=fm.favorite_recommend(tmp_path,dataset,frame,[11],k=3,content_weight=0)
    assert out.method.startswith('HOFM3 movie factors')
    assert out.movies.iloc[0].movieId==12
    assert 11 not in set(out.movies.movieId)
    assert 'original user-ID forward score' in out.caution


def test_hofm3_mismatch_refuses_to_claim_model(tmp_path,monkeypatch):
    folder=tmp_path/'models/ml-32m/temporal_fm/fm_all_hofm3semi25_bpr'
    folder.mkdir(parents=True)
    (folder/'weights.pt').write_bytes(b'not a model')
    write_json(folder/'metadata.json',{'fm_order':3,'dataset':'ml-32m',
                                      'sources':{'r':'other'},'train_cutoff':42})
    class EV:
        movies=movies()
        meta={'sources':{'r':'correct'},'train_cutoff':42}
    from reco_studio import engines
    monkeypatch.setattr(engines,'get_events',lambda *a:EV())
    monkeypatch.setattr(fm,'validation_evidence',lambda *a:({'fm_all_hofm3semi25_bpr':.10},'matched.json'))
    out=fm.favorite_recommend(tmp_path,'ml-32m',movies(),[11],k=2)
    assert 'fallback' in out.method
    assert 11 not in set(out.movies.movieId)
