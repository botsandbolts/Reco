import importlib.util
from pathlib import Path
import pytest


def _mod():
    file=Path(__file__).resolve().parents[1]/'scripts/install_best_favorites.py'
    spec=importlib.util.spec_from_file_location('favorite_installer',file)
    result=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def _app(tmp_path):
    src = """# PATCH CUSTOM

def _css(st):
    pass

def render(st):
    tabs=st.tabs(['🎯 Recommendations','❤️ Favorite-based discovery','📊 Compare models',
                  '📈 Training & epochs','🌳 Retrieval / LambdaRank','🗺️ Genre UMAP','⚙️ Setup & checkpoints'])
    funcs=(_known_user,_discover_movies,_model_comparisons,_training,_retrieval,_umap,_setup)
"""
    path=tmp_path/'reco_studio/interface.py'
    path.parent.mkdir(parents=True)
    path.write_text(src)
    (path.parent/'favorite_models.py').write_text('')
    (path.parent/'favorite_page.py').write_text('')
    return path


def test_install_only_rewires_tab_and_preserves_customizations(tmp_path):
    path=_app(tmp_path)
    result=_mod()
    assert result.install(tmp_path)
    updated=path.read_text()
    assert '🎬 Choose films & recommend' in updated
    assert 'render_favorites' in updated
    assert '# PATCH CUSTOM' in updated
    assert 'md.get' not in updated  # Nothing injects fake model handling.
    assert path.with_name('interface.py.before_best_favorites.bak').exists()
    assert result.install(tmp_path) is False
    assert path.with_name('interface.py.before_best_favorites.bak').read_text().count('PATCH CUSTOM')==1


def test_install_aborts_on_unknown_ui(tmp_path):
    path=_app(tmp_path)
    path.write_text('def render(): pass\n')
    with pytest.raises(ValueError,match='Unknown Reco Studio'):_mod().install(tmp_path)
    assert path.read_text()=='def render(): pass\n'


def test_installer_never_touches_model_weights(tmp_path):
    path=_app(tmp_path)
    weights=tmp_path/'models/ml-32m/temporal_fm/fm_all_hofm3semi25_bpr/weights.pt'
    weights.parent.mkdir(parents=True)
    weights.write_bytes(b'trained third order checkpoint')
    _mod().install(tmp_path)
    assert weights.read_bytes()==b'trained third order checkpoint'
