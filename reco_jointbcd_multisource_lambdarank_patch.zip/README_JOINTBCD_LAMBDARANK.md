# Joint B+C+D + FM/SVD/BPR-MF + LightGBM LambdaRank

This additive patch makes the **trained Stage-D correction (`jointBCD`)** a real multi-source LambdaRank input and a candidate retrieval source, alongside the optional **third-order HOFM3**. It does not retrain or modify the original `fm_all_semi25_bpr` or the Stage-D weights. A new LightGBM checkpoint is saved separately.

## Prerequisites

In your Codespace `/workspaces/Reco`, you must already have:

- `temporal_fm` with `preference_experiment.py` (B–E patch), plus `advanced_retrieval.py` and `advanced_ltr.py` (advanced ranking patch).
- The trained FM checkpoint `models/ml-32m/temporal_fm/fm_all_semi25_bpr/weights.pt`.
- For the full FM mixture, the *third-order* FM checkpoint `models/ml-32m/temporal_fm/fm_all_hofm3semi25_bpr/weights.pt` and the degree-3 checkpoint loader. If missing, pass `--aux-fm-model none` to run without HOFM3.
- The completed Stage-D model `models/ml-32m/temporal_preferences/fm_all_semi25_bpr_d_jointBCD/weights.pt` and matching metadata. Train Stage D first with `python -m temporal_fm.preference_experiment --base-model fm_all_semi25_bpr --stage d --run-label jointBCD ...` if needed.
- Prepared data and cached Sentence Transformer features under `data/temporal/ml-32m`.
- SVD/BPR-MF baselines will be fitted/loaded by the existing shared benchmark code; they do not need pretrained checkpoints if that pipeline is installed.

### Install

Upload `reco_jointbcd_multisource_lambdarank_patch.zip` to the root of GitHub `herberton777/Reco`:

```bash
cd /workspaces/Reco
git fetch origin main
git show origin/main:reco_jointbcd_multisource_lambdarank_patch.zip > reco_jointbcd_multisource_lambdarank_patch.zip
unzip -o reco_jointbcd_multisource_lambdarank_patch.zip
python -m pip install -r requirements-advanced-ltr.txt
python -m pytest -q tests/test_jointbcd_lambdarank.py
python scripts/install_jointbcd_studio.py
```

If `requirements-advanced-ltr.txt` does not exist, install/extract the earlier `reco_advanced_ranking_complete.zip` first, **without overwriting a later FM trainer or checkpoint loader**.

### Train research-level LambdaRank — 4 CPUs

```bash
cd /workspaces/Reco
set -o pipefail
OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 \
python -u -m temporal_fm.jointbcd_lambdarank \
  --dataset ml-32m --backend sentence \
  --base-model fm_all_semi25_bpr --preference-label jointBCD \
  --ranker-train-users 700 --ranker-valid-users 200 --eval-users 300 \
  --fm-candidates 500 --hofm3-candidates 200 \
  --aux-fm-model fm_all_hofm3semi25_bpr \
  --svd-candidates 200 --bpr-candidates 200 \
  --pop-candidates 100 --semantic-candidates 100 \
  --joint-pool 2000 --jointbcd-candidates 300 \
  --baseline-profile research --objective lambdarank \
  --trees 600 --leaves 15 --learning-rate 0.03 \
  --min-child-samples 60 --early-stop-rounds 40 \
  --k 10 --device cpu --threads 4 \
  --run-label jointBCD_multisource \
  2>&1 | tee jointBCD_lambdarank.log
```

If the third-order checkpoint is unavailable, replace `--aux-fm-model fm_all_hofm3semi25_bpr` with `--aux-fm-model none`; the other models remain in the mixture.

The terminal prints training group progress, early stopping and validation NDCG every **20 LightGBM trees**, plus final disjoint-cohort metrics. Results go to `reports/temporal/ml-32m/advanced_ltr_validation_jointBCD_multisource_*.json`. The trained LightGBM checkpoint lives under `models/ml-32m/temporal_fm/advanced_ltr/jointBCD_multisource_*/model.txt` and will be visible in Reco Studio.

### View in Streamlit

Use your existing Reco Studio, or the advanced research dashboard. With Reco Studio already installed, run `python scripts/install_jointbcd_studio.py` to activate on-demand **movie recommendations using this new LambdaRank**; the installer backs up `reco_studio/engines.py`. It refuses unexpected code versions. Start `streamlit run reco_studio_app.py --server.port 8502`. Select the base FM checkpoint `fm_all_semi25_bpr` and new LambdaRank checkpoint in Recommendations.

For direct reports: `streamlit run temporal_fm/advanced_dashboard.py --server.port 8503`.

### Benchmark integrity

- Stage D is B+C+D together. This patch **does not require training B and C separately**.
- Stage-D retrieves only from the **top 2,000 already-retrieved FM movies**, reranking them to contribute 300 candidates. The other generators, including optional independent HOFM3 retrieval, broaden the union. Thus Stage-D is **not an independent full-catalogue recall method**.
- Candidate lists are built without held-out labels. Early-stop users are disjoint from ranker training and reported evaluation users. User-history/time features use only pre-cutoff training ratings.
- LightGBM internal NDCG is conditional on candidate retrieval and groups having a relevant item. Use the disjoint evaluation report instead.
- The rankings of FM, JointBCD, SVD and BPR **within the shared union** are not identical to their full-catalogue rankings. Do not compare those scores to older evaluations on a different cohort, cutoff or candidate policy.
- The data and checkpoint signatures are verified; checkpoint weight hashes are recorded, so a retrain of the frozen FM or preference head produces a different experiment identity.
- Actual MovieLens 32M training must run in Codespaces; synthetic tests cannot establish ranking gains.
