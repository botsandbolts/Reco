"""Correct an old ranking._model metadata compatibility bug without disabling validation.

Older FM checkpoints store source fingerprints under metadata['sources'], whereas
some released ranking loaders incorrectly look for metadata['ratings'] etc.
"""
from __future__ import annotations
import ast
from pathlib import Path

TARGET=Path('temporal_fm/ranking.py')
OLD="if meta.get(key)!=val:\n            raise ValueError(f'{name}: original {key} data changed since training')"
NEW="if meta.get('sources', {}).get(key, meta.get(key))!=val:\n            raise ValueError(f'{name}: original {key} data changed since training')"

def install(path=TARGET):
    path=Path(path)
    if not path.exists():raise FileNotFoundError(f'Missing {path}. Install temporal_fm ranking first.')
    source=path.read_text(encoding='utf-8')
    if NEW in source:
        print('Source signature fix already installed.')
        return True
    if OLD not in source:
        print('The ranking loader differs from the known legacy implementation; no changes made.')
        return False
    updated=source.replace(OLD,NEW,1)
    ast.parse(updated)
    path.with_suffix('.py.before_source_fix.bak').write_text(source,encoding='utf-8')
    path.write_text(updated,encoding='utf-8')
    print(f'Fixed nested source signature validation in {path}; original backed up.')
    return True

if __name__=='__main__':install()
