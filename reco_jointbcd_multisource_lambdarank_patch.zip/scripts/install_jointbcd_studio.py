"""Safely integrate new jointBCD LambdaRank into an existing Reco Studio app.

This installer patches only one entry point in reco_studio/engines.py, backing it up.
It is idempotent and will refuse unknown/changed source layouts.
"""
from __future__ import annotations
import ast
from pathlib import Path

TARGET=Path('reco_studio/engines.py')
ANCHOR="    md=ranker['metadata']\n"
INSERT="""    md=ranker['metadata']
    if md.get('reranker_type') == 'jointbcd':
        from temporal_fm.jointbcd_lambdarank import make_retriever
        from temporal_fm.ranking import _train_counts
        from temporal_fm.advanced_retrieval import _best
        import hashlib
        if md.get('cutoff') != ev.meta.get('train_cutoff') or md.get('sources') != ev.meta.get('sources'):
            raise ValueError('Joint BCD LambdaRank uses a different MovieLens snapshot')
        if md.get('backend') != provider.backend:
            raise ValueError('Joint BCD LambdaRank feature backend mismatch')
        head_path = Path(md['preference_checkpoint']) / 'weights.pt'
        actual_digest = hashlib.sha256(head_path.read_bytes()).hexdigest()
        if actual_digest != md['preference_sha256']:
            raise ValueError('Stage D checkpoint changed since LambdaRank training')
        base_path = Path('models') / ev.meta['dataset'] / 'temporal_fm' / md['base_model'] / 'weights.pt'
        if md.get('base_sha256') and hashlib.sha256(base_path.read_bytes()).hexdigest() != md['base_sha256']:
            raise ValueError('FM checkpoint changed since LambdaRank training')
        aux_name = md.get('aux_fm_model')
        if aux_name and md.get('aux_sha256'):
            aux_path = Path('models') / ev.meta['dataset'] / 'temporal_fm' / aux_name / 'weights.pt'
            if hashlib.sha256(aux_path.read_bytes()).hexdigest() != md['aux_sha256']:
                raise ValueError('Auxiliary HOFM3 checkpoint changed since LambdaRank training')
        _, counts = _train_counts(ev)
        retriever = make_retriever(ev, provider, base,
            {int(user_id): set(seen)}, [int(user_id)], counts, md, threads=threads)
        q = retriever.query(int(user_id), set(seen), set(), md['quotas'])
        if q is None:
            raise ValueError('No eligible movies in retrieved candidate set')
        allowed = set(map(int, candidates))
        mask = np.isin(q['movies'], list(allowed))
        if not mask.any():
            raise ValueError('No LambdaRank movies match your current genre/year filters')
        booster = lgb.Booster(model_file=str(ranker['path']))
        if q['features'].shape[1] != booster.num_feature() or booster.num_feature() != len(md['feature_names']):
            raise ValueError('Saved LambdaRank feature dimensions do not match')
        values = np.asarray(booster.predict(q['features'][mask], num_threads=threads), dtype=np.float64)
        movies = q['movies'][mask]
        top = _best(values, k)
        result = ev.movies.iloc[movies[top]][['movieId', 'title', 'genres']].copy()
        result['LambdaRank score'] = np.round(values[top], 4)
        return result.reset_index(drop=True)
"""

def install(path=TARGET):
    path=Path(path)
    if not path.exists():
        print('Reco Studio not installed: leave it unchanged; use advanced_dashboard.py for results.')
        return False
    source=path.read_text(encoding='utf-8')
    if "md.get('reranker_type') == 'jointbcd'" in source:
        print('Joint BCD Reco Studio integration already installed.')
        return True
    if source.count(ANCHOR)!=1:
        raise ValueError('Unknown Reco Studio engine version; refusing to modify it')
    result=source.replace(ANCHOR,INSERT,1)
    ast.parse(result)
    path.with_suffix('.py.before_jointbcd.bak').write_text(source,encoding='utf-8')
    path.write_text(result,encoding='utf-8')
    print(f'Integrated jointBCD LambdaRank into {path} (backup preserved).')
    return True

if __name__=='__main__':install()
