"""Add a trained Stage-D (B+C+D) preference head to multi-source LambdaRank.

The trained FM and Stage-D head are frozen. Candidate generation is label-blind;
the Stage-D head reranks a large FM-retrieved pool, while SVD/BPR/pop/semantic
independently contribute candidates. LightGBM learns to combine their features.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import re
from pathlib import Path

import numpy as np
import torch

from .advanced_ltr import _split_users, _ranker_matrix
from .advanced_retrieval import AdvancedRetriever, _best, _rank_percentile, _retrieval_metrics
from .data import Events
from .lambdamart import FEATURE_NAMES as SNAPSHOT_FEATURES, _prepare, _aggregate, _paired_bootstrap
from .ranking import _cohort, _model, _ranking_scores, score_candidates
from .preference_experiment import (HistoryIndex, TemporalPreferenceFeatures,
                                    _checkpoint_info, _load_head)

CORE_SOURCES = ('fm', 'svd', 'bpr', 'pop', 'semantic')
SOURCES = (*CORE_SOURCES, 'hofm3', 'jointbcd')
DEFAULT_QUOTAS = {'fm':500, 'svd':200, 'bpr':200, 'pop':100,
                  'semantic':100, 'hofm3':200, 'jointbcd':300}
BASE_EXTRA = ['svd_score','bpr_score','semantic_title_score',
              'svd_rank_percentile','bpr_rank_percentile','semantic_rank_percentile']
MEMBERSHIP = [f'retrieved_by_{name}' for name in SOURCES]
JOINT_EXTRAS = ['jointbcd_score','jointbcd_delta','jointbcd_union_rank_percentile']


def feature_names(preference_names, include_hofm3=False):
    flags=[f'retrieved_by_{name}' for name in (*CORE_SOURCES, *(("hofm3",) if include_hofm3 else ()), "jointbcd")]
    aux=['hofm3_score','hofm3_rank_percentile'] if include_hofm3 else []
    return (list(SNAPSHOT_FEATURES)+BASE_EXTRA+aux+flags+['source_agreement']+
            JOINT_EXTRAS+[f'bcd_{name}' for name in preference_names])


def preference_folder(dataset, base_model, preference_label, root='models'):
    if not re.fullmatch(r'[a-zA-Z0-9_]+', preference_label):
        raise ValueError('Unsafe preference label; use the label supplied to preference_experiment')
    return Path(root)/dataset/'temporal_preferences'/f'{base_model}_d_{preference_label}'


def load_preference(ev, provider, base_model, folder, device, seed):
    folder=Path(folder)
    for name in ('weights.pt', 'metadata.json'):
        if not (folder/name).is_file():
            raise FileNotFoundError(f'Missing Stage-D B+C+D checkpoint: {folder/name}. '
                                    'Train --stage d with preference_experiment first.')
    expected=_checkpoint_info(ev,provider,base_model,'d',seed)
    head=_load_head(folder,expected,ev,provider,device)
    if head.stage!='d':raise ValueError('Preference checkpoint is not Stage D')
    return head


class JointBCDRetriever(AdvancedRetriever):
    """Multi-source retrieval with a genuine additional Stage-D candidate pool.

    Stage D scores a configurable *FM top-N pool*, not the full catalogue. This
    fact is retained in the report, to prevent calling it independent recall.
    """
    def __init__(self, ev, provider, model, histories, users, movie_pop, *,
                 head, joint_pool=2000, aux_model=None, **kwargs):
        if joint_pool < 1:raise ValueError('joint_pool must be positive')
        super().__init__(ev,provider,model,histories,users,movie_pop,
                         sources=CORE_SOURCES,**kwargs)
        self.head=head.eval();self.joint_pool=int(joint_pool)
        self.aux_model=aux_model.eval() if aux_model is not None else None
        self.active_sources=(*CORE_SOURCES, *(("hofm3",) if aux_model is not None else ()), 'jointbcd')
        self.builder=TemporalPreferenceFeatures(ev,provider,HistoryIndex(ev),'d')
        self.names=feature_names(self.builder.names,include_hofm3=aux_model is not None)
        self._weights=self.head.linear.weight.detach().cpu().numpy().astype(np.float32).ravel()
        if self._weights.shape!=(len(self.builder.names),):
            raise ValueError('Stage-D residual weights do not match feature schema')

    def _bcd_features(self,u,mids):
        mids=np.asarray(mids,dtype=np.int32)
        ctx=self.builder.context(u,self.cutoff)
        return self.builder.matrix(u,self.cutoff,mids,ctx=ctx)

    def query(self,u,history,truth,quotas=None,diagnostic_k=0):
        quotas={**DEFAULT_QUOTAS,**(quotas or {})}
        if any(int(quotas[name])<0 for name in SOURCES):
            raise ValueError('Source quotas must be nonnegative')
        if quotas['jointbcd']>self.joint_pool:
            raise ValueError('jointbcd quota cannot exceed joint_pool')
        unseen=np.setdiff1d(self.catalog,np.asarray(sorted(history),dtype=np.int32),assume_unique=True)
        if not len(unseen):return None
        # Base FM score is evaluated exactly once across all historically eligible movies.
        fm=score_candidates(self.model,self.ev,self.provider,u,unseen,self.cutoff,
                            device=self.device,batch_size=self.batch_size)
        full={'fm':fm,'pop':np.log1p(self.movie_pop[unseen]).astype(np.float32)}
        if self.baseline:
            ui=int(self.ev.user_indices(np.array([u],dtype=np.int32))[0])-1
            if ui<0:raise ValueError(f'Unknown training user {u}')
            for name,(user_vectors,item_vectors) in self.baseline.items():
                full[name]=(item_vectors[unseen]@user_vectors[ui]).astype(np.float32)
        full['semantic']=(self.snapshot.title[unseen] @ self.snapshot.title_affinity[int(u)]).astype(np.float32)
        if self.aux_model is not None:
            full['hofm3']=score_candidates(self.aux_model,self.ev,self.provider,u,unseen,self.cutoff,
                             device=self.device,batch_size=self.batch_size)
        if any(not np.isfinite(v).all() for v in full.values()):
            raise ValueError('Non-finite base retrieval score')
        # Candidate-aware preference head is applied to the FM short list.
        # It cannot import any held-out movie into retrieval.
        pool_local=_best(fm,max(self.joint_pool,quotas['jointbcd']))
        pool_features=self._bcd_features(u,unseen[pool_local])
        joint_pool_scores=fm[pool_local]+pool_features@self._weights
        joint_local=pool_local[_best(joint_pool_scores,quotas['jointbcd'])]
        selections={name:_best(full[name],int(quotas[name])) for name in self.active_sources if name!='jointbcd'}
        selections['jointbcd']=joint_local
        nonempty=[v for v in selections.values() if len(v)]
        if not nonempty:return None
        local=np.unique(np.concatenate(nonempty)).astype(np.int32)
        mids=unseen[local]
        flags={name:np.isin(local,selected).astype(np.float32)
               for name,selected in selections.items()}
        fm_rank=_rank_percentile(fm[local])*max(1,len(local)-1)
        popularity_mids=unseen[selections['pop']]
        snapshot_features=self.snapshot.features(u,mids,fm[local],fm_rank,popularity_mids)
        extra=[full[name][local] for name in ('svd','bpr','semantic')]
        extra.extend(_rank_percentile(full[name])[local] for name in ('svd','bpr','semantic'))
        if self.aux_model is not None:
            extra.extend([full['hofm3'][local],_rank_percentile(full['hofm3'])[local]])
        bcd_features=self._bcd_features(u,mids)
        delta=bcd_features@self._weights
        joint_score=fm[local]+delta
        extra.extend(flags[name] for name in self.active_sources)
        extra.append(sum(flags.values()).astype(np.float32))
        extra.extend((joint_score,delta,_rank_percentile(joint_score)))
        extra.extend(bcd_features[:,i] for i in range(bcd_features.shape[1]))
        X=np.column_stack([snapshot_features,*extra]).astype(np.float32)
        if X.shape[1]!=len(self.names) or not np.isfinite(X).all():
            raise ValueError(f'Invalid joint BCD features: {X.shape[1]} vs {len(self.names)}')
        truth=set(map(int,truth))
        labels=np.isin(mids,list(truth)).astype(np.int32)
        scores={name:full[name][local] for name in self.active_sources if name!='jointbcd'}
        scores['jointbcd']=joint_score.astype(np.float32)
        return {'user':int(u),'movies':mids,'labels':labels,'features':X,
                'scores':scores, 'candidate_recall':_retrieval_metrics(mids,truth),
                'relevant_total':len(truth),'retrieved_relevant':int(labels.sum()),
                'retrieval_sources':{name:unseen[ix] for name,ix in selections.items()},
                'eligible_catalogue_size':len(unseen)}


def _verified_hofm3(dataset, name):
    """Never silently treat an ordinary degree-2 FM as the HOFM3 source."""
    if not name:return
    metadata_path=Path('models')/dataset/'temporal_fm'/name/'metadata.json'
    if not metadata_path.is_file():
        raise FileNotFoundError(f'Missing HOFM3 metadata: {metadata_path}')
    meta=json.loads(metadata_path.read_text(encoding='utf-8'))
    if int(meta.get('fm_order',0)) != 3:
        raise ValueError(f'{name} is not a verified degree-3 checkpoint (fm_order=3)')


def make_retriever(ev,provider,fm,histories,users,pop,metadata,*,device='cpu',threads=4):
    """For saved-model inference in Reco Studio; validates exact feature schema."""
    folder=Path(metadata['preference_checkpoint'])
    base_model=metadata['base_model']
    head=load_preference(ev,provider,base_model,folder,device,int(metadata['seed']))
    aux_name=metadata.get('aux_fm_model')
    _verified_hofm3(ev.meta['dataset'],aux_name)
    aux=_model(ev,provider,aux_name,metadata['backend'],device,seed=int(metadata['seed'])) if aux_name else None
    retriever=JointBCDRetriever(ev,provider,fm,histories,users,pop,head=head,aux_model=aux,
              joint_pool=int(metadata['joint_pool']),
              baseline_profile=metadata['baseline_profile'],seed=int(metadata['seed']),
              threshold=float(metadata['threshold']),threads=threads,device=device)
    if retriever.names!=metadata['feature_names']:
        raise ValueError('Joint BCD model feature names differ from saved LightGBM schema')
    # Check model/head actually belong to the same dataset and cutoff in load_preference.
    return retriever


def run(dataset='ml-32m',data_dir='data',backend='sentence',
        base_model='fm_all_semi25_bpr',preference_label='jointBCD',
        ranker_train_users=700,ranker_valid_users=200,eval_users=300,
        fm_candidates=500,svd_candidates=200,bpr_candidates=200,
        pop_candidates=100,semantic_candidates=100,hofm3_candidates=200,jointbcd_candidates=300,
        aux_fm_model='fm_all_hofm3semi25_bpr',
        joint_pool=2000,baseline_profile='research',threshold=4.0,k=10,
        min_history=5,seed=42,eval_split='validation',device='cpu',threads=4,
        batch_size=2048,trees=600,leaves=15,learning_rate=.03,min_child_samples=60,
        reg_lambda=3.,colsample_bytree=.8,early_stop_rounds=40,
        objective='lambdarank',run_label='jointBCD_multisource',force_retrain=False):
    import lightgbm as lgb
    if eval_split not in ('validation','test'):raise ValueError('Unknown evaluation split')
    if objective not in ('lambdarank','rank_xendcg'):raise ValueError('Invalid LightGBM ranking objective')
    if not re.fullmatch('[A-Za-z0-9_-]+',run_label):raise ValueError('Unsafe run label')
    if min(ranker_train_users,ranker_valid_users,eval_users,k,trees,early_stop_rounds,threads)<1:
        raise ValueError('Training/validation sizes must be positive')
    quotas={'fm':fm_candidates,'svd':svd_candidates,'bpr':bpr_candidates,
            'pop':pop_candidates,'semantic':semantic_candidates,'hofm3':hofm3_candidates if aux_fm_model else 0,
            'jointbcd':jointbcd_candidates}
    if any(v<k for v in quotas.values() if v):raise ValueError('Each enabled retrieval quota must be >= K')
    if joint_pool<jointbcd_candidates:raise ValueError('joint_pool must cover jointbcd_candidates')
    torch.set_num_threads(threads)
    ev=Events(Path(data_dir)/'temporal'/dataset)
    if eval_split=='validation':
        ids,hs,ys,pop,cohort=_cohort(ev,'validation',threshold,
                            ranker_train_users+ranker_valid_users+eval_users,min_history,seed)
        tr,va,te=_split_users(ids,ranker_train_users,ranker_valid_users,eval_users,seed)
        train_h=valid_h=eval_h=hs;train_y=valid_y=eval_y=ys
    else:
        ids,hs,ys,pop,cohort=_cohort(ev,'validation',threshold,
                            ranker_train_users+ranker_valid_users,min_history,seed)
        tr,va,_=_split_users(ids,ranker_train_users,ranker_valid_users,0,seed)
        te,eval_h,eval_y,_,test_info=_cohort(ev,'test',threshold,eval_users,min_history,seed+99)
        cohort={'validation':cohort,'test':test_info}
        train_h=valid_h=hs;train_y=valid_y=ys
        print('WARNING: test split is for final confirmation only',flush=True)
    provider=_prepare(ev,backend)
    provider.backend=backend  # legacy _prepare does not always annotate its FeatureProvider
    fm=_model(ev,provider,base_model,backend,device,seed=seed)
    folder=preference_folder(dataset,base_model,preference_label)
    head=load_preference(ev,provider,base_model,folder,device,seed)
    _verified_hofm3(dataset,aux_fm_model)
    aux=_model(ev,provider,aux_fm_model,backend,device,seed=seed) if aux_fm_model else None
    hist={**train_h,**valid_h,**eval_h}
    all_users=list(dict.fromkeys(tr+va+te))
    retriever=JointBCDRetriever(ev,provider,fm,hist,all_users,pop,head=head,aux_model=aux,
                   joint_pool=joint_pool,baseline_profile=baseline_profile,
                   seed=seed,threads=threads,threshold=threshold,device=device,batch_size=batch_size)
    print(f'Loaded frozen FM {base_model} + frozen Stage D {folder.name}',flush=True)
    print(f'Candidate quotas {quotas} / Stage-D pool {joint_pool}',flush=True)
    print('Building LambdaRank training queries...',flush=True)
    X,y,g,_,_=_ranker_matrix(retriever,tr,train_h,train_y,quotas)
    print('Building disjoint early-stopping queries...',flush=True)
    Xv,yv,gv,_,_=_ranker_matrix(retriever,va,valid_h,valid_y,quotas)
    # Fingerprint the actual Stage-D checkpoint, not merely its directory name.
    stage_digest=hashlib.sha256((folder/'weights.pt').read_bytes()).hexdigest()
    base_path=Path('models')/dataset/'temporal_fm'/base_model/'weights.pt'
    base_digest=hashlib.sha256(base_path.read_bytes()).hexdigest() if base_path.is_file() else None
    aux_path=Path('models')/dataset/'temporal_fm'/aux_fm_model/'weights.pt' if aux_fm_model else None
    aux_digest=hashlib.sha256(aux_path.read_bytes()).hexdigest() if aux_path is not None and aux_path.is_file() else None
    params={'dataset':dataset,'sources':ev.meta['sources'],'cutoff':ev.meta['train_cutoff'],
       'base_model':base_model,'backend':backend,'stage':'d','reranker_type':'jointbcd',
       'preference_checkpoint':str(folder),'preference_sha256':stage_digest,
       'base_sha256':base_digest,'aux_fm_model':aux_fm_model,'aux_sha256':aux_digest,
       'joint_pool':joint_pool,
       'baseline_profile':baseline_profile,'quotas':quotas,'seed':seed,'threshold':threshold,
       'k':k,'eval_split':eval_split,'ranker_train_users':ranker_train_users,
       'ranker_valid_users':ranker_valid_users,'eval_users':eval_users,
       'trees':trees,'leaves':leaves,'learning_rate':learning_rate,
       'min_child_samples':min_child_samples,'reg_lambda':reg_lambda,
       'colsample_bytree':colsample_bytree,'early_stop_rounds':early_stop_rounds,
       'objective':objective,'feature_names':retriever.names}
    key=hashlib.sha256(json.dumps(params,sort_keys=True,default=str).encode()).hexdigest()[:12]
    dest=Path('models')/dataset/'temporal_fm'/'advanced_ltr'/f'{run_label}_{key}'
    dest.mkdir(parents=True,exist_ok=True)
    if (dest/'model.txt').exists() and not force_retrain:
        ranker=lgb.Booster(model_file=str(dest/'model.txt'))
        print('Reusing saved LightGBM model',dest,flush=True)
    else:
        estimator=lgb.LGBMRanker(objective=objective,metric='ndcg',n_estimators=trees,
              learning_rate=learning_rate,num_leaves=leaves,
              min_child_samples=min_child_samples,colsample_bytree=colsample_bytree,
              reg_lambda=reg_lambda,random_state=seed,verbosity=-1,n_jobs=threads,
              lambdarank_truncation_level=k+5,label_gain=[0,1])
        estimator.fit(X,y,group=g,feature_name=retriever.names,
              eval_set=[(Xv,yv)],eval_group=[gv],eval_at=[k],
              callbacks=[lgb.early_stopping(early_stop_rounds,verbose=True),lgb.log_evaluation(20)])
        ranker=estimator.booster_
        ranker.save_model(str(dest/'model.txt'))
    if ranker.num_feature()!=len(retriever.names):
        raise ValueError('Saved ranker has a mismatched feature count')
    (dest/'metadata.json').write_text(json.dumps({**params,'best_iteration':ranker.best_iteration,
       'train_informative_groups':len(g),'valid_informative_groups':len(gv)},indent=2,default=str))
    print('Evaluating DISJOINT holdout users...',flush=True)
    models=(*retriever.active_sources,'advanced_lambdamart')
    scores_by={name:[] for name in models}
    covered={name:set() for name in models}
    per_user={name:[] for name in models}
    retrieved=total=0;examples={};count=0
    for ix,u in enumerate(te,1):
        q=retriever.query(u,eval_h[u],eval_y[u],quotas)
        if q is None:continue
        predictions={**q['scores'],'advanced_lambdamart':ranker.predict(q['features'],num_threads=threads)}
        total+=q['relevant_total'];retrieved+=q['retrieved_relevant'];count+=1
        for name,values in predictions.items():
            winner=q['movies'][_best(values,k)]
            row=_ranking_scores(winner,eval_y[u],k,ev.genre_matrix,pop,int(ev.meta['splits']['train']))
            scores_by[name].append(row)
            covered[name].update(map(int,winner))
            per_user[name].append(float(row['ndcg_at_k']))
        if len(examples)<4:
            top=q['movies'][_best(predictions['advanced_lambdamart'],k)]
            examples[str(u)]=[{'movieId':int(ev.movies.iloc[int(m)].movieId),
                     'title':str(ev.movies.iloc[int(m)].title),'relevant':bool(int(m) in eval_y[u])}
                     for m in top]
        if ix%25==0:print(f'  eval {ix}/{len(te)} users',flush=True)
    if not count:raise ValueError('No eligible evaluation queries')
    metrics={name:_aggregate(scores_by[name],covered[name],len(retriever.catalog)) for name in models}
    report={'dataset':dataset,'split':eval_split,'model':base_model,'k':k,'seed':seed,
       'cutoff':int(ev.meta['train_cutoff']),'eval_users':count,
       'reranker_type':'jointbcd','preference_checkpoint':str(folder),
       'candidate_policy':'FM,optional-HOFM3,SVD,BPR,pop,semantic + Stage-D-on-FM-shortlist (NO label injection)',
       'joint_pool':joint_pool,'aux_fm_model':aux_fm_model,
       'candidate_recall':float(retrieved/max(total,1)),
       'metrics':metrics,'delta_vs_fm':_paired_bootstrap(per_user['advanced_lambdamart'],per_user['fm'],seed),
       'delta_vs_jointbcd':_paired_bootstrap(per_user['advanced_lambdamart'],per_user['jointbcd'],seed+1),
       'feature_importance_gain':dict(zip(retriever.names,map(float,ranker.feature_importance('gain')))),
       'examples':examples,'ranker_path':str(dest/'model.txt'),'configuration':params,
       'ranker_train_users':len(tr),'ranker_valid_users':len(va),
       'informative_train_groups':len(g),'informative_valid_groups':len(gv),
       'caveats':['Separate ranker train, early-stop and held-out evaluation users.',
                  'Validation selection of the original FM/Stage D means final test is still required.',
                  'Stage D retrieval reranks a bounded FM candidate pool, not the entire catalogue.',
                  'LambdaRank early-stop NDCG excludes groups without retrieved positives.',
                  'Reported base scores are compared on one shared candidate union, not full-catalogue rankings.',
                  'Features and candidate retrieval are frozen to training-period history.']}
    folder_reports=Path('reports')/'temporal'/dataset
    folder_reports.mkdir(parents=True,exist_ok=True)
    outfile=folder_reports/f'advanced_ltr_{eval_split}_{run_label}_{key}.json'
    outfile.write_text(json.dumps(report,indent=2,default=str))
    with outfile.with_suffix('.csv').open('w',newline='') as fp:
        writer=csv.DictWriter(fp,fieldnames=['model',*next(iter(metrics.values())).keys()])
        writer.writeheader()
        for name,row in metrics.items():writer.writerow({'model':name,**row})
    for name,row in metrics.items():
        print(f'{name:23s} NDCG@{k}={row["ndcg_at_k"]:.5f} Recall@{k}={row["recall_at_k"]:.5f}',flush=True)
    print('Candidate recall',report['candidate_recall'],'Report',outfile,flush=True)
    return report


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset',default='ml-32m')
    p.add_argument('--data-dir',default='data')
    p.add_argument('--backend',choices=('sentence','hash'),default='sentence')
    p.add_argument('--base-model',default='fm_all_semi25_bpr')
    p.add_argument('--preference-label',default='jointBCD')
    p.add_argument('--ranker-train-users',type=int,default=700)
    p.add_argument('--ranker-valid-users',type=int,default=200)
    p.add_argument('--eval-users',type=int,default=300)
    for source,value in DEFAULT_QUOTAS.items():p.add_argument(f'--{source}-candidates',type=int,default=value)
    p.add_argument('--aux-fm-model',default='fm_all_hofm3semi25_bpr',
                   help='Optional degree-3 FM checkpoint; set to none to disable')
    p.add_argument('--joint-pool',type=int,default=2000)
    p.add_argument('--baseline-profile',choices=('quick','research'),default='research')
    p.add_argument('--threshold',type=float,default=4.)
    p.add_argument('--k',type=int,default=10)
    p.add_argument('--min-history',type=int,default=5)
    p.add_argument('--seed',type=int,default=42)
    p.add_argument('--eval-split',choices=('validation','test'),default='validation')
    p.add_argument('--device',choices=('cpu','cuda'),default='cpu')
    p.add_argument('--threads',type=int,default=4)
    p.add_argument('--batch-size',type=int,default=2048)
    p.add_argument('--trees',type=int,default=600)
    p.add_argument('--leaves',type=int,default=15)
    p.add_argument('--learning-rate',type=float,default=.03)
    p.add_argument('--min-child-samples',type=int,default=60)
    p.add_argument('--reg-lambda',type=float,default=3.)
    p.add_argument('--colsample-bytree',type=float,default=.8)
    p.add_argument('--early-stop-rounds',type=int,default=40)
    p.add_argument('--objective',choices=('lambdarank','rank_xendcg'),default='lambdarank')
    p.add_argument('--run-label',default='jointBCD_multisource')
    p.add_argument('--force-retrain',action='store_true')
    a=vars(p.parse_args(argv))
    if a['aux_fm_model'].lower() in ('none','off',''):
        a['aux_fm_model']=''
    if a['eval_split']=='test' and not a['force_retrain']:
        raise ValueError('To evaluate the final test after validation, use --force-retrain and a frozen configuration')
    return run(**a)

if __name__=='__main__':main()
