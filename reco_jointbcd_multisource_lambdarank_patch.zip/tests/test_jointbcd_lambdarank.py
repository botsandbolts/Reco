"""Offline tests for training provenance, label-blind candidate selection and UI integration."""
import ast
from pathlib import Path
import numpy as np
import pytest

from temporal_fm.jointbcd_lambdarank import (feature_names, preference_folder,
                    JointBCDRetriever, SOURCES)


def test_feature_schema_is_unique_and_includes_joint_bcd():
    names=feature_names(['g1','semantic2'])
    assert len(names)==len(set(names))
    assert {'jointbcd_score','jointbcd_delta','retrieved_by_jointbcd','bcd_g1','bcd_semantic2'} <= set(names)
    assert 'fm_score' in ' '.join(names) or 'fm' in ' '.join(names)


def test_checkpoint_naming_is_exact():
    p=preference_folder('ml-32m','fm_all_semi25_bpr','jointBCD')
    assert p.as_posix().endswith('fm_all_semi25_bpr_d_jointBCD')
    with pytest.raises(ValueError):preference_folder('ml-32m','fm_all_semi25_bpr','../unsafe')


class _DummyBuilder:
    names=['genre_recent','tags_recent']
    def context(self,u,t): return (u,t)
    def matrix(self,u,t,mids,ctx=None):
        ids=np.asarray(mids,dtype=np.int32)
        return np.column_stack([ids/10.,ids%3]).astype(np.float32)

class _DummySnapshot:
    def __init__(self):
        self.title=np.ones((20,2),dtype=np.float32)
        self.title_affinity={1:np.array([0.05,0.05],dtype=np.float32)}
    def features(self,u,mids,fm_score,fm_rank,pop_mids):
        from temporal_fm.lambdamart import FEATURE_NAMES
        return np.zeros((len(mids),len(FEATURE_NAMES)),dtype=np.float32)

class _DummyEvents:
    movie_has_train=np.ones(12,dtype=bool)
    def user_indices(self,arr):return np.ones(len(arr),dtype=np.int32)


def _fake_retriever(monkeypatch):
    import temporal_fm.jointbcd_lambdarank as m
    obj=object.__new__(JointBCDRetriever)
    obj.catalog=np.arange(12,dtype=np.int32)
    obj.ev=_DummyEvents();obj.provider=object();obj.model=object()
    obj.device='cpu';obj.batch_size=100;obj.cutoff=100
    obj.movie_pop=np.arange(20,dtype=np.float32)
    obj.baseline={'svd':(np.array([[1.]],dtype=np.float32),np.arange(20,dtype=np.float32).reshape(-1,1)),
                  'bpr':(np.array([[1.]],dtype=np.float32),np.arange(20,dtype=np.float32).reshape(-1,1))}
    obj.snapshot=_DummySnapshot()
    obj.builder=_DummyBuilder()
    obj._weights=np.array([2.0,0.3],dtype=np.float32)
    obj.joint_pool=8
    obj.aux_model=None
    obj.active_sources=('fm','svd','bpr','pop','semantic','jointbcd')
    obj.names=feature_names(obj.builder.names)
    monkeypatch.setattr(m,'score_candidates',lambda *args,**kwargs: np.arange(12,dtype=np.float32)[::-1])
    return obj


def test_candidate_pool_is_label_blind(monkeypatch):
    retriever=_fake_retriever(monkeypatch)
    quotas={'fm':3,'svd':3,'bpr':3,'pop':3,'semantic':3,'jointbcd':2}
    a=retriever.query(1,{0,1},{2},quotas)
    b=retriever.query(1,{0,1},{9},quotas)
    assert np.array_equal(a['movies'],b['movies'])
    assert np.allclose(a['features'],b['features'])
    assert not np.array_equal(a['labels'],b['labels'])
    assert a['features'].shape==(len(a['movies']),len(retriever.names))
    assert np.isfinite(a['features']).all()
    assert set(a['scores'])==set(retriever.active_sources)
    assert not ({0,1} & set(a['movies']))
    assert np.any(a['features'][:,-2:]!=0)
    assert 'jointbcd' in a['retrieval_sources']


def test_joint_pool_quota_rejected(monkeypatch):
    r=_fake_retriever(monkeypatch)
    with pytest.raises(ValueError,match='joint_pool'):
        r.query(1,{0},{5},{'jointbcd':20})


def test_reco_studio_installer_idempotent(tmp_path):
    import importlib.util
    script=Path(__file__).resolve().parents[1]/'scripts'/'install_jointbcd_studio.py'
    spec=importlib.util.spec_from_file_location('jointbcd_installer',script)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    path=tmp_path/'engines.py'
    path.write_text('def foo(ranker):\n    md=ranker[\'metadata\']\n    return md\n')
    assert mod.install(path)
    assert mod.install(path)
    ast.parse(path.read_text())
    assert path.with_suffix('.py.before_jointbcd.bak').is_file()


def test_optional_hofm3_source_is_feature_and_candidate(monkeypatch):
    import temporal_fm.jointbcd_lambdarank as m
    retriever=_fake_retriever(monkeypatch)
    base=m.score_candidates
    other=object()
    retriever.aux_model=other
    retriever.active_sources=('fm','svd','bpr','pop','semantic','hofm3','jointbcd')
    retriever.names=feature_names(retriever.builder.names,include_hofm3=True)
    monkeypatch.setattr(m,'score_candidates',lambda mdl,*args,**kw:
      np.arange(len(args[3]),dtype=np.float32) if mdl is other else base(mdl,*args,**kw))
    q=retriever.query(1,{0,1},{7},{'fm':3,'svd':3,'bpr':3,'pop':3,'semantic':3,'hofm3':4,'jointbcd':2})
    assert q['features'].shape[1]==len(retriever.names)
    assert len(q['retrieval_sources']['hofm3'])==4
    assert 'hofm3' in q['scores']
    assert np.isfinite(q['features']).all()


def test_hofm3_order_guard(tmp_path, monkeypatch):
    import json
    from temporal_fm.jointbcd_lambdarank import _verified_hofm3
    monkeypatch.chdir(tmp_path)
    folder=tmp_path/'models/ml-32m/temporal_fm/fm_all_hofm3semi25_bpr'
    folder.mkdir(parents=True)
    (folder/'metadata.json').write_text(json.dumps({'fm_order':2}))
    with pytest.raises(ValueError, match='degree-3'):
        _verified_hofm3('ml-32m','fm_all_hofm3semi25_bpr')
    (folder/'metadata.json').write_text(json.dumps({'fm_order':3}))
    assert _verified_hofm3('ml-32m','fm_all_hofm3semi25_bpr') is None
