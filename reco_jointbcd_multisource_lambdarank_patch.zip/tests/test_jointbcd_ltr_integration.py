"""Actual synthetic data -> FM -> stage D -> LambdaRank -> saved report (no MovieLens download)."""
from pathlib import Path
import numpy as np
import pandas as pd
import pytest


def test_joint_bcd_train_and_rerank(tmp_path,monkeypatch):
    pytest.importorskip('lightgbm')
    from temporal_fm.rank_train import train
    from temporal_fm.preference_experiment import run as train_d
    from temporal_fm.jointbcd_lambdarank import run as rank
    raw=tmp_path/'data/raw/ml-latest-small';raw.mkdir(parents=True)
    n_users=44;n_movies=175
    pd.DataFrame({'movieId':np.arange(1,n_movies+1),
      'title':[f'Film {i} (2000)' for i in range(n_movies)],
      'genres':['Action|Comedy' if i%2 else 'Drama|Romance' for i in range(n_movies)]}).to_csv(raw/'movies.csv',index=False)
    rng=np.random.default_rng(911)
    rows=[]
    for i in range(6400):
        rows.append((i%n_users+1,int(rng.integers(1,n_movies+1)),
                     5. if i%7 else 2.,1_450_000_000+i*3600))
    pd.DataFrame(rows,columns=['userId','movieId','rating','timestamp']).to_csv(raw/'ratings.csv',index=False)
    pd.DataFrame({'movieId':[1,2,3,4],'tag':['funny','romantic','dramatic','action'],
        'timestamp':[1_450_000_000,1_450_000_300,1_450_000_600,1_450_000_900]}).to_csv(raw/'tags.csv',index=False)
    monkeypatch.chdir(tmp_path)
    train(dataset='ml-latest-small',data_dir='data',models='fm',profile='quick',
          text_backend='hash',validation_users=5,validation_candidates=30,
          tag_dims=12,threads=1,negatives=1)
    train_d(dataset='ml-latest-small',data_dir='data',backend='hash',base_model='fm_all_bpr',
        stage='d',run_label='jointBCD',epochs=1,steps_per_epoch=1,batch_size=4,
        eval_users=3,validate_every=1,seed=42,device='cpu',threads=1,force_retrain=True)
    result=rank(dataset='ml-latest-small',data_dir='data',backend='hash',
        base_model='fm_all_bpr',preference_label='jointBCD',
        ranker_train_users=8,ranker_valid_users=6,eval_users=5,
        fm_candidates=40,svd_candidates=20,bpr_candidates=20,
        pop_candidates=15,semantic_candidates=15,jointbcd_candidates=10,
        joint_pool=60,baseline_profile='quick',trees=20,leaves=7,
        learning_rate=.08,min_child_samples=2,early_stop_rounds=5,
        k=5,device='cpu',threads=1,batch_size=256,run_label='smoke',aux_fm_model='')
    assert Path(result['ranker_path']).is_file()
    assert set(result['metrics'])=={'fm','svd','bpr','pop','semantic','jointbcd','advanced_lambdamart'}
    assert 0 <= result['candidate_recall'] <= 1
    assert 'bcd_genre_last10' in result['configuration']['feature_names']
