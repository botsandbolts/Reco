# Reco Research Lab — Model comparisons, training histories and genre UMAP

This is an **additive, read-only Streamlit dashboard** for the project at
`/workspaces/Reco`. It does not overwrite `app.py`, train models in Streamlit,
retrain FM/LightGBM, fetch datasets, or deserialize untrusted checkpoints.

## Install

Upload `reco_research_lab_streamlit_patch.zip` to the root of the GitHub
repository; in the Codespaces terminal:

```bash
cd /workspaces/Reco
git fetch origin main
git show origin/main:reco_research_lab_streamlit_patch.zip > reco_research_lab_streamlit_patch.zip
unzip -o reco_research_lab_streamlit_patch.zip
python -m pip install -r requirements-research-lab.txt
python -m pytest -q tests/test_research_lab.py
```

The `pages/09_Research_Lab.py` page should appear in the navigation menu
when using classic Streamlit multipage navigation. If the current app uses
`st.navigation` or custom tabs, launch the Research Lab **independently**:

```bash
streamlit run research_lab_app.py --server.address 0.0.0.0 --server.port 8501
```

Do not launch two Streamlit apps simultaneously on the same port. Stop the
old server first with Ctrl+C, or use port 8502.

## What appears

1. **Overview:** discover report files for the selected dataset, but only
   display measured results when files actually exist.
2. **Model comparisons:** choose one ranking or regression report; see model
   tables, plots, the exact split and candidate protocol. Temporal preferences
   B/C/D/E compare across files **only if their exact evaluation user IDs and
   all relevant experiment settings match**.
3. **Training epochs:** view saved `history.json` epoch/loss/validation curves
   for Temporal FM and Stage B/C/D; select live terminal log snapshots.
4. **Retrieval & LambdaRank:** union candidate recall, retrieval-source recall,
   LightGBM feature-gain importance and matched NDCG/Recall.
5. **Genre UMAP:** movie dots colored by first-listed genre with title/movie-ID
   hover. Supports MovieLens Small, 1M and 32M, plus model-provided embeddings.
6. **Checkpoints & methods:** identify trained checkpoints without loading
   PyTorch weights. Clear caveats about benchmark comparability.

## Generate UMAP (offline; not inside Streamlit)

Use a bounded **3,000-movie sample**, which is practical on CPU:

```bash
OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4 \
python -m reco_research_lab.genre_umap --dataset ml-32m \
  --mode genre-multihot --sample-size 3000 --seed 42

python -m reco_research_lab.genre_umap --dataset ml-1m \
  --mode title-genre-tfidf --sample-size 3000 --seed 42

python -m reco_research_lab.genre_umap --dataset ml-latest-small \
  --mode genre-multihot --sample-size 3000 --seed 42
```

Catalogues are read, in order, from `data/temporal/<dataset>/movies.csv`,
`data/processed/<dataset>/movies.parquet`, and appropriate raw `movies.csv`
or `movies.dat` files. You must have prepared the dataset beforehand. For
MovieLens 1M, `movies.dat` is parsed as `::` separated Latin-1 data.

### Different model embeddings

The UMAP runner accepts an existing **safe `.npz` file** with these arrays:

- `movie_ids` (original MovieLens IDs; one per row)
- `embeddings` (or `item_vectors` / `vectors`; float matrix, rows aligned to IDs)

For a saved SVD/BPR/HOFM item embedding matrix that you have exported to NPZ:

```bash
python -m reco_research_lab.genre_umap --dataset ml-32m \
  --mode model-embeddings --embedding-npz reports/item_vectors_bpr.npz \
  --sample-size 3000
```

This command **does not export vectors from trained PyTorch weights**; that
requires the correct architecture-specific mapping from movie IDs to rows.
The importer deliberately rejects missing or duplicate movie IDs rather than
silently mislabelling model vectors. Embedding-source information is saved
beside each map in a `.json` file. Each map gets its own UMAP fit and axes,
so **distances/locations should not be compared across independent maps**.

## Where results come from

| Experiment | File patterns |
|---|---|
| Temporal FM regression | `reports/temporal/<dataset>/validation_*.json` |
| FM/HOFM3, popularity, SVD/BPR comparison | `reports/temporal/<dataset>/ranking_*.json`, `shared_*.json` |
| Temporal B+C+D | `reports/temporal/<dataset>/preference_experiments/*.json` |
| B/C/D epoch progress | `models/<dataset>/temporal_preferences/*/history.json` |
| Multi-source candidate recall | `reports/temporal/<dataset>/advanced_retrieval_*.json` |
| LightGBM LambdaRank | `reports/temporal/<dataset>/advanced_ltr_*.json` |
| Per-user unified benchmarks | `reports/unified/<dataset>/unified_*.json` |
| MovieLens Small | `artifacts/metrics.json` |
| Genre UMAP | `reports/research_lab/umap/<dataset>/genre_umap_*.csv` |

Source data and model checkpoints remain local (and generally Git-ignored).
If an output has not been generated on this Codespace, the page clearly
reports it as missing. No saved report is modified or invented.

## Monitoring B+C+D training

To print and save epoch logs using all four CPUs:

```bash
set -o pipefail
OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 \
python -u -m temporal_fm.preference_experiment \
  --dataset ml-32m --backend sentence --base-model fm_all_semi25_bpr \
  --stage d --run-label jointBCD --epochs 15 --steps-per-epoch 1000 \
  --batch-size 128 --eval-users 300 --validate-every 2 \
  --device cpu --threads 4 --force-retrain \
  2>&1 | tee jointBCD_research_training.log
```

Stage D contains the B+C+D engineered features. The previous implementation
keeps the base FM checkpoint frozen; this dashboard does not change that.
Click **Refresh reports** in Streamlit to read newly saved epoch histories.

## Scientific caveats

- **Never mix per-user chronological Small/unified 32M benchmark numbers with
  Temporal FM's global-cutoff scores.** Different candidate sets or evaluation
  cohorts can greatly change NDCG.
- Rating prediction RMSE/MAE and top-K ranking NDCG measure different tasks.
- UMAP genre plots illustrate content relationships, not predictive ranking.
- Terminal logs may include sensitive paths or data; do not commit them publicly.
- No real MovieLens 32M performance improvements have been verified by this patch.
