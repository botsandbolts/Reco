"""Streamlit auto-discovers this additional page under `pages/`."""
from pathlib import Path
import sys

project_root = Path(__file__).resolve().parents[1]
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))
from reco_research_lab.dashboard import render

render(project_root, page=True)
