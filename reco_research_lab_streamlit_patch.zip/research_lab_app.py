"""Alternative standalone entry point: streamlit run research_lab_app.py"""
from pathlib import Path
from reco_research_lab.dashboard import render

render(Path(__file__).resolve().parent, page=True)
