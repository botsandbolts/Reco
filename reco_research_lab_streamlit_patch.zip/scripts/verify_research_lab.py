"""Lightweight research dashboard preflight; no training or downloads."""
from pathlib import Path
import sys

root=Path(__file__).resolve().parents[1]
if str(root) not in sys.path:sys.path.insert(0,str(root))
from reco_research_lab.report_store import DATASETS,discover,discover_checkpoints
from reco_research_lab.genre_umap import find_catalog

print('Reco Research Lab preflight')
print('Root:',root)
for dataset in DATASETS:
    print('\nDataset:',dataset)
    print('  Reports:',len(discover(root,dataset)))
    print('  Checkpoints:',len(discover_checkpoints(root,dataset)))
    try:print('  Catalogue:',find_catalog(root,dataset))
    except FileNotFoundError:print('  Catalogue: NOT FOUND — UMAP must wait until data are prepared')
print('\nOpen: streamlit run research_lab_app.py --server.address 0.0.0.0 --server.port 8501')
