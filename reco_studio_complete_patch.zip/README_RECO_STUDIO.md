# Reco Studio — one integrated MovieLens Streamlit interface

**Purpose:** replace the collection of incompatible Streamlit dashboards with a coherent, responsive application that **actually recommends movies**. Designed for a 4-vCPU GitHub Codespace (including mobile-browser access).

### What works

| Page | Function | Prerequisite |
| --- | --- | --- |
| 🎯 Recommendations | Recommend previously unseen movies for real, anonymous MovieLens users | Small: trusted `artifacts/recommender.joblib`; 1M/32M: prepared temporal data; cached SVD/BPR or trained FM/HOFM3 optionally |
| ❤️ Favorite-based discovery | Type a title, select favorites, receive actual movie recommendations using title+genre TF-IDF | Movie catalogue only |
| 📊 Compare models | Full-catalogue FM/HOFM3/DeepFM, SVD/BPR/popularity, semantic and trained LambdaRank comparisons where report files exist | Actual saved report JSON |
| 📈 Training and epochs | Per-epoch loss/NDCG, validation times and terminal logs | `history.json` or `*.log` |
| 🌳 Retrieval / LambdaRank | Candidate recall, comparison, saved feature importance | Retrieval and LambdaRank reports |
| 🗺️ Genre UMAP | Genre-colored actual catalogue or saved model-embedding maps, Small / 1M / 32M | Saved UMAP CSV+JSON |
| ⚙️ Setup | Read-only checkpoint inventory, setup commands, provenance notes | None |

**Scientific safeguards:** known-user 1M/32M scoring uses only **train** history; excludes rated movies; excludes movies not yet released at the training cutoff (when a release year is known); uses *only warm catalogue* for trained FM. Reports from different datasets and temporal protocols are **not** merged into an unsupported global leaderboard. Cold-start favorite recommendations are described as content TF-IDF, not as neural personalization. Streamlit never trains models automatically or adds held-out relevant labels to the candidate pool.

## Install from GitHub upload in Codespaces

1. Upload `reco_studio_complete_patch.zip` to the **root of the GitHub Reco repository** (not `research-patches/` unless you adjust the Git path).
2. Open the Codespaces Terminal (not Output) and run:

```bash
cd /workspaces/Reco
git fetch origin main
git show origin/main:reco_studio_complete_patch.zip > reco_studio_complete_patch.zip
unzip -o reco_studio_complete_patch.zip
python -m pip install -r requirements-reco-studio.txt
python -m pytest -q tests/test_reco_studio*.py tests/test_studio_ui.py tests/test_research_lab.py
```

You can first test the **new standalone app without modifying the existing app.py**:

```bash
streamlit run reco_studio_app.py --server.address 0.0.0.0 --server.port 8502
```

Then open the forwarded Codespaces port **8502**. On mobile you may need to use Chrome desktop site to access all tabs. **Do not run two Streamlit servers on port 8502.** Stop an old server in its terminal with Ctrl+C before starting the new one.

Once satisfied, you can make Studio the main `app.py`:

```bash
python scripts/install_reco_studio.py --make-default --hide-legacy-page
streamlit run app.py --server.address 0.0.0.0 --server.port 8502
```

The installer writes `app.py.before_reco_studio.bak` and moves the old duplicate Research Lab page to `pages_disabled/`. It never deletes checkpoint data or report files and is idempotent for repeat main-app installs. **You can restore the original**:

```bash
cp app.py.before_reco_studio.bak app.py
mkdir -p pages
mv pages_disabled/09_Research_Lab.py pages/09_Research_Lab.py
```

If GitHub `main` has changed in the meantime, these instructions only retrieve the named ZIP file—no destructive `git pull` or reset.

## First use

**Want movie recommendations without waiting for ML model loading?** Choose MovieLens 32M (or Small/1M) in the sidebar → **Favorite-based discovery** → enter a movie name, choose it, click **Add selected to favorites**, then **Find similar movies**.

**Want FM/HOFM3 personalized recommendations?** Select **Recommendations** → enter a training user ID → choose cached SVD/BPR or the trained `fm_all_hofm3semi25_bpr` (or `fm_all_semi25_bpr`) checkpoint → optionally choose a trained B+C+D Stage D correction or LambdaRank reranker → **Generate recommendations**. If no compatible checkpoint or feature cache exists, the app gives a diagnostic instead of pretending it ran that model.

**Important:** HOFM3 requires the previously installed third-order `_model` loader. The Studio patch does **not** change the Factorization Machine architecture or silently convert a degree-3 model to degree 2. For LambdaRank, your previously installed `temporal_fm.advanced_retrieval` and chronological SVD/BPR source files must also be available.

**To generate MovieLens 32M UMAP:**

```bash
OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 \
python -m reco_research_lab.genre_umap \
  --dataset ml-32m --mode genre-multihot --sample-size 3000 --seed 42
```

Other sizes:

```bash
python -m reco_research_lab.genre_umap --dataset ml-1m --mode title-genre-tfidf --sample-size 3000
python -m reco_research_lab.genre_umap --dataset ml-latest-small --mode genre-multihot --sample-size 3000
```

Maps with model embeddings require a trustworthy `.npz` holding `movie_ids` and `embeddings` arrays aligned with the selected catalogue.

### What this patch does *not* do

- Does **not** install or re-train the Temporal FM/HOFM3/LightGBM models. Those require the previously installed pipelines and trained checkpoints in your Codespace.
- Does **not** claim a measured 32M performance improvement. It displays **only actual saved metrics**.
- Does **not** bundle MovieLens datasets, model checkpoints, or large embeddings.
- Does **not** collect personal visitor ratings on a server.
- The live interface was checked through a comprehensive synthetic Streamlit test double. A real browser session against your private Codespace is still necessary because this environment does not contain your 32M dataset, checkpoints, or a Streamlit server.

### Troubleshooting

| Symptom | Solution |
| --- | --- |
| `No module named reco_studio` | Run from `/workspaces/Reco` and verify `ls reco_studio` |
| Port `8502` occupied | Stop the previous Streamlit process, or use `--server.port 8503` |
| No Small model | Run `python -m src.train`; favorite-based discovery requires only its movie catalogue |
| No 32M model | Confirm `models/ml-32m/temporal_fm/<name>/weights.pt` and `metadata.json` exist |
| HOFM3 incompatible checkpoint | Install its HOFM3 loader patch and verify with `python -m temporal_fm.ranking` |
| Cannot score LambdaRank | Check trained ranker under `models/ml-32m/temporal_fm/advanced_ltr`, compatible SVD/BPR baselines, and `requirements-advanced-ltr.txt` |
| No UMAP | Run the CLI above; Streamlit does not fit UMAP during page loading |
| Duplicate key in old Research Lab | Use the **new** `reco_studio_app.py`, or `--hide-legacy-page` after switching main |
| Training history empty | Create a training run with per-epoch `history.json` and/or `2>&1 | tee train.log` |

This dashboard is a noncommercial research portfolio UI. Source code licensing does not override GroupLens MovieLens dataset terms.
