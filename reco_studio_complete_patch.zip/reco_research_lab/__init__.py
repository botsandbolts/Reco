"""Read-only MovieLens research dashboards and genre UMAP tooling."""
__version__ = "1.0.0"
