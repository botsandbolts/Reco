"""Research Lab: report-backed comparisons and offline genre UMAP maps.

This is a read-only Streamlit page; importing it never loads a PyTorch checkpoint,
trains a model, downloads MovieLens, or merges incompatible evaluation results.
"""
from __future__ import annotations
from datetime import datetime
from pathlib import Path

import pandas as pd

from .report_store import (DATASETS, discover, discover_history, discover_checkpoints,
                           discover_logs, tail_log, load_json, metrics_frame,
                           small_metrics_frame, comparable_preferences, fingerprint)

METRICS = ('ndcg_at_k','recall_at_k','hit_rate_at_k','mrr_at_k',
           'precision_at_k','catalog_coverage_at_k','candidate_recall',
           'rmse','mae')


def _show_metric_chart(st, table: pd.DataFrame, key: str):
    fields = [name for name in METRICS if name in table and
              pd.to_numeric(table[name],errors='coerce').notna().any()]
    if not fields:
        st.info('This report contains no supported numeric ranking/accuracy columns.')
        if len(table): st.dataframe(table,use_container_width=True)
        return
    metric = st.selectbox('Metric', fields, key=key)
    values = pd.to_numeric(table[metric],errors='coerce').dropna().sort_values(ascending=metric in ('rmse','mae'))
    st.bar_chart(values, use_container_width=True)
    st.dataframe(table,use_container_width=True)
    if metric in ('rmse','mae'):
        st.caption('Lower is better. These are **rating prediction errors**, not top-K ranking metrics.')
    elif metric=='candidate_recall':
        st.caption('Fraction of held-out relevant movies retrieved before reranking.')
    else:
        st.caption('Higher is better for ranking metrics. Compare only results generated together in the selected report.')


def _select_file(st, title, refs, key):
    return st.selectbox(title,refs,format_func=lambda p:p.name if isinstance(p,Path) else p.path.name,key=key)


def _show_single_report(st, selected, widget_prefix):
    try: data=load_json(selected.path)
    except (ValueError,OSError) as exc:
        st.error(f'Could not read report: {exc}');return
    actual=data.get('dataset')
    if actual and actual != selected.dataset:
        st.error(f'Metadata mismatch: report claims {actual}, selected {selected.dataset}. Ignoring metrics.')
        return
    kind=selected.kind
    if kind=='MovieLens Small baseline':
        split=st.radio('Holdout', ['validation','test'],horizontal=True,key=f'{widget_prefix}_small_holdout')
        table=small_metrics_frame(data,split)
    else:
        table=metrics_frame(data,kind)
    st.caption(' · '.join(str(part) for part in (
        f'Dataset: {selected.dataset}', f'Family: {kind}',
        f'Split: {data.get("split", "per-user")}', f'K={data.get("k","unknown")}',
        f'Cutoff: {data.get("cutoff",data.get("train_cutoff","not recorded"))}',
        f'Users: {data.get("eval_users",data.get("user_count",data.get("evaluated_users",data.get("user_sample_size","unknown"))))}') ))
    policy=data.get('candidate_policy',data.get('protocol','not specified'))
    st.caption(f'Candidate/evaluation protocol: {policy}')
    if 'sample' in str(policy).lower() and 'full' not in str(policy).lower():
        st.warning('Sampled candidate metrics are not comparable with full-catalogue metrics.')
    if kind=='Temporal FM rating prediction':
        st.warning('Explicit-rating regression (RMSE/MAE) is a different task from top-K recommendation.')
    elif kind=='Unified scalable comparison':
        st.warning('The unified per-user holdout cannot be compared directly with globally chronological Temporal FM runs.')
    if kind=='Temporal preferences B/C/D/E':
        st.info('These preference reports represent a frozen FM with an additive residual scorer, not an FM trained jointly with the temporal head.')
    _show_metric_chart(st,table,f'{widget_prefix}_single_report_metric')
    if kind=='Multi-source LambdaRank':
        recall=data.get('candidate_recall')
        if isinstance(recall,(float,int)):st.metric('Candidate recall',f'{recall:.2%}')
        importance=data.get('feature_importance_gain',{})
        if isinstance(importance,dict) and importance:
            st.markdown('#### LambdaRank feature importance (gain)')
            series=pd.to_numeric(pd.Series(importance),errors='coerce').dropna().sort_values(ascending=False)
            st.bar_chart(series.head(25))
        if data.get('delta_vs_fm'):st.write('Paired ΔNDCG versus FM:',data['delta_vs_fm'])
    if data.get('examples'):
        with st.expander('Saved example recommendations'):
            examples=data['examples']
            if isinstance(examples,dict):
                keys=list(examples)
                model_name=st.selectbox('Example model/user',keys,key=f'{widget_prefix}_lab_examples')
                example=examples[model_name]
                if isinstance(example,dict):
                    nested=list(example)
                    if nested:
                        uid=st.selectbox('Anonymous user',nested,key=f'{widget_prefix}_lab_example_user')
                        st.json(example[uid])
                else:st.json(example)
    if data.get('caveats'):
        with st.expander('Caveats and provenance'):
            st.write(data['caveats'])
    with st.expander('Report JSON metadata'):
        st.json({k:v for k,v in data.items() if k not in ('metrics','results','per_user','examples','history')})


def _render_comparisons(st, root: Path, dataset: str, refs):
    st.subheader('Matched model comparisons')
    st.caption('Choose one saved report at a time. Scores from different protocols or cohorts are never silently pooled.')
    candidates=[r for r in refs if r.kind not in ('Advanced retrieval',)]
    if not candidates:
        st.info('No model benchmark reports found for this dataset. Run the relevant ranking/benchmark CLI first.')
        return
    kinds=sorted(set(r.kind for r in candidates))
    kind=st.selectbox('Experiment family',kinds,key='research_report_kind')
    report=_select_file(st,'Saved report',[r for r in candidates if r.kind==kind],'research_report_file')
    _show_single_report(st,report,'comparison')
    if kind=='Temporal preferences B/C/D/E':
        # Limit group merging to an explicit exact user cohort (not just user count).
        reports=[]
        for ref in candidates:
            if ref.kind!=kind:continue
            try:
                raw=load_json(ref.path)
                if raw.get('dataset')==dataset and raw.get('metrics') and raw.get('stage'):
                    reports.append((ref.path,raw))
            except (ValueError,OSError):continue
        try: wanted=fingerprint(load_json(report.path),kind)
        except (ValueError,OSError):
            st.warning('Selected report has no explicit user IDs: cannot safely combine stages across files.')
            return
        cohort=[(p,r) for p,r in reports if _try_same_cohort(r,wanted)]
        if len(set(r.get('stage') for _,r in cohort))>1:
            st.markdown('#### Strictly matched B / C / D / E stage comparison')
            try:
                table=pd.DataFrame(comparable_preferences(cohort)).set_index('model')
                _show_metric_chart(st,table,'pref_matched_metric')
            except (ValueError,KeyError) as exc:st.warning(str(exc))


def _try_same_cohort(r,wanted):
    try:return fingerprint(r,'Temporal preferences B/C/D/E')==wanted
    except (ValueError,TypeError):return False


def _render_training(st, root: Path, dataset: str, refs):
    st.subheader('Training histories · FM, HOFM, B+C+D')
    st.caption('Read-only checkpoint histories. Refresh the page to include newly saved epochs. No training is started here.')
    paths=discover_history(root,dataset)
    if not paths:
        st.info('No history.json found in models/<dataset>/temporal_preferences or temporal_fm.')
    else:
        path=_select_file(st,'Training history checkpoint',paths,'lab_history_file')
        try:
            history=load_json(path) if path.stat().st_size and path.read_text().lstrip().startswith('{') else None
            if history is None:
                import json
                history=json.loads(path.read_text(encoding='utf-8'))
        except (OSError,ValueError) as exc:
            st.error(f'Cannot open history: {exc}');history=None
        if isinstance(history,dict):
            # Some trainers store {'history':[...]} or {'train':...}.
            for key in ('history','epochs','training_history'):
                if isinstance(history.get(key),list):history=history[key];break
        if isinstance(history,list):
            df=pd.DataFrame([x for x in history if isinstance(x,dict)])
            if df.empty:st.info('Empty history')
            else:
                st.dataframe(df,use_container_width=True)
                ix='epoch' if 'epoch' in df.columns else None
                if ix:
                    df=df.sort_values(ix)
                    loss=[x for x in df.columns if 'loss' in x and pd.api.types.is_numeric_dtype(df[x])]
                    val=[x for x in df.columns if any(token in x for token in ('ndcg','rmse','recall'))
                         and pd.api.types.is_numeric_dtype(df[x])]
                    if loss:
                        st.markdown('#### Per-epoch training loss')
                        st.line_chart(df.set_index(ix)[loss])
                    if val:
                        st.markdown('#### Per-epoch validation')
                        st.line_chart(df.set_index(ix)[val])
                    if 'epoch_seconds' in df.columns:
                        st.metric('Last epoch duration',f'{df.epoch_seconds.iloc[-1]:.1f} s')
        else:st.info('History is not a supported list of per-epoch rows.')
    st.markdown('#### Live terminal log snapshots')
    logs=discover_logs(root)
    if logs:
        log=_select_file(st,'Training log',logs,'lab_log')
        st.code(tail_log(log,200),language='text')
        st.caption('Click **Refresh reports** to read new output. The actual training process runs in Codespaces, not in Streamlit.')
    else:
        st.info('No *.log in repository root or logs/. Save terminal output using `2>&1 | tee experiment.log`.')
    st.markdown('#### Temporal preference reports')
    subset=[r for r in refs if r.kind=='Temporal preferences B/C/D/E']
    if subset:
        st.dataframe(pd.DataFrame([{'file':r.path.name,'modified':datetime.fromtimestamp(r.modified).isoformat(timespec='minutes')} for r in subset]))


def _render_retrieval(st, dataset: str, refs):
    st.subheader('Retrieval diagnostics and LightGBM LambdaRank')
    a,b=st.tabs(['Candidate Recall','LambdaRank features & rankings'])
    with a:
        selected=[r for r in refs if r.kind=='Advanced retrieval']
        if not selected:
            st.info('No advanced_retrieval_*.json report yet. Run temporal_fm.advanced_retrieval.')
        else:
            chosen=_select_file(st,'Retrieval report',selected,'retrieval_report')
            try:report=load_json(chosen.path)
            except (OSError,ValueError) as exc:st.error(str(exc));return
            if report.get('dataset')!=dataset:st.error('Dataset metadata mismatch');return
            summary=report.get('summary',{})
            if isinstance(summary,dict):
                val=summary.get('union_candidate_recall')
                if isinstance(val,(float,int)):st.metric('Combined candidate recall',f'{val:.2%}')
                rec={k:v for k,v in summary.items() if ('recall_at_' in k) and isinstance(v,(int,float))}
                if rec:st.bar_chart(pd.Series(rec).sort_values(ascending=False))
            if isinstance(report.get('per_user'),list):
                st.dataframe(pd.DataFrame(report['per_user']).head(250),use_container_width=True)
            st.caption('Candidate retrieval cannot count held-out positives injected into the pool.')
    with b:
        selected=[r for r in refs if r.kind=='Multi-source LambdaRank']
        if not selected:
            st.info('No LambdaRank report yet. Run the advanced HOFM3/SVD/BPR LambdaRank pipeline.')
        else:
            chosen=_select_file(st,'LambdaRank report',selected,'ranker_report')
            _show_single_report(st,chosen,'lambdarank')


def _render_umap(st, root: Path, dataset: str):
    st.subheader('UMAP · genre and movie-embedding exploration')
    st.caption('Visualizes actual saved movie catalogues. Colors show first listed genre; movie tooltips include all genres. '
               'UMAP is exploratory—its coordinates are not recommendation scores.')
    folder=root/'reports'/'research_lab'/'umap'/dataset
    maps=sorted(folder.glob('genre_umap_*.csv'),key=lambda p:p.stat().st_mtime,reverse=True) if folder.exists() else []
    if not maps:
        st.info('No precomputed UMAP for this MovieLens size. Generate one offline in the Codespaces terminal:')
        st.code('python -m reco_research_lab.genre_umap --dataset '+dataset+
                ' --mode genre-multihot --sample-size 3000 --seed 42',language='bash')
        st.caption('Other modes: `--mode title-genre-tfidf` or '
                   '`--mode model-embeddings --embedding-npz path/to/item_vectors.npz`. '
                   'Model NPZ must include `movie_ids` and `embeddings` arrays.')
        return
    selected=_select_file(st,'Saved genre UMAP',maps,'research_umap_map')
    meta_path=selected.with_suffix('.json')
    try:
        df=pd.read_csv(selected)
        meta=load_json(meta_path) if meta_path.exists() else {}
    except (OSError,ValueError) as exc:st.error(str(exc));return
    if meta.get('dataset')!=dataset:
        st.error('Map dataset mismatch; cannot show map from a different MovieLens version.')
        return
    required={'movieId','title','genres','main_genre','x','y'}
    if not required.issubset(df.columns):st.error('Map missing required columns');return
    if len(df)>15000:st.error('Map is larger than 15,000 points; regenerate a bounded sample.');return
    st.caption(' · '.join((f'{len(df):,} movies',f'Dataset: {dataset}',
                          f'Mode: {meta.get("mode","unknown")}',
                          f'Source: {meta.get("embedding_source","unknown")}',
                          f'Seed: {meta.get("seed","unknown")}')))
    genres=sorted(df.main_genre.fillna('Unknown').unique().tolist())
    selected_genres=st.multiselect('Highlight genres (empty = all)',genres,key='lab_genre_filter')
    filtered=df[df.main_genre.isin(selected_genres)] if selected_genres else df
    try:
        import plotly.express as px
        fig=px.scatter(filtered,x='x',y='y',color='main_genre',
                       hover_name='title',hover_data={'movieId':True,'genres':True,'x':False,'y':False},
                       opacity=.7,render_mode='webgl',title=f'{dataset}: {meta.get("mode","UMAP")}')
        fig.update_layout(legend_title_text='Main genre',height=650)
        st.plotly_chart(fig,use_container_width=True)
    except ImportError:
        st.scatter_chart(filtered,x='x',y='y',color='main_genre')
    st.caption('Different UMAP runs are independently fitted; axes and distances are not numerically comparable between models or datasets.')
    with st.expander('Map construction and data'):
        st.json(meta)
        st.dataframe(filtered[['movieId','title','genres']].head(100),use_container_width=True)
    st.markdown('#### Build another map')
    st.code(f'python -m reco_research_lab.genre_umap --dataset {dataset} --mode title-genre-tfidf --sample-size 3000',language='bash')


def _render_checkpoints(st, root: Path, dataset: str):
    st.subheader('Checkpoint inventory and research reproducibility')
    values=discover_checkpoints(root,dataset)
    if values:
        st.dataframe(pd.DataFrame(values),use_container_width=True)
        st.caption('Only checkpoint filenames and safe JSON metadata are read. No model weights are loaded here.')
    else:st.info('No local checkpoints discovered. Trained models may be in Codespaces or ignored by Git.')
    st.markdown('#### Protocol and scientific integrity')
    st.markdown('''
- **MovieLens Small / unified scalable benchmarks:** usually per-user positive holdouts.
- **Temporal FM / DeepFM / shared chronology:** global timestamp cutoff.
- **BPR / HOFM2 / HOFM3 / preferences:** evaluate matched, identical users and eligible catalogues.
- **LambdaRank:** measure candidate recall separately from NDCG@10 after reranking.
- **RMSE and MAE:** explicit rating prediction; never place them on a ranking-metric leaderboard.
- **UMAP:** shows content or embedding geometry, not an accuracy improvement.
- **Logs and artefacts:** generated on your machine; this page does not produce simulated model results.
''')


def render(root: Path|str='.',page:bool=True):
    import streamlit as st
    root=Path(root).resolve()
    if page:
        st.set_page_config(page_title='Reco Research Lab',page_icon='🎬',layout='wide')
    st.title('🎬 Reco · Research Lab')
    st.caption('MovieLens Small / 1M / 32M · FM / HOFM / BPR / SVD / LambdaRank · '
               'B+C+D preference drift · genre UMAP')
    dataset=st.selectbox('MovieLens dataset',DATASETS,index=2,key='research_lab_dataset')
    refs=discover(root,dataset)
    if st.button('Refresh reports',key='research_refresh'):
        st.rerun()
    kind_counts=pd.Series([r.kind for r in refs]).value_counts()
    c1,c2,c3=st.columns(3)
    c1.metric('Available reports',len(refs))
    c2.metric('Experiment families',len(kind_counts))
    c3.metric('Local model checkpoints',len(discover_checkpoints(root,dataset)))
    tabs=st.tabs(['Overview','Model comparisons','B+C+D / training epochs',
                  'Retrieval & LambdaRank','Genre UMAP','Checkpoints & methods'])
    with tabs[0]:
        st.subheader('Observed research outputs')
        if len(refs):
            st.dataframe(pd.DataFrame([{'experiment':r.kind,'file':r.path.relative_to(root).as_posix(),
                  'updated':datetime.fromtimestamp(r.modified).isoformat(timespec='minutes')} for r in refs]).head(100),
                  use_container_width=True)
        else:
            st.info(f'No saved research reports yet for {dataset}. This is expected before training or evaluation.')
        st.markdown('**Models represented by compatible reports:** popularity, SVD, BPR-MF, '
                    'FM/DeepFM, semi-hard FM, HOFM3, B/C/D preferences, neural two-tower, '
                    'TIGER and LightGBM LambdaRank where those reports exist.')
        st.caption('A missing model is not listed as measured; older TIGER evaluations must not be mixed with global-chronology FM.')
    with tabs[1]:_render_comparisons(st,root,dataset,refs)
    with tabs[2]:_render_training(st,root,dataset,refs)
    with tabs[3]:_render_retrieval(st,dataset,refs)
    with tabs[4]:_render_umap(st,root,dataset)
    with tabs[5]:_render_checkpoints(st,root,dataset)

if __name__=='__main__':render(Path.cwd(),page=True)
