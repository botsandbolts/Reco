"""Offline genre-colored UMAP maps for MovieLens Small, 1M and 32M.

No model training, dataset downloads or pickle loads are performed here.
User supplies optional .npz with *aligned* movie_ids and embeddings.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import json
import re

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.preprocessing import normalize

from .report_store import DATASETS


def find_catalog(root: Path, dataset: str) -> Path:
    if dataset not in DATASETS: raise ValueError('Dataset must be Small, ml-1m or ml-32m')
    root=Path(root)
    candidates=[root/'data'/'temporal'/dataset/'movies.csv',
                root/'data'/'processed'/dataset/'movies.parquet',
                root/'data'/dataset/'movies.csv',
                root/'data'/'raw'/dataset/'movies.csv',
                root/'data'/'raw'/dataset/dataset/'movies.csv',
                root/'data'/'raw'/dataset/'movies.dat',
                root/'data'/'raw'/dataset/dataset/'movies.dat',
                root/'data'/dataset/'movies.dat',
                root/'data'/'ml-latest-small'/'movies.csv',
                root/'data'/'processed'/dataset/'movies.csv']
    for path in candidates:
        if path.exists() and (dataset!='ml-1m' or path.parts[-2:] != ('ml-latest-small','movies.csv')):
            # Last Small fallback must be used only for Small itself.
            if dataset!='ml-latest-small' and 'ml-latest-small' in path.parts:continue
            return path
    raise FileNotFoundError(
        f'Missing {dataset} movie catalogue. Expected data/temporal/{dataset}/movies.csv, '
        f'data/processed/{dataset}/movies.parquet, or data/raw/{dataset}/movies.dat.')


def load_catalog(path: Path) -> pd.DataFrame:
    path=Path(path)
    if path.suffix=='.dat':
        rows=[]
        for line in path.read_text(encoding='latin-1').splitlines():
            if not line:continue
            parts=line.split('::',2)
            if len(parts)!=3: raise ValueError('Malformed MovieLens 1M movies.dat')
            rows.append((int(parts[0]),parts[1],parts[2]))
        data=pd.DataFrame(rows,columns=['movieId','title','genres'])
    elif path.suffix=='.parquet':
        # pandas requires pyarrow or fastparquet; normal Temporal FM csv needs neither.
        data=pd.read_parquet(path,columns=['movieId','title','genres'])
    else:
        data=pd.read_csv(path,usecols=['movieId','title','genres'],encoding='utf-8')
    if data.empty:raise ValueError('Empty catalogue')
    data=data.dropna(subset=['movieId']).copy()
    data['movieId']=pd.to_numeric(data['movieId'],errors='raise').astype('int64')
    if data.movieId.duplicated().any():raise ValueError('Movie IDs must be unique')
    for col in ('title','genres'):
        data[col]=data[col].fillna('').astype(str)
    return data.sort_values('movieId').reset_index(drop=True)


def major_genre(value: str) -> str:
    genres=[v.strip() for v in str(value).split('|') if v.strip() and v.strip()!='(no genres listed)']
    return genres[0] if genres else 'Unknown'


def select_sample(df: pd.DataFrame, limit: int, seed: int) -> pd.DataFrame:
    if limit<10 or limit>15000:raise ValueError('sample-size must be between 10 and 15000')
    if len(df)<=limit:return df.reset_index(drop=True)
    # Group stratification, 1 item per genre where possible; remaining uniform.
    rng=np.random.default_rng(seed)
    categories=df['genres'].map(major_genre)
    chosen=[]
    for _,indices in categories.groupby(categories).groups.items():
        if len(chosen)>=limit:break
        chosen.append(int(rng.choice(np.asarray(list(indices),dtype=int))))
    needed=limit-len(chosen)
    residual=np.setdiff1d(np.arange(len(df)),np.asarray(chosen,dtype=int),assume_unique=False)
    if needed>0:chosen.extend(rng.choice(residual,size=needed,replace=False).tolist())
    return df.iloc[sorted(chosen)].reset_index(drop=True)


def _vectors_from_npz(path: Path, movie_ids: np.ndarray) -> np.ndarray:
    with np.load(path,allow_pickle=False) as z:
        if 'movie_ids' not in z.files:
            raise ValueError('Embedding npz must include movie_ids to guarantee catalogue alignment')
        keys=('embeddings','item_vectors','vectors','semantic_item')
        matching=[key for key in keys if key in z.files]
        if not matching:raise ValueError('Embedding npz needs embeddings, item_vectors, vectors, semantic_item ')
        ids=np.asarray(z['movie_ids'],dtype=np.int64)
        vectors=np.asarray(z[matching[0]],dtype=np.float32)
        if vectors.ndim!=2 or len(ids)!=len(vectors):raise ValueError('Item vector/ID alignment invalid')
        if len(np.unique(ids))!=len(ids):raise ValueError('Duplicate movie_ids in embedding file')
        ids_index={int(i):j for j,i in enumerate(ids)}
        if any(int(i) not in ids_index for i in movie_ids):
            missing=[int(i) for i in movie_ids if int(i) not in ids_index]
            raise ValueError(f'Model vectors missing {len(missing)} sampled catalogue IDs; first: {missing[:4]}')
        return vectors[np.array([ids_index[int(i)] for i in movie_ids],dtype=int)]


def build_features(df: pd.DataFrame, mode: str, embedding_npz: str|None, seed: int):
    if mode=='model-embeddings':
        if not embedding_npz:raise ValueError('Specify --embedding-npz for model-embeddings mode')
        vectors=_vectors_from_npz(Path(embedding_npz),df.movieId.to_numpy())
        if vectors.shape[1]<2:raise ValueError('At least two embedding dimensions required')
        return normalize(vectors),str(Path(embedding_npz)),vectors.shape[1]
    texts=df.genres.str.replace('|',' ',regex=False)
    if mode=='title-genre-tfidf':
        # Movie title tokens plus genre terms; no pretrained language model is claimed.
        texts=df.title.str.replace(r'\(\d{4}\)\s*$','',regex=True)+' '+texts
    elif mode!='genre-multihot':
        raise ValueError('Unknown mode')
    if mode=='genre-multihot':
        genres=sorted(set(g for row in df.genres for g in row.split('|') if g))
        if not genres:raise ValueError('No genres in catalogue')
        lookup={genre:i for i,genre in enumerate(genres)}
        mat=np.zeros((len(df),len(genres)),dtype=np.float32)
        for i,row in enumerate(df.genres):
            for genre in row.split('|'):
                if genre in lookup:mat[i,lookup[genre]]=1
        return normalize(mat), 'genre multi-hot',len(genres)
    tfidf=TfidfVectorizer(strip_accents='unicode',lowercase=True,ngram_range=(1,2),
                          token_pattern=r'(?u)\b\w+\b',min_df=1)
    mat=tfidf.fit_transform(texts)
    if min(mat.shape)>=5 and mat.shape[1]>48:
        n=min(48,mat.shape[0]-1,mat.shape[1]-1)
        dense=TruncatedSVD(n_components=n,random_state=seed).fit_transform(mat)
    else:
        dense=mat.toarray()
    return normalize(np.asarray(dense,dtype=np.float32)), 'title+genre TF-IDF',mat.shape[1]


def build_map(dataset='ml-32m',root='.',mode='genre-multihot',sample_size=3000,
              seed=42,neighbors=25,min_dist=0.15,embedding_npz=None,output=None):
    if not 2<=neighbors<=200:raise ValueError('neighbors must be 2..200')
    if not 0<=min_dist<=1:raise ValueError('min_dist must be 0..1')
    try:import umap
    except ImportError as exc:raise RuntimeError('Install UMAP: pip install -r requirements-research-lab.txt') from exc
    source=find_catalog(Path(root),dataset)
    catalog=load_catalog(source)
    sample=select_sample(catalog,int(sample_size),int(seed))
    if len(sample)<4:raise ValueError('At least 4 movies required')
    x,origin,dim=build_features(sample,mode,embedding_npz,seed)
    if not np.isfinite(x).all():raise ValueError('Nonfinite embeddings')
    # Reused maps are not cross-model aligned: axis rotations have no meaning.
    reducer=umap.UMAP(n_components=2,n_neighbors=min(neighbors,len(sample)-1),
                      min_dist=min_dist,metric='cosine',random_state=seed,n_jobs=1)
    xy=np.asarray(reducer.fit_transform(x),dtype=np.float32)
    if not np.isfinite(xy).all():raise ValueError('UMAP returned nonfinite coordinates')
    suffix = ''
    if mode == 'model-embeddings':
        suffix = '_' + re.sub(r'[^A-Za-z0-9_-]', '_', Path(embedding_npz).stem)[:55]
    dest=Path(output) if output else (Path(root)/'reports'/'research_lab'/'umap'/dataset/
                                     f'genre_umap_{mode}{suffix}_n{len(sample)}_seed{seed}.csv')
    dest.parent.mkdir(parents=True,exist_ok=True)
    table=sample[['movieId','title','genres']].copy()
    table['main_genre']=sample.genres.map(major_genre)
    table['x']=xy[:,0];table['y']=xy[:,1]
    table.to_csv(dest,index=False)
    details={'dataset':dataset,'source_catalog':str(source),'embedding_source':origin,
             'embedding_dimensions':int(dim),'mode':mode,'n_movies':len(table),
             'seed':seed,'neighbors':neighbors,'min_dist':min_dist,
             'note':'UMAP is exploratory. Distances across independently fitted maps are not comparable. '
                    'Genre colors are descriptive, not ranking metrics.'}
    dest.with_suffix('.json').write_text(json.dumps(details,indent=2),encoding='utf-8')
    print('Saved genre UMAP:',dest,flush=True)
    print('Metadata:',dest.with_suffix('.json'),flush=True)
    return dest


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset',choices=DATASETS,default='ml-32m')
    p.add_argument('--root',default='.')
    p.add_argument('--mode',choices=['genre-multihot','title-genre-tfidf','model-embeddings'],default='genre-multihot')
    p.add_argument('--sample-size',type=int,default=3000)
    p.add_argument('--neighbors',type=int,default=25)
    p.add_argument('--min-dist',type=float,default=0.15)
    p.add_argument('--seed',type=int,default=42)
    p.add_argument('--embedding-npz',default=None,
                   help='NPZ file with movie_ids and embeddings/item_vectors/vectors arrays')
    p.add_argument('--output',default=None)
    return build_map(**vars(p.parse_args(argv)))

if __name__=='__main__':main()
