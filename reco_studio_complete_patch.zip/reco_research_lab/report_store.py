"""Read-only, protocol-aware inspection of existing MovieLens experiments.

A report file is the atomic comparison unit. Do not pool numbers from distinct
source reports unless cohort identities and retrieval policies are identical.
"""
from __future__ import annotations
from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any

import pandas as pd

DATASETS = ('ml-latest-small', 'ml-1m', 'ml-32m')
KINDS = ('Temporal FM rating prediction', 'FM/BPR top-K ranking',
         'Shared chronology benchmark', 'Advanced retrieval',
         'Multi-source LambdaRank', 'Temporal preferences B/C/D/E',
         'Unified scalable comparison', 'MovieLens Small baseline', 'Other')


@dataclass(frozen=True)
class ReportRef:
    path: Path
    dataset: str
    kind: str
    modified: float


def classify(path: Path) -> str:
    filename = path.name
    if 'preference_experiments' in path.parts: return 'Temporal preferences B/C/D/E'
    if filename.startswith('advanced_retrieval_'): return 'Advanced retrieval'
    if filename.startswith(('advanced_ltr_', 'lambdamart_')): return 'Multi-source LambdaRank'
    if filename.startswith('shared_'): return 'Shared chronology benchmark'
    if filename.startswith(('ranking_',)): return 'FM/BPR top-K ranking'
    if filename.startswith('validation_'): return 'Temporal FM rating prediction'
    if filename.startswith('unified_'): return 'Unified scalable comparison'
    if filename == 'metrics.json' and path.parent.name == 'artifacts': return 'MovieLens Small baseline'
    return 'Other'


def discover(root: Path, dataset: str) -> list[ReportRef]:
    """Discover limited known report trees, never scan private user directories."""
    if dataset not in DATASETS: raise ValueError(f'Unsupported dataset: {dataset}')
    root = Path(root)
    candidates = []
    # Protect from accidental expensive recursive searches across large checkpoints.
    folders = [root/'reports'/'temporal'/dataset,
               root/'reports'/'temporal'/dataset/'preference_experiments',
               root/'reports'/'unified'/dataset,
               root/'reports'/'scalable'/dataset]
    if dataset == 'ml-latest-small':
        folders += [root/'artifacts', root/'reports'/'unified'/'ml-latest-small']
    seen = set()
    for folder in folders:
        if not folder.is_dir(): continue
        for path in folder.glob('*.json'):
            if path in seen or path.name in ('meta.json','manifest.json','metadata.json'): continue
            seen.add(path)
            kind = classify(path)
            if kind != 'Other' and path.is_file():
                candidates.append(ReportRef(path=path, dataset=dataset, kind=kind,
                                            modified=path.stat().st_mtime))
    return sorted(candidates, key=lambda p: p.modified, reverse=True)


def load_json(path: Path) -> dict[str, Any]:
    if Path(path).stat().st_size > 40_000_000:
        raise ValueError('Report exceeds 40 MB; inspect the summary CSV instead')
    result = json.loads(Path(path).read_text(encoding='utf-8'))
    if not isinstance(result, dict): raise ValueError('JSON report must be an object')
    return result


def metrics_frame(report: dict[str, Any], kind: str) -> pd.DataFrame:
    """Normalize metrics in a *single* report only; no cross-report leaderboard."""
    if kind == 'MovieLens Small baseline':
        return pd.DataFrame()  # choose validation/test before converting
    if kind == 'Temporal FM rating prediction':
        metrics = report.get('results', {})
    elif kind == 'Unified scalable comparison':
        metrics = report.get('results', {})
    else:
        metrics = report.get('metrics', {})
    if not isinstance(metrics, dict): return pd.DataFrame()
    records = {str(name): x for name, x in metrics.items() if isinstance(x, dict)}
    frame = pd.DataFrame.from_dict(records, orient='index')
    if not frame.empty: frame.index.name = 'model'
    return frame


def small_metrics_frame(report: dict[str, Any], split: str):
    if split not in ('validation','test'): raise ValueError('Bad split')
    return pd.DataFrame.from_dict(report.get(split, {}), orient='index')


def fingerprint(report: dict[str, Any], kind: str) -> tuple:
    """A *strict* signature for grouping preference results across files.

    Lack of evaluated_user_ids prevents assuming the cohorts are equal.
    """
    user_ids = report.get('evaluated_user_ids')
    if not isinstance(user_ids, list) or not user_ids: raise ValueError('Missing explicit user cohort')
    return (report.get('dataset'),report.get('split'), report.get('base_checkpoint'),
            report.get('seed'), report.get('k'), report.get('cutoff'),
            report.get('candidate_policy'), tuple(user_ids))


def comparable_preferences(reports: list[tuple[Path, dict]]) -> list[dict]:
    """One row per distinct stage with strict same-cohort guarantees."""
    if not reports: return []
    cohort = fingerprint(reports[0][1], 'Temporal preferences B/C/D/E')
    if any(fingerprint(r, 'Temporal preferences B/C/D/E') != cohort for _,r in reports):
        raise ValueError('Cannot compare preferences from different datasets, cohorts or candidate policies')
    # If multiple reports for the same stage, choose latest file rather than duplicate.
    chosen = {}
    for path,report in sorted(reports, key=lambda x: x[0].stat().st_mtime):
        chosen[report['stage']] = report
    rows = []
    first = next(iter(chosen.values()))
    for name in ('fm_base','popularity'):
        if name in first.get('metrics',{}): rows.append({'model':name,**first['metrics'][name]})
    for stage, report in sorted(chosen.items()):
        key = f'fm_{stage}_temporal'
        if key in report.get('metrics',{}):
            rows.append({'model':f'{stage.upper()} · {report.get("stage_description", "temporal")}',
                         **report['metrics'][key]})
    return rows


def discover_history(root: Path, dataset: str) -> list[Path]:
    if dataset not in DATASETS:raise ValueError('Bad dataset')
    roots=[Path(root)/'models'/dataset/'temporal_preferences',
           Path(root)/'models'/dataset/'temporal_fm']
    paths=[]
    for folder in roots:
        if folder.is_dir():paths.extend(folder.glob('*/history.json'))
    return sorted(paths, key=lambda p:p.stat().st_mtime, reverse=True)


def discover_checkpoints(root: Path, dataset: str) -> list[dict]:
    if dataset not in DATASETS:raise ValueError('Bad dataset')
    result=[]
    for sub in ('temporal_fm','temporal_preferences','shared_chrono_baselines'):
        folder=Path(root)/'models'/dataset/sub
        if not folder.is_dir():continue
        for model in sorted(folder.iterdir()):
            if not model.is_dir():continue
            weights=model/'weights.pt'
            meta=model/'metadata.json'
            if not meta.exists():meta=model/'meta.json'
            record={'family':sub,'name':model.name,'weights_present':weights.exists(),
                    'metadata_present':meta.exists(),'last_updated':model.stat().st_mtime}
            if meta.exists():
                try:
                    parsed=load_json(meta)
                    for key in ('fm_order','objective','profile','kind','stage','run_label','seed'):
                        if key in parsed and isinstance(parsed[key],(str,int,float)):
                            record[key]=parsed[key]
                except (ValueError,OSError):record['metadata_error']=True
            result.append(record)
    return result


def discover_logs(root: Path) -> list[Path]:
    folder=Path(root)
    paths = list(folder.glob('*.log')) + list((folder/'logs').glob('*.log'))
    return sorted((p for p in paths if p.is_file()),key=lambda p:p.stat().st_mtime,reverse=True)[:50]


def tail_log(path: Path, lines: int = 150) -> str:
    """Bounded log tail (last 256 KB) even for very large research runs."""
    lines=max(1,min(int(lines),1000))
    with Path(path).open('rb') as stream:
        stream.seek(0,2)
        stream.seek(max(0,stream.tell()-262144))
        data=stream.read().decode('utf-8',errors='replace')
    return '\n'.join(data.splitlines()[-lines:])
