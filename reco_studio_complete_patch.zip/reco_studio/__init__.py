"""Reco Studio: tested, read-only recommendation and experiment UI."""
__version__ = '1.0.0'
