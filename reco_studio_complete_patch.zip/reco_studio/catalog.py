"""Small/1M/32M catalogue loading and no-model-needed content recommendations.

No network access, checkpoints or user-held-out ratings are used by this module.
"""
from __future__ import annotations
from functools import lru_cache
from pathlib import Path
import re
import numpy as np
import pandas as pd
from reco_research_lab.genre_umap import find_catalog, load_catalog
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import normalize


def catalog(root: str | Path, dataset: str) -> pd.DataFrame:
    """Load the *selected dataset* catalogue, never fall back to another dataset."""
    return load_catalog(find_catalog(Path(root), dataset))


def movie_filter(frame: pd.DataFrame, genre: str = 'All genres', query: str = '',
                 min_year: int = 0, max_year: int = 9999) -> np.ndarray:
    years = pd.to_numeric(frame.title.str.extract(r'\((\d{4})\)\s*$')[0], errors='coerce')
    keep = (years.isna() | years.between(min_year, max_year)).to_numpy()
    if genre != 'All genres':
        keep &= frame.genres.fillna('').str.split('|').apply(lambda g: genre in g).to_numpy()
    if query.strip():
        keep &= frame.title.str.contains(query.strip(), case=False, regex=False, na=False).to_numpy()
    return keep


def genre_options(frame: pd.DataFrame) -> list[str]:
    all_genres = {g for row in frame.genres.fillna('').astype(str)
                  for g in row.split('|') if g and g != '(no genres listed)'}
    return ['All genres', *sorted(all_genres)]


def catalog_index(frame: pd.DataFrame) -> dict[int,int]:
    return {int(movie):int(i) for i,movie in enumerate(frame.movieId)}


def content_recommendations(frame: pd.DataFrame, favorites: list[int], k: int = 10,
                            genre: str = 'All genres', min_year: int = 0,
                            max_year: int = 9999, movie_query: str = '') -> pd.DataFrame:
    """Real TF-IDF genre/title similarity; no claims of personalized neural inference."""
    if not 1 <= k <= 100: raise ValueError('k must be 1..100')
    mapping = catalog_index(frame)
    fav_indices = [mapping[int(x)] for x in dict.fromkeys(favorites) if int(x) in mapping]
    if not fav_indices: raise ValueError('Choose at least one known favorite movie')
    text = (frame.title.fillna('').str.replace(r'\(\d{4}\)\s*$', '', regex=True)
            + ' ' + frame.genres.fillna('').str.replace('|', ' ', regex=False) * 3)
    tfidf = TfidfVectorizer(strip_accents='unicode', ngram_range=(1,2),
                            token_pattern=r'(?u)\b\w+\b', min_df=1)
    sparse = tfidf.fit_transform(text)
    profile = np.asarray(sparse[fav_indices].mean(axis=0)).ravel()
    profile /= max(float(np.linalg.norm(profile)), 1e-12)
    # scipy sparse matrix * dense normalized preference vector
    scores = np.asarray(sparse @ profile).ravel().astype('float32')
    eligible = movie_filter(frame, genre, movie_query, min_year, max_year)
    eligible[np.asarray(fav_indices, dtype=int)] = False
    return top_results(frame, scores, eligible, k, score_label='Content similarity')


def top_results(frame: pd.DataFrame, scores: np.ndarray, eligible: np.ndarray,
                k: int, score_label: str = 'Score') -> pd.DataFrame:
    """Never back-fill with excluded films, even when fewer than K remain."""
    scores = np.asarray(scores, dtype='float64').ravel()
    eligible = np.asarray(eligible, dtype=bool)
    if len(frame) != len(scores) or len(frame) != len(eligible):
        raise ValueError('Scores and eligibility must align with catalogue')
    if k < 1: raise ValueError('k must be positive')
    pool = np.flatnonzero(eligible & np.isfinite(scores))
    if not len(pool):
        return pd.DataFrame(columns=['movieId','title','genres',score_label])
    # stable deterministic sorting; only sort bounded results if possible
    winners = pool[np.argsort(-scores[pool], kind='stable')[:k]]
    result = frame.iloc[winners][['movieId','title','genres']].copy()
    result[score_label] = np.round(scores[winners], 4)
    return result.reset_index(drop=True)


def favorites_matching(frame: pd.DataFrame, query: str, limit: int = 70) -> pd.DataFrame:
    query = query.strip()
    if not query: return frame[['movieId','title','genres']].head(min(30, limit)).copy()
    matches = frame[frame.title.str.contains(query, case=False, regex=False, na=False)]
    return matches[['movieId','title','genres']].head(limit).copy()
