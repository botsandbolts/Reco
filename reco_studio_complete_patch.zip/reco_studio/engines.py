"""Read-only recommendation engine adapters for *installed* trained checkpoints.

Loading is opt-in when users click Recommend. Checkpoint metadata and source signatures
are verified by temporal_fm.ranking._model, never silently downgraded to FM2.
"""
from __future__ import annotations
from functools import lru_cache
from pathlib import Path
import json
import numpy as np
import pandas as pd
from .catalog import top_results


class MissingModel(RuntimeError):
    pass


def small_checkpoint(root: Path) -> Path:
    return root/'artifacts'/'recommender.joblib'


def small_recommend(root: Path, raw_user: int, model_name: str, k: int):
    from src.recommender import HybridRecommender
    path = small_checkpoint(root)
    if not path.is_file():
        raise MissingModel('MovieLens Small model absent: run `python -m src.train`.')
    # joblib/pickle can execute code. Only load *your own* trusted training artifacts.
    engine = HybridRecommender.load(path)
    if int(raw_user) not in engine.user_to_idx: raise ValueError('Not an existing training user')
    if model_name not in engine.models: raise ValueError('Selected model is not trained')
    return engine.recommend(int(raw_user), k=k, model=model_name), engine


def temporal_checkpoints(root: Path, dataset: str) -> list[dict]:
    folder = root/'models'/dataset/'temporal_fm'
    output=[]
    if not folder.is_dir(): return output
    for path in sorted(folder.iterdir()):
        if not path.is_dir() or not (path/'weights.pt').is_file(): continue
        meta_file=path/'metadata.json'
        if not meta_file.is_file(): continue
        try:
            if meta_file.stat().st_size>300_000:continue
            m=json.loads(meta_file.read_text(encoding='utf-8'))
            if not isinstance(m,dict):continue
            output.append({'name':path.name,'fm_order':m.get('fm_order',2),
                           'objective':m.get('objective','unspecified'),
                           'seed':m.get('seed'), 'backend':m.get('text_backend',m.get('backend','sentence')),
                           'profile':m.get('profile','unknown'),'path':path})
        except (ValueError,OSError): continue
    return output


def preference_checkpoints(root: Path, dataset: str, base: str) -> list[dict]:
    folder = root/'models'/dataset/'temporal_preferences'
    output=[]
    if not folder.exists():return output
    for path in sorted(folder.iterdir()):
        meta_file = path/'metadata.json'
        if not (path/'weights.pt').is_file() or not meta_file.is_file(): continue
        try:
            meta=json.loads(meta_file.read_text(encoding='utf-8'))
        except (OSError,ValueError): continue
        if meta.get('base_model')==base and meta.get('stage') in ('b','c','d','e'):
            output.append({'name':path.name,'stage':meta['stage'],'path':path})
    return output


def ltr_checkpoints(root: Path, dataset: str, base: str) -> list[dict]:
    result=[]
    base_folder=root/'models'/dataset/'temporal_fm'/'advanced_ltr'
    for path in sorted(base_folder.glob('*/model.txt')):
        meta_file=path.parent/'metadata.json'
        if not meta_file.exists(): continue
        try:meta=json.loads(meta_file.read_text(encoding='utf-8'))
        except (OSError,ValueError):continue
        if meta.get('base_model')==base:
            result.append({'name':path.parent.name,'path':path,'metadata':meta})
    return result


@lru_cache(maxsize=3)
def _events(folder: str):
    from temporal_fm.data import Events
    return Events(Path(folder))


def get_events(root: Path, dataset: str):
    folder=root/'data'/'temporal'/dataset
    if not (folder/'manifest.json').is_file():
        raise MissingModel(f'Missing prepared temporal data for {dataset}. Train or prepare the Temporal FM pipeline first.')
    return _events(str(folder.resolve()))


def training_seen(ev, raw_user: int) -> tuple[set[int], pd.DataFrame]:
    """Scan ONLY train indices, in bounded chunks, for one user; display most recent ratings."""
    if int(ev.user_indices([int(raw_user)])[0]) == 0:
        raise ValueError(f'User {raw_user} has no training history in this dataset')
    found=[]; seen=set()
    idx=ev.split('train')
    for start in range(0,len(idx),400_000):
        chunk=np.asarray(idx[start:start+400_000],dtype=np.int64)
        chosen=chunk[np.asarray(ev.user_raw[chunk],dtype=np.int32)==int(raw_user)]
        if len(chosen):
            mids=np.asarray(ev.movie_idx[chosen],dtype=np.int32)
            seen.update(map(int,mids))
            found.extend(map(int,chosen))
    if not found:raise ValueError('User has no actual training interactions')
    found=np.asarray(found,dtype=np.int64)
    order=np.argsort(np.asarray(ev.timestamp[found],dtype=np.int64),kind='stable')[-40:][::-1]
    chosen=found[order]
    history=pd.DataFrame({'movieId':np.asarray(ev.movies.movieId.iloc[np.asarray(ev.movie_idx[chosen],dtype=np.int32)]),
      'title':np.asarray(ev.movies.title.iloc[np.asarray(ev.movie_idx[chosen],dtype=np.int32)]),
      'rating':np.asarray(ev.rating[chosen],dtype=np.float32),
      'date':pd.to_datetime(np.asarray(ev.timestamp[chosen],dtype=np.int64),unit='s',utc=True)})
    return seen,history


@lru_cache(maxsize=3)
def training_movie_counts(folder: str):
    ev=_events(folder)
    counts=np.zeros(len(ev.movies),dtype=np.int64)
    idx=ev.split('train')
    for start in range(0,len(idx),500_000):
        chunk=np.asarray(idx[start:start+500_000],dtype=np.int64)
        counts+=np.bincount(np.asarray(ev.movie_idx[chunk],dtype=np.int32),minlength=len(counts))
    return counts


def eligible_movies(ev, seen: set[int], genre: str = 'All genres',
                    min_year: int = 0, max_year: int = 9999):
    """Known-at-cutoff warm catalogue; optional user-requested genre/year filtering."""
    eligible = np.ones(len(ev.movies),dtype=bool)
    eligible[~np.asarray(ev.movie_has_train,dtype=bool)] = False
    if seen: eligible[np.fromiter(seen,dtype=np.int32)] = False
    # No future-released movies (as extracted from title year) at global cutoff.
    cutoff_year=int(pd.Timestamp(int(ev.meta['train_cutoff']),unit='s',tz='UTC').year)
    years=np.asarray(ev.release_year,dtype=np.int32)
    eligible &= ((years<=cutoff_year) | (years<=0))
    eligible &= ((years>=min_year) | (years<=0)) & ((years<=max_year) | (years<=0))
    if genre != 'All genres':
        if genre not in ev.genres: return np.zeros(len(eligible),dtype=bool)
        eligible &= ev.genre_matrix[:,ev.genres.index(genre)]>0
    return np.flatnonzero(eligible).astype(np.int32)


def popularity_recommend(root: Path,dataset: str,user_id: int,k: int=10,
                         genre: str='All genres',min_year:int=0,max_year:int=9999):
    ev=get_events(root,dataset)
    seen,history=training_seen(ev,user_id)
    candidates=eligible_movies(ev,seen,genre,min_year,max_year)
    scores=np.log1p(training_movie_counts(str(ev.folder.resolve()))[candidates]).astype('float32')
    ranked=candidates[np.argsort(-scores,kind='stable')[:k]]
    result=ev.movies.iloc[ranked][['movieId','title','genres']].copy()
    result['Popularity score']=np.round(np.log1p(training_movie_counts(str(ev.folder.resolve()))[ranked]),4)
    return result.reset_index(drop=True),history


def baseline_checkpoints(root: Path, dataset: str, ev=None) -> list[dict]:
    """Discover ALREADY trained chronological SVD/BPR factors; never train in UI."""
    folder=root/'models'/dataset/'shared_chrono_baselines'
    result=[]
    if not folder.is_dir():return result
    for file in sorted(folder.glob('*/factors.npz')):
        manifest=file.parent/'manifest.json'
        if not manifest.exists():continue
        try:
            meta=json.loads(manifest.read_text(encoding='utf-8'))
        except (OSError,ValueError):continue
        if meta.get('dataset')!=dataset:continue
        if ev is not None and (meta.get('sources')!=ev.meta.get('sources') or
                               meta.get('cutoff')!=ev.meta.get('train_cutoff')):
            continue
        result.append({'name':file.parent.name,'path':file,'metadata':meta})
    return result


def baseline_recommend(root: Path,dataset: str,user_id: int,baseline: dict,
                       method: str,k:int=10,genre: str='All genres',min_year:int=0,max_year:int=9999):
    """Genuine cached SVD/BPR-MF inference, with metadata and shape checks."""
    if method not in ('SVD','BPR-MF'):raise ValueError('Unknown matrix factorization method')
    ev=get_events(root,dataset)
    seen,history=training_seen(ev,user_id)
    if baseline['metadata'].get('sources')!=ev.meta.get('sources') or baseline['metadata'].get('cutoff')!=ev.meta.get('train_cutoff'):
        raise ValueError('SVD/BPR factors were trained on a different data cutoff')
    with np.load(baseline['path'],allow_pickle=False) as arrays:
        prefix='svd' if method=='SVD' else 'bpr'
        users=np.asarray(arrays[f'{prefix}_user'],dtype=np.float32)
        items=np.asarray(arrays[f'{prefix}_item'],dtype=np.float32)
    uid=int(ev.user_indices([user_id])[0])-1
    if uid<0 or uid>=len(users):raise ValueError('User ID absent from baseline factor matrix')
    if len(items)!=len(ev.movies) or users.shape[1]!=items.shape[1]:
        raise ValueError('Factor vectors do not align with prepared movie catalogue')
    candidates=eligible_movies(ev,seen,genre,min_year,max_year)
    scored=items[candidates]@users[uid]
    subset=ev.movies.iloc[candidates].reset_index(drop=True)
    return top_results(subset,scored,np.ones(len(candidates),dtype=bool),k,f'{method} score'),history


def temporal_context(ev,backend,model_name,root):
    from temporal_fm.train import FeatureProvider
    from temporal_fm.ranking import _model
    feature_dir=ev.folder/f'features_{backend}'
    meta_file=feature_dir/'meta.json'
    if not meta_file.is_file():raise MissingModel(f'Missing title embeddings: {meta_file}')
    md=json.loads(meta_file.read_text())
    tag_dir=feature_dir if (feature_dir/'tag_keys.npy').exists() else None
    if ev.meta.get('tags_path') and tag_dir is None:
        raise MissingModel('Historical tag files are missing. Rebuild the feature cache.')
    p=FeatureProvider(ev,backend,md['model_name'],tag_dir)
    p.model_name=md['model_name']
    p.backend=backend
    # ranking._model uses relative paths rooted at cwd. Callers run Codespaces from repo root.
    m=_model(ev,p,model_name,backend,'cpu')
    return p,m


def temporal_recommend(root: Path,dataset: str,user_id: int,model_name: str,
                       k: int=10,genre:str='All genres',min_year:int=0,max_year:int=9999,
                       preference: Path|None=None,ranker: dict|None=None,
                       threads: int=4):
    import torch
    from temporal_fm.ranking import score_candidates
    torch.set_num_threads(max(1,int(threads)))
    ev=get_events(root,dataset)
    seen,history=training_seen(ev,user_id)
    candidates=eligible_movies(ev,seen,genre,min_year,max_year)
    if not len(candidates):raise ValueError('No eligible unseen movies match these filters')
    checkpoint={v['name']:v for v in temporal_checkpoints(root,dataset)}.get(model_name)
    if not checkpoint:raise MissingModel(f'Missing checkpoint {model_name}')
    backend=checkpoint['backend']
    provider,model=temporal_context(ev,backend,model_name,root)
    at_time=int(ev.meta['train_cutoff'])+1
    if ranker is not None:
        result=_lambda_rank_recommend(ev,provider,model,user_id,seen,candidates,k,ranker,threads)
        return result,history
    if preference is not None:
        from temporal_fm.preference_experiment import (HistoryIndex,TemporalPreferenceFeatures,
             _checkpoint_info,_load_head,_score_corrected)
        md=json.loads((preference/'metadata.json').read_text())
        stage=md.get('stage')
        builder=TemporalPreferenceFeatures(ev,provider,HistoryIndex(ev),stage)
        expected=_checkpoint_info(ev,provider,model_name,stage,md['seed'])
        head=_load_head(preference,expected,ev,provider,'cpu')
        scores=_score_corrected(head,model,ev,provider,builder,user_id,at_time,candidates,device='cpu')
    else:
        scores=score_candidates(model,ev,provider,user_id,candidates,at_time,device='cpu',batch_size=2048)
    subset=ev.movies.iloc[candidates].reset_index(drop=True)
    final=top_results(subset,scores,np.ones(len(subset),dtype=bool),k,'Model score')
    return final,history


def _lambda_rank_recommend(ev,provider,base,user_id,seen,candidates,k,ranker,threads):
    """Recreate the saved reranker feature pipeline with *no* held-out labels."""
    try:import lightgbm as lgb
    except ImportError as exc:raise MissingModel('Install LightGBM to score saved LambdaRank models') from exc
    from temporal_fm.advanced_retrieval import AdvancedRetriever,SOURCES
    md=ranker['metadata']
    if md.get('cutoff')!=ev.meta.get('train_cutoff') or md.get('sources')!=ev.meta.get('sources'):
        raise ValueError('Saved LambdaRank model uses a different data snapshot')
    if md.get('backend')!=provider.backend:
        raise ValueError('Saved LambdaRank backend differs from the currently loaded FM features')
    if md.get('feature_names') is None:raise ValueError('Missing LambdaRank feature schema')
    counts=training_movie_counts(str(ev.folder.resolve()))
    retriever=AdvancedRetriever(ev,provider,base,{int(user_id):set(seen)},[int(user_id)],counts,
          sources=SOURCES,baseline_profile=md.get('baseline_profile','quick'),
          seed=md.get('seed',42),threads=threads,device='cpu')
    q=retriever.query(int(user_id),set(seen),set(),md.get('quotas'))
    if q is None:raise ValueError('The retriever returned no candidates')
    # Filtering applies before sorting (not after), while respecting the training cutoff.
    allowed=set(map(int,candidates))
    keep=np.asarray([int(mid) in allowed for mid in q['movies']],dtype=bool)
    if not keep.any():raise ValueError('No multi-source candidates survive your genre/year filters')
    booster=lgb.Booster(model_file=str(ranker['path']))
    if booster.num_feature()!=len(md['feature_names']) or q['features'].shape[1]!=booster.num_feature():
        raise ValueError('Saved LightGBM feature schema differs from installed code')
    preds=np.asarray(booster.predict(q['features'][keep],num_threads=threads),dtype=np.float64)
    indices=np.asarray(q['movies'],dtype=np.int32)[keep]
    chosen=indices[np.argsort(-preds,kind='stable')[:k]]
    scores=preds[np.argsort(-preds,kind='stable')[:k]]
    result=ev.movies.iloc[chosen][['movieId','title','genres']].copy()
    result['LambdaRank score']=np.round(scores,4)
    return result.reset_index(drop=True)
