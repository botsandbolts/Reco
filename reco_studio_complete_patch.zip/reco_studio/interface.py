"""One coherent Streamlit UI for interactive movies and honest ML experiments.

All tabs are independent; missing optional files never crash the whole interface.
"""
from __future__ import annotations
from datetime import datetime
from pathlib import Path
import json
import numpy as np
import pandas as pd
from .catalog import (catalog,genre_options,content_recommendations,
                      favorites_matching,top_results)
from .engines import (small_checkpoint,small_recommend,temporal_checkpoints,
                      preference_checkpoints,ltr_checkpoints,temporal_recommend,
                      popularity_recommend,get_events,MissingModel,baseline_checkpoints,baseline_recommend)
from reco_research_lab.report_store import (DATASETS,discover,discover_history,
    discover_checkpoints,discover_logs,tail_log,load_json,metrics_frame,small_metrics_frame,
    comparable_preferences)


def _css(st):
    st.markdown('''<style>
    .block-container { max-width: 1450px; padding-top: 1.5rem; }
    div[data-testid="stMetric"] { background: rgba(110,125,150,.09); padding: 12px; border-radius: 10px; }
    [data-testid="stDataFrame"] {border:1px solid rgba(150,150,150,.2);border-radius:8px;}
    </style>''',unsafe_allow_html=True)


def _title(st):
    st.title('🎬 Reco Studio')
    st.caption('Interactive recommendations · MovieLens research · Transparent evaluation')


def _safe_render(st,fn,*args):
    try: fn(st,*args)
    except (FileNotFoundError,ValueError,RuntimeError,ImportError,OSError,KeyError,IndexError) as exc:
        st.error(f'{type(exc).__name__}: {exc}')
        st.caption('Other Studio tabs remain available. Your checkpoints and reports have not been changed.')


def _catalog(st,root,dataset):
    from reco_research_lab.genre_umap import find_catalog
    try: return catalog(root,dataset)
    except (FileNotFoundError,ValueError) as exc:
        st.warning(str(exc))
        st.caption('The catalogue is required for recommendations. See **Setup & checkpoints** for data preparation commands.')
        return None


def _display_recs(st,rec,title,key):
    st.subheader(title)
    if rec is None or rec.empty:
        st.info('No eligible unseen movies match the selected criteria. Relax the filters or choose another user.');return
    st.caption(f'{len(rec)} recommendations · ratings excluded where a known-user history is available')
    st.dataframe(rec,hide_index=True,use_container_width=True)
    st.download_button('Download recommendations CSV',rec.to_csv(index=False).encode('utf-8'),
                       file_name='reco_recommendations.csv',mime='text/csv',key=f'reco_download_{key}')


def _overview(st,root,dataset):
    reports=discover(root,dataset)
    checkpoints=discover_checkpoints(root,dataset)
    c1,c2,c3=st.columns(3)
    c1.metric('Reports',len(reports));c2.metric('Checkpoints',len(checkpoints))
    c3.metric('Dataset',{'ml-32m':'32M','ml-1m':'1M','ml-latest-small':'Small'}[dataset])
    st.markdown('**Use the Recommendations tab to score real movies.** Movie Discovery works with catalogue data alone. '
                'Other tabs show saved experiment results, not generated or synthetic benchmarks.')
    st.caption('For research plots, choose one evaluation report at a time. Different MovieLens sizes, '
               'chronological cutoffs and sampled/full candidate protocols are never pooled.')


def _known_user(st,root,dataset):
    st.subheader('Find movies for a known MovieLens user')
    if dataset=='ml-latest-small':
        _small_user(st,root)
    else:
        _temporal_user(st,root,dataset)


def _small_user(st,root):
    if not small_checkpoint(root).is_file():
        st.warning('No trained MovieLens Small artifact found. Run `python -m src.train` in Codespaces.')
        st.code('python -m src.train',language='bash')
        return
    # Locally trained joblib models are trusted by the user. Never load untrusted external pickles.
    from src.recommender import HybridRecommender
    @st.cache_resource(show_spinner='Loading your trusted MovieLens Small model...')
    def _load(path,mtime):return HybridRecommender.load(path)
    engine=_load(str(small_checkpoint(root)),small_checkpoint(root).stat().st_mtime_ns)
    users=engine.user_ids.tolist()
    col1,col2,col3=st.columns([2,2,1])
    with col1:user=st.selectbox('Anonymous training user',users,key='small_known_user')
    with col2:model=st.selectbox('Recommendation model',engine.models,key='small_user_model')
    with col3:k=st.slider('Movies',5,30,10,key='small_user_k')
    if st.button('Recommend movies',type='primary',key='small_run'):
        scores=np.asarray(engine.score_user(int(user),model),dtype=float)
        allowed=np.ones(len(scores),dtype=bool)
        allowed[list(engine.seen[int(user)])]=False
        rec=top_results(engine.movies,scores,allowed,k,score_label='Model score')
        st.session_state['reco_small_last']=(user,model,k,rec)
    rec=st.session_state.get('reco_small_last')
    if rec and rec[:3]==(user,model,k):_display_recs(st,rec[3],'Recommended movies','small')
    with st.expander('Recent training history (no held-out events)'):
        seen=sorted(engine.seen[int(user)])
        st.dataframe(engine.movies.iloc[seen][['title','genres']].tail(25),hide_index=True)


def _temporal_user(st,root,dataset):
    try:ev=get_events(root,dataset)
    except (FileNotFoundError,ValueError,MissingModel) as exc:
        st.warning(str(exc));return
    checkpoints=temporal_checkpoints(root,dataset)
    baselines=baseline_checkpoints(root,dataset,ev)
    c1,c2=st.columns([2,2]);
    with c1:
        raw_user=int(st.number_input('MovieLens user ID',min_value=1,max_value=9999999,
                         value=int(ev.train_users[0]),step=1,key=f'uid_{dataset}'))
    if int(ev.user_indices([raw_user])[0])==0:
        st.warning('Unknown user at the training cutoff. Choose an ID in the training set.');return
    with c2:
        genre=st.selectbox('Genre filter', ['All genres', *ev.genres],key=f'rec_genre_{dataset}')
    a,b,c=st.columns([1,1,1]);
    with a:k=st.slider('Results',5,50,10,key='temporal_k')
    with b:threads=st.selectbox('CPU threads',[1,2,4],index=2,key='threads')
    with c:method=st.selectbox('Retrieval / scoring',
                    ['Popularity (train only)'] +
                    [f'{kind} cached baseline: {c["name"]}' for c in baselines for kind in ('SVD','BPR-MF')] +
                    [f'FM/HOFM checkpoint: {c["name"]}' for c in checkpoints],
                    key=f'temporal_method_{dataset}')
    model_name=method.split(': ',1)[1] if method.startswith('FM/HOFM checkpoint: ') else None
    baseline=next((r for r in baselines if method.endswith(': '+r['name'])),None) if 'cached baseline' in method else None
    baseline_kind=method.split(' cached baseline:',1)[0] if baseline else None
    preference=None;ranker=None
    if model_name:
        addon=['Base FM/HOFM score']
        prefs=preference_checkpoints(root,dataset,model_name)
        rerankers=ltr_checkpoints(root,dataset,model_name)
        addon.extend([f'Temporal {r["stage"].upper()}: {r["name"]}' for r in prefs])
        addon.extend([f'LightGBM LambdaRank: {r["name"]}' for r in rerankers])
        addon_choice=st.selectbox('Optional post-processing',addon,key='rec_addon')
        preference=next((r['path'] for r in prefs if addon_choice==f'Temporal {r["stage"].upper()}: {r["name"]}'),None)
        ranker=next((r for r in rerankers if addon_choice==f'LightGBM LambdaRank: {r["name"]}'),None)
        st.caption('FM/HOFM scores all eligible warm movies. Temporal preferences apply a trained residual; '
                   'LambdaRank reranks its multi-source retrieved candidates. No held-out labels enter recommendations.')
    if not checkpoints and not baselines:
        st.info('No compatible saved factor/checkpoint models found locally. Popularity works without model weights.')
    st.caption('Recommendation time = immediately after the **global training cutoff**. '
               'Newer ratings are not used as features. Movies already rated in training are removed.')
    if st.button('Generate recommendations',type='primary',key='temporal_recommend'):
        with st.spinner('Scoring eligible movies with the selected trained model...'):
            try:
                if baseline is not None:
                    rec,hist=baseline_recommend(root,dataset,raw_user,baseline,baseline_kind,k,genre)
                elif model_name:
                    rec,hist=temporal_recommend(root,dataset,raw_user,model_name,k,genre,
                                                preference=preference,ranker=ranker,threads=threads)
                else:
                    rec,hist=popularity_recommend(root,dataset,raw_user,k,genre)
                st.session_state['temporal_last']=(dataset,raw_user,method,addon_choice if model_name else 'pop',rec,hist,genre,k)
            except (ImportError,FileNotFoundError,ValueError,RuntimeError,KeyError,IndexError) as exc:
                st.error(f'Could not score this checkpoint: {exc}')
                st.info('Your checkpoint is unchanged. Verify the model metadata, feature cache, and installed HOFM3 loader.')
    value=st.session_state.get('temporal_last')
    if value and value[:4]==(dataset,raw_user,method,addon_choice if model_name else 'pop') and value[6:]==(genre,k):
        _display_recs(st,value[4],'Personalized top movies','temporal')
        with st.expander('User rating history used at cutoff'):
            st.dataframe(value[5],hide_index=True,use_container_width=True)
    elif value:
        st.info('Your selection has changed. Click Generate recommendations for the new settings.')


def _discover_movies(st,root,dataset):
    st.subheader('Discover movies from your favorites')
    df=_catalog(st,root,dataset)
    if df is None:return
    st.caption(f'{len(df):,} movies · Available without training a model · genre/title TF-IDF cosine similarity')
    query=st.text_input('Search for favorite movies',value='',placeholder='Type part of a title, e.g. Matrix',key='favorite_search')
    options=favorites_matching(df,query,limit=70)
    choices={f'{row.title} · #{int(row.movieId)}':int(row.movieId)
             for row in options.itertuples(index=False)}
    found=st.multiselect('Choose favorites from search results',list(choices),
                         key=f'fav_select_{dataset}',max_selections=8)
    # Preserve prior favorites across search queries and reruns.
    key=f'favorite_ids_{dataset}';st.session_state.setdefault(key,[])
    if st.button('Add selected to favorites',key='add_favorites'):
        st.session_state[key]=list(dict.fromkeys(st.session_state[key]+[choices[n] for n in found]))
    selected=st.session_state[key]
    if selected:
        mapping=df.set_index('movieId')
        st.write('**Selected favorites:** ', ', '.join(str(mapping.loc[x].title) for x in selected if x in mapping.index))
        if st.button('Clear favorites',key='clear_favs'):st.session_state[key]=[];st.rerun()
    controls=st.columns([2,1])
    with controls[0]:g=st.selectbox('Optional genre',genre_options(df),key='fav_genre')
    with controls[1]:k=st.slider('How many?',5,40,12,key='fav_k')
    if st.button('Find similar movies',type='primary',key='find_similar'):
        if not selected: st.warning('First add at least one favorite movie.')
        else:
            with st.spinner('Comparing titles and genres...'):
                result=content_recommendations(df,selected,k=k,genre=g)
            st.session_state['fav_last']=(dataset,tuple(selected),k,g,result)
    past=st.session_state.get('fav_last')
    if past and past[:4]==(dataset,tuple(selected),k,g):_display_recs(st,past[4],'Movies you might enjoy','favorites')
    st.divider()
    with st.expander('Browse and filter the movie catalogue'):
        filter_text=st.text_input('Filter titles',key='browse_title')
        selection=favorites_matching(df,filter_text,limit=120)
        st.dataframe(selection,hide_index=True,use_container_width=True)


def _metric_table(st,report,kind,split,prefix):
    df=small_metrics_frame(report,split) if kind=='MovieLens Small baseline' else metrics_frame(report,kind)
    if df.empty:
        st.info('This report has no recognized model metrics. View JSON metadata below.');return
    available=[c for c in ('ndcg_at_k','recall_at_k','hit_rate_at_k','precision_at_k',
                          'mrr_at_k','catalog_coverage_at_k','rmse','mae')
               if c in df.columns and pd.to_numeric(df[c],errors='coerce').notna().any()]
    if available:
        metric=st.selectbox('Metric to visualize',available,key=f'{prefix}_metric')
        series=pd.to_numeric(df[metric],errors='coerce').dropna()
        series=series.sort_values(ascending=metric in ('rmse','mae'))
        st.bar_chart(series)
    st.dataframe(df,use_container_width=True)


def _model_comparisons(st,root,dataset):
    st.subheader('Matched benchmark reports')
    refs=discover(root,dataset)
    supported=[r for r in refs if r.kind not in ('Advanced retrieval','Other')]
    if not supported:
        st.info('No saved benchmark reports found for this dataset. Run `temporal_fm.ranking`, `shared_benchmark`, or training.');return
    families=sorted({r.kind for r in supported})
    family=st.selectbox('Experiment family',families,key='studio_family')
    subset=[r for r in supported if r.kind==family]
    selection=st.selectbox('Report (newest first)',subset,format_func=lambda x:x.path.name,key='studio_report')
    report=load_json(selection.path)
    if report.get('dataset') and report['dataset'] not in (dataset,'MovieLens latest-small (GroupLens)'):
        st.error('Report metadata names another dataset. Declining to plot.');return
    st.caption(f'File: {selection.path.relative_to(root)} · '
               f'Split: {report.get("split","unspecified")} · K={report.get("k","unknown")} · '
               f'Cutoff: {report.get("cutoff",report.get("train_cutoff","unknown"))}')
    if family in ('Unified scalable comparison','MovieLens Small baseline'):
        st.info('This experiment uses a per-user holdout; do not compare its NDCG to global chronological 32M FM.')
    if 'sampled' in str(report.get('candidate_policy','')).lower():
        st.warning('Sampled-candidate metrics are not comparable to full-catalogue ranking metrics.')
    if family=='Temporal FM rating prediction':
        st.warning('RMSE and MAE describe rating prediction, not NDCG ranking.')
    split=st.radio('Holdout',['validation','test'],horizontal=True,key='studio_small_split') if family=='MovieLens Small baseline' else None
    _metric_table(st,report,family,split,'studio_report')
    if family=='Temporal preferences B/C/D/E':
        # Cross-file aggregation only when full cohort IDs and all protocol fields match.
        from reco_research_lab.report_store import fingerprint
        try:
            wanted=fingerprint(report,family)
            cohort=[]
            for candidate in subset:
                raw=load_json(candidate.path)
                try: actual=fingerprint(raw,family)
                except (KeyError,TypeError,ValueError):continue
                if wanted==actual:cohort.append((candidate.path,raw))
            if len({r.get('stage') for _,r in cohort})>=2:
                st.markdown('#### Matched B / C / D / E comparison')
                frame=pd.DataFrame(comparable_preferences(cohort)).set_index('model')
                _metric_table(st,{'metrics':frame.to_dict(orient='index')},'Temporal preferences B/C/D/E',None,'studio_bcd_matched')
            else:
                st.caption('Only one stage, or no explicit identical user cohort, is available. '
                           'To compare B/C/D, evaluate each on the same users and split.')
        except (ValueError,TypeError,KeyError) as exc:
            st.caption(f'Cannot safely combine temporal preference reports: {exc}')
    with st.expander('Saved example recommendations'):
        examples=report.get('examples',{})
        if not examples:st.info('No movie lists were saved in this report. Use Recommendations for live scoring.')
        else:st.json(examples)
    with st.expander('Complete report metadata'):
        st.json({k:v for k,v in report.items() if k not in ('per_user','history')})


def _training(st,root,dataset):
    st.subheader('Training histories · FM / HOFM3 / B+C+D / DeepFM')
    paths=discover_history(root,dataset)
    if paths:
        p=st.selectbox('Training checkpoint history',paths,format_func=lambda p:p.parent.name,key='studio_history')
        content=json.loads(p.read_text(encoding='utf-8'))
        rows=content if isinstance(content,list) else next((content[x] for x in ('history','epochs','training_history')
                        if isinstance(content.get(x),list)),[])
        df=pd.DataFrame([r for r in rows if isinstance(r,dict)])
        if not df.empty:
            st.dataframe(df,use_container_width=True)
            ep='epoch' if 'epoch' in df else df.columns[0]
            numeric=[col for col in df if pd.api.types.is_numeric_dtype(df[col]) and col!=ep]
            if numeric:
                for filt,label in ((('loss',),'Training loss'),(('ndcg','recall','hit'),'Validation metrics'),
                                   (('seconds','duration'),'Epoch runtime')):
                    cols=[c for c in numeric if any(t in c for t in filt)]
                    if cols:st.markdown(f'**{label}**');st.line_chart(df.set_index(ep)[cols])
        else:st.info('No recorded per-epoch rows in this checkpoint.')
    else:st.info('No history.json checkpoints found for this dataset.')
    st.markdown('#### Live training terminal logs')
    logs=discover_logs(root)
    if logs:
        p=st.selectbox('Choose log',logs,format_func=lambda p:p.name,key='studio_log')
        st.code(tail_log(p,150),language='text')
    else:st.caption('Save training logs with `2>&1 | tee my_experiment.log`.')
    st.caption('Refresh the page to see new logged epochs. The dashboard never trains models automatically.')


def _retrieval(st,root,dataset):
    st.subheader('Candidate retrieval and LightGBM LambdaRank')
    refs=discover(root,dataset)
    choose=st.radio('Section',['Candidate recall','LambdaRank'],horizontal=True,key='retrieval_view')
    options=[r for r in refs if r.kind==('Advanced retrieval' if choose=='Candidate recall' else 'Multi-source LambdaRank')]
    if not options:
        st.info('No saved '+choose+' report for this dataset. Train/evaluate the multi-source pipeline first.');return
    selected=st.selectbox('Saved result',options,format_func=lambda r:r.path.name,key='retrieval_file')
    report=load_json(selected.path)
    if report.get('dataset')!=dataset:
        st.error('Dataset provenance mismatch.');return
    if choose=='Candidate recall':
        summary=report.get('summary',{})
        st.metric('Union candidate recall',f'{float(summary.get("union_candidate_recall",0)):.1%}')
        f={k:v for k,v in summary.items() if 'recall_at_' in k and isinstance(v,(int,float))}
        if f:st.bar_chart(pd.Series(f))
        if isinstance(report.get('per_user'),list):st.dataframe(pd.DataFrame(report['per_user']).head(150))
    else:
        if isinstance(report.get('candidate_recall'),(int,float)):
            st.metric('Candidate recall',f'{report["candidate_recall"]:.1%}')
        _metric_table(st,report,'Multi-source LambdaRank',None,'studio_ltr')
        importance=report.get('feature_importance_gain',{})
        if isinstance(importance,dict) and importance:
            st.markdown('**LightGBM feature importance (gain)**')
            st.bar_chart(pd.Series(importance).sort_values(ascending=False).head(25))
        if report.get('delta_vs_fm'):
            st.markdown('**Paired delta vs FM**');st.json(report['delta_vs_fm'])
    st.caption('A reranker cannot recover a relevant movie absent from the candidate pool. '
               'Only matched reports with identical protocols should be compared.')


def _umap(st,root,dataset):
    st.subheader('Genre-colored UMAP · catalogue and model embeddings')
    folder=root/'reports'/'research_lab'/'umap'/dataset
    maps=sorted(folder.glob('genre_umap_*.csv'),key=lambda p:p.stat().st_mtime,reverse=True) if folder.is_dir() else []
    if not maps:
        st.info('No saved UMAP yet. Generate a map from the Codespaces terminal:')
        st.code(f'python -m reco_research_lab.genre_umap --dataset {dataset} --mode genre-multihot --sample-size 3000 --seed 42',language='bash')
        st.caption('Also supported: `--mode title-genre-tfidf` or `--mode model-embeddings --embedding-npz ...`.')
        return
    path=st.selectbox('Map',maps,format_func=lambda p:p.name,key='studio_umap_file')
    frame=pd.read_csv(path)
    meta=load_json(path.with_suffix('.json')) if path.with_suffix('.json').exists() else {}
    if meta.get('dataset')!=dataset:
        st.error('The map metadata does not match the dataset.');return
    if len(frame)>15000 or not {'x','y','title','genres','main_genre','movieId'}.issubset(frame.columns):
        st.error('Invalid or oversized UMAP data.');return
    genres=sorted(frame.main_genre.dropna().unique())
    selected=st.multiselect('Genres',genres,key='studio_umap_genres')
    filtered=frame[frame.main_genre.isin(selected)] if selected else frame
    import plotly.express as px
    fig=px.scatter(filtered,x='x',y='y',color='main_genre',hover_name='title',
                   hover_data={'genres':True,'movieId':True,'x':False,'y':False},
                   opacity=.72,render_mode='webgl')
    fig.update_layout(height=600,margin=dict(l=0,r=0,b=0,t=30),legend_title='Genre')
    st.plotly_chart(fig,use_container_width=True,key='studio_umap_plot')
    st.caption(f'{len(frame):,} movies · Feature space: {meta.get("mode","unknown")} · '
               f'Source: {meta.get("embedding_source","unknown")}. '
               'UMAP geometry is exploratory, not recommendation accuracy.')
    with st.expander('Map provenance'):
        st.json(meta)


def _setup(st,root,dataset):
    st.subheader('Local project health and setup')
    c=discover_checkpoints(root,dataset)
    st.dataframe(pd.DataFrame(c),hide_index=True,use_container_width=True) if c else st.info('No local checkpoints for this dataset.')
    st.markdown('#### First-run commands')
    if dataset=='ml-latest-small':
        st.code('python -m pip install -r requirements-dev.txt\npython -m src.train',language='bash')
    else:
        st.code(f'# Verify prepared data for {dataset}\nls data/temporal/{dataset}\n'
                f'# List stored FM checkpoints\nls models/{dataset}/temporal_fm/',language='bash')
    st.markdown('#### Important model boundaries')
    st.write('• HOFM3 needs the installed third-order checkpoint loader; it is not automatically equivalent to a second-order FM.')
    st.write('• Stage D is a separately trained B+C+D correction over a frozen FM unless you use a jointly integrated FM patch.')
    st.write('• Streamlit does not re-train SVD, BPR, HOFM3 or LambdaRank on page load.')
    st.write('• Only load your own trusted model files. MovieLens data have separate GroupLens licensing conditions.')
    if (root/'reco_research_lab').is_dir():
        st.caption('This Studio includes the report/UMAP readers; your existing app.py and earlier Research Lab files are preserved.')


def render(root='.'):
    import streamlit as st
    st.set_page_config(page_title='Reco Studio · Movie Recommendation Research',page_icon='🎬',layout='wide')
    root=Path(root).resolve()
    _css(st);_title(st)
    st.sidebar.header('Explore the research')
    dataset=st.sidebar.selectbox('MovieLens size',DATASETS,index=2,
                                 format_func=lambda d:{'ml-32m':'32M · research','ml-1m':'1M · classical',
                                                      'ml-latest-small':'Small · demo'}[d],key='studio_dataset')
    st.sidebar.caption('All information is loaded from your local Codespace. Missing results are never invented.')
    _overview(st,root,dataset)
    st.divider()
    tabs=st.tabs(['🎯 Recommendations','❤️ Favorite-based discovery','📊 Compare models',
                  '📈 Training & epochs','🌳 Retrieval / LambdaRank','🗺️ Genre UMAP','⚙️ Setup & checkpoints'])
    funcs=(_known_user,_discover_movies,_model_comparisons,_training,_retrieval,_umap,_setup)
    for tab,fn in zip(tabs,funcs):
        with tab:_safe_render(st,fn,root,dataset)

