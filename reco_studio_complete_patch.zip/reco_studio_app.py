"""Start with: streamlit run reco_studio_app.py --server.port 8502"""
from pathlib import Path
from reco_studio.interface import render
render(Path(__file__).resolve().parent)
