"""Reversible installer for Reco Studio; does not touch datasets/checkpoints/reports.

Default installs nothing: extracting the ZIP is enough to use the standalone app.
Use --make-default to replace app.py with a lightweight entrypoint after backup.
Use --hide-legacy-page to move the older, sometimes broken duplicate Research Lab page.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil

SHIM='''"""Reco Studio main application (original backed up by installer)."""\nfrom pathlib import Path\nfrom reco_studio.interface import render\nrender(Path(__file__).resolve().parent)\n'''


def install(root:Path,make_default=False,hide_legacy_page=False)->list[str]:
    root=Path(root).resolve()
    if not (root/'reco_studio_app.py').is_file() or not (root/'reco_studio/interface.py').is_file():
        raise FileNotFoundError('Extract the Reco Studio ZIP into repository root first')
    notices=[]
    if make_default:
        path=root/'app.py'
        if path.exists() and path.read_text(encoding='utf-8')!=SHIM:
            backup=root/'app.py.before_reco_studio.bak'
            if backup.exists():
                if backup.read_bytes()!=path.read_bytes():
                    raise FileExistsError(f'Backup already exists and differs: {backup}. Refusing to overwrite.')
            else:shutil.copy2(path,backup)
            notices.append('Backed up original app.py to app.py.before_reco_studio.bak')
        path.write_text(SHIM,encoding='utf-8')
        notices.append('Installed Reco Studio as app.py')
    if hide_legacy_page:
        source=root/'pages/09_Research_Lab.py'
        if source.is_file():
            target=root/'pages_disabled/09_Research_Lab.py'
            target.parent.mkdir(parents=True,exist_ok=True)
            if target.exists():
                raise FileExistsError(f'Refusing to overwrite existing saved page: {target}')
            shutil.move(source,target)
            notices.append('Moved duplicate legacy Research Lab page to pages_disabled/ (recoverable)')
        else:notices.append('No legacy Research Lab page to hide')
    if not notices:notices.append('Standalone mode ready: streamlit run reco_studio_app.py --server.port 8502')
    return notices


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path('.'))
    p.add_argument('--make-default',action='store_true')
    p.add_argument('--hide-legacy-page',action='store_true')
    args=p.parse_args()
    for line in install(args.root,args.make_default,args.hide_legacy_page):print(line)

if __name__=='__main__':main()
