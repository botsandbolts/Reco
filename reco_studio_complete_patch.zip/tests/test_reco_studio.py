"""Synthetic, offline regression tests for model-backed recommendation UI logic."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
from reco_studio.catalog import (movie_filter,genre_options,catalog_index,
    favorites_matching,content_recommendations,top_results)
from reco_studio.engines import (temporal_checkpoints,preference_checkpoints,
    ltr_checkpoints,eligible_movies,training_seen,training_movie_counts)


def movies():
    return pd.DataFrame({
      'movieId':[101,102,103,104,105,106],
      'title':['Galaxy Wars (2001)','Galactic Trek (2002)', 'Love (1995)',
               'Funny (1998)','Galaxy Reborn (2022)','Old Cosmos (1980)'],
      'genres':['Sci-Fi|Adventure','Sci-Fi|Adventure','Romance',
                'Comedy','Sci-Fi','Sci-Fi']})


def test_favorites_generate_recommendations_and_exclude_all_favorites():
    df=movies()
    out=content_recommendations(df,[101,102,105],k=10)
    assert not out.empty
    assert not {101,102,105}.intersection(out.movieId.tolist())
    assert out.iloc[0].movieId in (106,103,104)
    assert len(out)==3


def test_favorite_genre_filter_and_too_many_requested():
    out=content_recommendations(movies(),[101,102],genre='Sci-Fi',k=99)
    assert set(out.movieId)=={105,106}
    assert 'Content similarity' in out.columns


def test_top_results_never_backfills_excluded_or_nonfinite():
    df=movies()
    mask=np.array([False,True,False,False,False,False])
    scores=np.array([900,1,np.nan,10,20,12])
    assert top_results(df,scores,mask,100).movieId.tolist()==[102]
    assert top_results(df,scores,np.zeros(6,dtype=bool),20).empty


def test_1m_movie_filter_is_literal_and_genre_exact():
    m=movies()
    assert len(genre_options(m))>1
    assert not movie_filter(m,genre='Science',query='Galaxy').any()
    assert movie_filter(m,genre='Sci-Fi',query='Galaxy').sum()==2
    assert movie_filter(m,query='[',min_year=2000).sum()==0
    assert catalog_index(m)[103]==2
    assert len(favorites_matching(m,'GALAXY'))==2


def write_meta(folder,contents):
    folder.mkdir(parents=True)
    (folder/'metadata.json').write_text(json.dumps(contents))
    (folder/'weights.pt').write_bytes(b'fake')


def test_checkpoint_discovery_filters_model_and_stage(tmp_path):
    root=tmp_path/'models/ml-32m/temporal_fm'
    write_meta(root/'fm_all_hofm3semi25_bpr',{'fm_order':3,'text_backend':'sentence','seed':42})
    write_meta(root/'fm_all_bpr',{'fm_order':2,'text_backend':'hash','seed':13})
    (root/'missing').mkdir()
    arr=temporal_checkpoints(tmp_path,'ml-32m')
    assert {a['name'] for a in arr}=={'fm_all_hofm3semi25_bpr','fm_all_bpr'}
    write_meta(tmp_path/'models/ml-32m/temporal_preferences/fm_all_bpr_d_jointBCD',
               {'base_model':'fm_all_bpr','stage':'d'})
    assert len(preference_checkpoints(tmp_path,'ml-32m','fm_all_bpr'))==1
    assert preference_checkpoints(tmp_path,'ml-32m','fm_all_hofm3semi25_bpr')==[]


def test_saved_ltr_model_discovery(tmp_path):
    target=tmp_path/'models/ml-32m/temporal_fm/advanced_ltr/test'
    target.mkdir(parents=True)
    (target/'model.txt').write_text('fake')
    (target/'metadata.json').write_text(json.dumps({'base_model':'fm_all_bpr','cutoff':14}))
    assert len(ltr_checkpoints(tmp_path,'ml-32m','fm_all_bpr'))==1
    assert ltr_checkpoints(tmp_path,'ml-32m','fm_all_hofm3semi25_bpr')==[]


class FakeEvents:
    def __init__(self,root):
        self.folder=root
        root.mkdir(parents=True)
        self.movies=movies()
        self.meta={'train_cutoff':946684800,'dataset':'ml-32m'}  # 2000-01-01
        self.movie_has_train=np.asarray([True]*6)
        self.release_year=np.asarray([2001,2002,1995,1998,2022,1980])
        self.genres=['Sci-Fi','Romance','Comedy']
        self.genre_matrix=np.asarray([[1,0,0],[1,0,0],[0,1,0],
                                      [0,0,1],[1,0,0],[1,0,0]])
        self.train_users=np.asarray([1,2])
        self.user_raw=np.asarray([1,1,1,2,2],dtype=np.int32)
        self.movie_idx=np.asarray([2,3,5,0,1],dtype=np.int32)
        self.rating=np.asarray([5,4,3,5,5],dtype=np.float32)
        self.timestamp=np.asarray([100,200,300,400,500],dtype=np.int64)
        np.save(root/'train_index.npy',np.arange(5,dtype=np.int32))
    def split(self,name):
        assert name=='train'
        return np.load(self.folder/'train_index.npy',mmap_mode='r')
    def user_indices(self,ids):
        return np.asarray([1 if int(u)==1 else 2 if int(u)==2 else 0 for u in ids],dtype=np.int64)


def test_user_history_and_popularity_are_training_only(tmp_path,monkeypatch):
    from reco_studio import engines
    f=FakeEvents(tmp_path/'data/temporal/ml-32m')
    monkeypatch.setattr(engines,'_events',lambda unused:f)
    seen,h=training_seen(f,1)
    assert seen=={2,3,5}
    assert len(h)==3
    counts=training_movie_counts(str(f.folder))
    assert counts.tolist()==[1,1,1,1,0,1]
    # no future-release films; no user-rated films
    cand=eligible_movies(f,seen)
    assert cand.tolist()==[]
    assert eligible_movies(f,set(),genre='Sci-Fi').tolist()==[5]


def test_missing_artifacts_do_not_generate_fake_models(tmp_path):
    assert temporal_checkpoints(tmp_path,'ml-1m')==[]
    assert preference_checkpoints(tmp_path,'ml-1m','fm_all_bpr')==[]


def test_cached_svd_bpr_scores_with_history_and_release_checks(tmp_path,monkeypatch):
    from reco_studio import engines
    f=FakeEvents(tmp_path/'data/temporal/ml-32m')
    f.meta.update(sources={'rating':'test'},train_cutoff=1735689600)  # 2025
    monkeypatch.setattr(engines,'_events',lambda unused:f)
    (f.folder/'manifest.json').write_text('{}')
    folder=tmp_path/'models/ml-32m/shared_chrono_baselines/experiment'
    folder.mkdir(parents=True)
    (folder/'manifest.json').write_text(json.dumps({'dataset':'ml-32m','sources':{'rating':'test'},
                                                    'cutoff':1735689600,'profile':'quick'}))
    np.savez(folder/'factors.npz',svd_user=np.array([[1,1],[1,0]]),
             svd_item=np.array([[4,0],[2,0],[1,0],[3,0],[0,10],[0,1]]),
             bpr_user=np.array([[1,1],[1,0]]),
             bpr_item=np.array([[4,0],[2,0],[1,0],[3,0],[0,10],[0,1]]))
    checkpoints=engines.baseline_checkpoints(tmp_path,'ml-32m',f)
    assert len(checkpoints)==1
    rec,hist=engines.baseline_recommend(tmp_path,'ml-32m',1,checkpoints[0],'SVD',k=30)
    assert set(rec.movieId)=={101,102,105}
    assert len(hist)==3
    # Subsequent data-cutoff change invalidates cached vectors.
    f.meta['train_cutoff']=123
    with pytest.raises(ValueError,match='different'):
        engines.baseline_recommend(tmp_path,'ml-32m',1,checkpoints[0],'BPR-MF')
