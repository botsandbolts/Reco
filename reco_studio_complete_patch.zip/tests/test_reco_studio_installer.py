from pathlib import Path
import importlib.util


def _installer():
    path=Path(__file__).resolve().parents[1]/'scripts/install_reco_studio.py'
    spec=importlib.util.spec_from_file_location('studio_install',path)
    m=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def test_reversible_default_install(tmp_path):
    (tmp_path/'app.py').write_text('print("original")')
    (tmp_path/'reco_studio').mkdir()
    (tmp_path/'reco_studio/interface.py').write_text('')
    (tmp_path/'reco_studio_app.py').write_text('')
    old=tmp_path/'pages/09_Research_Lab.py'
    old.parent.mkdir()
    old.write_text('broken older page')
    install=_installer().install
    messages=install(tmp_path,make_default=True,hide_legacy_page=True)
    assert 'render(' in (tmp_path/'app.py').read_text()
    assert (tmp_path/'app.py.before_reco_studio.bak').read_text()=='print("original")'
    assert (tmp_path/'pages_disabled/09_Research_Lab.py').read_text()=='broken older page'
    assert not old.exists()
    # Running again does not destroy the original backup.
    install(tmp_path,make_default=True)
    assert (tmp_path/'app.py.before_reco_studio.bak').read_text()=='print("original")'


def test_install_does_not_change_data_or_reports(tmp_path):
    (tmp_path/'reco_studio').mkdir()
    (tmp_path/'reco_studio/interface.py').write_text('')
    (tmp_path/'reco_studio_app.py').write_text('')
    model=tmp_path/'models/ml-32m/temporal_fm/fm_all_bpr/weights.pt'
    model.parent.mkdir(parents=True)
    model.write_bytes(b'opaque weights')
    _installer().install(tmp_path)
    assert model.read_bytes()==b'opaque weights'
