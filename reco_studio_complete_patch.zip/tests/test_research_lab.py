"""All synthetic: tests run without MovieLens downloads, GPU, or Streamlit."""
from __future__ import annotations
import json
import sys
import types
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from reco_research_lab.report_store import (
    discover, metrics_frame, comparable_preferences, fingerprint,
    discover_history, discover_checkpoints, discover_logs, tail_log, load_json)
from reco_research_lab.genre_umap import (
    find_catalog, load_catalog, select_sample, build_features, build_map)


def write(path, payload):
    path.parent.mkdir(exist_ok=True,parents=True)
    path.write_text(json.dumps(payload),encoding='utf-8')
    return path


def sample_cohort(stage='b',dataset='ml-32m',ids=(10,11),policy='full_warm_catalog'):
    return dict(dataset=dataset,split='validation',base_checkpoint='fm_all_semi25_bpr',
                seed=42,k=10,cutoff=12345,candidate_policy=policy,
                evaluated_user_ids=list(ids),stage=stage,stage_description=stage,
                metrics={'fm_base':{'ndcg_at_k':.06},
                         'popularity':{'ndcg_at_k':.04},
                         'fm_'+stage+'_temporal':{'ndcg_at_k':.07}})


def test_report_discovery_is_dataset_separated(tmp_path):
    write(tmp_path/'reports/temporal/ml-32m/ranking_eval.json',
          {'dataset':'ml-32m','metrics':{'fm':{'ndcg_at_k':.08}}})
    write(tmp_path/'reports/temporal/ml-1m/ranking_eval.json',
          {'dataset':'ml-1m','metrics':{'fm':{'ndcg_at_k':.03}}})
    write(tmp_path/'artifacts/metrics.json',
          {'dataset':'MovieLens latest-small','test':{'popularity':{'ndcg_at_k':.03}}})
    assert len(discover(tmp_path,'ml-32m'))==1
    assert len(discover(tmp_path,'ml-1m'))==1
    assert len(discover(tmp_path,'ml-latest-small'))==1
    assert discover(tmp_path,'ml-1m')[0].kind=='FM/BPR top-K ranking'
    with pytest.raises(ValueError):discover(tmp_path,'ml-100m')


def test_exact_comparability_requires_same_user_ids_policy_and_cutoff(tmp_path):
    b=write(tmp_path/'b.json',sample_cohort('b'))
    c=write(tmp_path/'c.json',sample_cohort('c'))
    assert len(comparable_preferences([(b,load_json(b)),(c,load_json(c))]))==4
    for overrides in ({'evaluated_user_ids':[10,12]}, {'cutoff':12346},
                      {'candidate_policy':'sampled'}, {'dataset':'ml-1m'}):
        invalid=sample_cohort('c');invalid.update(overrides)
        bad=write(tmp_path/'bad.json',invalid)
        with pytest.raises(ValueError,match='different'):
            comparable_preferences([(b,load_json(b)),(bad,load_json(bad))])
    no_ids=sample_cohort();no_ids.pop('evaluated_user_ids')
    with pytest.raises(ValueError,match='user cohort'):fingerprint(no_ids,'pref')


def test_metrics_frames_are_only_from_selected_file():
    a={'metrics':{'fm':{'ndcg_at_k':.078},'svd':{'ndcg_at_k':.06}}}
    b={'results':{'popularity':{'ndcg_at_k':.03}}}
    assert metrics_frame(a,'FM/BPR top-K ranking').loc['fm','ndcg_at_k']==.078
    assert list(metrics_frame(b,'Unified scalable comparison').index)==['popularity']
    assert metrics_frame(a,'MovieLens Small baseline').empty


def test_metadata_and_history_are_read_only(tmp_path):
    md=tmp_path/'models/ml-32m/temporal_fm/fm_all_hofm3semi25_bpr'
    write(md/'metadata.json',{'fm_order':3,'seed':42,'objective':'bpr'})
    (md/'weights.pt').write_bytes(b'not a safe model to load')
    write(md/'history.json',[{'epoch':1,'bpr_loss':.7}])
    values=discover_checkpoints(tmp_path,'ml-32m')
    assert values[0]['name']=='fm_all_hofm3semi25_bpr'
    assert values[0]['fm_order']==3
    assert len(discover_history(tmp_path,'ml-32m'))==1
    (tmp_path/'training.log').write_text('a\n'*100+'epoch 15/15 complete')
    assert len(discover_logs(tmp_path))==1
    assert 'epoch 15/15' in tail_log(tmp_path/'training.log',1)


def test_movielens_1m_catalogue_in_latin1(tmp_path):
    f=tmp_path/'data/raw/ml-1m/movies.dat'
    f.parent.mkdir(parents=True)
    f.write_bytes('1::Amélie (2001)::Comedy|Romance\n2::Drama (1995)::Drama\n'.encode('latin-1'))
    assert find_catalog(tmp_path,'ml-1m')==f
    frame=load_catalog(f)
    assert frame.title.iloc[0]=='Amélie (2001)'
    assert frame.movieId.tolist()==[1,2]


def test_stratified_sampling_is_reproducible():
    df=pd.DataFrame({'movieId':list(range(100)),
                     'title':['X']*100,
                     'genres':['Drama' if x%2==0 else 'Action' for x in range(100)]})
    a=select_sample(df,30,42)
    b=select_sample(df,30,42)
    assert a.movieId.tolist()==b.movieId.tolist()
    assert set(a.genres)=={'Action','Drama'}


def test_embedding_ids_align_to_catalogue_even_when_shuffled(tmp_path):
    f=tmp_path/'vectors.npz'
    np.savez_compressed(f,movie_ids=[3,1,2],embeddings=[[3.,0.,0.],[1.,0.,0.],[0.,2.,0.]])
    df=pd.DataFrame({'movieId':[1,2,3],'title':['one','two','three'],
                     'genres':['Action','Drama','Comedy']})
    actual,source,dims=build_features(df,'model-embeddings',str(f),42)
    assert actual[0].tolist()==[1.,0.,0.]
    assert actual[1].tolist()==[0.,1.,0.]
    assert dims==3 and source.endswith('vectors.npz')
    np.savez_compressed(f,movie_ids=[3,1],embeddings=[[3.,0.,0.],[1.,0.,0.]])
    with pytest.raises(ValueError,match='missing'):
        build_features(df,'model-embeddings',str(f),42)


def test_end_to_end_umap_saves_csv_and_metadata(monkeypatch,tmp_path):
    class FakeUMAP:
        def __init__(self, **kwargs): self.kwargs=kwargs
        def fit_transform(self,x):
            # deterministic stand-in: offline CI does not install UMAP
            return np.asarray(x)[:,:2]
    monkeypatch.setitem(sys.modules,'umap',types.SimpleNamespace(UMAP=FakeUMAP))
    data=tmp_path/'data/temporal/ml-32m/movies.csv'
    data.parent.mkdir(parents=True)
    pd.DataFrame({'movieId':np.arange(1,101),
                  'title':['Movie '+str(i) for i in range(100)],
                  'genres':['Action|Sci-Fi','Drama','Comedy','Romance']*25}).to_csv(data,index=False)
    path=build_map(dataset='ml-32m',root=tmp_path,mode='genre-multihot',sample_size=60)
    df=pd.read_csv(path)
    metadata=load_json(path.with_suffix('.json'))
    assert len(df)==60 and set(('x','y','genres','main_genre')).issubset(df)
    assert metadata['dataset']=='ml-32m'
    assert metadata['embedding_source']=='genre multi-hot'
    assert not list((tmp_path/'data').rglob('*.pt'))


def test_cannot_use_other_dataset_map_in_selected_dataset(tmp_path):
    # Test mapper's provenance contract rather than relying on arbitrary folder names.
    f=write(tmp_path/'reports/research_lab/umap/ml-1m/map.json',
            {'dataset':'ml-32m','embedding_source':'genre multi-hot'})
    assert load_json(f)['dataset']!='ml-1m'


def test_dashboard_renders_without_artifacts(monkeypatch,tmp_path):
    class Ctx:
        def __enter__(self):return self
        def __exit__(self,*args):return False
    class FakeSt:
        def __init__(self):self.messages=[]
        def __getattr__(self,name):
            if name in ('tabs','columns'):
                return lambda items:[self]* (len(items) if isinstance(items,list) else items)
            if name=='selectbox':return lambda label,items,**kwargs: list(items)[0]
            if name=='multiselect':return lambda *args,**kwargs:[]
            if name=='button':return lambda *args,**kwargs:False
            if name in ('expander',):return lambda *args,**kwargs:self
            if name=='metric':return lambda *args,**kwargs:None
            return lambda *args,**kwargs:self.messages.append((name,args))
        def __enter__(self):return self
        def __exit__(self,*args):return False
    fake=FakeSt()
    monkeypatch.setitem(sys.modules,'streamlit',fake)
    from reco_research_lab.dashboard import render
    render(tmp_path)
    assert any(name=='title' for name,args in fake.messages)
    assert any(name=='info' for name,args in fake.messages)


def test_dashboard_with_realistic_reports_and_map(monkeypatch,tmp_path):
    import sys
    from reco_research_lab.dashboard import render
    write(tmp_path/'reports/temporal/ml-32m/ranking_demo.json',
          {'dataset':'ml-32m','k':10,'split':'validation',
           'candidate_policy':'full_train_catalog','metrics':{
               'fm_all_hofm3semi25_bpr':{'ndcg_at_k':.09,'recall_at_k':.07},
               'popularity':{'ndcg_at_k':.05,'recall_at_k':.04}}})
    write(tmp_path/'reports/temporal/ml-32m/advanced_ltr_demo.json',
          {'dataset':'ml-32m','split':'validation','k':10,
           'metrics':{'advanced_lambdamart':{'ndcg_at_k':.13},'fm':{'ndcg_at_k':.08}},
           'feature_importance_gain':{'fm_score':15,'bpr_score':7},
           'candidate_recall':.4})
    write(tmp_path/'reports/temporal/ml-32m/advanced_retrieval_demo.json',
          {'dataset':'ml-32m','summary':{'union_candidate_recall':.4,'fm_recall_at_500':.2},
           'per_user':[{'userId':1,'union_candidate_recall':1.0}]})
    write(tmp_path/'reports/temporal/ml-32m/preference_experiments/preference_b.json',
          sample_cohort('b'))
    write(tmp_path/'models/ml-32m/temporal_preferences/example/metadata.json',
          {'stage':'d','seed':42})
    write(tmp_path/'models/ml-32m/temporal_preferences/example/history.json',
          [{'epoch':1,'bpr_loss':.6,'validation_ndcg_at_10':.07,'epoch_seconds':5.0},
           {'epoch':2,'bpr_loss':.5,'validation_ndcg_at_10':.09,'epoch_seconds':5.5}])
    (tmp_path/'training.log').write_text('epoch 1/2\nepoch 2/2\n')
    map_path=tmp_path/'reports/research_lab/umap/ml-32m/genre_umap_genre-multihot_n10_seed42.csv'
    map_path.parent.mkdir(parents=True)
    pd.DataFrame({'movieId':np.arange(10),'title':[f'Movie {i}' for i in range(10)],
                  'genres':['Action']*10,'main_genre':['Action']*10,
                  'x':np.arange(10,dtype=float),'y':np.arange(10,dtype=float)}).to_csv(map_path,index=False)
    write(map_path.with_suffix('.json'),{'dataset':'ml-32m','mode':'genre-multihot'})
    class FakeStreamlit:
        def __init__(self):self.calls=[]
        def __getattr__(self,name):
            if name in ('tabs','columns'):
                return lambda x:[self]*(len(x) if isinstance(x,(list,tuple)) else x)
            if name in ('selectbox','radio'):
                return lambda title,options,**kwargs:list(options)[kwargs.get('index',0)]
            if name=='multiselect':return lambda *args,**kw:[]
            if name=='button':return lambda *args,**kw:False
            if name=='expander':return lambda *args,**kw:self
            return lambda *args,**kwargs:self.calls.append(name)
        def __enter__(self):return self
        def __exit__(self,*a):return False
    st=FakeStreamlit()
    monkeypatch.setitem(sys.modules,'streamlit',st)
    render(tmp_path)
    assert 'bar_chart' in st.calls
    assert 'line_chart' in st.calls
    assert 'dataframe' in st.calls
    assert 'plotly_chart' in st.calls
