"""Render ALL Studio tabs together to catch duplicate widget keys without Streamlit installed."""
import json
import sys
import pandas as pd
from reco_studio import interface

class FakeSt:
    def __init__(self):
        self.keys=set()
        self.errors=[]
        self.session_state={}
        self.sidebar=self
        self.widgets=[]
    def _key(self,name,kwargs):
        key=kwargs.get('key')
        if key is not None:
            if key in self.keys:raise AssertionError(f'Duplicate Streamlit key: {key}')
            self.keys.add(key)
        self.widgets.append((name,key))
    def __enter__(self):return self
    def __exit__(self,*args):return False
    def cache_resource(self,**kwargs):return lambda func:func
    def columns(self,config):return [self]*(len(config) if isinstance(config,list) else config)
    def tabs(self,labels):return [self for _ in labels]
    def selectbox(self,label,options,**kwargs):
        self._key('selectbox',kwargs)
        return list(options)[kwargs.get('index',0)]
    def multiselect(self,label,options,**kwargs):
        self._key('multiselect',kwargs);return []
    def radio(self,label,options,**kwargs):
        self._key('radio',kwargs);return list(options)[0]
    def text_input(self,*a,**kw):self._key('text_input',kw);return kw.get('value','')
    def slider(self,*a,**kw):self._key('slider',kw);return a[3] if len(a)>3 else kw.get('value',10)
    def number_input(self,*a,**kw):self._key('number_input',kw);return kw.get('value',1)
    def button(self,*a,**kw):self._key('button',kw);return False
    def expander(self,*a,**kw):return self
    def plotly_chart(self,*a,**kw):self._key('plotly_chart',kw)
    def error(self,value):self.errors.append(str(value))
    def __getattr__(self,name):
        return lambda *a,**kw:None


def write_json(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj))


def test_render_populated_research_lab_without_key_collisions(monkeypatch,tmp_path):
    fake=FakeSt()
    monkeypatch.setitem(sys.modules,'streamlit',fake)
    # A full known-user trainer manifest is not needed to render a safe fallback;
    # show errors only if a rendering bug occurs.
    write_json(tmp_path/'reports/temporal/ml-32m/ranking_demo.json',{
        'dataset':'ml-32m','split':'validation','candidate_policy':'full_train_catalog',
        'metrics':{'fm_all_hofm3semi25_bpr':{'ndcg_at_k':.08,'recall_at_k':.05},
                   'popularity':{'ndcg_at_k':.04,'recall_at_k':.03}}})
    write_json(tmp_path/'reports/temporal/ml-32m/advanced_ltr_demo.json',{
        'dataset':'ml-32m','split':'validation','candidate_recall':.13,
        'metrics':{'advanced_lambdamart':{'ndcg_at_k':.09}},
        'feature_importance_gain':{'fm_score':12,'bpr_score':4}})
    write_json(tmp_path/'reports/temporal/ml-32m/advanced_retrieval_demo.json',{
        'dataset':'ml-32m','summary':{'union_candidate_recall':.15,
                                      'fm_recall_at_500':.13}})
    write_json(tmp_path/'models/ml-32m/temporal_fm/fm_all_bpr/history.json',[
       {'epoch':1,'bpr_loss':.7,'validation_ndcg_at_10':.05},
       {'epoch':2,'bpr_loss':.6,'validation_ndcg_at_10':.06}])
    data_dir=tmp_path/'reports/research_lab/umap/ml-32m'
    data_dir.mkdir(parents=True)
    csv=data_dir/'genre_umap_genre-multihot_n5_seed42.csv'
    pd.DataFrame({'movieId':[1,2,3,4,5], 'title':['A','B','C','D','E'],
                  'genres':['Drama','Comedy','Action','Drama','Comedy'],
                  'main_genre':['Drama','Comedy','Action','Drama','Comedy'],
                  'x':[1,2,3,4,5],'y':[4,5,6,7,8]}).to_csv(csv,index=False)
    write_json(csv.with_suffix('.json'),{'dataset':'ml-32m','mode':'genre-multihot'})
    # Catalogue activates the genuinely interactive favorite-based UI.
    cat=tmp_path/'data/temporal/ml-32m/movies.csv'
    cat.parent.mkdir(parents=True,exist_ok=True)
    pd.DataFrame({'movieId':[1,2,3,4], 'title':['Alpha','Beta','Gamma','Delta'],
                  'genres':['Comedy','Drama','Action','Drama']}).to_csv(cat,index=False)
    interface.render(tmp_path)
    assert not fake.errors, fake.errors
    assert len(fake.keys)>10
    assert 'studio_report_metric' in fake.keys
    assert 'studio_umap_plot' in fake.keys
    assert 'fav_select_ml-32m' in fake.keys
    # Second pass reaches LambdaRank's own selector (not the comparison key).
    fake2=FakeSt()
    orig=fake2.radio
    def lambda_radio(label,opts,**kw):
        if 'LambdaRank' in opts:
            fake2._key('radio',kw);return 'LambdaRank'
        return orig(label,opts,**kw)
    fake2.radio=lambda_radio
    monkeypatch.setitem(sys.modules,'streamlit',fake2)
    interface.render(tmp_path)
    assert not fake2.errors, fake2.errors
    assert 'studio_ltr_metric' in fake2.keys


def test_missing_files_render_friendly_empty_state(monkeypatch,tmp_path):
    fake=FakeSt();monkeypatch.setitem(sys.modules,'streamlit',fake)
    interface.render(tmp_path)
    assert not fake.errors
    assert 'studio_dataset' in fake.keys


def test_switching_to_small_and_one_million_never_assumes_32m(monkeypatch,tmp_path):
    cat=tmp_path/'data/raw/ml-1m/movies.dat'
    cat.parent.mkdir(parents=True)
    cat.write_bytes('1::A (1995)::Drama\n2::B (1996)::Comedy\n'.encode('latin-1'))
    from reco_research_lab.report_store import DATASETS
    for dataset in ('ml-latest-small','ml-1m'):
        fake=FakeSt()
        orig=fake.selectbox
        def select_with_dataset(label,options,**kwargs):
            if kwargs.get('key')=='studio_dataset':
                fake._key('selectbox',kwargs)
                return dataset
            return orig(label,options,**kwargs)
        fake.selectbox=select_with_dataset
        monkeypatch.setitem(sys.modules,'streamlit',fake)
        interface.render(tmp_path)
        assert not fake.errors, fake.errors
        assert 'studio_dataset' in fake.keys
