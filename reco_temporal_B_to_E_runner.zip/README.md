# Codespaces B–E runner

Prerequisite: the full temporal preference ZIP and original Temporal FM/ranking patches have been extracted in `/workspaces/Reco`. This script does **not** modify your original FM checkpoint.

```bash
cd /workspaces/Reco
unzip -o reco_temporal_preferences_B_to_E_complete.zip
python -m pip install -r requirements-temporal-preferences.txt
python -m pytest -q tests/test_preference_stage_*.py tests/test_temporal_preferences.py
bash scripts/run_temporal_stages.sh
PROFILE=research bash scripts/run_temporal_stages.sh
```

`PROFILE=smoke` does 1 epoch, 3 training steps, 5 validation users per stage; `PROFILE=research` does 8 epochs, 500 steps, 300 evaluation users per stage. These are separate *experimental* runs: smoke training may save checkpoints; use `--force-retrain` on the research run to avoid reusing them.

```bash
PROFILE=research bash scripts/run_temporal_stages.sh --force-retrain
BASE_MODEL=fm_all_l2try_bpr STAGES='b c d e' PROFILE=research bash scripts/run_temporal_stages.sh --force-retrain
streamlit run temporal_fm/preference_dashboard.py --server.address 0.0.0.0 --server.port 8501
```

Using all 300 users and the full eligible MovieLens 32M catalogue can be expensive on CPU. Results must be compared using the same cohort and candidate policy; see `docs/TEMPORAL_PREFERENCES.md`.
