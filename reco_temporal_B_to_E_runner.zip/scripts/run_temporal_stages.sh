#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
DATASET="${DATASET:-ml-32m}"
BACKEND="${BACKEND:-sentence}"
BASE_MODEL="${BASE_MODEL:-fm_all_bpr}"
PROFILE="${PROFILE:-smoke}" # smoke or research
STAGES="${STAGES:-b c d e}"
if [[ ! -f temporal_fm/preference_experiment.py ]]; then
  echo 'Missing temporal preference modules. Extract reco_temporal_preferences_B_to_E_complete.zip first.' >&2; exit 2
fi
if [[ ! -f temporal_fm/ranking.py ]]; then
  echo 'Missing prerequisite Temporal FM ranking patch. Install it first.' >&2; exit 2
fi
if [[ ! -d models/$DATASET ]]; then
  echo "Missing models/$DATASET. Prepare and train the existing FM baseline first." >&2; exit 2
fi
if [[ "$PROFILE" == smoke ]]; then
  EPOCHS=1; STEPS=3; USERS=5
elif [[ "$PROFILE" == research ]]; then
  EPOCHS=8; STEPS=500; USERS=300
else
  echo 'PROFILE must be smoke or research' >&2; exit 2
fi
export OMP_NUM_THREADS=2 MKL_NUM_THREADS=2
for stage in $STAGES; do
  batch=64
  [[ "$stage" == e ]] && batch=32
  echo "=== Stage $stage | $BASE_MODEL | $PROFILE ==="
  python -u -m temporal_fm.preference_experiment \
    --dataset "$DATASET" --backend "$BACKEND" \
    --base-model "$BASE_MODEL" --stage "$stage" \
    --epochs "$EPOCHS" --steps-per-epoch "$STEPS" \
    --batch-size "$batch" --eval-users "$USERS" \
    --validate-every 2 --device cpu --threads 2 "$@"
done
