# Temporal Preference Upgrade — B / C / D / E

A reproducible, experimental extension for `temporal_fm` in **Reco**, with four distinct candidate-scoring ablations. It **does not** overwrite existing FM/DeepFM checkpoints, replace BPR training, or re-introduce BERT4Rec/SASRec.

## Prerequisites

This patch assumes the Temporal FM ZIPs have already been extracted into your Codespace, and **a compatible frozen checkpoint** such as `models/ml-32m/temporal_fm/fm_all_bpr/weights.pt` exists. The original dataset preparation, `features_sentence/` title embeddings, and historical tag store must also be available. If you trained with a different content-normalization setting, the existing FM loader reads that checkpoint's metadata.

In the repository root, apply the ZIP files **in this order**: B → C → D → E, or extract the combined ZIP once. These patches add new Python modules; they do not modify your original `rank_train.py`, `model.py`, or `ranking.py`.

```bash
cd /workspaces/Reco
unzip -o reco_temporal_B_genres.zip
unzip -o reco_temporal_C_semantics.zip
unzip -o reco_temporal_D_fusion.zip
unzip -o reco_temporal_E_attention.zip
python -m pip install -r requirements-temporal-preferences.txt
python -m pytest -q tests/test_preference_stage_*.py tests/test_temporal_preferences.py
```

You must place the ZIP archives in your Codespace first (e.g. upload to GitHub, then `git fetch origin main` and `git show origin/main:<name>.zip > <name>.zip`). Do **not** expect GitHub website uploads to automatically appear in an already-open Codespace.

## Stage B — recent genre preferences

Creates a disk-cached index from **training-only ratings**. For each candidate movie, computes genre affinities to the user's last 10, 30, 100 and up to 500 positively rated movies plus a short-minus-long preference drift feature. **Strict `< timestamp`** history means an event never predicts itself.

```bash
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 python -u -m temporal_fm.preference_experiment \
  --dataset ml-32m --backend sentence --base-model fm_all_bpr \
  --stage b --epochs 6 --steps-per-epoch 200 --batch-size 64 \
  --eval-users 40 --validate-every 2 --device cpu --threads 2
```

The first run constructs and caches a large chronologically sorted training-history index (temporary peak RAM can be substantial on 32M). Later experiments reuse it. For a minimal functionality check, run 1 epoch, 3 steps, batch size 8, 5 evaluation users.

## Stage C — recent semantic tag preferences

Adds cosine affinities to historical user tag profiles (last 30/100/up-to-500 positive ratings plus drift). Candidate and history tag vectors are retrieved using **only tags available strictly before the current prediction time**. Per-movie tag vectors are L2-normalized; missing tags stay zero.

```bash
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 python -u -m temporal_fm.preference_experiment \
  --dataset ml-32m --backend sentence --base-model fm_all_bpr \
  --stage c --epochs 6 --steps-per-epoch 200 --batch-size 64 \
  --eval-users 40 --validate-every 2 --device cpu --threads 2
```

## Stage D — long/short-term fusion

Combines B and C with **90/365-day exponential half-life profiles**, retaining historical long-term preferences and explicit short-vs-long drift. These are candidate-dependent affinity features; user-only activity values would cancel out of the pairwise ranking.

```bash
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 python -u -m temporal_fm.preference_experiment \
  --dataset ml-32m --backend sentence --base-model fm_all_bpr \
  --stage d --epochs 6 --steps-per-epoch 200 --batch-size 64 \
  --eval-users 40 --validate-every 2 --device cpu --threads 2
```

## Stage E — lightweight DIN-style candidate-aware attention

Adds a small learnable attention head over the most recent **30 positive ratings**, reading movie title, genre and historical-tag embeddings, time-since-rating, and each candidate representation. It uses an **additive residual on a frozen FM**, *not* a full DIN reproduction. E also retains the Stage D engineered features.

```bash
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 python -u -m temporal_fm.preference_experiment \
  --dataset ml-32m --backend sentence --base-model fm_all_bpr \
  --stage e --epochs 6 --steps-per-epoch 200 --batch-size 32 \
  --eval-users 40 --validate-every 2 --device cpu --threads 2
```

Stage E consumes more CPU/RAM and can overfit. Only compare it with B–D under the same cohort, seed and candidate catalogue. The feature-engineered variants may be better.

## Existing regularized FM checkpoint

Change `--base-model fm_all_bpr` to `--base-model fm_all_l2try_bpr` in **all** commands to compare enhancements of the L2-regularized model. Checkpoints for different base FM models are stored separately.

## Fixed benchmark and reports

All four stages use **exactly the same existing `temporal_fm.ranking._cohort` and `_ranking_scores` definitions**, and a full warm training catalogue by default (`--max-candidates 0`). FM and popularity are scored again on the **same** cohort. Model checkpoints are selected on held-out validation NDCG@10, never on test.

The reports include Recall@10, NDCG@10, Hit Rate@10, MRR@10, Precision@10, catalogue coverage, paired per-user NDCG differences and bootstrap 95% intervals. Report files are in `reports/temporal/ml-32m/preference_experiments/`.

For a more stable comparison use `--eval-users 300` consistently, keeping seed 42. This requires repeated full-catalogue scoring and may be slow on CPU. Never compare earlier runs using a different user cohort or sampled negatives as though they were the same benchmark. To evaluate a **frozen, selected** model on test (not for tuning):

```bash
python -m temporal_fm.preference_experiment --dataset ml-32m --backend sentence \
  --base-model fm_all_bpr --stage d --evaluate-only --split test --eval-users 300
```

## Graphical report

```bash
streamlit run temporal_fm/preference_dashboard.py \
  --server.address 0.0.0.0 --server.port 8501
```

The dashboard groups reports by base model, seed, split, and **exact evaluated user IDs / K / cutoff / candidate policy**, and refuses to silently mix incompatible cohorts. It shows all available B–E variants and the original FM/popularity baselines.

## Scientific limitations

- **MovieLens timestamps are rating-submission times**, not verified watch times. Apparent recency may partly reflect bulk rating activity.
- Positive labels are observed ratings ≥4 stars; unobserved items are not verified dislikes. Random negative samples can be false negatives.
- The cached history stores *training-period* ratings only, and every training feature queries strictly before its positive event. All evaluation features use the global training cutoff.
- Evaluation user eligibility is determined by held-out future positive events; reports should discuss the resulting selection bias.
- No 32M numerical benefit is claimed without actually running the supplied code in your environment.
- For 32M, a full historical tag store can itself take significant disk/memory. Avoid running simultaneous jobs in a memory-limited Codespace.
