"""Streamlit dashboard comparing matched Temporal Preference FM variants B/C/D/E."""
from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
import streamlit as st

st.set_page_config(page_title='Temporal Preferences | Reco',page_icon='🎬',layout='wide')
st.title('Temporal Preference Research · MovieLens')
st.caption('Stages B–D: historical preference engineering · Stage E: candidate-aware DIN head')
dataset=st.selectbox('Dataset',['ml-32m','ml-1m'],index=0)
folder=Path('reports')/'temporal'/dataset/'preference_experiments'
files=sorted(folder.glob('*.json')) if folder.is_dir() else []
if not files:
    st.info('No experiment reports yet. Run `python -m temporal_fm.preference_experiment --stage b ...` first.')
    st.stop()
reports=[]
for f in files:
    try:
        x=json.loads(f.read_text(encoding='utf-8'))
        if x.get('stage') in ('b','c','d','e') and x.get('metrics'):reports.append((f,x))
    except (OSError,ValueError):continue
if not reports:st.warning('No readable preference reports.');st.stop()
st.subheader('Matched validation report selection')
base=st.selectbox('Base FM checkpoint',sorted({r['base_checkpoint'] for _,r in reports}))
seed=st.selectbox('Cohort seed',sorted({r['seed'] for _,r in reports if r['base_checkpoint']==base}))
split=st.selectbox('Split',sorted({r['split'] for _,r in reports if r['base_checkpoint']==base and r['seed']==seed}))
subset=[(f,r) for f,r in reports if r['base_checkpoint']==base and r['seed']==seed and r['split']==split]
# Different user sets or candidate policies make comparisons scientifically invalid.
keys=sorted({(tuple(r.get('evaluated_user_ids',[])),r.get('candidate_policy'),r.get('k'),r.get('cutoff')) for _,r in subset},key=str)
cohort=st.selectbox('Exact evaluation cohort',keys,format_func=lambda x:f'{len(x[0])} users · {x[1]} · K={x[2]} · cutoff={x[3]}')
subset=[(f,r) for f,r in subset if (tuple(r.get('evaluated_user_ids',[])),r.get('candidate_policy'),r.get('k'),r.get('cutoff'))==cohort]
if cohort[1]!='full_warm_catalog':
    st.warning('This report uses sampled candidates and is NOT comparable with full-catalogue scores.')
selected={}
for path,report in sorted(subset,key=lambda x:x[0].stat().st_mtime):selected[report['stage']]=(path,report)
rows=[]
if selected:
    path,reference=next(iter(selected.values()))
    for name,metric in reference['metrics'].items():
        if name in ('fm_base','popularity'):rows.append({'model':name,**metric})
    for stage,(path,r) in sorted(selected.items()):
        result=r['metrics'].get(f'fm_{stage}_temporal')
        if result:rows.append({'model':f'FM + {stage.upper()} · {r["stage_description"]}',**result})
if not rows:st.warning('No matched metrics.');st.stop()
df=pd.DataFrame(rows).set_index('model')
st.dataframe(df,use_container_width=True)
metric=st.selectbox('Graph metric',[c for c in ('ndcg_at_k','recall_at_k','hit_rate_at_k','mrr_at_k','catalog_coverage_at_k') if c in df])
st.bar_chart(df[metric])
st.subheader('Paired NDCG improvement over original FM')
for stage,(_,report) in sorted(selected.items()):
    diff=report.get('paired_ndcg_delta_vs_base',{})
    st.write(f'**{stage.upper()}**: ΔNDCG@{report["k"]} = {diff.get("mean",0):+.5f}, '
             f'95% bootstrap CI {diff.get("bootstrap95",[])}; {diff.get("users",0)} users')
st.caption('Offline evaluation uses frozen FM checkpoints, historical feature cutoffs, and future positive labels. '
           'Confidence intervals are paired across users; they do not correct for exposure or selection bias.')
with st.expander('Example recommendations'):
    for stage,(_,report) in sorted(selected.items()):
        examples=report.get('examples',{})
        if examples:
            st.write(f'**Stage {stage.upper()}**')
            uid=next(iter(examples))
            st.caption(f'Anonymous user ID {uid}')
            st.dataframe(pd.DataFrame(examples[uid]),hide_index=True,use_container_width=True)
