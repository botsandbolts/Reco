"""Stage E: compact candidate-aware Deep Interest Network (DIN)-inspired residual.

This is not a BERT4Rec or paper-identical DIN reproduction: it is a lightweight
candidate-attention head over a strictly historical positive-rating sequence.
"""
from __future__ import annotations
import torch
from torch import nn
from torch.nn import functional as F

class DINResidual(nn.Module):
    def __init__(self,title_dim,genre_dim,tag_dim,latent=24):
        super().__init__()
        self.title=nn.Linear(title_dim,latent,bias=False)
        self.genre=nn.Linear(genre_dim,latent,bias=False)
        self.tag=nn.Linear(tag_dim,latent,bias=False)
        self.attention=nn.Sequential(nn.Linear(4*latent+1,48),nn.ReLU(),nn.Linear(48,1))
        self.readout=nn.Sequential(nn.Linear(latent*3,32),nn.ReLU(),nn.Linear(32,1))
        nn.init.zeros_(self.readout[-1].weight)
        nn.init.zeros_(self.readout[-1].bias)

    def _encode(self,values):
        return self.title(F.normalize(values['title'],dim=-1,eps=1e-8))+\
               self.genre(F.normalize(values['genres'],dim=-1,eps=1e-8))+\
               self.tag(F.normalize(values['tags'],dim=-1,eps=1e-8))

    def forward(self,candidate,history,ages,mask):
        # candidate: (B, dimensions), history: (B,L,dimensions), mask: (B,L).
        q=self._encode(candidate)
        h=self._encode(history)
        n=h.shape[1]
        q_rep=q.unsqueeze(1).expand(-1,n,-1)
        a=torch.log1p(torch.clamp(ages,0,36500)).unsqueeze(-1)/10.
        features=torch.cat([q_rep,h,q_rep*h,q_rep-h,a],dim=-1)
        logits=self.attention(features).squeeze(-1)
        logits=logits.masked_fill(~mask.bool(),-1e9)
        weights=F.softmax(logits,dim=1)*mask.float()
        weights=weights/weights.sum(dim=1,keepdim=True).clamp_min(1.e-8)
        pooled=(weights.unsqueeze(-1)*h).sum(dim=1)
        return self.readout(torch.cat([q,pooled,q*pooled],dim=-1)).flatten()
