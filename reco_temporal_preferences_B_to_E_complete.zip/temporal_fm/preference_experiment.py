"""Temporal preference experiments B-E: train a small BPR residual over frozen FM.

Stages: b=recent genres; c=+as-of tag semantics; d=+time-decayed fusion;
e=+candidate-aware DIN attention. All history is from TRAIN ratings < query time.
Examples in docs/TEMPORAL_PREFERENCES.md. Best checkpoints are independently stored.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
from pathlib import Path
import re
import time

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from .data import Events
from .train import FeatureProvider
from .ranking import _cohort,_model,_ranking_scores,score_candidates
from .preference_history import HistoryIndex
from .preference_genre import GENRE_NAMES,genre_context,genre_features

STAGES={'b':'Recent genre affinity', 'c':'Semantic-tag affinity',
        'd':'Long-short fusion', 'e':'DIN-style candidate-aware attention'}


def _names(stage):
    cols=list(GENRE_NAMES)
    if stage in 'cde':
        from .preference_semantic import TAG_NAMES
        cols.extend(TAG_NAMES)
    if stage in 'de':
        from .preference_fusion import FUSION_NAMES
        cols.extend(FUSION_NAMES)
    return cols


class TemporalPreferenceFeatures:
    def __init__(self,events,provider,history,stage,max_history=500,din_history=30):
        if stage not in STAGES:raise ValueError(f'Stage must be one of {list(STAGES)}')
        self.ev=events;self.provider=provider;self.history=history
        self.stage=stage;self.names=_names(stage)
        self.max_history=max_history;self.din_history=din_history
        self.cache_key=None;self.cache_value=None

    def context(self,raw_user,timestamp):
        key=(int(raw_user),int(timestamp))
        if key==self.cache_key:return self.cache_value
        ids=self.history.before(raw_user,timestamp,limit=self.max_history)
        gc=genre_context(self.ev,ids,timestamp)
        sc=None
        if self.stage in 'cde':
            from .preference_semantic import semantic_context
            sc=semantic_context(self.ev,self.provider,ids,timestamp)
        value=(ids,gc,sc)
        self.cache_key=key;self.cache_value=value
        return value

    def matrix(self,raw_user,timestamp,mids,ctx=None):
        mids=np.asarray(mids,dtype=np.int32)
        ids,gc,sc=self.context(raw_user,timestamp) if ctx is None else ctx
        genres=self.ev.genre_matrix[mids]
        values=[genre_features(gc,genres)]
        tags=None
        if self.stage in 'cde':
            from .preference_semantic import semantic_features
            tags=self.provider.tags.lookup(mids,np.full(len(mids),int(timestamp),dtype=np.int64))
            values.append(semantic_features(sc,tags))
        if self.stage in 'de':
            from .preference_fusion import fusion_features
            values.append(fusion_features(gc,sc,genres,tags))
        out=np.concatenate(values,axis=1).astype(np.float32)
        if not np.isfinite(out).all():raise ValueError('Nonfinite preference feature detected')
        return out

    def din_inputs(self,raw_user,timestamp,mids,ctx=None):
        if self.stage!='e':raise ValueError('DIN inputs require stage e')
        ids,_,_=self.context(raw_user,timestamp) if ctx is None else ctx
        ids=ids[-self.din_history:]
        ev=self.ev; p=self.provider
        hist_movies=np.asarray(ev.movie_idx[ids],dtype=np.int32)
        n=len(hist_movies);width=self.din_history
        hist={}
        for label,arr,d in (
            ('title',np.asarray(p.title[hist_movies],dtype=np.float32),p.title.shape[1]),
            ('genres',ev.genre_matrix[hist_movies],len(ev.genres)),
            ('tags',p.tags.lookup(hist_movies,np.full(n,int(timestamp),dtype=np.int64)),p.tags.tag_dims)):
            padded=np.zeros((width,d),dtype=np.float32)
            if n:padded[-n:]=arr
            hist[label]=padded
        ages=np.zeros(width,dtype=np.float32)
        if n:ages[-n:]=np.maximum(0,(int(timestamp)-np.asarray(ev.timestamp[ids],dtype=np.int64))/86400.)
        mask=np.zeros(width,dtype=np.bool_)
        if n:mask[-n:]=True
        cand={
            'title':np.asarray(p.title[mids],dtype=np.float32),
            'genres':np.asarray(ev.genre_matrix[mids],dtype=np.float32),
            'tags':p.tags.lookup(mids,np.full(len(mids),int(timestamp),dtype=np.int64)),
        }
        return cand,hist,ages,mask


class PreferenceHead(nn.Module):
    def __init__(self,n_features,stage,title_dim=0,genre_dim=0,tag_dim=0):
        super().__init__()
        self.stage=stage
        self.linear=nn.Linear(n_features,1,bias=False)
        nn.init.zeros_(self.linear.weight)
        if stage=='e':
            from .preference_din import DINResidual
            self.din=DINResidual(title_dim,genre_dim,tag_dim)

    def forward(self,features,base_scores,din=None):
        scores=base_scores+self.linear(features).flatten()
        if self.stage=='e':
            if din is None:raise ValueError('Stage E requires candidate-specific attention inputs')
            scores=scores+self.din(*din)
        return scores


def _batch(ev,p,users,mids,stamps,device):
    users=np.asarray(users,dtype=np.int32);mids=np.asarray(mids,dtype=np.int32)
    stamps=np.asarray(stamps,dtype=np.int64)
    ui=ev.user_indices(users);cal,continuum=ev.time_fields(ui,mids,stamps)
    vals={'user':ui,'item':ev.item_indices(mids),
          'title':np.asarray(p.title[mids],dtype=np.float32),
          'genres':ev.genre_matrix[mids],
          'tags':p.tags.lookup(mids,stamps),
          'calendar':cal,'time':continuum}
    return {k:torch.as_tensor(np.array(v,copy=True),device=device,
                              dtype=torch.long if k in ('user','item','calendar') else torch.float32)
            for k,v in vals.items()}


def _din_batch(feature_builder,users,timestamps,movies,device):
    candidate={k:[] for k in ('title','genres','tags')}
    history={k:[] for k in candidate}
    ages=[];masks=[]
    for u,t,m in zip(users,timestamps,movies):
        c,h,a,mk=feature_builder.din_inputs(int(u),int(t),np.array([int(m)]))
        for k in candidate:
            candidate[k].append(c[k][0]);history[k].append(h[k])
        ages.append(a);masks.append(mk)
    ct={k:torch.tensor(np.stack(v),dtype=torch.float32,device=device) for k,v in candidate.items()}
    ht={k:torch.tensor(np.stack(v),dtype=torch.float32,device=device) for k,v in history.items()}
    at=torch.tensor(np.stack(ages),dtype=torch.float32,device=device)
    mt=torch.tensor(np.stack(masks),dtype=torch.bool,device=device)
    return ct,ht,at,mt


def _batch_preference(feature_builder,users,timestamps,movies,device):
    features=np.stack([feature_builder.matrix(int(u),int(t),np.asarray([int(m)],dtype=np.int32))[0]
                       for u,t,m in zip(users,timestamps,movies)])
    return torch.as_tensor(features,device=device,dtype=torch.float32)


def _positive_training_events(ev,threshold):
    ids=np.asarray(ev.split('train'),dtype=np.int32)
    parts=[]
    for at in range(0,len(ids),400_000):
        chunk=ids[at:at+400_000]
        chosen=chunk[np.asarray(ev.rating[chunk]>=threshold)]
        if len(chosen):parts.append(chosen)
    if not parts:raise ValueError('No positive training events')
    return np.concatenate(parts)


def _negative_movies(rng,ev,history,users,timestamps,catalog):
    picked=np.empty(len(users),dtype=np.int32)
    years=np.asarray(timestamps,dtype='datetime64[s]').astype('datetime64[Y]').astype(np.int32)+1970
    for j,(u,t,year) in enumerate(zip(users,timestamps,years)):
        # Reject only ratings *previously known* at t, never inspect future ratings.
        seen=history.before(int(u),int(t),positive_only=False,limit=100000)
        seen_m=set(map(int,np.asarray(ev.movie_idx[seen],dtype=np.int32)))
        found=False
        for _ in range(300):
            m=int(catalog[rng.integers(len(catalog))])
            if m in seen_m:continue
            if ev.release_year[m]>year and ev.release_year[m]>0:continue
            picked[j]=m;found=True;break
        if not found:raise RuntimeError('Unable to find a historically eligible negative')
    return picked


def _train_pair(head,base,ev,provider,builder,users,stamps,pos,neg,optimizer,device):
    uu=np.concatenate((users,users));mm=np.concatenate((pos,neg));tt=np.concatenate((stamps,stamps))
    with torch.inference_mode():bs=base(_batch(ev,provider,uu,mm,tt,device)).detach()
    feat=_batch_preference(builder,uu,tt,mm,device)
    din=_din_batch(builder,uu,tt,mm,device) if builder.stage=='e' else None
    head.train();score=head(feat,bs,din)
    n=len(users);loss=F.softplus(score[n:]-score[:n]).mean()
    optimizer.zero_grad(set_to_none=True);loss.backward()
    torch.nn.utils.clip_grad_norm_(head.parameters(),max_norm=2.)
    optimizer.step()
    return float(loss.detach().cpu())


def _score_corrected(head,base,ev,provider,builder,user,timestamp,candidates,device,chunk_size=1024):
    mids=np.asarray(candidates,dtype=np.int32)
    result=[]
    ctx=builder.context(user,timestamp)
    head.eval();base.eval()
    with torch.inference_mode():
        for start in range(0,len(mids),chunk_size):
            items=mids[start:start+chunk_size]
            raw=np.full(len(items),int(user),dtype=np.int32)
            ts=np.full(len(items),int(timestamp),dtype=np.int64)
            base_s=base(_batch(ev,provider,raw,items,ts,device))
            f=torch.as_tensor(builder.matrix(user,timestamp,items,ctx),device=device,dtype=torch.float32)
            if builder.stage=='e':
                c,h,a,mask=builder.din_inputs(user,timestamp,items,ctx)
                din=(
                    {k:torch.as_tensor(v.copy(),device=device) for k,v in c.items()},
                    {k:torch.as_tensor(np.broadcast_to(v,(len(items),)+v.shape).copy(),device=device) for k,v in h.items()},
                    torch.as_tensor(np.broadcast_to(a,(len(items),len(a))).copy(),device=device),
                    torch.as_tensor(np.broadcast_to(mask,(len(items),len(mask))).copy(),device=device))
            else:din=None
            scores=head(f,base_s,din).cpu().numpy()
            if not np.isfinite(scores).all():raise ValueError('Nonfinite corrected scores')
            result.append(scores)
    return np.concatenate(result) if result else np.empty(0,dtype=np.float32)


def _load_data(dataset,data_dir,backend):
    ev=Events(Path(data_dir)/'temporal'/dataset)
    title_file=ev.folder/f'features_{backend}'/'meta.json'
    if not title_file.is_file():
        raise FileNotFoundError(f'Missing {title_file}. Train the existing FM checkpoint first.')
    meta=json.loads(title_file.read_text())
    t_dir=ev.folder/f'features_{backend}'
    t_dir=t_dir if (t_dir/'tag_keys.npy').exists() else None
    if ev.meta.get('tags_path') and t_dir is None:
        raise FileNotFoundError('Historical tag features unavailable; generate them with temporal_fm.rank_train')
    provider=FeatureProvider(ev,backend,meta['model_name'],t_dir)
    provider.backend=backend;provider.model_name=meta['model_name']
    return ev,provider


def _checkpoint_info(ev,provider,base_model,stage,seed):
    return {'dataset':ev.meta['dataset'],'sources':ev.meta['sources'],
            'train_cutoff':ev.meta['train_cutoff'],'validation_cutoff':ev.meta['val_cutoff'],
            'backend':provider.backend,'text_model':provider.model_name,
            'tag_dims':provider.tags.tag_dims,'base_model':base_model,
            'stage':stage,'seed':seed,'feature_names':_names(stage)}


def _load_head(folder,expected,ev,provider,device):
    metadata=json.loads((folder/'metadata.json').read_text())
    for k,v in expected.items():
        if metadata.get(k)!=v:raise ValueError(f'Incompatible temporal preference checkpoint: {k}')
    head=PreferenceHead(len(expected['feature_names']),expected['stage'],
              provider.title.shape[1],len(ev.genres),provider.tags.tag_dims).to(device)
    head.load_state_dict(torch.load(folder/'weights.pt',map_location=device,weights_only=True))
    head.eval();return head


def evaluate(head,base,ev,provider,builder,users=40,seed=42,k=10,split='validation',
             threshold=4.,device='cpu',max_candidates=0,example_users=3):
    from .ranking import _candidates,_train_counts
    active,seen,truth,pop,cohort=_cohort(ev,split,threshold,users,3,seed)
    rng=np.random.default_rng(seed+191)
    catalog=np.flatnonzero(ev.movie_has_train).astype(np.int32)
    cutoff=int(ev.meta['train_cutoff'])+1
    scores={key:[] for key in ('popularity','fm_base',f'fm_{builder.stage}_temporal')}
    examples={}; top_sets={key:set() for key in scores}; paired_rows={key:[] for key in scores}
    for idx,u in enumerate(active):
        cand=_candidates(catalog,seen[u],truth[u],max_candidates,rng)
        b=score_candidates(base,ev,provider,u,cand,cutoff,device,2048)
        f=_score_corrected(head,base,ev,provider,builder,u,cutoff,cand,device)
        variants={'popularity':np.log1p(pop[cand]),'fm_base':b,f'fm_{builder.stage}_temporal':f}
        for key,values in variants.items():
            top=cand[np.argsort(-values,kind='stable')[:k]]
            row=_ranking_scores(top,truth[u],k,ev.genre_matrix,pop,len(ev.split('train')))
            scores[key].append(row)
            top_sets[key].update(map(int,top))
            paired_rows[key].append(float(row['ndcg_at_k']))
            if idx<example_users and key==f'fm_{builder.stage}_temporal':
                examples[str(u)]=[{'movieId':int(ev.movies.iloc[int(m)].movieId),
                    'title':str(ev.movies.iloc[int(m)].title), 'relevant':bool(int(m) in truth[u])}
                    for m in top]
    report={}
    for key,rows in scores.items():
        if rows:report[key]={metric:round(float(np.mean([row[metric] for row in rows])),6)
                             for metric in ('ndcg_at_k','recall_at_k','hit_rate_at_k','mrr_at_k','precision_at_k')}
        if rows:
            report[key]['users']=len(rows)
            report[key]['catalog_coverage_at_k']=round(len(top_sets[key])/max(1,len(catalog)),6)
    corrected=f'fm_{builder.stage}_temporal'
    paired=np.asarray(paired_rows[corrected],dtype=np.float64)-np.asarray(paired_rows['fm_base'],dtype=np.float64)
    boot=np.random.default_rng(seed+999)
    ci=(np.percentile(boot.choice(paired,size=(400,len(paired)),replace=True).mean(axis=1),[2.5,97.5]).tolist()
        if len(paired) else [None,None])
    return {'metrics':report,'paired_ndcg_delta_vs_base':{'mean':float(np.mean(paired)) if len(paired) else None,
                'bootstrap95':ci,'users':len(paired)},'evaluated_user_ids':list(map(int,active)),'examples':examples,'cohort':cohort,
            'candidate_policy':'full_warm_catalog' if max_candidates==0 else 'SAMPLED_NOT_COMPARABLE',
            'split':split,'k':k,'cutoff':cutoff,
            'caveat':'Validation future positive labels are never features. Train histories and tag semantics are strictly historical.'}


def run(dataset='ml-32m',data_dir='data',backend='sentence',base_model='fm_all_bpr',
        stage='b',run_label='',epochs=6,steps_per_epoch=200,batch_size=64,
        learning_rate=.002,eval_users=40,validate_every=2,seed=42,threshold=4.,
        device='cpu',threads=2,force_retrain=False,max_candidates=0,
        evaluate_only=False,split='validation',k=10):
    if stage not in STAGES:raise ValueError('Unknown stage')
    if run_label and not re.fullmatch('[A-Za-z0-9_]+',run_label):raise ValueError('Invalid run label')
    if epochs<1 or steps_per_epoch<1 or batch_size<1 or eval_users<1 or validate_every<1:
        raise ValueError('Training and evaluation sizes must be positive')
    if device=='cuda' and not torch.cuda.is_available():raise ValueError('CUDA unavailable')
    torch.set_num_threads(max(1,threads))
    np.random.seed(seed);torch.manual_seed(seed)
    ev,provider=_load_data(dataset,data_dir,backend)
    base=_model(ev,provider,base_model,backend,device)
    base.eval()
    for param in base.parameters():param.requires_grad_(False)
    history=HistoryIndex(ev)
    builder=TemporalPreferenceFeatures(ev,provider,history,stage)
    expected=_checkpoint_info(ev,provider,base_model,stage,seed)
    label=f'{stage}_{run_label}' if run_label else stage
    folder=Path('models')/dataset/'temporal_preferences'/f'{base_model}_{label}'
    folder.mkdir(parents=True,exist_ok=True)
    existing=(folder/'weights.pt').exists()
    if existing and (evaluate_only or not force_retrain):
        head=_load_head(folder,expected,ev,provider,device)
        print('Using existing temporal preference checkpoint',folder,flush=True)
    else:
        if evaluate_only:raise FileNotFoundError(f'Missing trained checkpoint in {folder}')
        head=PreferenceHead(len(builder.names),stage,provider.title.shape[1],
                            len(ev.genres),provider.tags.tag_dims).to(device)
        optimizer=torch.optim.AdamW(head.parameters(),lr=learning_rate,weight_decay=1.e-4)
        positives=_positive_training_events(ev,threshold)
        catalog=np.flatnonzero(ev.movie_has_train).astype(np.int32)
        rng=np.random.default_rng(seed)
        best=-float('inf');logs=[]
        for epoch in range(1,epochs+1):
            started=time.perf_counter();ls=[]
            for step in range(steps_per_epoch):
                ids=positives[rng.integers(len(positives),size=batch_size)]
                users=np.asarray(ev.user_raw[ids],dtype=np.int32)
                timestamps=np.asarray(ev.timestamp[ids],dtype=np.int64)
                movies=np.asarray(ev.movie_idx[ids],dtype=np.int32)
                negatives=_negative_movies(rng,ev,history,users,timestamps,catalog)
                loss=_train_pair(head,base,ev,provider,builder,users,timestamps,movies,negatives,optimizer,device)
                ls.append(loss)
            row={'epoch':epoch,'bpr_loss':round(float(np.mean(ls)),6),
                 'epoch_seconds':round(time.perf_counter()-started,2)}
            if epoch%validate_every==0 or epoch==epochs:
                bench=evaluate(head,base,ev,provider,builder,eval_users,seed,k,device=device,
                               max_candidates=max_candidates,threshold=threshold)
                score=bench['metrics'][f'fm_{stage}_temporal']['ndcg_at_k']
                row['validation_ndcg_at_10']=score
                if score>best:
                    best=score
                    torch.save(head.state_dict(),folder/'weights.pt')
                    (folder/'metadata.json').write_text(json.dumps(expected,indent=2))
            logs.append(row)
            (folder/'history.json').write_text(json.dumps(logs,indent=2))
            print(f'{stage}: epoch {epoch}/{epochs} loss={row["bpr_loss"]:.4f} '
                  f'ndcg={row.get("validation_ndcg_at_10","--")} seconds={row["epoch_seconds"]}',flush=True)
        head=_load_head(folder,expected,ev,provider,device)
    result=evaluate(head,base,ev,provider,builder,eval_users,seed,k,split=split,
                    threshold=threshold,device=device,max_candidates=max_candidates)
    result.update({'dataset':dataset,'stage':stage,'stage_description':STAGES[stage],
                   'base_checkpoint':base_model,'checkpoint':str(folder/'weights.pt'),
                   'feature_names':builder.names,'seed':seed,
                   'selection_set':'validation',
                   'checkpoint_selection_done_on_validation':True,
                   'training_protocol':'Frozen FM + additive temporal residual, BPR positive vs historically unrated movies'})
    report_dir=Path('reports')/'temporal'/dataset/'preference_experiments'
    report_dir.mkdir(parents=True,exist_ok=True)
    filename=f'{base_model}_{label}_{split}_seed{seed}.json'
    target=report_dir/filename
    target.write_text(json.dumps(result,indent=2))
    with target.with_suffix('.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['model','ndcg_at_k','recall_at_k','hit_rate_at_k','mrr_at_k','precision_at_k','catalog_coverage_at_k','users'])
        writer.writeheader()
        for key,v in result['metrics'].items():writer.writerow({'model':key,**v})
    print('Saved:',target,flush=True)
    return result


def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--dataset',default='ml-32m')
    ap.add_argument('--data-dir',default='data')
    ap.add_argument('--backend',choices=['sentence','hash'],default='sentence')
    ap.add_argument('--base-model',default='fm_all_bpr')
    ap.add_argument('--stage',choices=list(STAGES),required=True)
    ap.add_argument('--run-label',default='')
    ap.add_argument('--epochs',type=int,default=6)
    ap.add_argument('--steps-per-epoch',type=int,default=200)
    ap.add_argument('--batch-size',type=int,default=64)
    ap.add_argument('--learning-rate',type=float,default=.002)
    ap.add_argument('--eval-users',type=int,default=40)
    ap.add_argument('--validate-every',type=int,default=2)
    ap.add_argument('--seed',type=int,default=42)
    ap.add_argument('--threshold',type=float,default=4.)
    ap.add_argument('--k',type=int,default=10)
    ap.add_argument('--device',choices=['cpu','cuda'],default='cpu')
    ap.add_argument('--threads',type=int,default=2)
    ap.add_argument('--force-retrain',action='store_true')
    ap.add_argument('--evaluate-only',action='store_true')
    ap.add_argument('--split',choices=['validation','test'],default='validation')
    ap.add_argument('--max-candidates',type=int,default=0,
                    help='0=full train catalogue; sampled results are NOT comparable')
    args=vars(ap.parse_args(argv))
    if args['split']=='test' and not args['evaluate_only']:
        ap.error('Test split must only be used with --evaluate-only after validation-based selection')
    return run(**args)

if __name__=='__main__':main()
