"""Stage D: multi-timescale recency decay and long/short-term preference fusion."""
from __future__ import annotations
import numpy as np
from .preference_genre import safe_normalize,weighted_profile

FUSION_NAMES=('genre_decay90','genre_decay365','genre_shift90','tags_decay90','tags_decay365','tags_shift90')

def fusion_features(genre_ctx,semantic_ctx,candidate_genres,candidate_tags):
    gm=safe_normalize(candidate_genres);tm=safe_normalize(candidate_tags)
    gw=genre_ctx['weights'];ages=genre_ctx['ages']
    tw=semantic_ctx['weights'];tg=semantic_ctx['tags']
    genre90=weighted_profile(genre_ctx['genres'],gw*np.exp2(-ages/90.))
    genre365=weighted_profile(genre_ctx['genres'],gw*np.exp2(-ages/365.))
    genre_all=weighted_profile(genre_ctx['genres'],gw)
    tag90=weighted_profile(tg,tw*np.exp2(-ages/90.))
    tag365=weighted_profile(tg,tw*np.exp2(-ages/365.))
    tag_all=weighted_profile(tg,tw)
    return np.column_stack((gm@genre90,gm@genre365,gm@(genre90-genre_all),
                            tm@tag90,tm@tag365,tm@(tag90-tag_all))).astype(np.float32)
