"""Stage B: strictly historical recent vs long-term user genre affinities."""
from __future__ import annotations
import numpy as np

GENRE_NAMES=('genre_last10','genre_last30','genre_last100','genre_long500','genre_drift30')

def safe_normalize(x):
    x=np.asarray(x,dtype=np.float32)
    return x/np.maximum(np.linalg.norm(x,axis=-1,keepdims=True),1.e-8)

def genre_context(events,history_event_ids,query_ts):
    inds=np.asarray(history_event_ids,dtype=np.int64)
    if not len(inds):return {'genres':np.empty((0,len(events.genres)),dtype=np.float32),'weights':np.empty(0,dtype=np.float32),'ages':np.empty(0,dtype=np.float32)}
    mid=np.asarray(events.movie_idx[inds],dtype=np.int32)
    ts=np.asarray(events.timestamp[inds],dtype=np.int64)
    if np.any(ts>=query_ts):raise ValueError('Future history leakage')
    rates=np.asarray(events.rating[inds],dtype=np.float32)
    ages=np.maximum(0,np.float32((int(query_ts)-ts)/86400.))
    return {'genres':safe_normalize(events.genre_matrix[mid]),'weights':np.clip(rates-3.5,.1,1.5), 'ages':ages}

def weighted_profile(rows,weights):
    if not len(rows):return np.zeros(rows.shape[1],dtype=np.float32)
    return safe_normalize(np.average(rows,weights=np.maximum(weights,1.e-6),axis=0))

def genre_features(ctx,candidate_genres):
    movies=safe_normalize(candidate_genres)
    rows=ctx['genres'];w=ctx['weights']
    v10=weighted_profile(rows[-10:],w[-10:]);v30=weighted_profile(rows[-30:],w[-30:])
    v100=weighted_profile(rows[-100:],w[-100:]);vlong=weighted_profile(rows,w)
    mat=np.column_stack([movies@v for v in (v10,v30,v100,vlong)])
    return np.column_stack([mat,(mat[:,1]-mat[:,3])]).astype(np.float32)
