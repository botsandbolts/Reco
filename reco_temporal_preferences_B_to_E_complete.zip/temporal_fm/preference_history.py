"""Disk-cached TRAIN-only chronological user-history index for recommender features.

Every query uses timestamp < prediction_time, never current/future ratings.
Do not confuse a MovieLens rating time with actual movie-watch time.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import numpy as np

class HistoryIndex:
    def __init__(self, events, rebuild=False):
        self.events=events
        folder=events.folder/'preference_history_v1'
        folder.mkdir(parents=True,exist_ok=True)
        signature=hashlib.sha256(json.dumps({
            'sources':events.meta['sources'], 'train_cutoff':events.meta['train_cutoff'],
            'split_len':len(events.split('train')),'seed':events.meta.get('seed')},sort_keys=True).encode()).hexdigest()
        files=[folder/f'{n}.npy' for n in ('user','timestamp','event')]
        meta=folder/'metadata.json'
        if rebuild or not(all(p.is_file() for p in files) and meta.is_file() and
                          json.loads(meta.read_text()).get('signature')==signature):
            # Sorting all train events uses O(N) memory; save one compact index, reuse across stages.
            ix=np.asarray(events.split('train'),dtype=np.int32)
            user=np.asarray(events.user_raw[ix],dtype=np.int32)
            ts=np.asarray(events.timestamp[ix],dtype=np.int64)
            order=np.lexsort((ix,ts,user))
            np.save(files[0],user[order]);np.save(files[1],ts[order]);np.save(files[2],ix[order])
            meta.write_text(json.dumps({'signature':signature,'count':len(ix)},indent=2))
        self.user=np.load(files[0],mmap_mode='r')
        self.ts=np.load(files[1],mmap_mode='r')
        self.event=np.load(files[2],mmap_mode='r')
        self.unique,self.starts,self.counts=np.unique(self.user,return_index=True,return_counts=True)

    def before(self,raw_user,timestamp,positive_only=True,limit=500):
        """Return events strictly BEFORE t, chronologically ordered, max latest 'limit'."""
        pos=int(np.searchsorted(self.unique,int(raw_user)))
        if pos>=len(self.unique) or self.unique[pos]!=raw_user:
            return np.empty(0,dtype=np.int32)
        start=int(self.starts[pos]);end=start+int(self.counts[pos])
        stop=start+int(np.searchsorted(self.ts[start:end],int(timestamp),side='left'))
        if positive_only:
            # Collect in batches backwards to avoid expanding very long sparse histories.
            chunks=[];found=0;cursor=stop
            while cursor>start and found<limit:
                lo=max(start,cursor-max(1024,limit))
                indices=np.asarray(self.event[lo:cursor],dtype=np.int32)
                good=indices[np.asarray(self.events.rating[indices]>=4.)]
                chunks.append(good);found+=len(good);cursor=lo
            if not chunks:return np.empty(0,dtype=np.int32)
            result=np.concatenate(chunks[::-1])
            return result[-limit:]
        return np.asarray(self.event[max(start,stop-limit):stop],dtype=np.int32)

    def has_rated_before(self,raw_user,movie_index,timestamp):
        ids=self.before(raw_user,timestamp,positive_only=False,limit=50000)
        return bool(np.any(np.asarray(self.events.movie_idx[ids])==int(movie_index)))
