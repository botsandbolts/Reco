"""Stage C: semantic affinity to past movies using AS-OF movie tag embeddings."""
from __future__ import annotations
import numpy as np
from .preference_genre import safe_normalize,weighted_profile

TAG_NAMES=('tags_last30','tags_last100','tags_long500','tags_drift30')

def semantic_context(events,provider,history_event_ids,query_ts):
    ids=np.asarray(history_event_ids,dtype=np.int64)
    mids=np.asarray(events.movie_idx[ids],dtype=np.int32)
    tags=provider.tags.lookup(mids,np.full(len(mids),int(query_ts),dtype=np.int64))
    # Missing tags must stay zero; unit-length vectors remove pooling magnitude differences.
    tags=safe_normalize(tags)
    weights=np.clip(np.asarray(events.rating[ids],dtype=np.float32)-3.5,.1,1.5)
    return {'tags':tags,'weights':weights}

def semantic_features(ctx,candidate_tags):
    rows=ctx['tags'];w=ctx['weights'];movie=safe_normalize(candidate_tags)
    v30=weighted_profile(rows[-30:],w[-30:]);v100=weighted_profile(rows[-100:],w[-100:]);vl=weighted_profile(rows,w)
    mat=np.column_stack((movie@v30,movie@v100,movie@vl))
    return np.column_stack((mat,mat[:,0]-mat[:,2])).astype(np.float32)
