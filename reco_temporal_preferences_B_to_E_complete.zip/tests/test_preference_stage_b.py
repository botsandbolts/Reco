import numpy as np
from temporal_fm.preference_genre import genre_context,genre_features

def test_recent_genres_reflect_history_without_normalization_explosion():
    ctx={'genres':np.array([[1.,0.],[1.,0.],[0.,1.]],dtype=np.float32),
         'weights':np.ones(3,dtype=np.float32),'ages':np.array([9,5,1],dtype=np.float32)}
    result=genre_features(ctx,np.array([[1,0],[0,1]],dtype=np.float32))
    assert result.shape==(2,5)
    assert np.isfinite(result).all()
    assert result[0,0]>0
    assert np.allclose(genre_features({'genres':np.zeros((0,2),dtype=np.float32),
        'weights':np.zeros(0,dtype=np.float32),'ages':np.zeros(0,dtype=np.float32)},
        np.array([[1,0]],dtype=np.float32)),0)
