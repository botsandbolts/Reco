import numpy as np
from temporal_fm.preference_semantic import semantic_features

def test_semantic_no_tags_returns_zero():
    ctx={'tags':np.zeros((4,3),dtype=np.float32),'weights':np.ones(4,dtype=np.float32)}
    assert np.array_equal(semantic_features(ctx,np.zeros((2,3),dtype=np.float32)),np.zeros((2,4)))
