import numpy as np
from temporal_fm.preference_fusion import fusion_features

def test_fusion_uses_time_decay_and_finite_features():
    genre={'genres':np.array([[1.,0.],[0.,1.]],dtype=np.float32),'ages':np.array([500,2],dtype=np.float32),
           'weights':np.array([1.,1.],dtype=np.float32)}
    semantic={'tags':genre['genres'],'weights':genre['weights']}
    features=fusion_features(genre,semantic,np.eye(2,dtype=np.float32),np.eye(2,dtype=np.float32))
    assert features.shape==(2,6)
    assert np.isfinite(features).all()
    assert features[1,0]>features[0,0]
