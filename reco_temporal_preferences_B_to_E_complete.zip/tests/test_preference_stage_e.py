import torch
from temporal_fm.preference_din import DINResidual

def test_din_supports_no_history_and_gradient():
    torch.manual_seed(42)
    model=DINResidual(4,3,2)
    candidate={n:torch.randn(2,d) for n,d in [('title',4),('genres',3),('tags',2)]}
    history={n:torch.randn(2,5,d) for n,d in [('title',4),('genres',3),('tags',2)]}
    mask=torch.tensor([[True,True,False,False,False],[False]*5])
    out=model(candidate,history,torch.zeros(2,5),mask)
    assert out.shape==(2,) and torch.isfinite(out).all()
    loss=out.square().sum();loss.backward()
    assert model.readout[-1].weight.grad is not None
