import json
import hashlib
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
import torch

from temporal_fm.data import prepare,Events
from temporal_fm.features import titles,make_tag_history
from temporal_fm.train import FeatureProvider
from temporal_fm.model import TemporalFM
from temporal_fm.preference_history import HistoryIndex
from temporal_fm.preference_experiment import TemporalPreferenceFeatures,run

@pytest.fixture
def configured(tmp_path,monkeypatch):
    monkeypatch.chdir(tmp_path)
    path=tmp_path/'data/raw/ml-1m';path.mkdir(parents=True)
    movies=pd.DataFrame({'movieId':list(range(1,31)),
        'title':[f'Movie {i} (2000)' for i in range(1,31)],
        'genres':['Sci-Fi|Action' if i%2 else 'Drama|Comedy' for i in range(1,31)]})
    movies.to_csv(path/'movies.csv',index=False)
    rows=[];tags=[];ts0=1600000000
    for u in range(1,9):
        for j in range(30):
            movie=((j*7+u*5)%30)+1
            # 4s and 5s positives, one low-rating per user.
            rating=2. if j%11==0 else 5.
            ts=ts0+j*86400+u*360
            rows.append((u,movie,rating,ts))
            tags.append((u,movie,'space adventures' if movie%2 else 'family drama',ts-3600))
    pd.DataFrame(rows,columns=['userId','movieId','rating','timestamp']).to_csv(path/'ratings.csv',index=False)
    pd.DataFrame(tags,columns=['userId','movieId','tag','timestamp']).to_csv(path/'tags.csv',index=False)
    folder=prepare('ml-1m',data_dir='data',sample_size=1000)
    ev=Events(folder)
    titles(ev,backend='hash')
    tag_dir=make_tag_history(ev,ev.meta['tags_path'],backend='hash',tag_dims=8,max_tag_vocab=50)
    p=FeatureProvider(ev,'hash','sentence-transformers/all-MiniLM-L6-v2',tag_dir)
    p.model_name='sentence-transformers/all-MiniLM-L6-v2';p.backend='hash'
    name='fm_all_bpr';out=Path('models/ml-1m/temporal_fm')/name;out.mkdir(parents=True)
    model=TemporalFM(len(ev.train_users),len(ev.movies),p.title.shape[1],len(ev.genres),
                     p.tags.tag_dims,k=8,mean_rating=0,ablation='all')
    torch.save(model.state_dict(),out/'weights.pt')
    (out/'metadata.json').write_text(json.dumps({'name':name,'objective':'bpr','sources':ev.meta['sources'],
        'train_cutoff':ev.meta['train_cutoff'],'validation_cutoff':ev.meta['val_cutoff'],
        'text_backend':'hash','text_model':p.model_name,'tag_dims':p.tags.tag_dims,
        'kind':'fm','ablation':'all','k':8,'seed':42}))
    return ev,p,HistoryIndex(ev)

def test_chronological_index_strictly_earlier(configured):
    ev,p,h=configured
    first=int(ev.user_raw[np.asarray(ev.split('train'))[0]])
    t=int(ev.meta['train_cutoff'])
    rows=h.before(first,t)
    assert np.all(ev.timestamp[rows] < t)
    assert np.all(ev.rating[rows]>=4)
    assert len(h.before(first,0))==0

def test_stages_no_future_and_valid_shapes(configured):
    ev,p,h=configured
    uid=int(ev.train_users[0]);ts=int(ev.meta['train_cutoff'])+1
    for stage,n in [('b',5),('c',9),('d',15),('e',15)]:
        fb=TemporalPreferenceFeatures(ev,p,h,stage)
        mat=fb.matrix(uid,ts,np.array([0,1,2],dtype=np.int32))
        assert mat.shape==(3,n)
        assert np.isfinite(mat).all()
        if stage=='e':
            c,his,age,mask=fb.din_inputs(uid,ts,np.array([0,1],dtype=np.int32))
            assert his['title'].shape==(30,p.title.shape[1]);assert mask.sum()>0

def test_future_rating_not_in_train_history(configured):
    ev,p,h=configured
    uid=int(ev.train_users[0]);t=int(ev.meta['train_cutoff'])+1
    original=h.before(uid,t)
    val_idx=np.asarray(ev.split('validation'),dtype=np.int64)
    assert np.all(np.asarray(ev.timestamp[val_idx])>ev.meta['train_cutoff'])
    assert not set(map(int,original)) & set(map(int,val_idx))
    # Test same-timestamp interactions are excluded (strictly less than t).
    if len(original):
        cutoff=int(ev.timestamp[original[-1]])
        assert not np.any(np.asarray(ev.timestamp[h.before(uid,cutoff)])>=cutoff)


def test_training_and_matched_rankings(configured):
    cp=Path('models/ml-1m/temporal_fm/fm_all_bpr/weights.pt')
    original=hashlib.sha256(cp.read_bytes()).hexdigest()
    for stage in 'bcde':
        report=run(dataset='ml-1m',backend='hash',base_model='fm_all_bpr',stage=stage,
                   epochs=1,steps_per_epoch=2 if stage=='e' else 1,batch_size=4,eval_users=3,seed=42,
                   validate_every=1,device='cpu',threads=1,force_retrain=True)
        assert report['candidate_policy']=='full_warm_catalog'
        assert set(report['metrics'])=={'popularity','fm_base',f'fm_{stage}_temporal'}
        for metrics in report['metrics'].values():
            assert metrics['users']>0
            assert 0<=metrics['ndcg_at_k']<=1
            assert 0<=metrics['recall_at_k']<=1
        reused=run(dataset='ml-1m',backend='hash',base_model='fm_all_bpr',stage=stage,
                   eval_users=3,evaluate_only=True)
        assert reused['metrics']==report['metrics']
        assert 'bootstrap95' in report['paired_ndcg_delta_vs_base']
    assert original==hashlib.sha256(cp.read_bytes()).hexdigest()
