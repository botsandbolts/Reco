# Unified HOFM3 + semi25 BPR + JointBCD — MovieLens 32M

## What this patch changes

It implements a **single PyTorch model** with a seventh learned historical-preference field, retaining the six existing HOFM3 fields (`user`, `movie`, `title`, `genre`, `historical tags`, `time`). The new field contains **all 15 Stage D B+C+D features**: recent/long-term genre affinities, historical semantic tag affinities, and decayed preference fusion. The model computes:

- Original second-order and third-order HOFM3 scores;
- Learned *linear* B+C+D terms, initialized from the already trained `jointBCD` Stage D checkpoint;
- New FM second-order **BCD × original-field** interactions;
- New third-order **BCD × two distinct original fields** interactions.

The original HOFM3 checkpoint (`fm_all_hofm3semi25_bpr`) was itself initialized from `fm_all_semi25_bpr`. The new model **warm-starts all HOFM3 parameters** and the trained JointBCD coefficients, then **fine-tunes them jointly** with pairwise BPR using **25% semi-hard negatives**, 75% standard sampled negatives. This is **not** a frozen additive head or a LightGBM ensemble. The initial score is exactly `HOFM3 score + pretrained JointBCD correction` (new cross-field weights initialize at zero), and all weights can then update.

**What it does not do:** it does not retain the separate old Stage D scorer during inference, and it does not change any existing checkpoints, LambdaRank pipelines or Streamlit files. It saves a new model under `models/ml-32m/unified_hofm3_bcd/` and metrics under `reports/temporal/ml-32m/unified_hofm3_bcd/`. Existing Studio loaders won't automatically discover this new checkpoint class; this patch provides its own reproducible CLI scorer/evaluator.

## Prerequisites

The prior patches must already be **extracted into Codespaces**:

- Temporal FM and ranking BPR, including semi-hard negatives;
- HOFM3 (`temporal_fm/hofm3.py`);
- B+C+D Temporal Preferences (`temporal_fm/preference_experiment.py`, `preference_history.py`, etc.);
- `models/ml-32m/temporal_fm/fm_all_hofm3semi25_bpr/{weights.pt,metadata.json}` — initialized from the `fm_all_semi25_bpr` checkpoint and trained with `--hard-negative-share 0.25`;
- `models/ml-32m/temporal_preferences/fm_all_semi25_bpr_d_jointBCD/{weights.pt,metadata.json}` — Stage D jointly containing B+C+D;
- Preprocessed `data/temporal/ml-32m/` feature store.

The `metadata.json` of each parent **must match the source dataset, train cutoff, text backend, model, tag dimensionality, and feature schema**. If not, the experiment fails with an explanatory error. Historical features use only TRAIN interactions strictly before the prediction timestamp.

## Install via GitHub Codespaces

Upload `reco_unified_hofm3_bcd_patch.zip` to your repository root using GitHub's website, then in the Codespaces terminal:

```bash
cd /workspaces/Reco
git fetch origin main
git show origin/main:reco_unified_hofm3_bcd_patch.zip > reco_unified_hofm3_bcd_patch.zip
unzip -o reco_unified_hofm3_bcd_patch.zip
python scripts/check_unified_hofm3_bcd.py
python -m pytest -q tests/test_unified_hofm3_bcd.py tests/test_unified_hofm3_integration.py
```

The ZIP adds files only. No install script mutates `rank_train.py`, ranking loaders, existing checkpoints or `app.py`.

## Smoke training, 4 CPUs

```bash
cd /workspaces/Reco
set -o pipefail
OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 \
python -u -m temporal_fm.unified_hofm3_bcd \
  --dataset ml-32m --backend sentence \
  --init-from fm_all_hofm3semi25_bpr \
  --preference-checkpoint auto \
  --run-label bcd_hofm3_smoke \
  --epochs 1 --min-epochs 1 \
  --steps-per-epoch 20 --batch-size 32 \
  --negatives 2 --hard-negative-share 0.25 --hard-pool 8 \
  --validation-users 20 --validate-every 1 \
  --max-candidates 500 --progress-every 5 \
  --threads 4 --device cpu 2>&1 | tee unified_smoke.log
```

**This smoke run uses a sampled candidate pool: its NDCG is not comparable to full-catalogue results.** The actual research run below uses the full warm catalogue.

## Research experiment, 4 CPUs, epoch and batch progress

```bash
cd /workspaces/Reco
set -o pipefail
OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 \
python -u -m temporal_fm.unified_hofm3_bcd \
  --dataset ml-32m --backend sentence \
  --init-from fm_all_hofm3semi25_bpr \
  --preference-checkpoint auto \
  --run-label bcd_hofm3_research \
  --epochs 15 --min-epochs 8 --steps-per-epoch 800 \
  --batch-size 128 --negatives 2 \
  --hard-negative-share 0.25 --hard-pool 8 \
  --learning-rate 0.00008 --new-feature-lr 0.0005 \
  --weight-decay 0.01 --third-l2 0.0001 \
  --validation-users 100 --validate-every 2 \
  --patience 3 --max-candidates 0 --progress-every 50 \
  --threads 4 --device cpu \
  2>&1 | tee unified_hofm3_bcd_research.log
```

Every 50 mini-batches a line prints `EPOCH x/15 STEP y/800 BPR=... elapsed=...`, and after each epoch a separate epoch summary prints. The full-catalogue validation phase also prints user progress. Models/metrics are saved automatically; *do not use* `--force-retrain` unless you explicitly intend to overwrite this NEW combined checkpoint.

A large 32M run on four CPU cores may be expensive due to historical preference lookups, especially with semi-hard mining. The smoke run should finish first.

## Matched full-catalogue evaluation

```bash
OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 \
python -u -m temporal_fm.unified_hofm3_bcd \
  --dataset ml-32m --backend sentence \
  --init-from fm_all_hofm3semi25_bpr \
  --run-label bcd_hofm3_research \
  --evaluate-only --split validation --validation-users 300 \
  --max-candidates 0 --k 10 --threads 4 --device cpu
```

The report evaluates **popularity, original frozen HOFM3 and the unified model** on the same sampled *users*, and with identical full-catalogue candidate eligibility. It does not silently combine scores from unrelated prior experiments. The test split is supported only with `--evaluate-only`, after validation-based selection.

## Checkpoint and report locations

```text
models/ml-32m/unified_hofm3_bcd/fm_all_hofm3semi25_bpr_bcd_hofm3_research/
    weights.pt
    metadata.json
    history.json
reports/temporal/ml-32m/unified_hofm3_bcd/
    fm_all_hofm3semi25_bpr_bcd_hofm3_research_validation_seed42.json
    fm_all_hofm3semi25_bpr_bcd_hofm3_research_validation_seed42.csv
```

Original parent weights remain unchanged. The new checkpoint stores all pairwise, cubic and B+C+D parameters in **one `weights.pt`**; inference requires the feature builder to compute the historical B+C+D inputs. This is a single neural model, not a requirement-free raw `(user, movie)` lookup.

## Scientific safeguards

- No use of validation/test interactions as preference-history features or as negative-sampling labels.
- Historical rating timestamps are rating times, **not necessarily watching times**.
- Negative examples are **unobserved**, not verified dislikes.
- 25% semi-hard negative sampling uses the second-highest model-scored item from each sampled pool to reduce false negatives. Remaining negatives use the historical semi25 trainer's popularity/uniform policy.
- Matching cutoffs, shared user cohorts and full-catalogue metrics are necessary to assess improvement; more complexity does **not** guarantee better ranking.

**Testing**: Mathematically checked third-order terms, parent-score initialization, backpropagation into old/new fields, strict historical filtering, save/reload, and a synthetic end-to-end training/evaluation run. This environment does not contain your 32M data or trained checkpoints, so measured 32M improvement remains unknown.
