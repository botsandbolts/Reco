"""Quick disk-only preflight for HOFM3 + trained semi25 JointBCD (no datasets loaded)."""
from pathlib import Path
import json
import sys

DATASET='ml-32m'
PARENT='fm_all_hofm3semi25_bpr'
PREF='fm_all_semi25_bpr_d_jointBCD'

def main():
    root=Path('models')/DATASET
    paths={
        'Trained third-order FM':root/'temporal_fm'/PARENT,
        'Trained Stage D (B+C+D)':root/'temporal_preferences'/PREF,
    }
    problems=[]
    for label,folder in paths.items():
        print(f'{label}: {folder}',flush=True)
        for name in ('weights.pt','metadata.json'):
            if not (folder/name).is_file():
                print('  MISSING',name,flush=True)
                problems.append(str(folder/name))
        if (folder/'metadata.json').is_file():
            data=json.loads((folder/'metadata.json').read_text())
            print('  dataset=',data.get('dataset'),'base=',data.get('base_model',data.get('init_from')),
                  'order=',data.get('fm_order'),'hard_share=',data.get('hard_negative_share'),flush=True)
            if label.startswith('Trained third') and (data.get('fm_order')!=3 or data.get('init_from')!='fm_all_semi25_bpr'):
                problems.append('HOFM3 must be a degree-3 model initialized from fm_all_semi25_bpr')
            if label.startswith('Trained Stage') and (data.get('stage')!='d' or data.get('base_model')!='fm_all_semi25_bpr'):
                problems.append('Stage D checkpoint must be trained from fm_all_semi25_bpr')
    if problems:
        print('\nPreflight FAILED:\n'+'\n'.join(problems),file=sys.stderr)
        raise SystemExit(1)
    print('\nPreflight passed: both pretrained components are present. Full data provenance is checked at runtime.')

if __name__=='__main__':
    main()
