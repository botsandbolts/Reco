"""Single jointly trained HOFM3 + semi-hard BPR + B/C/D temporal preferences.

Keeps the original six-field second/third-order terms and introduces the
seventh, candidate-conditioned historical-preference field. All weights train
jointly. Requires the existing HOFM3 and Temporal Preferences patches.

    python -u -m temporal_fm.unified_hofm3_bcd --help
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import re
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from .hofm3 import ThirdOrderTemporalFM
from .preference_experiment import (_load_data, _positive_training_events,
                                   _batch_preference, TemporalPreferenceFeatures)
from .preference_history import HistoryIndex
from .rank_train import (_batch_for_movies, _build_train_lookup,
                         _draw_unrated, _positive_counts)
from .ranking import _cohort, _candidates, _ranking_scores, score_candidates


class UnifiedHOFM3BCD(ThirdOrderTemporalFM):
    """Seventh historical-preference field with exact FM pair/triple interactions.

    The original six fields retain their learned pair and triple terms.
    New pairs: bcd_field * sum(original six pairwise fields).
    New triples: bcd_third * e2(original six cubic fields).
    BCD linear effects are also learned. No frozen residual scorer is used.
    """
    def __init__(self, *args, n_bcd_features: int, **kwargs):
        super().__init__(*args, **kwargs)
        if n_bcd_features < 1:
            raise ValueError('n_bcd_features must be positive')
        k = self.user.embedding_dim
        self.bcd_pair = nn.Linear(n_bcd_features, k, bias=False)
        self.bcd_triple = nn.Linear(n_bcd_features, self.third_rank, bias=False)
        self.bcd_linear = nn.Linear(n_bcd_features, 1, bias=False)
        # Exactly reproduce initial HOFM3 scores before learning the new field.
        nn.init.zeros_(self.bcd_pair.weight)
        nn.init.zeros_(self.bcd_triple.weight)
        nn.init.zeros_(self.bcd_linear.weight)

    def load_hofm3_state(self, weights):
        new_keys = {'bcd_pair.weight', 'bcd_triple.weight', 'bcd_linear.weight'}
        expected = set(self.state_dict()) - new_keys
        if set(weights) != expected:
            missing = sorted(expected - set(weights))
            unexpected = sorted(set(weights) - expected)
            raise ValueError(f'HOFM3 warm-start mismatch: missing={missing[:8]}, unexpected={unexpected[:8]}')
        result = self.load_state_dict(weights, strict=False)
        if set(result.missing_keys) != new_keys or result.unexpected_keys:
            raise ValueError('Unexpected HOFM3 load result')

    def _original_pairwise_fields(self, b):
        u = self.user(b['user']); i = self.movie(b['item'])
        content = self.ablation in ('content', 'all_no_time', 'all')
        tags = self.ablation in ('all_no_time', 'all')
        tempor = self.ablation == 'all'
        zero = torch.zeros_like(u)
        return torch.stack([
            u, i,
            self.title(b['title']) if content else zero,
            self.genre(b['genres']) if content else zero,
            self.tags(b['tags']) if tags else zero,
            (self.calendar(b['calendar']) + self.time_cont(b['time'])) if tempor else zero,
        ], dim=1)

    def forward(self, batch, bcd):
        if bcd.ndim != 2 or bcd.shape[0] != batch['user'].shape[0] or bcd.shape[1] != self.bcd_pair.in_features:
            raise ValueError('BCD feature shape mismatch')
        base = super().forward(batch)
        pair = self.bcd_pair(bcd)
        pair_cross = (pair * self._original_pairwise_fields(batch).sum(dim=1)).sum(dim=-1)
        original_triples = self.third_fields(batch)
        s1 = original_triples.sum(dim=1)
        e2 = (s1.square() - original_triples.square().sum(dim=1)) / 2.
        triple_cross = self.third_scale * (self.bcd_triple(bcd) * e2).sum(dim=-1)
        return base + self.bcd_linear(bcd).flatten() + pair_cross + triple_cross


def _parent_info(dataset, parent, ev, provider):
    folder = Path('models') / dataset / 'temporal_fm' / parent
    mp, wp = folder / 'metadata.json', folder / 'weights.pt'
    if not mp.is_file() or not wp.is_file():
        raise FileNotFoundError(f'Missing trained HOFM3 parent: {mp} and {wp}')
    metadata = json.loads(mp.read_text(encoding='utf-8'))
    checks = {
        'dataset': dataset,
        'fm_order': 3,
        'kind': 'fm',
        'ablation': 'all',
        'train_cutoff': ev.meta['train_cutoff'],
        'validation_cutoff': ev.meta['val_cutoff'],
        'text_backend': provider.backend,
        'text_model': provider.model_name,
        'tag_dims': provider.tags.tag_dims,
    }
    for key, expected in checks.items():
        if metadata.get(key) != expected:
            raise ValueError(f'Parent checkpoint mismatch {key}: {metadata.get(key)!r} != {expected!r}')
    if metadata.get('sources') != ev.meta['sources']:
        raise ValueError('Parent checkpoint dataset source signatures differ')
    if not metadata.get('init_from'):
        raise ValueError('Parent HOFM3 metadata has no recorded FM initialization; cannot verify lineage')
    if float(metadata.get('hard_negative_share', -1)) != .25:
        raise ValueError('Parent HOFM3 was not recorded as trained with 25% semi-hard negatives')
    return metadata, wp



def _load_preference_head(dataset, ev, provider, builder, preference_checkpoint, expected_base, device):
    """Extract already-trained Stage D linear weights; check history/data provenance.

    Pretrained Stage D was an additive BPR correction to semi25. Here its
    weights become the seventh field's linear term. The old HOFM3 factors and
    new pair/triple interactions are subsequently optimized jointly.
    """
    if preference_checkpoint == 'none':
        return None, None
    folder = (Path('models') / dataset / 'temporal_preferences' /
              f'{expected_base}_d_jointBCD' if preference_checkpoint == 'auto'
              else Path(preference_checkpoint))
    mp, wp = folder / 'metadata.json', folder / 'weights.pt'
    if not mp.is_file() or not wp.is_file():
        raise FileNotFoundError(
            f'Missing trained jointBCD at {folder}. Train Stage D first, '
            'or explicitly use --preference-checkpoint none for a from-scratch ablation.')
    meta=json.loads(mp.read_text(encoding='utf-8'))
    checks={'dataset':dataset, 'sources':ev.meta['sources'],
            'train_cutoff':ev.meta['train_cutoff'],
            'validation_cutoff':ev.meta['val_cutoff'],
            'backend':provider.backend, 'text_model':provider.model_name,
            'tag_dims':provider.tags.tag_dims, 'base_model':expected_base,
            'stage':'d', 'feature_names':builder.names}
    for key, val in checks.items():
        if meta.get(key) != val:
            raise ValueError(f'jointBCD checkpoint mismatch for {key}')
    state=torch.load(wp,map_location=device,weights_only=True)
    if set(state) != {'linear.weight'}:
        raise ValueError('Stage D checkpoint must contain only the trained linear.weight')
    if state['linear.weight'].shape != (1,len(builder.names)):
        raise ValueError('jointBCD feature weights shape mismatch')
    return state['linear.weight'], str(wp)


def _make_model(ev, provider, parent_meta, n_bcd, device):
    model = UnifiedHOFM3BCD(
        len(ev.train_users), len(ev.movies), provider.title.shape[1],
        len(ev.genres), provider.tags.tag_dims,
        k=int(parent_meta['k']), deep=False, mean_rating=0., ablation='all',
        third_rank=int(parent_meta['third_rank']),
        third_scale=float(parent_meta['third_scale']), n_bcd_features=n_bcd,
    ).to(device)
    return model


def _compute_features(builder, raw_users, times, movies, device):
    return _batch_preference(builder, raw_users, times, movies, device)


def score_items(model, ev, provider, builder, raw_user, at_time, movie_indices,
                device='cpu', chunk_size=1024):
    mids = np.asarray(movie_indices, dtype=np.int32)
    result = []
    if not len(mids):
        return np.empty(0, dtype=np.float32)
    ctx = builder.context(int(raw_user), int(at_time))
    u_index = int(ev.user_indices(np.array([raw_user], dtype=np.int32))[0])
    if not u_index:
        raise ValueError(f'Unknown training user {raw_user}')
    was_training = model.training
    model.eval()
    try:
        with torch.inference_mode():
            for start in range(0, len(mids), chunk_size):
                chunk = mids[start:start+chunk_size]
                u = np.full(len(chunk), u_index, dtype=np.int64)
                t = np.full(len(chunk), int(at_time), dtype=np.int64)
                b = _batch_for_movies(ev, provider, u, chunk, t, device)
                f = torch.as_tensor(builder.matrix(raw_user, at_time, chunk, ctx),
                                    device=device, dtype=torch.float32)
                scores = model(b, f).cpu().numpy()
                if not np.isfinite(scores).all():
                    raise ValueError('Non-finite integrated FM scores')
                result.append(scores)
    finally:
        model.train(was_training)
    return np.concatenate(result)


def draw_mixed_negatives(model, ev, provider, builder, rng, users_index, raw_users,
                         times, known, catalog, bank, n_negatives, device,
                         hard_share=.25, hard_pool=8, pop_share=.6):
    """Full TRAIN-known exclusion; 25% semi-hard mining by current unified model.

    This is deliberately aligned with the original semi25 negative policy:
    TRAIN-known movies are excluded, as are future-release movies. This can
    exclude ratings entered later within TRAIN, but never reads val/test labels.
    """
    ui = np.repeat(np.asarray(users_index, dtype=np.int64), n_negatives)
    raw = np.repeat(np.asarray(raw_users, dtype=np.int32), n_negatives)
    tt = np.repeat(np.asarray(times, dtype=np.int64), n_negatives)
    out = _draw_unrated(rng, ui, known, catalog, len(ev.movies), bank,
                        ev.release_year, tt, pop_share)
    selected = np.flatnonzero(rng.random(len(out)) < hard_share)
    if not len(selected):
        return ui, raw, tt, out
    choice = np.empty((len(selected), hard_pool), dtype=np.int32)
    choice[:, 0] = out[selected]
    for j in range(1, hard_pool):
        choice[:, j] = _draw_unrated(rng, ui[selected], known, catalog,
                                    len(ev.movies), bank, ev.release_year,
                                    tt[selected], pop_share)
    flat_u = np.repeat(ui[selected], hard_pool)
    flat_raw = np.repeat(raw[selected], hard_pool)
    flat_t = np.repeat(tt[selected], hard_pool)
    flat_m = choice.ravel()
    values = np.empty(len(flat_m), dtype=np.float32)
    was_training = model.training
    model.eval()
    try:
        with torch.inference_mode():
            for a in range(0, len(values), 1024):
                b = min(len(values), a+1024)
                inp = _batch_for_movies(ev, provider, flat_u[a:b], flat_m[a:b], flat_t[a:b], device)
                feat = _compute_features(builder, flat_raw[a:b], flat_t[a:b], flat_m[a:b], device)
                values[a:b] = model(inp, feat).detach().cpu().numpy()
    finally:
        model.train(was_training)
    scores = values.reshape(len(selected), hard_pool)
    if not np.isfinite(scores).all():
        raise ValueError('Non-finite mining scores')
    # Second-highest: semi-hard rather than maximum-loss, to reduce false negatives.
    pick = np.argsort(-scores, axis=1, kind='stable')[:, 1]
    out[selected] = choice[np.arange(len(selected)), pick]
    return ui, raw, tt, out


def evaluate(model, ev, provider, builder, users=100, seed=42, threshold=4., k=10,
             split='validation', max_candidates=0, device='cpu', progress_every=25,
             original_parent=None):
    active, histories, truth, pop, cohort = _cohort(ev, split, threshold, users, 3, seed)
    catalog = np.flatnonzero(ev.movie_has_train).astype(np.int32)
    when = int(ev.meta['train_cutoff'])+1
    rng = np.random.default_rng(seed+221)
    names = ['popularity', 'unified_hofm3_bcd']
    if original_parent is not None:
        names.insert(1, 'original_hofm3')
    rows = {name: [] for name in names}
    coverage = {name: set() for name in rows}
    examples = {}
    for j, u in enumerate(active):
        cand = _candidates(catalog, histories[u], truth[u], max_candidates, rng)
        ranked = {'popularity': np.log1p(pop[cand]),
                  'unified_hofm3_bcd': score_items(model, ev, provider, builder, u, when, cand, device)}
        if original_parent is not None:
            ranked['original_hofm3'] = score_candidates(original_parent, ev, provider, u, cand, when, device)
        for name, scores in ranked.items():
            top = cand[np.argsort(-scores, kind='stable')[:k]]
            row = _ranking_scores(top, truth[u], k, ev.genre_matrix, pop, len(ev.split('train')))
            rows[name].append(row)
            coverage[name].update(map(int, top))
            if j < 3 and name == 'unified_hofm3_bcd':
                examples[str(u)] = [{'movieId': int(ev.movies.iloc[int(m)].movieId),
                                    'title': str(ev.movies.iloc[int(m)].title)} for m in top]
        if progress_every and ((j+1)%progress_every == 0 or j+1 == len(active)):
            print(f'EVALUATION {split}: users {j+1}/{len(active)}', flush=True)
    avg = {}
    for name, rr in rows.items():
        avg[name] = {key: round(float(np.mean([r[key] for r in rr])), 6)
                     for key in ('ndcg_at_k', 'recall_at_k', 'hit_rate_at_k', 'precision_at_k', 'mrr_at_k')}
        avg[name]['users'] = len(rr)
        avg[name]['catalog_coverage_at_k'] = round(len(coverage[name])/max(1,len(catalog)),6)
    return {'metrics':avg, 'dataset':ev.meta['dataset'], 'split':split, 'cohort':cohort,
            'evaluated_user_ids':list(map(int,active)), 'examples':examples,
            'candidate_policy':'full_warm_catalog' if not max_candidates else 'sampled_not_comparable',
            'train_cutoff':ev.meta['train_cutoff'],'k':k,'seed':seed,
            'caveats': ['Training ratings are not exposure data; unrated does not imply disliked.',
                        'All historical features use strictly earlier TRAIN events.',
                        'The recommendation candidate catalogue contains only movies with TRAIN history.',
                        'Sampled-candidate ranking metrics are not full-catalogue ranking metrics.']}


def run(dataset='ml-32m', data_dir='data', backend='sentence',
        init_from='fm_all_hofm3semi25_bpr', run_label='unifiedBCD',
        preference_checkpoint='auto',
        epochs=12, steps_per_epoch=600, batch_size=128, negatives=2,
        hard_negative_share=.25, hard_pool=8, pop_negative_share=.6,
        learning_rate=.00008, new_feature_lr=.0005, weight_decay=.01,
        third_l2=.0001, seed=42, threshold=4., device='cpu', threads=4,
        validation_users=100, validate_every=2, min_epochs=6, patience=3,
        progress_every=50, k=10, max_candidates=0, split='validation',
        evaluate_only=False, force_retrain=False):
    if not re.fullmatch(r'[A-Za-z0-9_]+', run_label):
        raise ValueError('Use an alphanumeric run label')
    if not (0 <= hard_negative_share <= 1) or hard_pool < 2 or negatives < 1:
        raise ValueError('Invalid negative sampling parameters')
    if min_epochs < 1 or not (min_epochs <= epochs) or validate_every < 1 or patience < 1 or threads < 1 or batch_size < 1 or steps_per_epoch < 1 or validation_users < 1 or k < 1 or max_candidates < 0:
        raise ValueError('Invalid epoch/validation settings')
    if any(v < 0 or not math.isfinite(v) for v in (third_l2, weight_decay)):
        raise ValueError('Invalid regularization')
    if learning_rate <= 0 or new_feature_lr <= 0 or not (0 <= pop_negative_share <= 1):
        raise ValueError('Learning rates must be positive')
    if split == 'test' and not evaluate_only:
        raise ValueError('Test split requires --evaluate-only after model selection')
    if device == 'cuda' and not torch.cuda.is_available():
        raise ValueError('CUDA requested but unavailable')
    torch.set_num_threads(max(1, threads))
    torch.manual_seed(seed)
    np.random.seed(seed)
    ev, provider = _load_data(dataset, data_dir, backend)
    parent_meta, parent_weights = _parent_info(dataset, init_from, ev, provider)
    history = HistoryIndex(ev)
    builder = TemporalPreferenceFeatures(ev, provider, history, 'd')
    model = _make_model(ev, provider, parent_meta, len(builder.names), device)
    pref_base = parent_meta['init_from']
    preference_weights, preference_path = _load_preference_head(
        dataset, ev, provider, builder, preference_checkpoint, pref_base, device)
    original_parent = ThirdOrderTemporalFM(
        len(ev.train_users), len(ev.movies), provider.title.shape[1],
        len(ev.genres), provider.tags.tag_dims,
        k=int(parent_meta['k']), deep=False, mean_rating=0., ablation='all',
        third_rank=int(parent_meta['third_rank']), third_scale=float(parent_meta['third_scale'])
    ).to(device)
    original_parent.load_state_dict(torch.load(parent_weights, map_location=device, weights_only=True))
    original_parent.eval()
    for param in original_parent.parameters():
        param.requires_grad_(False)
    outfile = Path('models') / dataset / 'unified_hofm3_bcd' / f'{init_from}_{run_label}'
    weight_path = outfile/'weights.pt'
    meta_path = outfile/'metadata.json'
    outfile.mkdir(parents=True, exist_ok=True)
    expected = {'dataset':dataset, 'sources':ev.meta['sources'],
                'train_cutoff':ev.meta['train_cutoff'], 'validation_cutoff':ev.meta['val_cutoff'],
                'backend':backend,'text_model':provider.model_name, 'tag_dims':provider.tags.tag_dims,
                'parent_model':init_from, 'parent_init_from':parent_meta.get('init_from'),
                'parent_hard_negative_share':parent_meta.get('hard_negative_share'),
                'fm_order':3,'stage':'d','feature_names':builder.names,
                'pair_rank':int(parent_meta['k']), 'third_rank':int(parent_meta['third_rank']),
                'third_scale':float(parent_meta['third_scale']), 'seed':seed,
                'pretrained_preference_checkpoint':preference_path}
    if weight_path.exists() and not force_retrain:
        actual = json.loads(meta_path.read_text()) if meta_path.exists() else None
        if actual != expected:
            raise ValueError('Existing combined checkpoint has incompatible metadata; use a fresh --run-label')
        model.load_state_dict(torch.load(weight_path, map_location=device, weights_only=True))
        print('Loaded existing unified checkpoint:', weight_path, flush=True)
    elif evaluate_only:
        raise FileNotFoundError(f'No trained unified checkpoint at {weight_path}')
    else:
        orig = torch.load(parent_weights, map_location=device, weights_only=True)
        model.load_hofm3_state(orig)
        if preference_weights is not None:
            with torch.no_grad():
                model.bcd_linear.weight.copy_(preference_weights)
            print(f'Initialized JointBCD historical-feature weights from {preference_path}',flush=True)
        assert all(param.requires_grad for param in model.parameters())
        print(f'Initialized entire unified FM from {parent_weights}. All factors trainable.',flush=True)
        new_params = list(model.bcd_pair.parameters()) + list(model.bcd_triple.parameters()) + list(model.bcd_linear.parameters())
        new_ids = {id(p) for p in new_params}
        old_params = [p for p in model.parameters() if id(p) not in new_ids]
        optim = torch.optim.AdamW([
            {'params': old_params, 'lr':learning_rate},
            {'params': new_params, 'lr':new_feature_lr},
        ],weight_decay=weight_decay)
        known, positives = _build_train_lookup(ev,threshold)
        catalog = np.flatnonzero(ev.movie_has_train).astype(np.int32)
        counts = _positive_counts(ev,threshold)
        probs=(counts[catalog].astype(np.float64)+1)**.75
        probs/=probs.sum()
        rng=np.random.default_rng(seed)
        bank=rng.choice(catalog,size=200_000,replace=True,p=probs).astype(np.int32)
        best=-float('inf'); no_improve=0; hist=[]
        print(f'TRAIN {len(positives):,} positives, {epochs} epochs * {steps_per_epoch} steps '
              f'* {batch_size} pairs, hard share={hard_negative_share:.0%}; threads={threads}',flush=True)
        for epoch in range(1,epochs+1):
            model.train(); start=time.perf_counter(); losses=[]
            for step in range(1,steps_per_epoch+1):
                event_ids=np.asarray(positives[rng.integers(len(positives),size=batch_size)],dtype=np.int64)
                ui=ev.user_indices(np.asarray(ev.user_raw[event_ids],dtype=np.int32))
                raw=np.asarray(ev.user_raw[event_ids],dtype=np.int32)
                pos=np.asarray(ev.movie_idx[event_ids],dtype=np.int32)
                timestamps=np.asarray(ev.timestamp[event_ids],dtype=np.int64)
                nu, nraw, nt, nm = draw_mixed_negatives(
                    model,ev,provider,builder,rng,ui,raw,timestamps,known,catalog,bank,
                    negatives,device,hard_negative_share,hard_pool,pop_negative_share)
                bpos=_batch_for_movies(ev,provider,ui,pos,timestamps,device)
                bneg=_batch_for_movies(ev,provider,nu,nm,nt,device)
                fpos=_compute_features(builder,raw,timestamps,pos,device)
                fneg=_compute_features(builder,nraw,nt,nm,device)
                p=model(bpos,fpos)
                n=model(bneg,fneg).reshape(len(pos),negatives)
                rank_loss=F.softplus(n-p[:,None]).mean()
                reg=model.third_regularization(bpos,bneg,third_l2)
                loss=rank_loss+reg
                if not torch.isfinite(loss):
                    raise FloatingPointError(f'Nonfinite loss epoch {epoch} step {step}')
                optim.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(),max_norm=1.)
                optim.step()
                losses.append(float(rank_loss.detach()))
                if progress_every and (step%progress_every==0 or step==steps_per_epoch):
                    print(f'EPOCH {epoch}/{epochs} STEP {step}/{steps_per_epoch} '
                          f'BPR={np.mean(losses):.5f} elapsed={time.perf_counter()-start:.0f}s',flush=True)
            row={'epoch':epoch,'bpr_loss':round(float(np.mean(losses)),6),
                 'epoch_seconds':round(time.perf_counter()-start,2)}
            if epoch%validate_every==0 or epoch==epochs:
                print(f'EPOCH {epoch}: validating {validation_users} users full catalogue '
                      f'if --max-candidates=0...',flush=True)
                result=evaluate(model,ev,provider,builder,validation_users,seed,threshold,k,
                                'validation',max_candidates,device, original_parent=original_parent)
                val=result['metrics']['unified_hofm3_bcd']['ndcg_at_k']
                row['validation_ndcg_at_k']=val
                if val>best:
                    best=val;no_improve=0
                    torch.save(model.state_dict(),weight_path)
                    meta_path.write_text(json.dumps(expected,indent=2),encoding='utf-8')
                else:
                    no_improve+=1
            hist.append(row)
            (outfile/'history.json').write_text(json.dumps(hist,indent=2),encoding='utf-8')
            print(f'EPOCH {epoch}/{epochs} DONE loss={row["bpr_loss"]:.5f} '
                  f'NDCG@{k}={row.get("validation_ndcg_at_k", "not evaluated")} '
                  f'best={best:.6f}',flush=True)
            if epoch>=min_epochs and no_improve>=patience:
                print('Early stopping on validation.',flush=True)
                break
        model.load_state_dict(torch.load(weight_path,map_location=device,weights_only=True))
    result=evaluate(model,ev,provider,builder,validation_users,seed,threshold,k,split,
                    max_candidates,device, original_parent=original_parent)
    result.update({'model':'UnifiedHOFM3BCD', 'checkpoint':str(weight_path),
                   'parent_checkpoint':str(parent_weights),
                   'preference_checkpoint':preference_path,
                   'architecture':'Single jointly trainable seven-field HOFM3: original six fields + '
                                  'B/C/D preference field; BPR with semi-hard mining.',
                   'hard_negative_share':hard_negative_share,
                   'training_uses_test_labels':False})
    destination=Path('reports')/'temporal'/dataset/'unified_hofm3_bcd'
    destination.mkdir(parents=True,exist_ok=True)
    output=destination/f'{init_from}_{run_label}_{split}_seed{seed}.json'
    output.write_text(json.dumps(result,indent=2),encoding='utf-8')
    with output.with_suffix('.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['model','ndcg_at_k','recall_at_k','hit_rate_at_k','precision_at_k','mrr_at_k'])
        for key,metrics in result['metrics'].items():
            writer.writerow([key]+[metrics[name] for name in ('ndcg_at_k','recall_at_k','hit_rate_at_k','precision_at_k','mrr_at_k')])
    print('Saved report:',output,flush=True)
    return result


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset',default='ml-32m')
    p.add_argument('--data-dir',default='data')
    p.add_argument('--backend',default='sentence')
    p.add_argument('--init-from',default='fm_all_hofm3semi25_bpr')
    p.add_argument('--preference-checkpoint',default='auto',
                   help='auto=trained semi25 Stage D jointBCD; none=ablation; or give model folder')
    p.add_argument('--run-label',default='unifiedBCD')
    p.add_argument('--epochs',type=int,default=12)
    p.add_argument('--steps-per-epoch',type=int,default=600)
    p.add_argument('--batch-size',type=int,default=128)
    p.add_argument('--negatives',type=int,default=2)
    p.add_argument('--hard-negative-share',type=float,default=.25)
    p.add_argument('--hard-pool',type=int,default=8)
    p.add_argument('--pop-negative-share',type=float,default=.6)
    p.add_argument('--learning-rate',type=float,default=.00008)
    p.add_argument('--new-feature-lr',type=float,default=.0005)
    p.add_argument('--weight-decay',type=float,default=.01)
    p.add_argument('--third-l2',type=float,default=.0001)
    p.add_argument('--seed',type=int,default=42)
    p.add_argument('--threshold',type=float,default=4.)
    p.add_argument('--device',choices=['cpu','cuda'],default='cpu')
    p.add_argument('--threads',type=int,default=4)
    p.add_argument('--validation-users',type=int,default=100)
    p.add_argument('--validate-every',type=int,default=2)
    p.add_argument('--min-epochs',type=int,default=6)
    p.add_argument('--patience',type=int,default=3)
    p.add_argument('--progress-every',type=int,default=50)
    p.add_argument('--k',type=int,default=10)
    p.add_argument('--max-candidates',type=int,default=0)
    p.add_argument('--split',choices=['validation','test'],default='validation')
    p.add_argument('--evaluate-only',action='store_true')
    p.add_argument('--force-retrain',action='store_true')
    args=vars(p.parse_args(argv))
    return run(**args)


if __name__=='__main__':
    main()
