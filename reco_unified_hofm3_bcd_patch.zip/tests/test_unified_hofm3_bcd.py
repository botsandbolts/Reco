"""Offline mathematical, optimization, compatibility and checkpoint tests."""
import json
import numpy as np
import pytest
import torch

from temporal_fm.hofm3 import ThirdOrderTemporalFM
from temporal_fm.unified_hofm3_bcd import UnifiedHOFM3BCD, score_items


def _batch(n=6, k=3):
    rng=np.random.default_rng(12)
    return {'user':torch.tensor([1,2,3,1,2,3][:n]),
            'item':torch.tensor([1,2,3,4,5,6][:n]),
            'title':torch.tensor(rng.normal(size=(n,5)),dtype=torch.float32),
            'genres':torch.tensor(rng.random((n,3)),dtype=torch.float32),
            'tags':torch.tensor(rng.normal(size=(n,4)),dtype=torch.float32),
            'calendar':torch.tensor([1,2,3,4,5,6][:n]),
            'time':torch.tensor(rng.random((n,4)),dtype=torch.float32)}


def _models():
    old=ThirdOrderTemporalFM(8,10,5,3,4,k=5,deep=False,ablation='all',mean_rating=0.,third_rank=6)
    new=UnifiedHOFM3BCD(8,10,5,3,4,k=5,deep=False,ablation='all',mean_rating=0.,third_rank=6,n_bcd_features=15)
    new.load_hofm3_state(old.state_dict())
    return old,new


def test_exact_parent_scores_at_initialization():
    old,new=_models()
    b=_batch();feat=torch.randn(6,15)
    assert torch.allclose(old(b),new(b,feat),rtol=1e-6,atol=1e-6)


def test_gradients_update_old_and_temporal_fields():
    _,m=_models();b=_batch();feat=torch.randn(6,15)
    result=m(b,feat)
    loss=torch.nn.functional.softplus(result[3:]-result[:3]).mean()
    loss.backward()
    assert m.movie.weight.grad.abs().sum()>0
    assert m.third_movie.weight.grad.abs().sum()>0
    assert m.bcd_pair.weight.grad.abs().sum()>0
    assert m.bcd_triple.weight.grad.abs().sum()>0
    assert m.bcd_linear.weight.grad.abs().sum()>0
    opt=torch.optim.Adam(m.parameters(),lr=1e-3)
    before=m.bcd_pair.weight.detach().clone()
    opt.step()
    assert not torch.equal(before,m.bcd_pair.weight.detach())


def test_uses_distinct_three_way_interactions():
    _,m=_models();b=_batch();feat=torch.randn(6,15)
    with torch.no_grad():
        m.bcd_triple.weight.normal_(0,.03)
        got=m(b,feat)-ThirdOrderTemporalFM.forward(m,b)-m.bcd_linear(feat).flatten()-\
            (m.bcd_pair(feat)*m._original_pairwise_fields(b).sum(dim=1)).sum(-1)
        original=m.third_fields(b)
        new=m.bcd_triple(feat)
        slow=0
        for i in range(6):
            for j in range(i+1,6):
                slow=slow+(new*original[:,i,:]*original[:,j,:]).sum(-1)
        assert torch.allclose(got,slow*m.third_scale,atol=1e-5,rtol=1e-4)


def test_rejects_wrong_shape_and_wrong_checkpoint():
    _,m=_models();b=_batch()
    with pytest.raises(ValueError,match='BCD feature shape'):
        m(b,torch.randn(6,7))
    with pytest.raises(ValueError,match='warm-start mismatch'):
        m.load_hofm3_state({'bad':torch.tensor(1)})


def test_save_load_and_parent_independence(tmp_path):
    p,new=_models()
    parent=tmp_path/'parent.pt';child=tmp_path/'child.pt'
    torch.save(p.state_dict(),parent)
    torch.save(new.state_dict(),child)
    fresh=UnifiedHOFM3BCD(8,10,5,3,4,k=5,deep=False,ablation='all',mean_rating=0.,third_rank=6,n_bcd_features=15)
    fresh.load_state_dict(torch.load(child,weights_only=True))
    b=_batch();feat=torch.randn(6,15)
    assert torch.allclose(fresh(b,feat),new(b,feat))
    assert all(torch.equal(v,torch.load(parent,weights_only=True)[k]) for k,v in p.state_dict().items())


def test_no_future_context(monkeypatch):
    from temporal_fm.preference_history import HistoryIndex
    class Fake:
        unique=np.array([11]);starts=np.array([0]);counts=np.array([3])
        user=np.array([11]*3);ts=np.array([10,20,30]);event=np.array([0,1,2])
        class events:
            rating=np.array([5.,5.,5.])
    h=Fake()
    assert HistoryIndex.before(h,11,20).tolist()==[0]
    assert HistoryIndex.before(h,11,31).tolist()==[0,1,2]
    assert HistoryIndex.before(h,11,10).tolist()==[]


def test_d_feature_count():
    from temporal_fm.preference_experiment import _names
    n=_names('d')
    assert len(n)==15
    assert any('genre' in s for s in n)
    assert any('tags' in s for s in n)
    assert any('decay' in s for s in n)
