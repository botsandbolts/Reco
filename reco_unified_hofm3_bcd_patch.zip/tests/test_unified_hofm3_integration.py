"""Synthetic end-to-end train/eval smoke test; no MovieLens download."""
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
import torch

from temporal_fm.data import prepare, Events
from temporal_fm.features import titles, make_tag_history
from temporal_fm.train import FeatureProvider
from temporal_fm.hofm3 import ThirdOrderTemporalFM
from temporal_fm.unified_hofm3_bcd import run


@pytest.fixture
def ready(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    folder=Path('data/raw/ml-tiny');folder.mkdir(parents=True)
    pd.DataFrame({'movieId':range(1,41),
        'title':[f'Title {i} (2000)' for i in range(1,41)],
        'genres':['Comedy|Drama' if i%3 else 'Action|Sci-Fi' for i in range(1,41)]}
        ).to_csv(folder/'movies.csv',index=False)
    rows=[];tags=[]
    for user in range(1,11):
        for t in range(35):
            movie=(user*9+t*13)%40+1
            when=1600000000+t*86400+user*60
            rows.append((user,movie,5 if t%7 else 2,when))
            tags.append((user,movie,'family' if movie%2 else 'action',when-1800))
    pd.DataFrame(rows,columns=['userId','movieId','rating','timestamp']).to_csv(folder/'ratings.csv',index=False)
    pd.DataFrame(tags,columns=['userId','movieId','tag','timestamp']).to_csv(folder/'tags.csv',index=False)
    path=prepare('ml-tiny',sample_size=1000)
    ev=Events(path); titles(ev,backend='hash')
    tdir=make_tag_history(ev,ev.meta['tags_path'],'hash',tag_dims=8,max_tag_vocab=50)
    provider=FeatureProvider(ev,'hash','sentence-transformers/all-MiniLM-L6-v2',tdir)
    provider.model_name='sentence-transformers/all-MiniLM-L6-v2';provider.backend='hash'
    parent='fm_all_hofm3semi25_bpr'
    dst=Path('models/ml-tiny/temporal_fm')/parent;dst.mkdir(parents=True)
    m=ThirdOrderTemporalFM(len(ev.train_users),len(ev.movies),provider.title.shape[1],
                           len(ev.genres),provider.tags.tag_dims,k=8,third_rank=8,
                           ablation='all',mean_rating=0.)
    torch.save(m.state_dict(),dst/'weights.pt')
    data={'name':parent,'dataset':'ml-tiny','sources':ev.meta['sources'],
          'fm_order':3,'kind':'fm','ablation':'all',
          'train_cutoff':ev.meta['train_cutoff'],
          'validation_cutoff':ev.meta['val_cutoff'],
          'text_backend':'hash','text_model':provider.model_name,
          'tag_dims':provider.tags.tag_dims,'k':8,'third_rank':8,
          'third_scale':1.,'hard_negative_share':.25,
          'init_from':'fm_all_semi25_bpr'}
    (dst/'metadata.json').write_text(json.dumps(data))
    # Previously trained Stage D preference head (the third pretrained component).
    pdst=Path('models/ml-tiny/temporal_preferences/fm_all_semi25_bpr_d_jointBCD')
    pdst.mkdir(parents=True)
    from temporal_fm.preference_experiment import _names
    feat_names=_names('d')
    preference_metadata={'dataset':'ml-tiny','sources':ev.meta['sources'],
        'train_cutoff':ev.meta['train_cutoff'],'validation_cutoff':ev.meta['val_cutoff'],
        'backend':'hash','text_model':provider.model_name,
        'tag_dims':provider.tags.tag_dims,'base_model':'fm_all_semi25_bpr',
        'stage':'d','feature_names':feat_names}
    (pdst/'metadata.json').write_text(json.dumps(preference_metadata))
    pref=torch.nn.Linear(15,1,bias=False)
    with torch.no_grad(): pref.weight.fill_(.002)
    torch.save({'linear.weight':pref.weight.detach().clone()},pdst/'weights.pt')
    return dst


def test_train_reload_evaluate_preserves_parent(ready):
    path=ready/'weights.pt'
    orig=hashlib.sha256(path.read_bytes()).hexdigest()
    kwargs=dict(dataset='ml-tiny',backend='hash',init_from='fm_all_hofm3semi25_bpr',
                epochs=1,min_epochs=1,steps_per_epoch=2,batch_size=4,
                negatives=2,hard_negative_share=.25,hard_pool=3,
                validation_users=3,validate_every=1,device='cpu',
                threads=2,force_retrain=True)
    result=run(**kwargs)
    assert set(result['metrics'])=={'popularity','original_hofm3','unified_hofm3_bcd'}
    for row in result['metrics'].values():
        assert 0 <= row['ndcg_at_k'] <=1
        assert row['users']>=1
    assert result['candidate_policy']=='full_warm_catalog'
    assert hashlib.sha256(path.read_bytes()).hexdigest()==orig
    loaded=run(dataset='ml-tiny',backend='hash',init_from='fm_all_hofm3semi25_bpr',
               validation_users=3,evaluate_only=True,threads=2)
    assert loaded['metrics']==result['metrics']
    assert (Path('models/ml-tiny/unified_hofm3_bcd/fm_all_hofm3semi25_bpr_unifiedBCD')/'history.json').exists()
