# Train Temporal FM seriously on MovieLens 32M

This patch upgrades `temporal_fm.rank_train` from the earlier pairwise FM patch. It is a **drop-in replacement for `temporal_fm/rank_train.py`** and one new automated regression test; it does not replace data, the Streamlit app, the previous FM checkpoints, or the shared evaluation pipeline.

## What was wrong with the earlier run?

- `--profile research`: **450 steps × 256 positives/step**; epoch 6 represents **691,200 positive draws**. Draws were sampled **with replacement**, meaning many could be duplicates. This was not a pass across the 32M rating dataset.
- An early-stopping patience of four evaluated epochs stopped the run after the sampled validation metric stopped improving. That is why training ended at epoch 6 even though the preset had 15 epochs.
- Sampled validation NDCG@10 on only **32 users with 512 candidates each** is significantly easier than full-catalogue ranking. The screenshot's ~0.64 sampled NDCG cannot be compared with full-catalogue ~0.074 NDCG.
- Your **full-catalogue** results show BPR-FM Recall@10 ~0.0359 vs popularity ~0.0181, and Hit Rate ~0.5167 vs ~0.3333, despite nearly identical NDCG (~0.0736 vs ~0.0745). The model is learning some ranking signal; which metric matters depends on the use case.

## Install safely in Codespaces

Upload `fm_serious_training_patch.zip` to the **main branch** of `herberton777/Reco` using GitHub's web interface, then run:

```bash
cd /workspaces/Reco
git fetch origin main
git show origin/main:fm_serious_training_patch.zip > fm_serious_training_patch.zip
unzip -l fm_serious_training_patch.zip
# Preserve a copy of the previously installed rank trainer
cp temporal_fm/rank_train.py temporal_fm/rank_train.before_serious.py
unzip -o fm_serious_training_patch.zip
python -m pytest -q tests/test_serious_pairwise_fm.py
python -m temporal_fm.rank_train --help
```

This assumes the previous Temporal FM, pairwise ranking and shared benchmarking patches are already installed. Only two Python files are added/updated, plus this guide.

## Recommended full-catalogue validation + longer training (CPU)

The current trained checkpoint is `fm_all_bpr`, with 32 latent dimensions (research profile). This command **starts from those learned weights**, trains much longer, and saves to **`fm_all_strong_bpr`**. It does not modify `fm_all_bpr`.

```bash
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 \
python -u -m temporal_fm.rank_train \
  --dataset ml-32m \
  --text-backend sentence \
  --models fm --ablation all --profile research \
  --run-label strong --init-from fm_all_bpr \
  --epochs 20 --min-epochs 12 \
  --steps-per-epoch 1600 --batch-size 256 \
  --lr 0.0003 --patience 6 \
  --positive-sampling permuted \
  --validation-mode full --validation-users 20 \
  --validate-every 2 \
  --negatives 2 --pop-negative-share 0.6 \
  --device cpu --threads 2
```

- At least **4,915,200** positive examples (12 × 1600 × 256); up to **8,192,000** (20 × 1600 × 256). Each also has two sampled negatives.
- The sampler visits different training positives **without replacement** until the whole positive set has been visited, and only then repeats. It uses a constant-memory affine permutation rather than loading/shuffling millions of indices. Thus training covers positives much more thoroughly than the original replacement sampling.
- Validation evaluates the **entire warm catalogue per selected user**, not 512 sampled items. This is significantly more CPU-intensive, so the command uses only 20 validation users every second epoch.
- `--min-epochs 12` prevents early stopping before epoch 12. The best validation checkpoint is saved; the last epoch is not necessarily the best. Early stopping still applies after the minimum.
- This is **not guaranteed to pass over every 32M rating**; the BPR dataset includes only TRAIN ratings >= 4 stars, and sampled training runs stop after the configured budget. To traverse all positive training examples, see below.
- Fine-tuning with `--init-from` reuses model weights but resets the optimizer; it is not bit-for-bit resumption of the old run.
- If you changed the source data or text embedding model, or retrained the old checkpoint with a different latent dimension, the compatibility check will refuse to initialize it. Remove `--init-from fm_all_bpr` to train a fresh `strong` model, preserving the old model.

## Genuine full-pass training

If the goal is **literally visiting every observed positive training event once per epoch** (rather than drawing a fixed small sample), use `--full-pass-epochs`. This computes the required steps from the actual number of TRAIN ratings >= 4, visits each of those positive events once without replacement, and samples two unseen negatives per event.

```bash
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 \
python -u -m temporal_fm.rank_train \
  --dataset ml-32m --text-backend sentence \
  --models fm --ablation all --profile research \
  --run-label fullpass --init-from fm_all_bpr \
  --full-pass-epochs --positive-sampling permuted \
  --epochs 2 --min-epochs 2 --batch-size 256 \
  --validation-mode full --validation-users 20 --validate-every 1 \
  --device cpu --threads 2
```

**CAUTION:** Unlike the budgeted run, every positive training event is seen in each epoch; on a ~32M event dataset, this can take substantial CPU time. It trains only on positive ratings >= 4 (not all star-rated examples), because it is a BPR objective. Two full passes over all positives can involve tens of thousands of optimizer steps. A GPU-enabled runtime would be preferable if available.

## Compare the models fairly

Validation (same cutoff, same cohort, same full warm catalogue):

```bash
python -u -m temporal_fm.shared_benchmark \
  --dataset ml-32m --backend sentence \
  --models fm_all_bpr,fm_all_strong_bpr \
  --users 100 --k 10 --profile quick \
  --split validation --device cpu --threads 2
```

This benchmark also fits chronological BPR/SVD baselines; the `--profile quick` option affects **those baselines**, not the already-trained `fm_all_bpr` or `fm_all_strong_bpr`. Use `--profile research` for a stronger baseline. Do **not** compare sampled training NDCG directly with this report. Keep test data untouched until model selection is complete. If you trained with `--run-label fullpass`, substitute `fm_all_fullpass_bpr`.

Streamlit: `streamlit run app.py --server.address 0.0.0.0 --server.port 8501`, then open the Temporal FM shared-cutoff benchmark tab.

## Useful flags

- `--epochs N`: maximum number of epochs; `--min-epochs N` prevents stopping before the minimum.
- `--steps-per-epoch N`: number of optimizer steps per epoch (sampled-budget runs).
- `--full-pass-epochs`: computes steps so every positive TRAIN rating is visited once per epoch; incompatible with `--steps-per-epoch`.
- `--positive-sampling permuted|replacement`: no-repeat coverage vs previous random replacement.
- `--validation-mode full|sampled`: full warm-catalogue checkpoint selection vs a restricted sampled evaluation.
- `--validation-users N`, `--validation-candidates N`: users and (sampled mode only) candidate count.
- `--validate-every N`: compute validation NDCG every N epochs.
- `--run-label NAME`: save a separate model `fm_all_NAME_bpr`.
- `--init-from fm_all_bpr`: fine-tune prior BPR weights if architecture, data source and features match.
- `--batch-size N`, `--patience N`, `--lr FLOAT`, `--latent-dim N` override a preset.

## Validation / integrity

Validated against the original Temporal FM and pairwise suite on synthetic data: **23 passed**. Tests include no-repeat sampler, training with full validation and minimum epochs, weight initialization from an existing BPR checkpoint without changing the parent checkpoint, full-pass step counts, checkpoint loading, and shared benchmark compatibility.

**Not run on the actual 32M data**: the user dataset and Codespaces runtime are separate from this container. No 32M ranking improvement is claimed.
