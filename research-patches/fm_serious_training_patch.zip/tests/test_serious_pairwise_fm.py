import json
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
from temporal_fm.rank_train import PositiveIndexSampler, train
from temporal_fm.data import Events
from temporal_fm.rank_checkpoint import load_bpr_checkpoint
from temporal_fm.train import FeatureProvider
from temporal_fm.ranking import score_candidates, _cohort


def make_small_dataset(tmp_path):
    raw=tmp_path/'data'/'raw'/'ml-latest-small'
    raw.mkdir(parents=True)
    rng=np.random.default_rng(56)
    n_movies=40; n_users=12; n_events=1200
    pd.DataFrame({'movieId':np.arange(1,n_movies+1),
                  'title':[f'Movie {i} (1995)' for i in range(n_movies)],
                  'genres':['Action|Drama' if i%2 else 'Comedy|Sci-Fi' for i in range(n_movies)]}).to_csv(raw/'movies.csv',index=False)
    times=1_100_000_000+np.arange(n_events,dtype=np.int64)*10000
    pd.DataFrame({'userId':rng.integers(1,n_users+1,size=n_events),
                  'movieId':rng.integers(1,n_movies+1,size=n_events),
                  'rating':rng.choice([2.,3.,4.,4.5,5.],size=n_events),
                  'timestamp':times}).to_csv(raw/'ratings.csv',index=False)
    pd.DataFrame({'userId':[1,2,3], 'movieId':[2,2,3],
                  'tag':['space','dark','action'],
                  'timestamp':[int(times[2]),int(times[30]),int(times[70])]}).to_csv(raw/'tags.csv',index=False)


def test_no_repeat_until_exhausted_and_full_pass():
    sampler=PositiveIndexSampler(101,np.random.default_rng(10),'permuted')
    first=np.concatenate([sampler.draw(17) for _ in range(5)]+[sampler.draw(16)])
    assert len(first)==101
    assert len(set(map(int,first)))==101
    second=np.concatenate([sampler.draw(25) for _ in range(4)]+[sampler.draw(1)])
    assert len(set(map(int,second)))==101
    assert sampler.passes==2
    assert sampler.total==202
    r=PositiveIndexSampler(5,np.random.default_rng(4),'replacement')
    assert len(r.draw(12))==12


def test_long_training_finetune_full_validation_and_shared_loader(tmp_path,monkeypatch):
    make_small_dataset(tmp_path)
    monkeypatch.chdir(tmp_path)
    first=train(dataset='ml-latest-small',data_dir='data',text_backend='hash',
                profile='quick',models='fm',threads=1,tag_dims=8,
                validation_users=4,validation_candidates=35)
    assert not first['models']['fm_all_bpr']['reused']
    parent=Path('models/ml-latest-small/temporal_fm/fm_all_bpr/weights.pt')
    assert parent.exists()
    parent_bytes=parent.read_bytes()
    report=train(dataset='ml-latest-small',data_dir='data',text_backend='hash',
                 profile='quick',models='fm',threads=1,tag_dims=8,
                 validation_users=4,validation_mode='full',validate_every=2,
                 min_epochs=3,epochs=3,steps_per_epoch=6,batch_size=16,
                 run_label='long',init_from='fm_all_bpr')
    metrics=report['models']['fm_all_long_bpr']
    assert metrics['positive_draws']==3*6*16
    assert metrics['validation_mode']=='full'
    assert len(metrics['history'])==3
    assert metrics['history'][0].get('validation_ndcg_at_10') is None
    assert metrics['history'][1].get('validation_ndcg_at_10') is not None
    assert parent.read_bytes()==parent_bytes
    ev=Events(Path('data/temporal/ml-latest-small'))
    provider=FeatureProvider(ev,backend='hash',tag_dir=ev.folder/'features_hash')
    provider.model_name='sentence-transformers/all-MiniLM-L6-v2'
    model=load_bpr_checkpoint(ev,provider,'fm_all_long_bpr','hash','cpu',seed=42)
    users,hist,truth,_,_= _cohort(ev,'validation',4.,4,3,42)
    movies=np.setdiff1d(np.flatnonzero(ev.movie_has_train), list(hist[users[0]]))
    assert np.isfinite(score_candidates(model,ev,provider,users[0],movies,ev.meta['train_cutoff'])).all()
    again=train(dataset='ml-latest-small',data_dir='data',text_backend='hash',
                 profile='quick',models='fm',threads=1,tag_dims=8,
                 validation_users=4,validation_mode='full',validate_every=2,
                 min_epochs=3,epochs=3,steps_per_epoch=6,batch_size=16,
                 run_label='long',init_from='fm_all_bpr')
    assert again['models']['fm_all_long_bpr']['reused']


def test_full_pass_steps_and_invalid_options(tmp_path,monkeypatch):
    make_small_dataset(tmp_path)
    monkeypatch.chdir(tmp_path)
    report=train(dataset='ml-latest-small',data_dir='data',text_backend='hash',
                 profile='quick',models='fm',threads=1,tag_dims=8,
                 validation_users=4,validation_candidates=40,
                 full_pass_epochs=True,epochs=1,batch_size=128,run_label='fullpass')
    m=report['models']['fm_all_fullpass_bpr']
    assert m['positive_draws']>=m['train_positive_count']
    assert m['positive_draws']<m['train_positive_count']+128
    assert m['positive_passes_completed']>=1
    with pytest.raises(ValueError,match='either'):
        train(dataset='ml-latest-small',data_dir='data',text_backend='hash',
              profile='quick',full_pass_epochs=True,steps_per_epoch=10)
