# Shared-Cutoff Recommendation Benchmark (Temporal FM / DeepFM)

This is an additive, non-destructive patch for your existing `Reco` project. It deliberately **does not** merge scores from incompatible evaluation protocols.

## What this patch fixes

Your previous Temporal FM Top-K report used a **global chronological 80%/10%/10% time split**, future positive events per user, and the warm train catalogue. The existing `scalable`/TIGER benchmark uses a **per-user last-positive split**, generally one target per user. Its published values cannot be compared numerically with FM values.

This suite **re-trains new, lightweight BPR and SVD baselines** from only the Temporal FM training time period, then tests them alongside frozen Temporal FM checkpoints on exactly the same global-cutoff user cohort, full warm-movie catalogue and holdout positives. Older `models/ml-1m/bpr` or TIGER checkpoints are not loaded and are not overwritten.

It also includes two popularity baselines:

- `popularity_all`: number of all **pre-cutoff ratings** per movie (the same principle as your earlier popularity result).
- `popularity_positive`: number of pre-cutoff ratings >= 4.0 stars per movie.

Optional `fm_all_plus_pop_0.25` combines the z-scored raw FM prediction and training-only popularity with **fixed weights**. This is a diagnostic, not proof of ranking gains. Do not tune weights on test.

## Install in GitHub Codespaces

1. Download `fm_shared_comparison_patch.zip` from ChatGPT.
2. Upload the ZIP to the repository's `main` branch on GitHub, as you did before.
3. In the Codespaces terminal:

```bash
cd /workspaces/Reco
git fetch origin main
git show origin/main:fm_shared_comparison_patch.zip > fm_shared_comparison_patch.zip
unzip -o fm_shared_comparison_patch.zip
python -m pip install -r requirements-temporal-fm.txt
python -m pytest -q tests/test_shared_benchmark.py
python scripts/install_shared_benchmark.py
```

The installer ONLY inserts an additional read-only Streamlit section beside the existing Temporal FM lab. It backs up `app.py` to `app.before_shared_benchmark.py`; repeated installation does not duplicate UI. It refuses to modify an unexpected app layout.

## Run: fast sanity check

You need **existing Temporal FM checkpoints** trained with `--text-backend sentence` and a prepared `data/temporal/ml-1m` dataset. For example, the previous Temporal FM suite produced them with:

```bash
python -m temporal_fm.run --dataset ml-1m --profile research \
  --text-backend sentence --models fm,deepfm \
  --ablations id,content,all_no_time,all --device cpu
```

Once checkpoints exist, compare models fairly:

```bash
python -m temporal_fm.shared_benchmark \
  --dataset ml-1m \
  --backend sentence \
  --models fm_id,fm_all,deepfm_all \
  --users 60 \
  --k 10 \
  --profile quick \
  --device cpu
```

This command **does not retrain any FM/DeepFM checkpoint**. It trains or reuses fresh `svd_chrono` and `bpr_chrono` baselines only, using training-period interactions; the quick baseline is for testing functionality, not necessarily optimal ranking.

Use stronger BPR/SVD baseline training after the quick experiment:

```bash
python -m temporal_fm.shared_benchmark \
  --dataset ml-1m --backend sentence \
  --models fm_id,fm_content,fm_all_no_time,fm_all,deepfm_all \
  --users 200 --k 10 --profile research --device cpu
```

`research` here controls **training the new BPR/SVD baselines**, not the already-trained FM profile. FM uses whichever frozen training profile its checkpoint metadata specifies. You can omit checkpoints you have not trained. The `--seed 42` default must match the saved FM seed.

Avoid `--split test` during tuning. Use the validation results for model selection first.

## Model-specific training details

| Baseline configuration | quick | research |
|---|---:|---:|
| SVD / BPR latent factors | 24 | 48 |
| BPR steps | 100 | 1,500 |
| BPR batch size | 512 | 1,024 |
| BPR learning rate | .006 | .003 |
| Evaluation users (set explicitly) | 60 | 200 |

Both are fitted ONLY on training interactions dated on or before the FM global training cutoff. BPR samples positives from ratings >=4.0 and negatives among movies a user has **not rated during training**. SVD factorizes the train-only positive interaction matrix. These are new comparable baselines, not identical hyperparameters or preprocessing to your original BPR/SVD systems.

## Metrics and statistical comparison

- NDCG@10, Recall@10, Hit Rate@10, Precision@10, MRR@10, MAP@10.
- Catalogue coverage, genre diversity (mean pairwise Jaccard distance), novelty.
- Mean across-user FM score standard deviation (useful diagnosis of collapsed score variation).
- Paired bootstrap 95% confidence intervals for the per-user NDCG difference versus `popularity_all`. Uncertainty covers selected user samples only; it does not account for missing impressions or selection bias.
- Exactly the same sampled users, candidates, positive holdouts and ranking cutoff for every model in the report, with deterministic hashes proving cohort and candidate identity.

Files are written as **JSON and CSV** under:

```
reports/temporal/ml-1m/shared_validation_sentence_quick_k10_seed42_<digest>.json
reports/temporal/ml-1m/shared_validation_sentence_quick_k10_seed42_<digest>.csv
```

Reusable BPR/SVD factors are stored under `models/ml-1m/shared_chrono_baselines/<experiment-hash>/`. Neither old `models/ml-1m/bpr/` nor TIGER files are changed.

## Streamlit charts

```bash
streamlit run app.py --server.address 0.0.0.0 --server.port 8501
```

Visit **Temporal FM / DeepFM → Shared-cutoff recommendation benchmark**, choose one `shared_*.json` report, and compare the model table and bar chart. The old rating-RMSE report and original ranking charts are preserved for reference, but **only measurements within one shared report are directly comparable**.

## Why popularity might still win

This is possible and should not be hidden. An FM trained with MSE on *observed* 1–5-star ratings is a **rating regressor**, not a top-K ranking optimizer. Full-catalogue ranking is heavily affected by feedback/popularity biases. MovieLens 1M has **no tags**, and a title alone provides weak semantic content. The fixed blend tests whether FM contains additional information, but it cannot manufacture a signal the model has not learned.

If the new matched benchmark still favors popularity or BPR, next try a *separate* pairwise-ranking fine-tune of FM on training positives vs. unobserved items, combined with regularization, then validate using this exact same benchmark. Do not substitute RMSE for ranking objectives.

## Scope and limits

- Tested synthetically end-to-end on the MovieLens data schema. **No actual MovieLens 1M or 32M ranking outcomes are claimed**.
- Training and evaluation for 32M can require significantly more CPU/memory; start with 1M.
- MovieLens ratings are not verified viewing events; unobserved items are not verified dislikes.
- The evaluation requires *warm* users and movies and selects users with at least one held-out positive; this conditions the reported metrics.
- The `scalable`/TIGER old holdouts are incompatible with these global chronological splits. To compare TIGER as well, retrain it (and all other target systems) using the same training cutoff and holdout protocol.
