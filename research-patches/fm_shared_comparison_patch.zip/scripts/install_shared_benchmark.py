"""Safely attach Shared-Cutoff Benchmark to the existing Temporal FM Streamlit tab.
Does not replace app.py or any existing models. Makes a backup before changing app.
"""
from pathlib import Path
import argparse

def install(path=Path('app.py')):
    path=Path(path)
    if not path.is_file():raise FileNotFoundError(path)
    source=path.read_text(encoding='utf-8')
    call='    render_temporal_lab()'
    if 'render_shared_benchmark()' in source:
        print('Shared benchmark tab already installed')
        return False
    # Recognize only this known integration and refuse surprising projects.
    if source.count(call)!=1:
        raise ValueError('Expected one indented render_temporal_lab() call in app.py; no changes made')
    addition=(call+'\n    from temporal_fm.shared_dashboard import render_shared_benchmark\n'
              '    render_shared_benchmark()')
    backup=path.with_name('app.before_shared_benchmark.py')
    if not backup.exists():backup.write_text(source,encoding='utf-8')
    path.write_text(source.replace(call,addition,1),encoding='utf-8')
    print('Shared benchmark installed; backup:',backup)
    return True

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--app',default='app.py')
    install(p.parse_args().app)
