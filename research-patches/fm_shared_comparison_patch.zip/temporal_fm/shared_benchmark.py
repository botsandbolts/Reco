"""Shared-cutoff ranking benchmark for Temporal FM, BPR, SVD, and popularity.

All models see the SAME chronology, users, candidate catalogue, and positive labels.
Pre-existing BPR/TIGER checkpoints use a different split and CANNOT be compared here.

Usage:
  python -m temporal_fm.shared_benchmark --dataset ml-1m --backend sentence \
    --models fm_id,fm_all,deepfm_all --users 60 --profile quick --device cpu
"""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import time
import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.linalg import svds
import torch
import torch.nn.functional as F

from .data import Events
from .train import FeatureProvider
from .ranking import _cohort, _model, _ranking_scores, score_candidates, _train_counts

BASELINE_PROFILES = {
    'quick': {'factors': 24, 'bpr_steps': 100, 'batch_size': 512, 'lr': 0.006},
    'research': {'factors': 48, 'bpr_steps': 1500, 'batch_size': 1024, 'lr': 0.003},
}


def _training_pairs(ev, positive_threshold=4.0):
    """ONLY pre-cutoff interactions; pair duplicates do not add false positives."""
    n_items=len(ev.movies)
    all_parts=[]; positive_parts=[]
    training=ev.split('train')
    for a in range(0,len(training),200_000):
        idx=np.asarray(training[a:a+200_000],dtype=np.int64)
        user=ev.user_indices(np.asarray(ev.user_raw[idx],dtype=np.int32))-1
        movie=np.asarray(ev.movie_idx[idx],dtype=np.int64)
        flat=user.astype(np.int64)*n_items+movie
        all_parts.append(flat)
        positive_parts.append(flat[np.asarray(ev.rating[idx]>=positive_threshold)])
    known=np.unique(np.concatenate(all_parts))
    pos=np.unique(np.concatenate(positive_parts))
    if not len(pos):raise ValueError('No pre-cutoff positive interactions')
    return known, pos


def _svd_factors(positive, n_users, n_items, factors, seed):
    u=(positive//n_items).astype(np.int32)
    i=(positive%n_items).astype(np.int32)
    matrix=csr_matrix((np.ones(len(u),dtype=np.float32),(u,i)),shape=(n_users,n_items))
    rank=min(factors,n_users-1,n_items-1)
    if rank<1:raise ValueError('Not enough users/items for SVD')
    left,s,right=svds(matrix,k=rank,random_state=seed)
    # score = (U sqrt(S)) @ (V sqrt(S)).T
    r=np.argsort(s)[::-1]
    sq=np.sqrt(np.maximum(s[r],0))
    return np.asarray(left[:,r]*sq,dtype=np.float32),np.asarray(right[r,:].T*sq,dtype=np.float32)


def _sample_unrated(rng, users, known, catalog, n_items):
    """Vectorized rejection sampling; NEVER treat previously rated items as negatives."""
    negatives=rng.choice(catalog,size=len(users)).astype(np.int64)
    for _ in range(100):
        key=users*n_items+negatives
        place=np.searchsorted(known,key)
        bad=np.zeros(len(users),dtype=bool)
        valid=place<len(known)
        bad[valid]=known[place[valid]]==key[valid]
        if not np.any(bad):return negatives.astype(np.int32)
        negatives[bad]=rng.choice(catalog,size=int(bad.sum()))
    raise ValueError('Unable to draw unrated negatives: dataset has near-exhaustive users')


def _bpr_factors(positive,known,catalog,n_users,n_items,*,factors,steps,batch_size,lr,seed,threads=2):
    torch.set_num_threads(max(1,threads))
    torch.manual_seed(seed)
    rng=np.random.default_rng(seed)
    users=(positive//n_items).astype(np.int64)
    pos_movies=(positive%n_items).astype(np.int64)
    embeddings_user=torch.nn.Embedding(n_users,factors)
    embeddings_movie=torch.nn.Embedding(n_items,factors)
    torch.nn.init.normal_(embeddings_user.weight,std=.05)
    torch.nn.init.normal_(embeddings_movie.weight,std=.05)
    opt=torch.optim.AdamW(list(embeddings_user.parameters())+list(embeddings_movie.parameters()),
                          lr=lr,weight_decay=1e-5)
    last=0.
    for step in range(steps):
        sampled=rng.integers(0,len(users),size=batch_size)
        u=users[sampled];pos=pos_movies[sampled]
        neg=_sample_unrated(rng,u,known,catalog,n_items)
        ut=embeddings_user(torch.as_tensor(u))
        pt=embeddings_movie(torch.as_tensor(pos))
        nt=embeddings_movie(torch.as_tensor(neg,dtype=torch.int64))
        pos_score=(ut*pt).sum(-1)
        neg_score=(ut*nt).sum(-1)
        loss=F.softplus(neg_score-pos_score).mean()
        opt.zero_grad(set_to_none=True)
        loss.backward()
        opt.step()
        last=float(loss.detach())
        if step and step%500==0:
            print(f'  BPR step {step}/{steps}, loss={last:.4f}',flush=True)
    return embeddings_user.weight.detach().cpu().numpy().copy(),embeddings_movie.weight.detach().cpu().numpy().copy(),last


def _cache_path(ev, config):
    signature={'dataset':ev.meta['dataset'],'sources':ev.meta['sources'],
               'cutoff':ev.meta['train_cutoff'],'training_size':ev.meta['splits']['train'],**config}
    digest=hashlib.sha256(json.dumps(signature,sort_keys=True).encode()).hexdigest()[:14]
    folder=Path('models')/ev.meta['dataset']/'shared_chrono_baselines'/digest
    return folder,signature


def load_or_fit_baselines(ev, *,positive_threshold,profile,seed,threads=2,force=False):
    cfg=BASELINE_PROFILES[profile]
    model_dir,meta=_cache_path(ev,{'threshold':positive_threshold,'profile':profile,'seed':seed,'config':cfg})
    path=model_dir/'factors.npz'
    if path.exists() and not force:
        arr=np.load(path,allow_pickle=False)
        print('Reusing shared-chronology SVD/BPR baseline factors',flush=True)
        return ({'svd_chrono':(arr['svd_user'],arr['svd_item']),
                 'bpr_chrono':(arr['bpr_user'],arr['bpr_item'])},int(arr['positive_pairs'][()]))
    start=time.perf_counter()
    known,positive=_training_pairs(ev,positive_threshold)
    catalog=np.flatnonzero(ev.movie_has_train).astype(np.int32)
    nu=len(ev.train_users);ni=len(ev.movies)
    su,si=_svd_factors(positive,nu,ni,cfg['factors'],seed)
    bu,bi,loss=_bpr_factors(positive,known,catalog,nu,ni, factors=cfg['factors'],
        steps=cfg['bpr_steps'],batch_size=cfg['batch_size'],lr=cfg['lr'],seed=seed,threads=threads)
    model_dir.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(path,svd_user=su,svd_item=si,bpr_user=bu,bpr_item=bi,
                        positive_pairs=np.int64(len(positive)))
    (model_dir/'manifest.json').write_text(json.dumps({**meta,'bpr_final_loss':loss,
                'elapsed_seconds':round(time.perf_counter()-start,2)},indent=2),encoding='utf-8')
    return {'svd_chrono':(su,si),'bpr_chrono':(bu,bi)},len(positive)


def _zscore(x):
    a=np.asarray(x,dtype=np.float64)
    sd=float(a.std())
    return (a-float(a.mean()))/max(sd,1e-6)


def _bootstrap_difference(samples,base,seed,iterations=400):
    x=np.asarray(samples,dtype=np.float64)-np.asarray(base,dtype=np.float64)
    rng=np.random.default_rng(seed)
    # Fixed paired cohort; intervals describe sampled-user uncertainty only.
    boots=np.array([x[rng.integers(0,len(x),size=len(x))].mean() for _ in range(iterations)])
    return {'difference':round(float(x.mean()),6),
            'ci95_low':round(float(np.quantile(boots,.025)),6),
            'ci95_high':round(float(np.quantile(boots,.975)),6)}


def evaluate(dataset='ml-1m',data_dir='data',backend='sentence',
             models='fm_id,fm_all,deepfm_all',users=60,k=10,
             positive_threshold=4.,min_history=5,seed=42,
             profile='quick',split='validation',device='cpu',
             batch_size=1024,threads=2,blend_weight=.25,force_baselines=False,
             examples=3):
    if profile not in BASELINE_PROFILES:raise ValueError(f'Unknown profile: {profile}')
    if split not in ('validation','test'):raise ValueError('Select validation or test')
    if k<1 or users<1 or not (0<=blend_weight<=1):raise ValueError('Invalid K/users/blend')
    if device=='cuda' and not torch.cuda.is_available():raise ValueError('CUDA not available')
    if split=='test':print('WARNING: Use test only once after selecting models on validation.',flush=True)
    torch.set_num_threads(max(1,threads))
    ev=Events(Path(data_dir)/'temporal'/dataset)
    feature_dir=ev.folder/f'features_{backend}'
    feature_meta_path=feature_dir/'meta.json'
    if not feature_meta_path.exists():raise FileNotFoundError(f'Train a Temporal FM {backend} model first')
    feat_meta=json.loads(feature_meta_path.read_text(encoding='utf-8'))
    tag_dir=feature_dir if (feature_dir/'tag_keys.npy').exists() else None
    if bool(ev.meta['tags_path'])!=bool(tag_dir):raise ValueError('Historical tag features missing')
    provider=FeatureProvider(ev,backend,feat_meta['model_name'],tag_dir)
    provider.model_name=feat_meta['model_name']
    selected=[m.strip() for m in models.split(',') if m.strip()]
    if len(set(selected))!=len(selected):raise ValueError('Repeated model name')
    fm_models={m:_model(ev,provider,m,backend,device,seed=seed) for m in selected}
    active,histories,ground_truth,pop,cohort=_cohort(ev,split,positive_threshold,users,min_history,seed)
    catalog=np.flatnonzero(ev.movie_has_train).astype(np.int32)
    if len(catalog)<k:raise ValueError('Training catalogue smaller than K')
    baselines,n_pos=load_or_fit_baselines(ev,positive_threshold=positive_threshold,
                        profile=profile,seed=seed,threads=threads,force=force_baselines)
    # Score predictions ONLY at the train cutoff; no future rating dates passed to FM.
    timestamp=int(ev.meta['train_cutoff'])+1
    n_train=int(ev.meta['splits']['train'])
    names=['popularity_all','popularity_positive','svd_chrono','bpr_chrono',*selected]
    if 'fm_all' in fm_models and blend_weight>0:
        names.append(f'fm_all_plus_pop_{blend_weight:g}')
    metrics_by_name={name:[] for name in names}
    covered={name:set() for name in names}
    model_examples={name:{} for name in names}
    id_map=ev.movies['movieId'].to_numpy()
    # Count positive-only popularity from TRAIN ONLY.
    positive_count=np.zeros(len(ev.movies),dtype=np.int64)
    tr=ev.split('train')
    for start in range(0,len(tr),200_000):
        ind=np.asarray(tr[start:start+200_000],dtype=np.int64)
        good=ind[np.asarray(ev.rating[ind]>=positive_threshold)]
        positive_count+=np.bincount(np.asarray(ev.movie_idx[good],dtype=np.int32),minlength=len(ev.movies))
    chosen_hash=hashlib.sha256(np.asarray(active,dtype=np.int64).tobytes()).hexdigest()
    candidate_digest=hashlib.sha256()
    score_dispersion={name:[] for name in selected}
    for ord_num,u in enumerate(active):
        history=np.fromiter(histories[u],dtype=np.int32)
        candidate=np.setdiff1d(catalog,history,assume_unique=True)
        relevant=ground_truth[u]
        if not set(relevant).issubset(set(candidate)):
            raise ValueError('A relevant heldout movie is outside the candidate catalogue')
        candidate_digest.update(np.asarray([u,len(candidate)],dtype=np.int64).tobytes())
        candidate_digest.update(candidate.tobytes())
        idx=int(ev.user_indices(np.asarray([u],dtype=np.int32))[0])-1
        if idx<0:raise ValueError('Unknown training user')
        ranked={
          'popularity_all':np.log1p(pop[candidate]).astype(np.float32),
          'popularity_positive':np.log1p(positive_count[candidate]).astype(np.float32),
        }
        for name,(user_vec,item_vec) in baselines.items():
            ranked[name]=np.asarray(item_vec[candidate]@user_vec[idx],dtype=np.float32)
        for name,model in fm_models.items():
            raw=score_candidates(model,ev,provider,u,candidate,timestamp,device,batch_size)
            ranked[name]=raw
            score_dispersion[name].append(float(raw.std()))
        if 'fm_all' in fm_models and blend_weight>0:
            ranked[f'fm_all_plus_pop_{blend_weight:g}']=((1-blend_weight)*_zscore(ranked['fm_all'])+
                blend_weight*_zscore(ranked['popularity_all']))
        for name in names:
            scores=ranked[name]
            order=np.argsort(-scores,kind='stable')[:k]
            top=candidate[order]
            stats=_ranking_scores(top,relevant,k,ev.genre_matrix,pop,n_train)
            metrics_by_name[name].append(stats)
            covered[name].update(map(int,top))
            if ord_num<examples:
                model_examples[name][str(u)]={'history_size':len(histories[u]),
                  'positive_count':len(relevant),'recommendations':[
                    {'rank':int(rank),'movieId':int(id_map[m]),
                     'title':str(ev.movies.iloc[int(m)]['title']),
                     'score':float(scores[o]),'heldout_positive':bool(int(m) in relevant)}
                    for rank,(m,o) in enumerate(zip(top,order),start=1)]}
        if (ord_num+1)%20==0:
            print(f'Ranked {ord_num+1}/{len(active)} shared users',flush=True)
    keys=['ndcg_at_k','recall_at_k','precision_at_k','hit_rate_at_k','mrr_at_k',
          'map_at_k','genre_diversity_at_k','novelty_bits_at_k']
    report={
       'schema_version':1,'dataset':dataset,'split':split,'k':k,'positive_threshold':positive_threshold,
       'user_count':len(active),'selected_user_ids_sha256':chosen_hash,
       'shared_candidates_sha256':candidate_digest.hexdigest(),
       'same_users_and_catalogue':True,'catalogue_size':int(len(catalog)),
       'candidate_policy':'full_train_catalogue_excluding_all_training_ratings',
       'ground_truth':'ALL later ratings >= threshold, restricted to movies in training catalogue',
       'training_policy':'FM: all observed train ratings (MSE); SVD/BPR: train positives only',
       'train_cutoff':ev.meta['train_cutoff'],'validation_cutoff':ev.meta['val_cutoff'],
       'ranking_at_timestamp':timestamp,'backend':backend,'seed':seed,
       'baseline_training_profile':profile,'baseline_positive_pairs':n_pos,
       'blend_weight_fixed_not_tuned':blend_weight,'cohort':cohort,'metrics':{},
       'paired_delta_ndcg_vs_popularity_all':{},'examples':model_examples,
       'caveats':[
          'DIRECTLY comparable models are ONLY those in this shared benchmark report.',
          'Existing TIGER/BPR/SVD checkpoints from scalable/ use per-user holdouts and are NOT comparable.',
          'Fresh BPR/SVD baselines are trained ONLY on positive interactions before FM train cutoff.',
          'Unobserved movies are unknown, NOT true negative impressions.',
          'Popularity is a strong baseline under MovieLens observational feedback bias.',
          'FM trained on star-rating MSE is not trained specifically for top-K ranking.',
          'Only warm-training-catalogue movies and users with future positives appear.',
          'All scores are for recommendation at the training cutoff; no future timestamps or tags.',
          'FM+popularity uses a FIXED unsupervised blend; tune it only on validation, not test.',
          'MovieLens 1M has no native tags, so its tag input is absent.',
          'Confidence intervals represent user-sampling uncertainty, not uncertainty due to missing exposure labels.'
       ],
    }
    for name in names:
        rows=metrics_by_name[name]
        summary={key:round(float(np.mean([v[key] for v in rows])),6) for key in keys}
        summary.update({'users':len(rows),'catalog_coverage_at_k':round(len(covered[name])/len(catalog),6),
                        'recommendations_per_user':round(float(np.mean([v['recommended_count'] for v in rows])),3)})
        if name in score_dispersion:summary['score_std_across_candidates_mean']=round(float(np.mean(score_dispersion[name])),6)
        report['metrics'][name]=summary
        ref=np.array([r['ndcg_at_k'] for r in metrics_by_name['popularity_all']])
        subject=np.array([r['ndcg_at_k'] for r in rows])
        report['paired_delta_ndcg_vs_popularity_all'][name]=_bootstrap_difference(subject,ref,seed)
        print(f'{name:28s} NDCG@{k}={summary["ndcg_at_k"]:.4f} Recall@{k}={summary["recall_at_k"]:.4f}',flush=True)
    out_dir=Path('reports')/'temporal'/dataset
    out_dir.mkdir(parents=True,exist_ok=True)
    digest=hashlib.sha256(json.dumps({'names':names,'users':active,'cutoff':timestamp,
                              'seed':seed,'k':k,'split':split,'profile':profile,'blend':blend_weight},sort_keys=True).encode()).hexdigest()[:10]
    output=out_dir/f'shared_{split}_{backend}_{profile}_k{k}_seed{seed}_{digest}.json'
    output.write_text(json.dumps(report,indent=2),encoding='utf-8')
    import csv
    with output.with_suffix('.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=['model']+list(next(iter(report['metrics'].values())).keys()),extrasaction='ignore')
        writer.writeheader()
        for name,stats in report['metrics'].items():writer.writerow({'model':name,**stats})
    print('Saved comparable ranking report:',output,flush=True)
    return report


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dataset',default='ml-1m')
    parser.add_argument('--data-dir',default='data')
    parser.add_argument('--backend',choices=['sentence','hash'],default='sentence')
    parser.add_argument('--models',default='fm_id,fm_all,deepfm_all')
    parser.add_argument('--users',type=int,default=60)
    parser.add_argument('--k',type=int,default=10)
    parser.add_argument('--positive-threshold',type=float,default=4.)
    parser.add_argument('--min-history',type=int,default=5)
    parser.add_argument('--seed',type=int,default=42)
    parser.add_argument('--profile',choices=list(BASELINE_PROFILES),default='quick')
    parser.add_argument('--split',choices=['validation','test'],default='validation')
    parser.add_argument('--device',choices=['cpu','cuda'],default='cpu')
    parser.add_argument('--batch-size',type=int,default=1024)
    parser.add_argument('--threads',type=int,default=2)
    parser.add_argument('--blend-weight',type=float,default=.25)
    parser.add_argument('--force-baselines',action='store_true')
    parser.add_argument('--examples',type=int,default=3)
    evaluate(**vars(parser.parse_args(argv)))

if __name__=='__main__':main()
