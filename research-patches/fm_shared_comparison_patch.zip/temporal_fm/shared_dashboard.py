"""Read-only report display for apples-to-apples chronological recommendation benchmark."""
from pathlib import Path
import json

def render_shared_benchmark():
    import streamlit as st
    import pandas as pd
    st.divider()
    st.subheader('Shared-cutoff recommendation benchmark')
    st.caption('FM · DeepFM · freshly trained chronological BPR/SVD · popularity · fixed FM/popularity blend. '
               'Every row in one report uses exactly the same users, training cutoff, held-out relevance labels and candidate catalogue.')
    dataset=st.selectbox('Shared benchmark dataset',('ml-1m','ml-32m','ml-latest-small'),key='shared_ds')
    folder=Path('reports')/'temporal'/dataset
    files=sorted(folder.glob('shared_*.json'),key=lambda p:p.stat().st_mtime,reverse=True)
    if not files:
        st.info('No shared-cutoff report yet. The former FM ranking report must not be compared numerically with BPR/TIGER.')
        st.code(f'python -m temporal_fm.shared_benchmark --dataset {dataset} '
                '--backend sentence --models fm_id,fm_all,deepfm_all '
                '--users 60 --profile quick --device cpu',language='bash')
        return
    file=st.selectbox('Comparable benchmark report',files,format_func=lambda p:p.name,key='shared_report')
    try:report=json.loads(file.read_text(encoding='utf-8'))
    except (OSError,ValueError) as exc:st.error(str(exc));return
    st.caption(f"{report['split']} · {report['user_count']} users · "
               f"{report['catalogue_size']} warm movies · top {report['k']} · "
               f"cutoff={report['train_cutoff']} · protocol: {report['candidate_policy']}")
    data=pd.DataFrame.from_dict(report['metrics'],orient='index')
    if data.empty:st.warning('No metrics');return
    data.index.name='model'
    selected=st.selectbox('Compare a ranking metric',
        [m for m in ('ndcg_at_k','recall_at_k','hit_rate_at_k','mrr_at_k','precision_at_k',
                    'catalog_coverage_at_k','genre_diversity_at_k') if m in data],key='shared_metric')
    st.bar_chart(data[[selected]].sort_values(selected,ascending=False))
    st.dataframe(data.sort_values('ndcg_at_k',ascending=False),use_container_width=True)
    st.markdown('#### Paired NDCG difference versus popularity')
    paired=pd.DataFrame.from_dict(report.get('paired_delta_ndcg_vs_popularity_all',{}),orient='index')
    st.caption('A positive difference is favorable. Bootstrap 95% intervals resample the SAME validation users.')
    if len(paired):st.dataframe(paired.sort_values('difference',ascending=False),use_container_width=True)
    if any(paired.get('ci95_high',pd.Series(dtype=float)).lt(0)):
        st.warning('At least one model underperforms popularity across the paired bootstrap interval.')
    with st.expander('Example unseen-movie recommendations'):
        models=list(report.get('examples',{}))
        if models:
            name=st.selectbox('Model',models,key='shared_example_model')
            users=list(report['examples'][name])
            if users:
                user=st.selectbox('MovieLens user',users,key='shared_example_user')
                ex=report['examples'][name][user]
                st.caption(f"{ex['history_size']} previous ratings · {ex['positive_count']} later positive movies")
                st.dataframe(pd.DataFrame(ex['recommendations']),hide_index=True,use_container_width=True)
    with st.expander('Protocols, limits, and non-comparable older reports'):
        for warning in report.get('caveats',[]):st.write('• '+str(warning))
        st.write('Old TIGER or scalable BPR/SVD checkpoint scores MUST NOT be placed on these charts unless those models are retrained under this identical cutoff.')

if __name__=='__main__':render_shared_benchmark()
