from pathlib import Path
import json
import numpy as np
import pandas as pd
import pytest
from temporal_fm.shared_benchmark import (
    _sample_unrated, _training_pairs, _bootstrap_difference,
    _svd_factors, evaluate, BASELINE_PROFILES)
from temporal_fm.data import Events
from temporal_fm.train import run
from scripts.install_shared_benchmark import install


def _toy(tmp_path):
    raw=tmp_path/'raw'/'ml-latest-small';raw.mkdir(parents=True)
    pd.DataFrame({'movieId':range(1,81),
                  'title':[f'Movie {i} ({1998+i%12})' for i in range(1,81)],
                  'genres':['Action|Comedy' if i%2 else 'Drama|Thriller' for i in range(1,81)]}).to_csv(raw/'movies.csv',index=False)
    rng=np.random.default_rng(12);rows=[]
    for i in range(1000):
        rows.append((i%25+1,int(rng.integers(1,81)),
                     float(rng.choice([1.,2.,3.,4.,5.],p=[.1,.1,.2,.35,.25])),
                     1_200_000_000+i*36000))
    pd.DataFrame(rows,columns=['userId','movieId','rating','timestamp']).to_csv(raw/'ratings.csv',index=False)
    return raw


def test_negative_sampling_never_uses_train_rated():
    known=np.sort(np.array([0*10+1,0*10+2,1*10+3,1*10+4]))
    users=np.array([0]*50+[1]*50)
    neg=_sample_unrated(np.random.default_rng(42),users,known,np.arange(10),10)
    assert not np.isin(users*10+neg,known).any()


def test_svd_scores_finite():
    pu,pi=_svd_factors(np.array([0,1,12,14,23,25],dtype=np.int64),4,10,2,42)
    assert pu.shape==(4,2) and pi.shape==(10,2)
    assert np.isfinite(pi).all()


def test_pair_bootstrap():
    x=_bootstrap_difference([1,1,1],[0,0,0],42)
    assert x['difference']==1 and x['ci95_low']==1 and x['ci95_high']==1


def test_end_to_end_same_cohort_and_cached_baselines(tmp_path,monkeypatch):
    raw=_toy(tmp_path)
    monkeypatch.chdir(tmp_path)
    run(dataset='ml-latest-small',data_dir='data',ratings=str(raw/'ratings.csv'),
        movies=str(raw/'movies.csv'),profile='quick',text_backend='hash',
        models='fm',ablations='id,all',threads=1)
    report=evaluate(dataset='ml-latest-small',backend='hash',
        models='fm_id,fm_all',users=8,k=5,profile='quick',threads=1)
    assert report['same_users_and_catalogue']
    assert set(report['metrics'])=={'popularity_all','popularity_positive',
       'svd_chrono','bpr_chrono','fm_id','fm_all','fm_all_plus_pop_0.25'}
    assert report['user_count']>0
    assert report['candidate_policy']=='full_train_catalogue_excluding_all_training_ratings'
    for name,score in report['metrics'].items():
        assert score['users']==report['user_count']
        assert 0<=score['ndcg_at_k']<=1
        assert 0<=score['recall_at_k']<=1
        assert 0<=score['hit_rate_at_k']<=1
    ev=Events('data/temporal/ml-latest-small')
    known,pos=_training_pairs(ev)
    assert len(pos)<=len(known)
    report2=evaluate(dataset='ml-latest-small',backend='hash',
        models='fm_id,fm_all',users=8,k=5,profile='quick',threads=1)
    assert report['metrics']==report2['metrics']
    assert report['shared_candidates_sha256']==report2['shared_candidates_sha256']
    assert len(list(Path('reports/temporal/ml-latest-small').glob('shared_*.csv')))==1


def test_app_installer_idempotent(tmp_path):
    p=tmp_path/'app.py';p.write_text('with temporal_tab:\n    render_temporal_lab()\n')
    assert install(p) is True
    assert install(p) is False
    assert p.read_text().count('render_shared_benchmark()')==1
    assert (tmp_path/'app.before_shared_benchmark.py').exists()
    p.write_text('some_other_content()')
    with pytest.raises(ValueError):install(p)
