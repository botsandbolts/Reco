# Fix MovieLens 32M CSV metadata parsing and BIGINT mismatch

This patch replaces only `scalable/prepare.py` and adds an optional regression test.

## What happened

- The 32M ratings were processed and four Parquet partitions were exported.
- `movies.csv` contains a title with a literal, non-escaped interior quote, e.g. `7789,"11'09"01 - September 11 (2002)",Drama`.
- DuckDB's CSV format/type sniffer rejected that record. Another message reported that it inferred `BIGINT` where the script specified `INTEGER`.

## What changed

- The movie catalogue now uses a **MovieLens-specific, validated parser** that splits the `movieId,title,genres` row at the first and last comma. It preserves title commas and interior quotation marks, validates IDs and duplicates, and does not silently skip invalid rows.
- The resulting small movie table is registered as a Pandas DataFrame in DuckDB, explicitly casts `movieId` to `BIGINT`, and exports Parquet atomically through a temporary file.
- The ratings CSV reader now disables auto-detection, because its complete schema is already defined.
- When **all four** interaction Parquet partitions exist but the manifest does not, the next run reuses them without re-downloading ratings or repeating the 32M window-function computation.

## Android / Codespaces installation

Upload `movie32m_csv_fix.zip` to your GitHub repository via **Add file → Upload files** (if `.gitignore` rejects ZIP files, use GitHub Codespaces Explorer upload or upload `scalable/prepare.py` directly). In the Codespaces terminal:

```bash
cd /workspaces/Reco
git pull origin main
unzip -o movie32m_csv_fix.zip
python -m pytest -q tests/test_scalable_csv_fix.py
python -m scalable.prepare --dataset ml-32m --memory 3GB --threads 2
```

**Do not use `--force`.** The expected output includes:

```text
Reusing the four existing interaction partitions.
train: 15,339,203 positives (reused)
rank_train: 199,676 positives (reused)
validation: 199,676 positives (reused)
test: 199,676 positives (reused)
Parsed 87,585 movie records safely.
Finished: data/processed/ml-32m; movies: 87,585
```

Counts above are from the prior run's screenshots (training/holdouts) and the official MovieLens 32M specification (movies); trust the script's actual results if they differ.

Verify:

```bash
python - <<'PY'
import json
from pathlib import Path
p = Path('data/processed/ml-32m')
m = json.loads((p / 'manifest.json').read_text())
print('Movie count:', m['catalog_size'])
print('Partitions:', m['counts'])
print('Movies Parquet:', (p/'movies.parquet').stat().st_size, 'bytes')
PY
```

Then continue with the scalable training commands in `SCALING_32M.md`.

## Validation scope

Twelve local tests passed with the patched scalable code, including parsing, duplicate/rejected rows, and a mocked DuckDB resume operation. The actual 32M dataset is not present in the local environment, so the real 32M DuckDB export still needs validation in Codespaces. No datasets are bundled in this patch.
