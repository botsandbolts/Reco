"""Download and preprocess MovieLens with disk-backed DuckDB window functions.

Unlike a Pandas implementation, 32M rows do not need to be resident in memory.
"""
from __future__ import annotations
import argparse
import csv
import shutil
import zipfile
from pathlib import Path
import requests
from .common import DATASETS, store_json


def _download(dataset, root):
    root.mkdir(parents=True, exist_ok=True)
    archive = root / f"{dataset}.zip"
    if archive.exists() and zipfile.is_zipfile(archive):
        return archive
    tmp = archive.with_suffix(".zip.part")
    print(f"Downloading {dataset}; download size depends on the dataset ...", flush=True)
    with requests.get(DATASETS[dataset], stream=True, timeout=(20, 180)) as response:
        response.raise_for_status()
        with tmp.open("wb") as out:
            for chunk in response.iter_content(chunk_size=1 << 20):
                if chunk:
                    out.write(chunk)
    if not zipfile.is_zipfile(tmp):
        tmp.unlink(missing_ok=True)
        raise RuntimeError("Downloaded file is not a valid ZIP archive")
    tmp.replace(archive)
    return archive


def _convert_1m(source, destination, columns, encoding="latin-1"):
    """Convert MovieLens 1M's ::-delimited DAT files to UTF-8 CSV streaming."""
    with source.open("rt", encoding=encoding) as inp, destination.open("w", newline="", encoding="utf-8") as out:
        writer = csv.writer(out)
        writer.writerow(columns)
        for line in inp:
            fields = line.rstrip("\r\n").split("::")
            if len(fields) != len(columns):
                raise ValueError(f"Malformed MovieLens 1M record: {line[:70]}")
            writer.writerow(fields)


def extract_inputs(dataset, root):
    archive = _download(dataset, root)
    extracted = root / dataset
    extracted.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as zf:
        suffix = "dat" if dataset == "ml-1m" else "csv"
        for name in ("ratings", "movies"):
            fname = f"{dataset}/{name}.{suffix}"
            dst = extracted / f"{name}.{suffix}"
            if not dst.exists():
                with zf.open(fname) as src, dst.open("wb") as target:
                    shutil.copyfileobj(src, target)
    if dataset == "ml-1m":
        converted = [
            ("ratings", ["userId", "movieId", "rating", "timestamp"]),
            ("movies", ["movieId", "title", "genres"]),
        ]
        for name, columns in converted:
            target = extracted / f"{name}.csv"
            if not target.exists():
                _convert_1m(extracted / f"{name}.dat", target, columns)
    return extracted / "ratings.csv", extracted / "movies.csv"


def sql_literal(value):
    """Quote a local filename or setting as a DuckDB SQL string literal."""
    return "'" + str(value).replace("'", "''") + "'"


def _read_movie_catalog_safely(csv_path):
    """Read MovieLens titles, including literal interior double quotes.

    The schema is always movieId,title,genres. Genre labels use | rather
    than commas, so the FIRST comma separates ID and the LAST separates genre.
    This is a MovieLens-specific parser, not a general CSV parser.
    """
    import pandas as pd

    rows = []
    with Path(csv_path).open("r", encoding="utf-8-sig", newline="") as handle:
        header = handle.readline().rstrip("\r\n")
        if header != "movieId,title,genres":
            raise ValueError(f"Unexpected movies.csv header: {header!r}")
        for lineno, raw in enumerate(handle, 2):
            line = raw.rstrip("\r\n")
            if not line:
                raise ValueError(f"Empty movie record at line {lineno}")
            movie_id, sep1, remainder = line.partition(",")
            title_field, sep2, genres = remainder.rpartition(",")
            if not sep1 or not sep2 or not genres:
                raise ValueError(f"Malformed movie record at line {lineno}: {line[:120]!r}")
            try:
                movie_id = int(movie_id)
            except ValueError as exc:
                raise ValueError(f"Non-integer movieId at line {lineno}: {movie_id!r}") from exc
            if movie_id < 1:
                raise ValueError(f"Nonpositive movieId at line {lineno}: {movie_id}")
            if title_field.startswith('"'):
                if not title_field.endswith('"'):
                    raise ValueError(f"Unterminated quoted title at line {lineno}")
                title = title_field[1:-1].replace('""', '"')
            else:
                title = title_field
            rows.append((movie_id, title, genres))

    catalog = pd.DataFrame(rows, columns=["movieId", "title", "genres"])
    if catalog.empty:
        raise ValueError("Empty movie catalogue")
    if catalog.movieId.duplicated().any():
        raise ValueError("Duplicate movie IDs in movie catalogue")
    return catalog


def run(dataset="ml-latest-small", data_dir="data", memory="3GB", threads=2, force=False):
    if dataset not in DATASETS:
        raise ValueError(f"Choose one of {list(DATASETS)}")
    if threads < 1:
        raise ValueError("threads must be positive")
    import re
    import duckdb

    root = Path(data_dir)
    out = root / "processed" / dataset
    manifest = out / "manifest.json"
    if manifest.exists() and not force:
        print(f"Already prepared: {out} (pass --force to rebuild)")
        return out
    partitions = ("train", "rank_train", "validation", "test")
    if force:
        for part in (*partitions, "movies"):
            (out / f"{part}.parquet").unlink(missing_ok=True)
        manifest.unlink(missing_ok=True)

    out.mkdir(parents=True, exist_ok=True)
    (out / "spill").mkdir(exist_ok=True)
    con = duckdb.connect((out / "work.duckdb").as_posix())
    try:
        con.execute(f"SET threads = {threads}")
        if not re.fullmatch(r"[0-9]+(?:MB|GB)", memory):
            raise ValueError("Memory must be a size such as 2GB or 800MB")
        con.execute(f"SET memory_limit = {sql_literal(memory)}")
        con.execute(f"SET temp_directory = {sql_literal((out / 'spill').as_posix())}")

        have_partitions = all((out / f"{part}.parquet").is_file() and
                              (out / f"{part}.parquet").stat().st_size > 0
                              for part in partitions)
        if have_partitions and not force:
            print("Reusing the four existing interaction partitions.", flush=True)
            counts = {}
            for part in partitions:
                counts[part] = int(con.execute("SELECT count(*) FROM read_parquet(?)",
                    [(out / f"{part}.parquet").as_posix()]).fetchone()[0])
                print(f"{part}: {counts[part]:,} positives (reused)", flush=True)
        else:
            raw_ratings, _ = extract_inputs(dataset, root / "raw")
            columns = "{'userId':'INTEGER','movieId':'INTEGER','rating':'FLOAT','timestamp':'BIGINT'}"
            con.execute(f"""
                CREATE OR REPLACE TABLE ranked AS
                WITH source AS (
                  SELECT userId, movieId, rating, timestamp,
                         ROW_NUMBER() OVER (PARTITION BY userId, movieId ORDER BY timestamp DESC) AS duplicate_rank
                  FROM read_csv(?, header=true, columns={columns}, auto_detect=false)
                  WHERE rating >= 4.0
                ), unique_positive AS (
                  SELECT userId, movieId, timestamp FROM source WHERE duplicate_rank=1
                )
                SELECT userId, movieId,
                       ROW_NUMBER() OVER (PARTITION BY userId ORDER BY timestamp DESC, movieId DESC) AS reverse_position,
                       COUNT(*) OVER (PARTITION BY userId) AS user_positives
                FROM unique_positive
            """, [raw_ratings.as_posix()])
            conditions = {
                "train": "user_positives < 4 OR reverse_position > 3",
                "rank_train": "user_positives >= 4 AND reverse_position = 3",
                "validation": "user_positives >= 4 AND reverse_position = 2",
                "test": "user_positives >= 4 AND reverse_position = 1",
            }
            counts = {}
            for part, condition in conditions.items():
                dest = (out / f"{part}.parquet").as_posix()
                con.execute(f"COPY (SELECT userId, movieId FROM ranked WHERE {condition}) "
                            f"TO {sql_literal(dest)} (FORMAT PARQUET, COMPRESSION ZSTD)")
                counts[part] = int(con.execute(f"SELECT count(*) FROM ranked WHERE {condition}").fetchone()[0])
                print(f"{part}: {counts[part]:,} positives", flush=True)
            con.execute("DROP TABLE ranked")

        movies_parquet = out / "movies.parquet"
        # Rebuild the cheap movie catalogue on an unfinished preparation, even
        # when a previous failed COPY left a nonempty partial Parquet file.
        raw_movies = root / "raw" / dataset / "movies.csv"
        if not raw_movies.is_file():
            _, raw_movies = extract_inputs(dataset, root / "raw")
        movies_df = _read_movie_catalog_safely(raw_movies)
        print(f"Parsed {len(movies_df):,} movie records safely.", flush=True)
        temp_movies = out / "movies.pending.parquet"
        temp_movies.unlink(missing_ok=True)
        con.register("_safe_movies", movies_df)
        try:
            con.execute("COPY (SELECT CAST(movieId AS BIGINT) AS movieId, title, genres "
                        "FROM _safe_movies) "
                        f"TO {sql_literal(temp_movies.as_posix())} "
                        "(FORMAT PARQUET, COMPRESSION ZSTD)")
            temp_movies.replace(movies_parquet)
        finally:
            con.unregister("_safe_movies")
            temp_movies.unlink(missing_ok=True)
        catalog_size = int(con.execute("SELECT count(*) FROM read_parquet(?)",
                                      [movies_parquet.as_posix()]).fetchone()[0])
        store_json(manifest, {
            "dataset": dataset, "positive_threshold": 4.0,
            "split": "per-user three most recent positives for rank_train, validation, test",
            "counts": counts, "catalog_size": catalog_size,
            "warning": "Per-user split is not a globally chronological split; missing ratings are not dislikes."
        })
        print(f"Finished: {out}; movies: {catalog_size:,}")
    finally:
        con.close()
    return out


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--dataset", choices=DATASETS, default="ml-latest-small")
    p.add_argument("--data-dir", default="data")
    p.add_argument("--memory", default="3GB")
    p.add_argument("--threads", type=int, default=2)
    p.add_argument("--force", action="store_true")
    print(run(**vars(p.parse_args())))
