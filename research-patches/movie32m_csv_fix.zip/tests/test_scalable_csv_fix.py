"""Regression tests for MovieLens 32M's unconventional movie CSV quoting."""
import pytest

from scalable.prepare import _read_movie_catalog_safely


def test_malformed_title_quotes_are_preserved(tmp_path):
    source = tmp_path / "movies.csv"
    source.write_text('movieId,title,genres\n'
                      '7789,"11\'09"01 - September 11 (2002)",Drama\n'
                      '8000,"Comedy, in the City (2004)",Comedy|Romance\n'
                      '8001,"Said ""Hello"" (1998)",Drama\n'
                      '3000000000,Simple Title (2001),Action\n', encoding="utf-8")
    df = _read_movie_catalog_safely(source)
    assert len(df) == 4
    assert df.iloc[0].title == "11'09\"01 - September 11 (2002)"
    assert df.iloc[1].title == "Comedy, in the City (2004)"
    assert df.iloc[1].genres == "Comedy|Romance"
    assert df.iloc[2].title == 'Said "Hello" (1998)'
    assert df.iloc[3].movieId == 3000000000


def test_bad_rows_fail_explicitly(tmp_path):
    src = tmp_path / "movies.csv"
    src.write_text('movieId,title,genres\n22,Missing Genre,\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Malformed movie record"):
        _read_movie_catalog_safely(src)


def test_duplicate_ids_not_silently_dropped(tmp_path):
    src = tmp_path / "movies.csv"
    src.write_text('movieId,title,genres\n5,First,Action\n5,Other,Drama\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Duplicate movie IDs"):
        _read_movie_catalog_safely(src)


def test_resume_uses_existing_partitions_and_does_not_download(tmp_path, monkeypatch):
    import json
    import sys
    import types
    from scalable import prepare

    data_dir = tmp_path / 'data'
    processed = data_dir / 'processed' / 'ml-32m'
    processed.mkdir(parents=True)
    for name in ('train', 'rank_train', 'validation', 'test'):
        (processed / f'{name}.parquet').write_bytes(b'preexisting')
    movies = data_dir / 'raw' / 'ml-32m' / 'movies.csv'
    movies.parent.mkdir(parents=True)
    movies.write_text('movieId,title,genres\n7789,"11\'09"01 - September 11 (2002)",Drama\n',
                      encoding='utf-8')

    def fail_download(*args, **kwargs):
        raise AssertionError('Dataset must not be downloaded again')
    monkeypatch.setattr(prepare, 'extract_inputs', fail_download)

    class Connection:
        def execute(self, query, args=None):
            self.query = query
            self.args = args
            if query.startswith('COPY'):
                (processed / 'movies.pending.parquet').write_bytes(b'newparquet')
            return self

        def fetchone(self):
            return (1,)

        def register(self, name, data):
            assert data.iloc[0].title == "11'09\"01 - September 11 (2002)"

        def unregister(self, name):
            pass

        def close(self):
            pass

    monkeypatch.setitem(sys.modules, 'duckdb', types.SimpleNamespace(connect=lambda _: Connection()))
    result = prepare.run(dataset='ml-32m', data_dir=data_dir)
    assert result == processed
    assert (processed / 'movies.parquet').read_bytes() == b'newparquet'
    assert json.loads((processed / 'manifest.json').read_text())['counts']['train'] == 1
