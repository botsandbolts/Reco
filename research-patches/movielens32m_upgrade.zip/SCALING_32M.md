# MovieLens at Scale — DuckDB + BPR-MF + FAISS + Semantic Fusion

A **separate scaling pipeline** for the existing `Reco` GitHub repository. It does **not** overwrite `app.py`, `src/`, `artifacts/`, or the MovieLens Small benchmark. All new source files are in `scalable/`.

## Important status

- Core negative-sampling, BPR-training, exclusion, and numerical benchmark tests were run on synthetic data.
- **The 1M and 32M datasets have not been downloaded or trained in this environment.** DuckDB, FAISS and Sentence Transformers are optional dependencies to be installed in GitHub Codespaces. Do not publish results before running the experiments.
- Your large-scale metrics are **not directly comparable** to the previous MovieLens Small scores: user populations, catalogues, and evaluation samples differ.
- For stable benchmarks prefer **MovieLens 32M**, not the rolling MovieLens Latest Full dataset.

## Why this architecture?

| Layer | Technology | Motivation |
| --- | --- | --- |
| Download / ingestion | Streaming Python HTTP + ZIP extraction | Avoid loading archive content into RAM |
| ETL | DuckDB SQL with disk-backed windows | Per-user chronological positive-only splits; Parquet outputs |
| Storage | Parquet and on-disk DuckDB | Compressed columnar storage and spillable SQL |
| Collaborative ranking | PyTorch BPR-MF | Pairwise ranking loss and resampled negatives |
| Optional semantic fusion | Sentence Transformers → PCA/UMAP → trainable projection | Learn complementary content features |
| Retrieval | FAISS `IndexFlatIP` / `IndexHNSWFlat` | Exact and approximate similarity search |
| Metrics | Sampled-user full-catalogue top-K | Recall, NDCG, coverage, latency |
| Demonstration | Streamlit | Standalone large-dataset recommendation interface |

**No dense user × item matrix is ever created.** On 32M, such a float32 matrix would require approximately 70 GB, and would not fit a typical free Codespace. Sparse training interactions, minibatches, and low-rank factors are used instead.

## Step 0 — Upload patch, install dependencies

Upload `movielens32m_upgrade.zip` using GitHub's **Add file → Upload files**, then in the Codespaces terminal:

```bash
cd /workspaces/Reco
git pull origin main
unzip -o movielens32m_upgrade.zip
python -m pip install -r requirements-scale.txt
python -m pytest -q tests/test_scalable.py
```

The ZIP extracts **directly into the current folder**, adding `scalable/`, `tests/test_scalable.py`, `requirements-scale.txt`, `requirements-scale-semantic.txt`, `SCALING_32M.md`, and `models/.gitignore`.

**Never commit** downloaded data, model artifacts, user-level history, or dataset ZIPs. The patch contains `models/.gitignore`; your existing `.gitignore` already ignores `data/`.

## Step 1 — Smoke test with MovieLens Small

```bash
python -m scalable.prepare --dataset ml-latest-small --memory 2GB --threads 2
python -m scalable.train --dataset ml-latest-small --epochs 2 --steps-per-epoch 30 --batch-size 1024 --svd
python -m scalable.evaluate --dataset ml-latest-small --users 100 --index flat
streamlit run scalable/dashboard.py --server.address 0.0.0.0 --server.port 8501
```

If the smoke test fails, **stop and inspect the error** before running 32M. This training pipeline is independent of the original `src.train` and may not produce the same model scores.

## Step 2 — Intermediate dataset (MovieLens 1M)

The loader automatically converts MovieLens 1M's `::`-delimited `.dat` files into UTF-8 CSV before DuckDB ingestion.

```bash
python -m scalable.prepare --dataset ml-1m --memory 2GB --threads 2
python -m scalable.train --dataset ml-1m --epochs 5 --steps-per-epoch 200 --batch-size 2048 --svd
python -m scalable.evaluate --dataset ml-1m --users 500 --index flat
```

This is a useful integration benchmark before downloading all 32 million ratings.

## Step 3 — MovieLens 32M, basic BPR-MF

Check the available free Codespaces storage and memory. Download size is approximately **239 MB (decimal)**, but the extracted CSV, on-disk ranking tables, Parquet files, and models use substantially more. Give DuckDB temporary spill room.

```bash
python -m scalable.prepare --dataset ml-32m --memory 3GB --threads 2
```

This creates:

```text
data/raw/ml-32m.zip

data/raw/ml-32m/ratings.csv

data/raw/ml-32m/movies.csv

data/processed/ml-32m/work.duckdb

data/processed/ml-32m/train.parquet

data/processed/ml-32m/rank_train.parquet

data/processed/ml-32m/validation.parquet

data/processed/ml-32m/test.parquet

data/processed/ml-32m/movies.parquet

data/processed/ml-32m/manifest.json
```

Run a **bounded-cost BPR smoke training**:

```bash
python -m scalable.train --dataset ml-32m --epochs 3 --steps-per-epoch 300 --batch-size 4096 --factors 64
```

`steps-per-epoch` is an intentional compute budget. On 32M, this configuration **samples only part of the total training history**; it is for pipeline verification, not necessarily a competitive model. For larger experiments, increase the steps and epochs and track the compute cost and validation curve.

Evaluate **validation only** first:

```bash
python -m scalable.evaluate --dataset ml-32m --users 1000 --index flat --k 10
```

Once you've chosen all hyperparameters using validation and fixed the final model, evaluate test **once**:

```bash
python -m scalable.evaluate --dataset ml-32m --split test --users 1000 --index flat --final-test
```

The script requires the `--final-test` flag intentionally.

## Step 4 — Compare against sparse SVD

SVD fitting on 32M is more computationally expensive; it is optional, not the default:

```bash
python -m scalable.train --dataset ml-32m --output-dir models/ml-32m/bpr-with-svd \
  --epochs 5 --steps-per-epoch 1000 --batch-size 4096 --svd
python -m scalable.evaluate --dataset ml-32m --model-dir models/ml-32m/bpr-with-svd \
  --users 1000 --index flat
```

The evaluation reuses **the same held-out users** for SVD and BPR and excludes the same observed and previous held-out positives.

## Step 5 — Semantic fusion with PCA or UMAP

Install semantic dependencies (the first Sentence Transformer download needs internet):

```bash
python -m pip install -r requirements-scale-semantic.txt
python -m scalable.semantic --dataset ml-32m --reducer pca --dims 64
```

This creates `data/processed/ml-32m/semantic_pca64.npy` aligned to the movie catalogue. The model uses only **titles and genres**. It does *not* acquire richer plot descriptions, so gains are not guaranteed.

Train a semantic BPR model in a separate folder:

```bash
python -m scalable.train --dataset ml-32m --output-dir models/ml-32m/bpr-pca \
  --semantic-vectors data/processed/ml-32m/semantic_pca64.npy \
  --semantic-weight 0.3 --epochs 5 --steps-per-epoch 1000
python -m scalable.evaluate --dataset ml-32m --model-dir models/ml-32m/bpr-pca --users 1000
```

For nonlinear dimensionality reduction:

```bash
python -m scalable.semantic --dataset ml-32m --reducer umap --dims 64 --umap-fit-items 12000
python -m scalable.train --dataset ml-32m --output-dir models/ml-32m/bpr-umap \
  --semantic-vectors data/processed/ml-32m/semantic_umap64.npy \
  --semantic-weight 0.3 --epochs 5 --steps-per-epoch 1000
python -m scalable.evaluate --dataset ml-32m --model-dir models/ml-32m/bpr-umap --users 1000
```

For a fair comparison, keep seeds, positive events, epochs, and training steps fixed across BPR variants. Choose weight, UMAP dimensions, and learning rate on **validation**, not test. UMAP fits on at most 12,000 catalogue item embeddings, then transforms the complete catalogue; its geometry can distort semantic relationships.

## Step 6 — Compare exact and approximate retrieval

```bash
python -m scalable.ann_benchmark --model-dir models/ml-32m/bpr --queries 100 --k 20
```

This reports **HNSW recall against exact FAISS inner-product ranking**, and latency for each. Index build time and memory use are not yet included in the report. HNSW is a speed/accuracy trade-off rather than a guaranteed improvement in rank quality.

You can also evaluate an approximate system directly:

```bash
python -m scalable.evaluate --dataset ml-32m --model-dir models/ml-32m/bpr \
  --index hnsw --users 1000
```

## Step 7 — Explore the full-catalogue demo

```bash
streamlit run scalable/dashboard.py --server.address 0.0.0.0 --server.port 8501
```

Enter `models/ml-32m/bpr` (or your other folder) in the sidebar. The app offers anonymous-user recommendations and benchmark tables. It **does not require training at request time**.

## Scientific limitations

1. **Implicit negatives**: unobserved movies are not verified dislikes or even viewed impressions.
2. **Positive selection**: `rating >= 4` ignores the information contained in lower ratings.
3. **Per-user chronological splitting**: some users' future events can still predate other users' training events; not global time-consistent validation.
4. **Benchmark cohort**: scoring is restricted to a seeded sample of held-out users; it is *not* exhaustive over 200,948 users.
5. **ANN approximation**: HNSW may produce lower observed Recall/NDCG than FlatIP because it can miss candidates.
6. **UMAP preprocessing**: titles/genres are semantically thin, and nonlinear distance preservation is not guaranteed.
7. **No business uplift claim**: off-line historical ratings cannot estimate causal recommendation impact.
8. **Compute quota**: free Codespaces machines can time out or have insufficient RAM/storage; the 32M run has not been validated here.

For more production-grade work: adopt a global time cutoff, include cold-item and popularity-stratified evaluation, add early stopping on validation, maintain model/version lineage with MLflow, implement two-stage top-K candidate retrieval + LambdaMART reranking, and add runtime profiling and data checks.

## References and conditions

- [MovieLens 32M — GroupLens](https://grouplens.org/datasets/movielens/32m/)
- [MovieLens 32M README, dataset format and license](https://files.grouplens.org/datasets/movielens/ml-32m-README.html)
- [FAISS](https://github.com/facebookresearch/faiss)
- [UMAP](https://umap-learn.readthedocs.io/)

MovieLens is distributed under its own research/noncommercial usage restrictions. Do not redistribute raw dataset or substantial derived copies on GitHub without checking the terms.

## Optional portfolio comparison report

After collecting validation results across 1M and 32M experiments:

```bash
python -m scalable.report --models-dir models --split validation
```

The report is written to `models/comparison_validation_flat.md` and is ignored by Git until you choose to publish a reviewed, appropriately anonymized report.
