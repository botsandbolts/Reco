"""Memory-aware MovieLens scaling research pipeline."""
