"""Measure HNSW recall against exact FAISS FlatIP for item retrieval."""
from __future__ import annotations
import argparse
import time
import numpy as np
from .common import load_model, store_json
from .evaluate import _index


def run(model_dir, queries=100, k=20, seed=42, threads=2):
    if min(queries, k) < 1:
        raise ValueError("queries and k must be positive")
    _, _, _, users, items, _ = load_model(model_dir)
    rng = np.random.default_rng(seed)
    positions = rng.choice(len(users), size=min(queries, len(users)), replace=False)
    query = np.ascontiguousarray(users[positions], dtype=np.float32)
    exact = _index(items, "flat", threads)
    approx = _index(items, "hnsw", threads)
    t0 = time.perf_counter()
    _, ground_truth = exact.search(query, k)
    flat_t = time.perf_counter()-t0
    t0 = time.perf_counter()
    _, retrieved = approx.search(query, k)
    ann_t = time.perf_counter()-t0
    recalls = [len(set(a).intersection(b))/k for a,b in zip(ground_truth, retrieved)]
    report = {"queries": len(query), "k": k,
              "hnsw_recall_vs_exact": round(float(np.mean(recalls)), 5),
              "flat_latency_ms_mean": round(flat_t*1000/len(query), 3),
              "hnsw_latency_ms_mean": round(ann_t*1000/len(query), 3),
              "metric": "inner product; no normalization of learned factors"}
    store_json(__import__("pathlib").Path(model_dir) / "ann_benchmark.json", report)
    print(report)
    return report

if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--model-dir", required=True)
    p.add_argument("--queries", type=int, default=100)
    p.add_argument("--k", type=int, default=20)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--threads", type=int, default=2)
    run(**vars(p.parse_args()))
