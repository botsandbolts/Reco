"""Batched BPR matrix factorization with optional trainable semantic fusion."""
from __future__ import annotations
import time
import numpy as np


def sample_negatives(users, n_items, seen_codes, rng, popularity_cdf=None):
    """Uniform / popularity-mixed negatives, excluding ONLY training positives.

    seen_codes is sorted user_index*n_items+item_index; no giant Python sets.
    """
    users = np.asarray(users, dtype=np.int64)
    if n_items <= 1:
        raise ValueError("Need at least two items")
    if len(users) == 0:
        return np.array([], dtype=np.int64)
    out = rng.integers(0, n_items, size=len(users), dtype=np.int64)
    if popularity_cdf is not None:
        biased = rng.random(len(users)) < 0.5
        out[biased] = np.searchsorted(popularity_cdf, rng.random(biased.sum()), side="right")
        np.minimum(out, n_items - 1, out=out)
    for attempt in range(100):
        codes = users * n_items + out
        offsets = np.searchsorted(seen_codes, codes)
        safe = np.minimum(offsets, len(seen_codes) - 1)
        invalid = (offsets < len(seen_codes)) & (seen_codes[safe] == codes)
        if not invalid.any():
            return out
        if attempt == 99:
            raise ValueError("Cannot find unseen negatives; catalogue may be fully observed")
        out[invalid] = rng.integers(0, n_items, size=int(invalid.sum()))
    return out


def train_bpr(u_train, i_train, n_users, n_items, *, factors=64, epochs=3,
              steps_per_epoch=300, batch_size=4096, lr=0.003,
              weight_decay=1e-5, seed=42, semantic=None, semantic_weight=0.3,
              device="auto"):
    """Train fast on large sparse datasets by sampling training positives per step.

    Returns final score-compatible vectors (dot product), epoch losses, and runtime.
    Samples stochastic positives with replacement; steps_per_epoch explicitly bounds
    runtime and is recorded as part of the experiment protocol.
    """
    import torch
    from torch import nn
    from torch.nn import functional as F

    if n_users < 1 or n_items < 2 or len(u_train) != len(i_train) or not len(u_train):
        raise ValueError("Invalid user-item interactions")
    if min(epochs, steps_per_epoch, batch_size, factors) < 1:
        raise ValueError("Training counts and dimensions must be positive")
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(min(4, torch.get_num_threads()))
    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"

    u_train = np.asarray(u_train, dtype=np.int64)
    i_train = np.asarray(i_train, dtype=np.int64)
    if u_train.min() < 0 or u_train.max() >= n_users or i_train.min() < 0 or i_train.max() >= n_items:
        raise ValueError("Out of bounds indices")
    # Codes are int64, allowing 200k x 88k item vocabularies without overflow.
    seen_codes = np.unique(u_train * np.int64(n_items) + i_train)
    seen_unique, positives_per_user = np.unique(u_train, return_counts=True)
    if np.any(positives_per_user >= n_items):
        raise ValueError("A user has rated every item; no valid negative to sample")
    counts = np.bincount(i_train, minlength=n_items).astype(np.float64)
    weights = (counts + 0.1) ** 0.75
    popularity_cdf = np.cumsum(weights / weights.sum())
    popularity_cdf[-1] = 1.0

    features = None
    if semantic is not None:
        features = np.asarray(semantic, dtype=np.float32)
        if features.ndim != 2 or features.shape[0] != n_items:
            raise ValueError("semantic features must have one row per catalog movie")
        features = features / np.maximum(np.linalg.norm(features, axis=1, keepdims=True), 1e-9)

    class BPR(nn.Module):
        def __init__(self):
            super().__init__()
            self.users = nn.Embedding(n_users, factors)
            self.items = nn.Embedding(n_items, factors)
            self.bias = nn.Embedding(n_items, 1)
            nn.init.normal_(self.users.weight, std=0.07)
            nn.init.normal_(self.items.weight, std=0.07)
            nn.init.zeros_(self.bias.weight)
            if features is not None:
                self.register_buffer("semantic_features", torch.tensor(features, dtype=torch.float32))
                self.project = nn.Linear(features.shape[1], factors, bias=False)
                nn.init.xavier_uniform_(self.project.weight, gain=0.2)

        def score(self, u, i):
            item_vec = self.items(i)
            if features is not None:
                item_vec = item_vec + semantic_weight * self.project(self.semantic_features[i])
            return (self.users(u) * item_vec).sum(-1) + self.bias(i).squeeze(-1)

    model = BPR().to(device)
    optim = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    losses = []
    start = time.perf_counter()
    for epoch in range(epochs):
        model.train()
        epoch_loss = 0.0
        for _ in range(steps_per_epoch):
            sample = rng.integers(0, len(u_train), size=batch_size)
            users = u_train[sample]
            pos = i_train[sample]
            neg = sample_negatives(users, n_items, seen_codes, rng, popularity_cdf)
            U = torch.from_numpy(users).to(device)
            P = torch.from_numpy(pos).to(device)
            N = torch.from_numpy(neg).to(device)
            loss = F.softplus(-(model.score(U, P) - model.score(U, N))).mean()
            optim.zero_grad(set_to_none=True)
            loss.backward()
            optim.step()
            epoch_loss += float(loss.detach())
        avg = epoch_loss / steps_per_epoch
        losses.append(round(avg, 6))
        print(f"BPR epoch {epoch+1}/{epochs}: training loss={avg:.5f}", flush=True)

    model.eval()
    with torch.no_grad():
        user_vec = model.users.weight.detach().cpu().numpy().astype(np.float32)
        item_vec = model.items.weight.detach()
        if features is not None:
            item_vec = item_vec + semantic_weight * model.project(model.semantic_features)
        movie_vec = item_vec.cpu().numpy().astype(np.float32)
        movie_bias = model.bias.weight.detach().cpu().numpy().astype(np.float32)
        # Add a constant user coordinate to implement item bias in pure IP retrieval.
        user_out = np.column_stack([user_vec, np.ones(n_users, dtype=np.float32)])
        item_out = np.concatenate([movie_vec, movie_bias], axis=1)
    return user_out, item_out, losses, round(time.perf_counter() - start, 3)
