"""Shared utilities for scaling MovieLens, with explicit artifact contracts."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.sparse import csr_matrix, load_npz, save_npz

DATASETS = {
    "ml-latest-small": "https://files.grouplens.org/datasets/movielens/ml-latest-small.zip",
    "ml-1m": "https://files.grouplens.org/datasets/movielens/ml-1m.zip",
    "ml-32m": "https://files.grouplens.org/datasets/movielens/ml-32m.zip",
}


def store_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2), encoding="utf-8")
    tmp.replace(path)


def encode_ids(values, sorted_ids):
    values = np.asarray(values)
    indices = np.searchsorted(sorted_ids, values)
    safe = np.minimum(indices, len(sorted_ids) - 1)
    if np.any(indices >= len(sorted_ids)) or np.any(sorted_ids[safe] != values):
        raise ValueError("Interactions include IDs not present in the model vocabulary")
    return indices.astype(np.int32)


def load_interactions(processed_dir, partition):
    """Load exactly two integer columns; larger arrays are returned as NumPy."""
    import duckdb
    source = (Path(processed_dir) / f"{partition}.parquet").as_posix()
    con = duckdb.connect()
    try:
        arrays = con.execute(
            "SELECT userId, movieId FROM read_parquet(?)", [source]
        ).fetchnumpy()
        return (arrays["userId"].astype(np.int32, copy=False),
                arrays["movieId"].astype(np.int32, copy=False))
    finally:
        con.close()


def load_catalog(processed_dir):
    import duckdb
    con = duckdb.connect()
    try:
        return con.execute(
            "SELECT movieId, title, genres FROM read_parquet(?) ORDER BY movieId",
            [(Path(processed_dir) / "movies.parquet").as_posix()],
        ).fetchdf()
    finally:
        con.close()


def load_model(model_dir):
    p = Path(model_dir)
    cfg = json.loads((p / "model.json").read_text(encoding="utf-8"))
    user_ids = np.load(p / "user_ids.npy", mmap_mode="r")
    item_ids = np.load(p / "item_ids.npy", mmap_mode="r")
    user_vectors = np.load(p / "user_vectors.npy", mmap_mode="r")
    item_vectors = np.load(p / "item_vectors.npy", mmap_mode="r")
    seen = load_npz(p / "train_seen.npz").tocsr()
    assert seen.shape == (len(user_ids), len(item_ids))
    return cfg, user_ids, item_ids, user_vectors, item_vectors, seen
