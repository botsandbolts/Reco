"""Standalone Streamlit explorer for large MovieLens models; small app unchanged."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
import streamlit as st
from scalable.common import load_model, load_catalog
from scalable.evaluate import _index, top_unseen

st.set_page_config(page_title="Large-scale MovieLens Research", layout="wide", page_icon="🎬")
st.title("🎬 MovieLens at Scale")
st.caption("MovieLens research only • BPR matrix factorization • FAISS • reproducible evaluation")
model_dir = Path(st.sidebar.text_input("Model folder", "models/ml-latest-small/bpr"))
if not (model_dir / "model.json").exists():
    st.warning("Train a scalable model first, then enter its model folder above.")
    st.code("python -m scalable.prepare --dataset ml-latest-small\n"
            "python -m scalable.train --dataset ml-latest-small\n"
            "streamlit run scalable/dashboard.py", language="bash")
    st.stop()

@st.cache_resource(show_spinner="Loading factor matrices and FAISS index...")
def get_model(folder, stamp):
    cfg, uids, mids, user_vectors, item_vectors, seen = load_model(folder)
    return cfg, uids, mids, user_vectors, item_vectors, seen, _index(item_vectors, "flat")

stamp = (model_dir / "model.json").stat().st_mtime
cfg, user_ids, movie_ids, U, I, seen, index = get_model(str(model_dir), stamp)
st.sidebar.write(f"Dataset: {cfg['dataset']}")
st.sidebar.write(f"Users: {len(user_ids):,} • Movies: {len(movie_ids):,}")
recommendations, metrics_tab, notes = st.tabs(["Recommendations", "Metrics", "Methodology"])
with recommendations:
    max_user = len(user_ids) - 1
    ui = st.number_input("Anonymous user index (0-based)", min_value=0,
                         max_value=max_user, value=min(10, max_user))
    howmany = st.slider("Number of recommendations", 5, 25, 10)
    excluded = seen.indices[seen.indptr[ui]:seen.indptr[ui+1]]
    winners = top_unseen(U[ui], I, index, excluded, k=howmany)
    try:
        catalog = load_catalog(Path("data") / "processed" / cfg["dataset"])
        byid = catalog.set_index("movieId")
        rows = byid.loc[movie_ids[winners]].reset_index()
        rows["score"] = np.round(I[winners] @ U[ui], 3)
        st.dataframe(rows, use_container_width=True, hide_index=True)
    except Exception:
        st.dataframe(pd.DataFrame({"movieId":movie_ids[winners],
                                   "score":np.round(I[winners] @ U[ui], 3)}),
                     use_container_width=True, hide_index=True)
    st.caption("Movies in the training set are excluded. This is an anonymous historical user, not a live account.")
with metrics_tab:
    options = sorted(model_dir.glob("metrics_*.json")) + sorted(model_dir.glob("ann_benchmark.json"))
    if not options:
        st.info("Run `python -m scalable.evaluate` to generate metrics.")
    for file in options:
        st.subheader(file.name)
        values = json.loads(file.read_text(encoding="utf-8"))
        if "results" in values:
            df = pd.DataFrame(values["results"]).T
            st.dataframe(df, use_container_width=True)
            if "ndcg_at_k" in df:
                st.bar_chart(df["ndcg_at_k"])
        else:
            st.json(values)
with notes:
    st.markdown("""
    ### Design
    - **Training:** PyTorch BPR with bounded stochastic minibatches; sparse positive-only history.
    - **Candidate retrieval:** FAISS inner-product search. FlatIP is exact; HNSW is approximate.
    - **Evaluation:** sampled held-out users, full catalogue candidates, seen-item exclusion.
    - **Semantic option:** Sentence Transformers → PCA/UMAP → trainable semantic item projection.
    - **Limitations:** positive-only ratings are not impression logs; negative items are unobserved,
      not known dislikes. The chronological split is within users, not global calendar time.
      The code is a research demonstration, not a commercial recommender service.
    """)
