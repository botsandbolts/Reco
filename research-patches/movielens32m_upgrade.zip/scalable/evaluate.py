"""Reproducible sampled-user full-catalogue recommendation evaluation with FAISS.

FAISS FlatIP returns exact top scores; HNSW is approximate. Previously observed
train/ranker/validation positives are excluded according to the selected split.
"""
from __future__ import annotations
import argparse
import json
import time
from pathlib import Path
import numpy as np
from .common import load_interactions, load_model, store_json


def _index(items, method="flat", threads=2):
    """Construct a FAISS index, with a slower NumPy exact fallback for tests."""
    items = np.ascontiguousarray(items, dtype=np.float32)
    if method == "numpy":
        return None
    try:
        import faiss
    except ImportError as exc:
        raise RuntimeError("Install faiss-cpu: python -m pip install -r requirements-scale.txt") from exc
    faiss.omp_set_num_threads(threads)
    if method == "flat":
        index = faiss.IndexFlatIP(items.shape[1])
    elif method == "hnsw":
        index = faiss.IndexHNSWFlat(items.shape[1], 32, faiss.METRIC_INNER_PRODUCT)
        index.hnsw.efConstruction = 80
        index.hnsw.efSearch = 128
    else:
        raise ValueError("index must be flat, hnsw, or numpy")
    index.add(items)
    return index


def top_unseen(user_vec, items, index, excluded, k=10, candidate_window=512):
    """Retrieve top K catalog items, expanding search if exclusions exhaust it."""
    n_items = len(items)
    excluded = set(map(int, excluded))
    if k < 1 or candidate_window < 1:
        raise ValueError("k and candidate_window must be positive")
    if index is None:
        scores = items @ np.asarray(user_vec, dtype=np.float32)
        if excluded:
            scores[list(excluded)] = -np.inf
        return np.argsort(-scores, kind="stable")[:min(k, n_items-len(excluded))]
    request = min(n_items, max(candidate_window, k+len(excluded)+32))
    while True:
        _, ids = index.search(np.asarray(user_vec, dtype=np.float32).reshape(1, -1), request)
        picked = [int(i) for i in ids[0] if i >= 0 and int(i) not in excluded]
        if len(picked) >= k or request == n_items:
            return np.asarray(picked[:k], dtype=np.int32)
        request = min(n_items, 2 * request)


def _available_targets(processed_dir, split, user_ids, item_ids):
    u, i = load_interactions(processed_dir, split)
    j = np.searchsorted(user_ids, u)
    valid_user = j < len(user_ids)
    keep = valid_user.copy()
    keep[valid_user] = user_ids[j[valid_user]] == u[valid_user]
    m = np.searchsorted(item_ids, i)
    valid_movie = m < len(item_ids)
    keep &= valid_movie
    keep[valid_movie] &= (item_ids[m[valid_movie]] == i[valid_movie])
    return j[keep].astype(np.int32), m[keep].astype(np.int32)


def measure(user_vecs, item_vecs, seen, users, targets, *,
            previous=None, k=10, candidate_window=512, method="flat", threads=2):
    """Ranking quality, conditional on these preselected users/holdout targets."""
    if len(users) != len(targets):
        raise ValueError("users and targets lengths differ")
    if seen.shape != (len(user_vecs), len(item_vecs)):
        raise ValueError("Seen matrix shape differs from factors")
    index = _index(item_vecs, method, threads=threads)
    coverage = set()
    hits = 0
    dcg = 0.0
    t0 = time.perf_counter()
    for u, target in zip(users, targets):
        u, target = int(u), int(target)
        excluded = set(map(int, seen.indices[seen.indptr[u]:seen.indptr[u+1]]))
        if previous:
            excluded.update(previous.get(u, ()))
        if target in excluded:
            raise ValueError("Held-out target appears in exclusion history / leakage")
        top = top_unseen(user_vecs[u], item_vecs, index, excluded, k, candidate_window)
        coverage.update(map(int, top))
        matches = np.flatnonzero(top == target)
        if len(matches):
            hits += 1
            dcg += 1.0 / np.log2(int(matches[0]) + 2)
    duration = time.perf_counter() - t0
    return {
        "users_evaluated": len(users),
        "recall_at_k": round(hits / len(users), 6) if len(users) else None,
        "ndcg_at_k": round(dcg / len(users), 6) if len(users) else None,
        "catalog_coverage_at_k": round(len(coverage) / len(item_vecs), 6),
        "retrieval_index": method,
        "query_latency_ms_mean": round(duration*1000 / len(users), 3) if len(users) else None,
    }


def _previous_events(processed, partitions, user_ids, item_ids):
    previous = {}
    for partition in partitions:
        users, items = _available_targets(processed, partition, user_ids, item_ids)
        for u, i in zip(users, items):
            previous.setdefault(int(u), set()).add(int(i))
    return previous


def run(dataset="ml-latest-small", data_dir="data", model_dir=None,
        split="validation", users=1000, seed=42, k=10,
        candidate_window=512, index="flat", threads=2, final_test=False):
    if split not in ("validation", "test"):
        raise ValueError("Choose validation or test")
    if split == "test" and not final_test:
        raise ValueError("To avoid repeated test-set tuning, use --final-test for test evaluation")
    if users < 1:
        raise ValueError("--users must be positive")
    path = Path(model_dir) if model_dir else Path("models") / dataset / "bpr"
    cfg, user_ids, item_ids, user_vec, item_vec, seen = load_model(path)
    if cfg["dataset"] != dataset:
        raise ValueError("Model was trained for a different dataset")
    processed = Path(data_dir) / "processed" / dataset
    u, targets = _available_targets(processed, split, user_ids, item_ids)
    if len(u) == 0:
        raise ValueError("No eligible evaluation users")
    rng = np.random.default_rng(seed)
    subset = np.sort(rng.choice(len(u), size=min(users, len(u)), replace=False))
    selected_users, selected_targets = u[subset], targets[subset]
    previous = _previous_events(
        processed, ["rank_train"] if split == "validation" else ["rank_train", "validation"],
        user_ids, item_ids,
    )
    result = {"dataset": dataset, "split": split,
              "note": "Sampled users; each has exactly one held-out positive; ratings are not impressions",
              "k": k, "sample_seed": seed, "requested_user_count": users,
              "method": cfg["model"], "config": cfg,
              "results": {}}
    models = [("bpr", user_vec, item_vec)]
    svd_users = path / "svd_user_vectors.npy"
    svd_items = path / "svd_item_vectors.npy"
    if svd_users.exists() and svd_items.exists():
        models.append(("svd", np.load(svd_users, mmap_mode="r"), np.load(svd_items, mmap_mode="r")))
    for name, uvec, ivec in models:
        scored = measure(uvec, ivec, seen, selected_users, selected_targets,
                         previous=previous, k=k, candidate_window=candidate_window,
                         method=index, threads=threads)
        result["results"][name] = scored
        print(f"{name}: Recall@{k}={scored['recall_at_k']} NDCG@{k}={scored['ndcg_at_k']} "
              f"Coverage={scored['catalog_coverage_at_k']} ", flush=True)
    filename = f"metrics_{split}_{index}_{seed}.json"
    store_json(path / filename, result)
    print(f"Saved: {path / filename}")
    return result


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--dataset", default="ml-latest-small")
    p.add_argument("--data-dir", default="data")
    p.add_argument("--model-dir", default=None)
    p.add_argument("--split", choices=["validation", "test"], default="validation")
    p.add_argument("--users", type=int, default=1000)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--k", type=int, default=10)
    p.add_argument("--candidate-window", type=int, default=512)
    p.add_argument("--index", choices=["flat", "hnsw", "numpy"], default="flat")
    p.add_argument("--threads", type=int, default=2)
    p.add_argument("--final-test", action="store_true")
    run(**vars(p.parse_args()))
