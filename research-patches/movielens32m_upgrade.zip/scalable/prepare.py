"""Download and preprocess MovieLens with disk-backed DuckDB window functions.

Unlike a Pandas implementation, 32M rows do not need to be resident in memory.
"""
from __future__ import annotations
import argparse
import csv
import shutil
import zipfile
from pathlib import Path
import requests
from .common import DATASETS, store_json


def _download(dataset, root):
    root.mkdir(parents=True, exist_ok=True)
    archive = root / f"{dataset}.zip"
    if archive.exists() and zipfile.is_zipfile(archive):
        return archive
    tmp = archive.with_suffix(".zip.part")
    print(f"Downloading {dataset}; download size depends on the dataset ...", flush=True)
    with requests.get(DATASETS[dataset], stream=True, timeout=(20, 180)) as response:
        response.raise_for_status()
        with tmp.open("wb") as out:
            for chunk in response.iter_content(chunk_size=1 << 20):
                if chunk:
                    out.write(chunk)
    if not zipfile.is_zipfile(tmp):
        tmp.unlink(missing_ok=True)
        raise RuntimeError("Downloaded file is not a valid ZIP archive")
    tmp.replace(archive)
    return archive


def _convert_1m(source, destination, columns, encoding="latin-1"):
    """Convert MovieLens 1M's ::-delimited DAT files to UTF-8 CSV streaming."""
    with source.open("rt", encoding=encoding) as inp, destination.open("w", newline="", encoding="utf-8") as out:
        writer = csv.writer(out)
        writer.writerow(columns)
        for line in inp:
            fields = line.rstrip("\r\n").split("::")
            if len(fields) != len(columns):
                raise ValueError(f"Malformed MovieLens 1M record: {line[:70]}")
            writer.writerow(fields)


def extract_inputs(dataset, root):
    archive = _download(dataset, root)
    extracted = root / dataset
    extracted.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as zf:
        suffix = "dat" if dataset == "ml-1m" else "csv"
        for name in ("ratings", "movies"):
            fname = f"{dataset}/{name}.{suffix}"
            dst = extracted / f"{name}.{suffix}"
            if not dst.exists():
                with zf.open(fname) as src, dst.open("wb") as target:
                    shutil.copyfileobj(src, target)
    if dataset == "ml-1m":
        converted = [
            ("ratings", ["userId", "movieId", "rating", "timestamp"]),
            ("movies", ["movieId", "title", "genres"]),
        ]
        for name, columns in converted:
            target = extracted / f"{name}.csv"
            if not target.exists():
                _convert_1m(extracted / f"{name}.dat", target, columns)
    return extracted / "ratings.csv", extracted / "movies.csv"


def sql_literal(value):
    """Quote a local filename or setting as a DuckDB SQL string literal."""
    return "'" + str(value).replace("'", "''") + "'"


def run(dataset="ml-latest-small", data_dir="data", memory="3GB", threads=2, force=False):
    if dataset not in DATASETS:
        raise ValueError(f"Choose one of {list(DATASETS)}")
    if threads < 1:
        raise ValueError("threads must be positive")
    import duckdb
    root = Path(data_dir)
    out = root / "processed" / dataset
    manifest = out / "manifest.json"
    if manifest.exists() and not force:
        print(f"Already prepared: {out} (pass --force to rebuild)")
        return out
    if force:
        for part in ("train", "rank_train", "validation", "test", "movies"):
            (out / f"{part}.parquet").unlink(missing_ok=True)
        manifest.unlink(missing_ok=True)
    raw_ratings, raw_movies = extract_inputs(dataset, root / "raw")
    out.mkdir(parents=True, exist_ok=True)
    (out / "spill").mkdir(exist_ok=True)
    con = duckdb.connect((out / "work.duckdb").as_posix())
    try:
        con.execute(f"SET threads = {threads}")
        if not __import__("re").fullmatch(r"[0-9]+(?:MB|GB)", memory):
            raise ValueError("Memory must be a size such as 2GB or 800MB")
        con.execute(f"SET memory_limit = {sql_literal(memory)}")
        con.execute(f"SET temp_directory = {sql_literal((out / 'spill').as_posix())}")
        # Explicit column types prevent CSV schema inference surprises.
        columns = "{'userId':'INTEGER','movieId':'INTEGER','rating':'FLOAT','timestamp':'BIGINT'}"
        con.execute(f"""
            CREATE OR REPLACE TABLE ranked AS
            WITH source AS (
              SELECT userId, movieId, rating, timestamp,
                     ROW_NUMBER() OVER (PARTITION BY userId, movieId ORDER BY timestamp DESC) AS duplicate_rank
              FROM read_csv(?, header=true, columns={columns})
              WHERE rating >= 4.0
            ), unique_positive AS (
              SELECT userId, movieId, timestamp FROM source WHERE duplicate_rank=1
            )
            SELECT userId, movieId,
                   ROW_NUMBER() OVER (PARTITION BY userId ORDER BY timestamp DESC, movieId DESC) AS reverse_position,
                   COUNT(*) OVER (PARTITION BY userId) AS user_positives
            FROM unique_positive
        """, [raw_ratings.as_posix()])
        sql = {
            "train": "user_positives < 4 OR reverse_position > 3",
            "rank_train": "user_positives >= 4 AND reverse_position = 3",
            "validation": "user_positives >= 4 AND reverse_position = 2",
            "test": "user_positives >= 4 AND reverse_position = 1",
        }
        counts = {}
        for partition, condition in sql.items():
            dest = (out / f"{partition}.parquet").as_posix()
            con.execute(f"COPY (SELECT userId, movieId FROM ranked WHERE {condition}) TO {sql_literal(dest)} (FORMAT PARQUET, COMPRESSION ZSTD)")
            counts[partition] = int(con.execute(f"SELECT count(*) FROM ranked WHERE {condition}").fetchone()[0])
            print(f"{partition}: {counts[partition]:,} positives", flush=True)
        movie_cols = "{'movieId':'INTEGER','title':'VARCHAR','genres':'VARCHAR'}"
        con.execute(f"COPY (SELECT movieId, title, genres FROM read_csv({sql_literal(raw_movies.as_posix())}, header=true, columns={movie_cols})) "
                    f"TO {sql_literal((out / 'movies.parquet').as_posix())} (FORMAT PARQUET, COMPRESSION ZSTD)")
        catalog_size = int(con.execute("SELECT count(*) FROM read_parquet(?)", [(out / "movies.parquet").as_posix()]).fetchone()[0])
        store_json(manifest, {"dataset": dataset, "positive_threshold": 4.0,
                              "split": "per-user three most recent positives for rank_train, validation, test",
                              "counts": counts, "catalog_size": catalog_size,
                              "warning": "Per-user split is not a globally chronological split; missing ratings are not dislikes."})
        print(f"Finished: {out}; movies: {catalog_size:,}")
    finally:
        con.close()
    # Keep the database for easy verification; delete it if space is tight after checking the parquet files.
    return out


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--dataset", choices=DATASETS, default="ml-latest-small")
    p.add_argument("--data-dir", default="data")
    p.add_argument("--memory", default="3GB")
    p.add_argument("--threads", type=int, default=2)
    p.add_argument("--force", action="store_true")
    print(run(**vars(p.parse_args())))
