"""Combine recorded validation results into a concise Markdown experiment report."""
from __future__ import annotations
import argparse
import json
from pathlib import Path


def run(models_dir="models", split="validation", index="flat"):
    base = Path(models_dir)
    rows = []
    for path in sorted(base.rglob(f"metrics_{split}_{index}_*.json")):
        try:
            report = json.loads(path.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            continue
        for model, record in report.get("results", {}).items():
            training = report.get("config", {})
            rows.append((report.get("dataset", "?"), str(path.parent), model,
                         record.get("users_evaluated"), record.get("recall_at_k"),
                         record.get("ndcg_at_k"), record.get("catalog_coverage_at_k"),
                         training.get("training_seconds")))
    text = [
        "# MovieLens scale comparison — sampled-user evaluation",
        "",
        f"Split: **{split}** | Retrieval index: **{index}**",
        "",
        "| Dataset | Run | Model | Users | Recall@K | NDCG@K | Coverage@K | Train seconds |",
        "| --- | --- | --- | ---: | ---: | ---: | ---: | ---: |",
    ]
    for dataset, directory, model, users, recall, ndcg, coverage, seconds in rows:
        text.append(f"| {dataset} | `{directory}` | {model} | {users} | {recall} | {ndcg} | {coverage} | {seconds} |")
    if not rows:
        text.append("| No completed experiments found | | | | | | | |")
    text += ["", "**Caution:** Datasets have different users and catalogues. This table summarizes runs; it does not establish a controlled scale effect unless sampling, tuning, and relevant protocol details are documented."]
    destination = base / f"comparison_{split}_{index}.md"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text("\n".join(text) + "\n", encoding="utf-8")
    print(f"Wrote {destination} with {len(rows)} experiment results")
    return destination

if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--models-dir", default="models")
    p.add_argument("--split", choices=["validation", "test"], default="validation")
    p.add_argument("--index", choices=["flat", "hnsw", "numpy"], default="flat")
    run(**vars(p.parse_args()))
