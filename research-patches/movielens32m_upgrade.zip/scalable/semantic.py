"""Precompute optional semantic movie factors aligned with the entire catalogue.

UMAP fits on a bounded random subset and transforms the catalogue, avoiding
unbounded neighbor graph construction for all ~88k items.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import normalize
from .common import load_catalog, store_json


def reduce_vectors(vectors, method="pca", dims=64, seed=42, umap_fit_items=12000):
    if dims < 2 or dims > min(vectors.shape):
        raise ValueError("dims must be >= 2 and at most min(n_items, n_features)")
    x = np.asarray(vectors, dtype=np.float32)
    if method == "raw":
        return normalize(x).astype(np.float32)
    print(f"Reducing {x.shape[0]:,} movies using PCA({dims}) ...", flush=True)
    pca = PCA(n_components=dims, svd_solver="randomized", random_state=seed)
    compact = pca.fit_transform(x).astype(np.float32)
    if method == "pca":
        return normalize(compact).astype(np.float32)
    if method != "umap":
        raise ValueError("Use raw, pca, or umap")
    try:
        import umap
    except ImportError as exc:
        raise RuntimeError("Install umap-learn with requirements-scale-semantic.txt") from exc
    rng = np.random.default_rng(seed)
    keep = np.sort(rng.choice(len(compact), size=min(umap_fit_items, len(compact)), replace=False))
    reducer = umap.UMAP(n_components=dims, n_neighbors=30, min_dist=0.05,
                        metric="euclidean", random_state=seed, low_memory=True,
                        n_jobs=1)
    reducer.fit(compact[keep])
    reduced = reducer.transform(compact).astype(np.float32)
    return normalize(reduced).astype(np.float32)


def run(dataset="ml-latest-small", data_dir="data", reducer="pca", dims=64,
        checkpoint="sentence-transformers/all-MiniLM-L6-v2", batch_size=128,
        seed=42, umap_fit_items=12000):
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError as exc:
        raise RuntimeError("Install requirements-scale-semantic.txt") from exc
    processed = Path(data_dir) / "processed" / dataset
    movies = load_catalog(processed)
    raw = processed / "semantic_raw.npy"
    if raw.exists():
        vectors = np.load(raw, mmap_mode="r")
        if vectors.shape[0] != len(movies):
            raise ValueError("Cached raw embeddings do not match the movie catalogue; delete cache")
        print(f"Reusing {raw}")
    else:
        texts = [f"Movie: {row.title}. Genres: {row.genres.replace('|', ', ')}"
                 for row in movies.itertuples(index=False)]
        print("Downloading/encoding Sentence Transformer; first use may take time", flush=True)
        model = SentenceTransformer(checkpoint)
        vectors = model.encode(texts, batch_size=batch_size, normalize_embeddings=True,
                               show_progress_bar=True, convert_to_numpy=True)
        vectors = np.asarray(vectors, dtype=np.float32)
        np.save(raw, vectors)
    out = reduce_vectors(vectors, method=reducer, dims=dims, seed=seed,
                         umap_fit_items=umap_fit_items)
    output = processed / f"semantic_{reducer}{dims if reducer != 'raw' else ''}.npy"
    np.save(output, out)
    store_json(output.with_suffix(".json"), {
        "dataset": dataset, "shape": list(out.shape), "reducer": reducer,
        "dims": dims, "seed": seed, "checkpoint": checkpoint,
        "source": "Title and genres only; not movie plot summaries",
        "catalog_order": "movieId ascending, matching movies.parquet and BPR model",
        "umap_fit_items": min(len(movies), umap_fit_items) if reducer == "umap" else None,
    })
    print(f"Saved {output} with shape={out.shape}")
    return output


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--dataset", default="ml-latest-small")
    p.add_argument("--data-dir", default="data")
    p.add_argument("--reducer", choices=["raw", "pca", "umap"], default="pca")
    p.add_argument("--dims", type=int, default=64)
    p.add_argument("--checkpoint", default="sentence-transformers/all-MiniLM-L6-v2")
    p.add_argument("--batch-size", type=int, default=128)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--umap-fit-items", type=int, default=12000)
    run(**vars(p.parse_args()))
