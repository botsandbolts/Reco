"""Train sampled-mini-batch BPR on disk-prepared MovieLens, optionally SVD.

No full dense user×movie matrix is created.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
from scipy.sparse import csr_matrix, save_npz
from .common import encode_ids, load_catalog, load_interactions, store_json
from .bpr import train_bpr


def run(dataset="ml-latest-small", data_dir="data", output_dir=None,
        factors=64, epochs=3, steps_per_epoch=300, batch_size=4096,
        lr=0.003, weight_decay=1e-5, seed=42, semantic_vectors=None,
        semantic_weight=0.3, svd=False):
    processed = Path(data_dir) / "processed" / dataset
    if not (processed / "manifest.json").exists():
        raise FileNotFoundError(f"Run python -m scalable.prepare --dataset {dataset} first")
    out = Path(output_dir) if output_dir else Path("models") / dataset / ("bpr-semantic" if semantic_vectors else "bpr")
    out.mkdir(parents=True, exist_ok=True)
    catalog = load_catalog(processed)
    item_ids = np.asarray(catalog.movieId, dtype=np.int64)
    raw_u, raw_i = load_interactions(processed, "train")
    user_ids = np.unique(raw_u.astype(np.int64))
    uu = encode_ids(raw_u, user_ids)
    ii = encode_ids(raw_i, item_ids)
    del raw_u, raw_i
    n_users, n_items = len(user_ids), len(item_ids)
    print(f"Training BPR on {len(uu):,} positives, {n_users:,} users, {n_items:,} items", flush=True)
    seen = csr_matrix((np.ones(len(uu), dtype=np.bool_), (uu, ii)), shape=(n_users, n_items))
    seen.sum_duplicates()
    seen.sort_indices()
    save_npz(out / "train_seen.npz", seen, compressed=True)
    np.save(out / "user_ids.npy", user_ids)
    np.save(out / "item_ids.npy", item_ids)
    semantic = None
    if semantic_vectors:
        semantic = np.load(semantic_vectors, mmap_mode="r")
        if semantic.shape[0] != n_items:
            raise ValueError(f"Embedding item count {semantic.shape[0]} differs from catalogue {n_items}")
    u_vec, i_vec, losses, duration = train_bpr(
        uu, ii, n_users, n_items, factors=factors, epochs=epochs,
        steps_per_epoch=steps_per_epoch, batch_size=batch_size, lr=lr,
        weight_decay=weight_decay, seed=seed, semantic=semantic,
        semantic_weight=semantic_weight,
    )
    np.save(out / "user_vectors.npy", u_vec)
    np.save(out / "item_vectors.npy", i_vec)
    if svd:
        from sklearn.decomposition import TruncatedSVD
        print("Fitting sparse TruncatedSVD (may take time on 32M) ...", flush=True)
        X = seen.astype(np.float32)
        n_factors = min(factors, n_users - 1, n_items - 1)
        if n_factors > 0:
            decomposition = TruncatedSVD(n_components=n_factors, n_iter=3, random_state=seed)
            np.save(out / "svd_user_vectors.npy", decomposition.fit_transform(X).astype(np.float32))
            np.save(out / "svd_item_vectors.npy", decomposition.components_.T.astype(np.float32))
    store_json(out / "model.json", {
        "model": "BPR-MF" if semantic is None else "BPR-MF + trainable semantic projection",
        "dataset": dataset, "training_positives": int(len(uu)), "users": n_users,
        "items": n_items, "factors": factors, "epochs": epochs,
        "steps_per_epoch": steps_per_epoch, "batch_size": batch_size,
        "seed": seed, "lr": lr, "weight_decay": weight_decay,
        "semantic_vectors": str(semantic_vectors) if semantic_vectors else None,
        "semantic_weight": semantic_weight if semantic_vectors else None,
        "losses": losses, "training_seconds": duration,
        "warning": "Unobserved items used as weak negatives; global chronology not guaranteed",
    })
    print(f"Saved model in {out}")
    return out


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--dataset", default="ml-latest-small")
    p.add_argument("--data-dir", default="data")
    p.add_argument("--output-dir", default=None)
    p.add_argument("--factors", type=int, default=64)
    p.add_argument("--epochs", type=int, default=3)
    p.add_argument("--steps-per-epoch", type=int, default=300)
    p.add_argument("--batch-size", type=int, default=4096)
    p.add_argument("--lr", type=float, default=0.003)
    p.add_argument("--weight-decay", type=float, default=1e-5)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--semantic-vectors", default=None)
    p.add_argument("--semantic-weight", type=float, default=0.3)
    p.add_argument("--svd", action="store_true")
    run(**vars(p.parse_args()))
