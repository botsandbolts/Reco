"""Self-contained quick tests, no MovieLens or network required."""
import numpy as np
import pytest
from scipy.sparse import csr_matrix
from scalable.bpr import sample_negatives, train_bpr
from scalable.evaluate import top_unseen, measure
from scalable.common import encode_ids


def test_encoding_is_safe():
    vocab = np.array([2, 4, 8, 12])
    assert encode_ids([2, 8, 12], vocab).tolist() == [0, 2, 3]
    with pytest.raises(ValueError):
        encode_ids([3], vocab)


def test_negatives_never_equal_training_positive():
    users = np.array([0, 0, 1, 1])
    items = np.array([0, 1, 2, 3])
    codes = np.sort(users * 7 + items)
    selected = np.tile(users, 25)
    result = sample_negatives(selected, 7, codes, np.random.default_rng(42))
    assert all((int(u) * 7 + int(i)) not in codes for u, i in zip(selected, result))


def test_bpr_train_and_numpy_evaluation():
    u = np.array([0, 0, 0, 1, 1, 2, 2, 2, 3, 3], dtype=np.int32)
    i = np.array([0, 1, 2, 1, 4, 2, 3, 5, 4, 6], dtype=np.int32)
    user_vec, item_vec, losses, seconds = train_bpr(
        u, i, 4, 9, factors=8, epochs=2, steps_per_epoch=4, batch_size=8, seed=9)
    assert user_vec.shape == (4, 9)
    assert item_vec.shape == (9, 9)
    assert len(losses) == 2
    assert seconds >= 0
    seen = csr_matrix((np.ones(len(u)), (u, i)), shape=(4, 9))
    score = measure(user_vec, item_vec, seen, np.array([0,1]),
                    np.array([7,8]), k=3, method="numpy")
    assert 0 <= score["recall_at_k"] <= 1
    assert 0 <= score["ndcg_at_k"] <= 1


def test_semantic_factor_fusion_and_seen_filtering():
    u = np.array([0, 0, 1, 1, 2, 2], dtype=np.int32)
    i = np.array([0, 1, 1, 2, 2, 3], dtype=np.int32)
    rng = np.random.default_rng(31)
    semantic = rng.normal(size=(6, 12)).astype("float32")
    U, I, _, _ = train_bpr(u, i, 3, 6, factors=4, epochs=1,
                           steps_per_epoch=3, batch_size=8, semantic=semantic)
    selected = top_unseen(U[0], I, index=None, excluded=[0,1], k=4)
    assert len(selected) == 4
    assert not set(selected) & {0,1}


def test_target_must_not_be_leaked():
    user_vec = np.array([[1., 0.]], dtype=np.float32)
    item_vec = np.array([[1., 0.], [0., 1.]], dtype=np.float32)
    seen = csr_matrix(([1], ([0], [0])), shape=(1, 2))
    with pytest.raises(ValueError, match="leakage"):
        measure(user_vec, item_vec, seen, [0], [0], method="numpy")
