"""Offline tests for converters and artifact/report contracts."""
import csv
import json
from pathlib import Path
from scalable.prepare import _convert_1m, sql_literal
from scalable.report import run


def test_movielens_1m_delimiter_conversion(tmp_path):
    old = tmp_path / "movies.dat"
    old.write_bytes('5::A Movie, with comma (2001)::Action|Comedy\n'.encode('latin-1'))
    converted = tmp_path / "movies.csv"
    _convert_1m(old, converted, ["movieId", "title", "genres"])
    with converted.open(newline="", encoding="utf-8") as handle:
        assert list(csv.reader(handle)) == [
            ["movieId", "title", "genres"],
            ["5", "A Movie, with comma (2001)", "Action|Comedy"],
        ]


def test_sql_path_quotes_are_escaped():
    assert sql_literal("test's.csv") == "'test''s.csv'"


def test_portfolio_report_reads_metrics(tmp_path):
    folder = tmp_path / "ml-1m" / "bpr"
    folder.mkdir(parents=True)
    payload = {"dataset": "ml-1m", "config": {"training_seconds": 5.3},
               "results": {"bpr": {"users_evaluated": 20, "recall_at_k": 0.2,
                                   "ndcg_at_k": 0.11, "catalog_coverage_at_k": 0.3}}}
    (folder / "metrics_validation_flat_42.json").write_text(json.dumps(payload))
    report = run(models_dir=tmp_path)
    text = report.read_text()
    assert "ml-1m" in text and "bpr" in text and "0.11" in text
