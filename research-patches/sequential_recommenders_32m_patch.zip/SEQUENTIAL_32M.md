# Large-scale sequential recommendation: BERT4Rec-inspired + SASRec-inspired

**Non-destructive add-on** for the existing `scalable/` MovieLens pipeline. The base
MovieLens Small app, BPR training, FAISS, and the 32M CSV fix remain unchanged.

## Methods

- **SASRec-inspired:** causal self-attention on user training rating history,
  predict the next observed positive interaction.
- **BERT4Rec-inspired:** bidirectional attention, randomized masked positions
  and next-item masks using *training-only* histories.
- **Semantic initialization:** optionally initialize trainable item embeddings
  from cached Sentence Transformer vectors (`semantic_pca64.npy` or UMAP64).
- **Optional score fusion:** combine sequential and existing BPR retrieval
  vectors with weighted normalized dot products in a concatenated FAISS index.
- **Evaluation:** same prepared MovieLens ranker/validation/test holdouts, same
  seed-selected users, full-catalogue FAISS candidates, train-seen exclusions,
  and previous-positive exclusions as the scalable BPR benchmark.

These are **BERT4Rec-inspired and SASRec-inspired minimal research implementations**,
not exact reproductions of the published architectures. Training uses **sampled
softmax** rather than full 87k-way softmax, and a bounded sample of mini-batches
per epoch. The comparative benchmark needs actual runs; no win is guaranteed.

## 0. Before you begin

**Resolve the CSV import error first.** The 32M preparation must have completed:

```bash
python -m scalable.prepare --dataset ml-32m --memory 3GB --threads 2
ls data/processed/ml-32m/manifest.json
```

The failure in `movies.csv` due to unescaped quotes / BIGINT type inference
must be resolved using the previously supplied 32M CSV fix.

## 1. Install

Upload and unzip this patch in the repository root:

```bash
cd /workspaces/Reco
git pull origin main
unzip -o sequential_32m_patch.zip
python -m pip install -r requirements-sequential.txt
python -m pytest -q tests/test_sequence_models.py
```

If you uploaded to GitHub with another filename, substitute its actual name.
This ZIP contains only **new** modules, a requirements file, tests, and this guide.

## 2. Prepare sequences on MovieLens 1M first

The existing scalable Parquet interaction tables omit timestamps. This patch
reconstructs ordered training histories by joining the **train** Parquet to the
cached original `ratings.csv` and aggregating in DuckDB. The result is a
compressed train sequence file, a bounded `sequences.npy`, a `lengths.npy`,
IDs, and a sparse `train_seen.npz` for excluding all seen movies, even those
outside the last 100 inputs.

```bash
python -m scalable.prepare --dataset ml-1m --memory 2GB
python -m scalable.sequence_data --dataset ml-1m --max-len 100 --memory 2GB
```

Only positive training interactions go into model sequences. The positive
threshold and reserved holdouts are inherited from `scalable.prepare`.
No training data are read from ranker, validation, or test.

## 3. Train an initial SASRec-inspired model

```bash
python -m scalable.sequence_train --dataset ml-1m --kind sasrec \
  --max-len 100 --dim 64 --layers 2 --heads 4 \
  --epochs 3 --steps-per-epoch 150 --batch-size 64 --negatives 128
```

Then train BERT4Rec-inspired separately:

```bash
python -m scalable.sequence_train --dataset ml-1m --kind bert4rec \
  --max-len 100 --dim 64 --layers 2 --heads 4 \
  --epochs 3 --steps-per-epoch 150 --batch-size 64 --negatives 128
```

These are small CPU-friendly experiments; they may require substantial time on
Codespaces. A GPU-backed Kaggle/Colab environment is preferable for 32M.

## 4. Evaluate both on the same 1M users

```bash
python -m scalable.sequence_evaluate --dataset ml-1m \
  --model-dir models/ml-1m/sasrec_L100 --users 500 --index flat
python -m scalable.sequence_evaluate --dataset ml-1m \
  --model-dir models/ml-1m/bert4rec_L100 --users 500 --index flat
```

**Important:** The default `--split validation` is used for architecture and
hyperparameter selection. Only run `--split test --final-test` once after model
selection. Do not tune on test results.

## 5. Scale to 32M

Make sure Codespaces has enough free disk space before the preparation. DuckDB
uses disk-backed processing but builds a temporary timestamp-ordered training
sequence. It reuses the downloaded CSV and Parquet interactions.

```bash
python -m scalable.sequence_data --dataset ml-32m --max-len 100 \
  --memory 3GB --threads 2
```

GPU training, when available:

```bash
python -m scalable.sequence_train --dataset ml-32m --kind sasrec \
  --dim 64 --max-len 100 --epochs 3 --steps-per-epoch 500 \
  --batch-size 64 --negatives 128 --device auto
```

BERT4Rec-inspired:

```bash
python -m scalable.sequence_train --dataset ml-32m --kind bert4rec \
  --dim 64 --max-len 100 --epochs 3 --steps-per-epoch 500 \
  --batch-size 64 --negatives 128 --device auto
```

A 500-step epoch is a fixed compute budget, **not one complete pass through all
training events**. The report records that distinction. No 32M GPU time or
memory guarantees are made for a free Codespace.

## 6. Semantic initialization (optional)

First generate the existing PCA embeddings, or reuse them if already cached:

```bash
python -m pip install -r requirements-scale-semantic.txt
python -m scalable.semantic --dataset ml-32m --reducer pca --dims 64
```

Then train a **separate** semantic-initialized BERT4Rec-inspired model:

```bash
python -m scalable.sequence_train --dataset ml-32m --kind bert4rec \
  --dim 64 --max-len 100 --semantic-vectors data/processed/ml-32m/semantic_pca64.npy \
  --semantic-mix 0.5 --output-dir models/ml-32m/bert4rec_semantic_L100 \
  --epochs 3 --steps-per-epoch 500 --batch-size 64
```

This initializes the movie embeddings before training; **it does not claim
RecoBERT or a pretrained BERT4Rec checkpoint**. Movie titles/genres are sparse
semantic information; licensed plot descriptions would be a future improvement.

## 7. Compare against BPR and BPR fusion

Train the separate scalable BPR baseline if needed:

```bash
python -m scalable.train --dataset ml-32m --epochs 3 --steps-per-epoch 300
```

Use exactly the same evaluation user sample for both models and blended scores:

```bash
python -m scalable.sequence_evaluate --dataset ml-32m \
  --model-dir models/ml-32m/bert4rec_L100 \
  --bpr-model-dir models/ml-32m/bpr --fusion-weight 0.6 \
  --users 1000 --index flat
```

Fusion is `0.6 * cosine(sequence) + 0.4 * cosine(BPR)`. It has a *new*
FAISS inner-product index representing the exact concatenated score. The same
ranker-training holdout is excluded for validation; ranker-training and
validation positives are excluded for final test. Neither enters the training
history.

Compare against the independent BPR evaluation with matching `--users`,
`--seed`, `--split`, `--k`, and `--index`. Metrics for fusion explicitly use
cosine normalization and thus differ in scoring from unnormalized original BPR.

## 8. Interactive demonstration

```bash
streamlit run scalable/sequence_dashboard.py \
  --server.address 0.0.0.0 --server.port 8501
```

Open the forwarded port 8501 in Codespaces. Choose the dataset and view all
available sequence metrics. Explore recommendations from individual models.
Your original app and scalable dashboard are left untouched.

## What needs further work

- MovieLens timestamps capture **rating submission**, not verified movie watches.
- Per-user chronological splitting is **not** a globally fixed time cutoff.
- Sparse MovieLens ratings are not exposure/click logs; missing != negative.
- BERT4Rec canonical masked prediction usually uses more masked positions than
  this bounded sampled-softmax implementation.
- SASRec paper reproduction needs protocol-aligned hyperparameter tuning.
- Real 32M training speed, memory use, and quality remain to be measured.
- Improvements over SVD or BPR cannot be assumed; record negative results.
- Model weights are `torch.load(weights_only=True)` to avoid untrusted pickles.

**Portfolio question:** How do static collaborative factors, causal sequence
attention, bidirectional masked attention, semantic initialization, and score
fusion trade off ranking quality, latency, and computational cost?
