"""Independent Streamlit dashboard for SASRec / BERT4Rec / BPR comparisons."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
import streamlit as st
from scipy.sparse import load_npz
from scalable.sequence_models import make_inference_batch
from scalable.sequence_train import load_model
from scalable.evaluate import top_unseen, _index
from scalable.common import load_catalog

st.set_page_config(page_title="Sequential Recommendation Research",page_icon="🎬",layout="wide")
st.title("🎬 Sequential Recommendation Lab")
st.caption("BERT4Rec-inspired · SASRec-inspired · BPR · FAISS · MovieLens research")
dataset=st.sidebar.selectbox("Dataset",["ml-1m","ml-32m","ml-latest-small"])
root=Path("models")/dataset
model_dirs=sorted([x for x in root.glob("*_L*") if (x/"model.json").exists()])
# Use a broad pattern rather than relying on directory names.
benchmark,explore,notes=st.tabs(["Research benchmark","Recommendations","Methodology"])
with benchmark:
    st.subheader("Side-by-side ranking results")
    rows=[]
    if root.is_dir():
        for folder in root.iterdir():
            for f in sorted(folder.glob("sequence_metrics_*.json")):
                payload=json.loads(f.read_text())
                for name,metric in payload.get("results",{}).items():
                    rows.append({"run":folder.name,"model":name,"split":payload.get("split"),
                                 "index":metric.get("retrieval_index"),
                                 "evaluated_users":metric.get("users_evaluated"),
                                 "Recall@K":metric.get("recall_at_k"),
                                 "NDCG@K":metric.get("ndcg_at_k"),
                                 "Coverage@K":metric.get("catalog_coverage_at_k"),
                                 "retrieval ms":metric.get("query_retrieval_ms_mean")})
    if rows:
        df=pd.DataFrame(rows)
        st.dataframe(df,hide_index=True,use_container_width=True)
        st.bar_chart(df.set_index("run")["NDCG@K"])
        st.caption("Compare equal splits, samples, candidate indices and K. Repeated runs are shown individually.")
    else:
        st.info("No sequence metrics yet. Run scalable.sequence_evaluate.")
with explore:
    st.subheader("Explore one trained sequential recommender")
    available=[x for x in root.iterdir() if (x/"weights.pt").exists()] if root.is_dir() else []
    if not available:
        st.warning("No sequence model in this dataset directory. Train one first.")
    else:
        chosen=st.selectbox("Model folder",[str(x) for x in available])
        @st.cache_resource(show_spinner="Loading sequence model and index...")
        def open_model(folder,version):
            model,cfg=load_model(folder)
            items=model.item_factors()
            return model,cfg,items,_index(items,"flat")
        stamp=(Path(chosen)/"weights.pt").stat().st_mtime
        model,cfg,items,idx=open_model(chosen,stamp)
        source=Path("data")/"processed"/dataset/f"sequential_L{cfg['max_len']}"
        sequences=np.load(source/"sequences.npy",mmap_mode="r")
        lengths=np.load(source/"lengths.npy",mmap_mode="r")
        item_ids=np.load(source/"item_ids.npy",mmap_mode="r")
        seen=load_npz(source/"train_seen.npz").tocsr()
        u=int(st.number_input("Anonymous user index (0-based)",0,len(sequences)-1,
                              min(10,len(sequences)-1)))
        k=st.slider("Recommendations",5,25,10)
        if lengths[u]>=1:
            import torch
            x,pos=make_inference_batch(sequences,lengths,np.asarray([u]),cfg["kind"])
            with torch.no_grad():
                q=model.hidden_at(torch.from_numpy(x),torch.from_numpy(pos)).numpy()[0]
            excludes=seen.indices[seen.indptr[u]:seen.indptr[u+1]]
            picks=top_unseen(q,items,idx,excludes,k=k)
            catalog=load_catalog(Path("data")/"processed"/dataset).set_index("movieId")
            result=catalog.reindex(item_ids[picks]).reset_index()
            result["score"]=(items[picks]@q).round(4)
            st.dataframe(result,hide_index=True,use_container_width=True)
            st.caption("Only train history is used for this user. Previously rated movies excluded.")
        else:
            st.info("Choose another user with at least one training interaction.")
with notes:
    st.markdown("""
    **Sequence information:** Chronological order is reconstructed from MovieLens
    **rating timestamps**, not verified film viewing dates. Only `train.parquet`
    interaction IDs may enter model training. Validation and test positives are
    held out, with previous evaluation events excluded at ranking time.

    **BERT4Rec-inspired:** Bidirectional attention, dynamic single-position masking
    plus next-item masking, sampled-softmax training. **SASRec-inspired:** Causal
    Transformer trained on randomly sampled prefixes and their next positive.
    These are small research implementations, *not exact paper reproductions*.

    **Ranking:** FAISS FlatIP yields exact retrieval for the model's learned dot
    product; FAISS HNSW trades accuracy for speed. Missing ratings are unknown,
    not actual dislikes. The per-user holdout is not globally chronological.
    """)
