"""Leakage-checked sequential evaluation over FAISS full-catalogue candidates.

Uses the exact same selected users, target partitions, and exclusions as the BPR
pipeline; optional score-fusion makes a new FAISS index in a concatenated space.
"""
from __future__ import annotations
import argparse
import json
import time
from pathlib import Path
import numpy as np
from scipy.sparse import load_npz
from .common import load_interactions, encode_ids, store_json, load_model
from .evaluate import _available_targets, _previous_events, _index, top_unseen
from .sequence_models import make_inference_batch
from .sequence_train import load_model as load_sequence_model


def normalize_rows(arr):
    x=np.asarray(arr,dtype=np.float32)
    return x/np.maximum(np.linalg.norm(x,axis=1,keepdims=True),1e-9)


def fuse_dot_product(seq_users,seq_items,bpr_users,bpr_items,weight=0.5):
    """Cosine score fusion via concatenated vectors, exactly searchable by FAISS IP."""
    if not 0<=weight<=1:
        raise ValueError("weight in [0,1]")
    if len(seq_items)!=len(bpr_items) or len(seq_users)!=len(bpr_users):
        raise ValueError("Fused user/item matrices are misaligned")
    queries=np.hstack([weight*normalize_rows(seq_users),
                       (1-weight)*normalize_rows(bpr_users)]).astype(np.float32)
    items=np.hstack([normalize_rows(seq_items),normalize_rows(bpr_items)]).astype(np.float32)
    return queries,items


def encode_users(model,sequences,lengths,users,kind,batch_size=128,device="cpu"):
    import torch
    out=[]
    with torch.no_grad():
        for part in np.array_split(users,max(1,int(np.ceil(len(users)/batch_size)))):
            x,p=make_inference_batch(sequences,lengths,part,kind)
            q=model.hidden_at(torch.from_numpy(x).to(device),
                              torch.from_numpy(p).to(device)).cpu().numpy().astype(np.float32)
            out.append(q)
    return np.concatenate(out,axis=0)


def compare_ranking(queries,items,train_seen,selected_users,targets,previous,
                    k=10,index="flat",candidate_window=512,threads=2):
    if len(selected_users)!=len(targets) or len(queries)!=len(targets):
        raise ValueError("Query/target length mismatch")
    idx=_index(items,index,threads=threads)
    hits=0; dcg=0.; covered=set();start=time.perf_counter()
    for q,u,target in zip(queries,selected_users,targets):
        u,target=int(u),int(target)
        exclusion=set(map(int,train_seen.indices[train_seen.indptr[u]:train_seen.indptr[u+1]]))
        exclusion.update(previous.get(u,()))
        if target in exclusion:
            raise ValueError("Holdout target found in input history: evaluation leakage")
        winners=top_unseen(q,items,idx,exclusion,k=k,candidate_window=candidate_window)
        covered.update(map(int,winners))
        found=np.flatnonzero(winners==target)
        if len(found):
            hits+=1
            dcg+=1./np.log2(int(found[0])+2)
    secs=time.perf_counter()-start
    n=len(queries)
    return {"users_evaluated":n,"recall_at_k":round(hits/n,6),
            "ndcg_at_k":round(dcg/n,6),
            "catalog_coverage_at_k":round(len(covered)/len(items),6),
            "query_retrieval_ms_mean":round(1000*secs/n,3),"retrieval_index":index}


def run(dataset="ml-1m",data_dir="data",model_dir=None,split="validation",users=500,
        k=10,index="flat",candidate_window=512,threads=2,seed=42,
        bpr_model_dir=None,fusion_weight=0.6,final_test=False,device="cpu"):
    import torch
    if split not in ("validation","test"):
        raise ValueError("Choose validation or test")
    if split=="test" and not final_test:
        raise ValueError("Test is locked: pass --final-test only after model selection on validation")
    if users<1 or k<1:
        raise ValueError("users and k must be positive")
    path=Path(model_dir) if model_dir else Path("models")/dataset/"bert4rec_L100"
    model,cfg=load_sequence_model(path,device=device)
    report=json.loads((path/"model.json").read_text())
    if report["dataset"]!=dataset:
        raise ValueError("Wrong dataset for saved model")
    processed=Path(data_dir)/"processed"/dataset
    source=processed/f"sequential_L{cfg['max_len']}"
    seq=np.load(source/"sequences.npy",mmap_mode="r")
    lengths=np.load(source/"lengths.npy",mmap_mode="r")
    user_ids=np.load(source/"user_ids.npy",mmap_mode="r")
    item_ids=np.load(source/"item_ids.npy",mmap_mode="r")
    if not (np.array_equal(user_ids,np.load(path/"user_ids.npy",mmap_mode="r")) and
            np.array_equal(item_ids,np.load(path/"item_ids.npy",mmap_mode="r"))):
        raise ValueError("Model and sequences use different user/item vocabularies")
    seen=load_npz(source/"train_seen.npz").tocsr()
    u,t=_available_targets(processed,split,user_ids,item_ids)
    eligible=lengths[u]>=2
    u,t=u[eligible],t[eligible]
    if not len(u):
        raise ValueError("No evaluation users with sequence history")
    rng=np.random.default_rng(seed)
    selection=np.sort(rng.choice(len(u),size=min(len(u),users),replace=False))
    u,t=u[selection],t[selection]
    prev=_previous_events(processed,["rank_train"] if split=="validation"
                          else ["rank_train","validation"],user_ids,item_ids)
    # Train-only user histories for fair BPR comparison. Do not append holdouts.
    q=encode_users(model,seq,lengths,u,cfg["kind"],device=device)
    item=np.asarray(model.item_factors(),dtype=np.float32)
    if item.shape[0]!=len(item_ids):
        raise ValueError("Model vocabulary does not match prepared catalogue")
    experiments={cfg["kind"]: (q,item)}
    if bpr_model_dir:
        bpr_path=Path(bpr_model_dir)
        bcfg,bu,bi,bq,bitems,bseen=load_model(bpr_path)
        if not (bcfg["dataset"]==dataset and np.array_equal(bu,user_ids)
                and np.array_equal(bi,item_ids)):
            raise ValueError("BPR and sequence models have different dataset IDs/order")
        experiments["bpr"]=(np.asarray(bq[u],dtype=np.float32),np.asarray(bitems,dtype=np.float32))
        experiments["sequence_bpr_fusion"]=fuse_dot_product(q,item,bq[u],bitems,fusion_weight)
    result={"dataset":dataset,"split":split,"seed":seed,"k":k,
            "history":"train only; earlier ranker/validation are exclusions only",
            "sampled_users":len(u),"results":{},
            "limitations":"Positive ratings are not impressions; per-user chronological split; sequence padding/truncation and sampled-softmax"}
    for name,(queries,items) in experiments.items():
        metric=compare_ranking(queries,items,seen,u,t,prev,k,index,candidate_window,threads)
        result["results"][name]=metric
        print(f"{name}: Recall@{k}={metric['recall_at_k']} NDCG@{k}={metric['ndcg_at_k']}")
    name=f"sequence_metrics_{split}_{index}_{seed}.json"
    store_json(path/name,result)
    print(f"Saved {path/name}")
    return result


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--dataset",default="ml-1m")
    p.add_argument("--data-dir",default="data")
    p.add_argument("--model-dir",default=None)
    p.add_argument("--split",choices=["validation","test"],default="validation")
    p.add_argument("--users",type=int,default=500)
    p.add_argument("--k",type=int,default=10)
    p.add_argument("--index",choices=["flat","hnsw","numpy"],default="flat")
    p.add_argument("--candidate-window",type=int,default=512)
    p.add_argument("--threads",type=int,default=2)
    p.add_argument("--seed",type=int,default=42)
    p.add_argument("--bpr-model-dir",default=None)
    p.add_argument("--fusion-weight",type=float,default=0.6)
    p.add_argument("--final-test",action="store_true")
    p.add_argument("--device",choices=["cpu","cuda"],default="cpu")
    print(run(**vars(p.parse_args())))
