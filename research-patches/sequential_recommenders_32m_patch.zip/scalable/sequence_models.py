"""Compact BERT4Rec-inspired and SASRec-inspired sequential item encoders.

BERT uses bidirectional masked-item pretraining with sampled-softmax;
SAS uses causal attention for next-item prediction with sampled-softmax.
These are *inspired* implementations, not exact paper reproductions.
"""
from __future__ import annotations
import numpy as np


def make_batch(sequences, lengths, user_indices, kind, rng):
    """Create training-only sequence/target pairs. 0=padding, 1=mask, 2+=items."""
    if kind not in ("bert4rec", "sasrec"):
        raise ValueError("Choose bert4rec or sasrec")
    x = np.zeros((len(user_indices), sequences.shape[1]), dtype=np.int64)
    locations = np.zeros(len(user_indices), dtype=np.int64)
    targets = np.zeros(len(user_indices), dtype=np.int64)
    for b, u in enumerate(user_indices):
        history = np.asarray(sequences[int(u), :int(lengths[int(u)])], dtype=np.int64)
        if len(history) < 2:
            raise ValueError("Need at least two positive train events per selected user")
        if kind == "bert4rec" and rng.random() < 0.5:
            # Bidirectional masked-item reconstruction; other train events may
            # occur before and after the hidden item. Never future held-out data.
            x[b, :len(history)] = history
            mask_at = int(rng.integers(0,len(history)))
            targets[b] = int(history[mask_at]) - 2
            x[b,mask_at] = 1
            locations[b] = mask_at
        else:
            # Next-item prediction with a random temporal prefix.
            cutoff = int(rng.integers(1,len(history)))
            targets[b] = int(history[cutoff]) - 2
            x[b,:cutoff] = history[:cutoff]
            if kind == "bert4rec":
                x[b,cutoff] = 1
                locations[b] = cutoff
            else:
                locations[b] = cutoff-1
    return x, locations, targets


def make_inference_batch(sequences, lengths, users, kind):
    """Encode TRAIN history only; appends MASK for BERT next-item retrieval."""
    max_len = sequences.shape[1]
    x = np.zeros((len(users),max_len), dtype=np.int64)
    loc = np.zeros(len(users), dtype=np.int64)
    for b,u in enumerate(users):
        hist = np.asarray(sequences[int(u),:int(lengths[int(u)])],dtype=np.int64)
        if not len(hist):
            raise ValueError("User has no train sequence")
        if kind == "bert4rec":
            hist = hist[-(max_len-1):]
            x[b,:len(hist)] = hist
            x[b,len(hist)] = 1
            loc[b] = len(hist)
        elif kind == "sasrec":
            hist = hist[-max_len:]
            x[b,:len(hist)] = hist
            loc[b] = len(hist)-1
        else:
            raise ValueError(kind)
    return x,loc


def sample_candidate_negatives(positives,n_items,negatives,rng):
    """Sample unobserved *candidate IDs*, excluding the labeled target itself."""
    if n_items < 2:
        raise ValueError("Need >=2 movies")
    p=np.asarray(positives,dtype=np.int64)
    out=rng.integers(0,n_items-1,size=(len(p),negatives))
    return out+(out>=p[:,None])


def semantic_initialization(vectors,dim,seed=42):
    """Prepare item-vocabulary initialization; if necessary reduce by PCA."""
    from sklearn.decomposition import PCA
    x=np.asarray(vectors,dtype=np.float32)
    if x.ndim!=2 or x.shape[1]<dim:
        raise ValueError("Semantic vectors must be 2D and have at least dim columns")
    if x.shape[1]!=dim:
        x=PCA(n_components=dim,svd_solver="randomized",random_state=seed).fit_transform(x)
    x=x/(np.linalg.norm(x,axis=1,keepdims=True)+1e-8)
    return x.astype(np.float32)


# Module may be imported without PyTorch for preprocessing/tests.
try:
    import torch
    from torch import nn
except ImportError:
    torch=None
    nn=None


if nn is not None:
    class SequentialRec(nn.Module):
        def __init__(self,n_items,max_len,kind="bert4rec",dim=64,layers=2,heads=4,dropout=0.2):
            super().__init__()
            if kind not in ("bert4rec","sasrec"):
                raise ValueError(kind)
            if dim%heads:
                raise ValueError("dim must be divisible by attention heads")
            self.kind=kind
            self.n_items=n_items
            self.max_len=max_len
            self.dim=dim
            self.token=nn.Embedding(n_items+2,dim,padding_idx=0)
            self.position=nn.Embedding(max_len,dim)
            layer=nn.TransformerEncoderLayer(d_model=dim,nhead=heads,
                        dim_feedforward=dim*4,dropout=dropout,batch_first=True,activation="gelu")
            self.encoder=nn.TransformerEncoder(layer,num_layers=layers,enable_nested_tensor=False)
            self.norm=nn.LayerNorm(dim)
            nn.init.normal_(self.token.weight,std=0.02)
            nn.init.normal_(self.position.weight,std=0.02)
            with torch.no_grad(): self.token.weight[0].zero_()

        def hidden_at(self,tokens,positions):
            b,l=tokens.shape
            if l>self.max_len:
                raise ValueError("Sequence longer than model max_len")
            pos=torch.arange(l,device=tokens.device).view(1,l)
            z=self.token(tokens)*(self.dim**0.5)+self.position(pos)
            padding=tokens.eq(0)
            mask=None
            if self.kind=="sasrec":
                mask=torch.triu(torch.ones(l,l,device=tokens.device,dtype=torch.bool),diagonal=1)
            output=self.encoder(z,mask=mask,src_key_padding_mask=padding)
            return self.norm(output[torch.arange(b,device=tokens.device),positions])

        def logits(self,query,candidates):
            return (query[:,None,:]*self.token(candidates+2)).sum(-1)/(self.dim**0.5)

        def item_factors(self):
            return (self.token.weight[2:]/(self.dim**0.5)).detach().cpu().numpy().astype(np.float32)
else:
    class SequentialRec:
        def __init__(self,*args,**kwargs):
            raise RuntimeError("Install torch: python -m pip install -r requirements-sequential.txt")
