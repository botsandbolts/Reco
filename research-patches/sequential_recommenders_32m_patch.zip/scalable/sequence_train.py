"""Train BERT4Rec-inspired or SASRec-inspired sequential recommenders.

Uses sampled-softmax classification to bound the 32M catalogue vocabulary cost.
GPU strongly recommended for 32M; CPU is suited to smoke tests and 1M.
"""
from __future__ import annotations
import argparse
import time
from pathlib import Path
import numpy as np
from .common import store_json
from .sequence_models import (SequentialRec,make_batch,sample_candidate_negatives,
                              semantic_initialization)


def run(dataset="ml-1m",data_dir="data",kind="bert4rec",max_len=100,
        output_dir=None,dim=64,layers=2,heads=4,dropout=0.2,
        epochs=3,steps_per_epoch=200,batch_size=64,negatives=128,
        lr=0.0003,seed=42,semantic_vectors=None,semantic_mix=0.5,device="auto"):
    import torch
    from torch.nn import functional as F
    if any(v < 1 for v in (epochs,steps_per_epoch,batch_size,negatives,dim,layers,heads)):
        raise ValueError("All training counts and dimensions must be positive")
    if not 0<=semantic_mix<=1:
        raise ValueError("semantic_mix must be between 0 and 1")
    if kind not in ("bert4rec","sasrec"):
        raise ValueError("Choose bert4rec or sasrec")
    source=Path(data_dir)/"processed"/dataset/f"sequential_L{max_len}"
    if not (source/"manifest.json").exists():
        raise FileNotFoundError("Run python -m scalable.sequence_data before training")
    user_ids=np.load(source/"user_ids.npy",mmap_mode="r")
    item_ids=np.load(source/"item_ids.npy",mmap_mode="r")
    x=np.load(source/"sequences.npy",mmap_mode="r")
    length=np.load(source/"lengths.npy",mmap_mode="r")
    eligible=np.flatnonzero(length>=2)
    if not len(eligible):
        raise ValueError("No histories of at least two interactions")
    out=Path(output_dir) if output_dir else Path("models")/dataset/f"{kind}_L{max_len}"
    out.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(min(4,torch.get_num_threads()))
    if device=="auto": device="cuda" if torch.cuda.is_available() else "cpu"
    model=SequentialRec(len(item_ids),max_len,kind,dim,layers,heads,dropout)
    if semantic_vectors is not None:
        vectors=np.load(semantic_vectors,mmap_mode="r")
        if vectors.shape[0]!=len(item_ids):
            raise ValueError("Semantic vectors are not aligned to movie vocabulary")
        initial=semantic_initialization(vectors,dim,seed)
        with torch.no_grad():
            base=model.token.weight[2:]
            scaled=torch.tensor(initial,dtype=base.dtype)*(.02*dim**0.5)
            base.mul_(1-semantic_mix).add_(scaled*semantic_mix)
        del vectors,initial
    model.to(device)
    optimizer=torch.optim.AdamW(model.parameters(),lr=lr,weight_decay=0.01)
    losses=[]
    t0=time.perf_counter()
    for epoch in range(epochs):
        model.train()
        total=0.
        for step in range(steps_per_epoch):
            us=rng.choice(eligible,size=batch_size,replace=True)
            batch,pos,targets=make_batch(x,length,us,kind,rng)
            negatives_mat=sample_candidate_negatives(targets,len(item_ids),negatives,rng)
            candidates=np.column_stack([targets,negatives_mat]).astype(np.int64)
            tokens=torch.from_numpy(batch).to(device)
            locations=torch.from_numpy(pos).to(device)
            candidate_t=torch.from_numpy(candidates).to(device)
            scores=model.logits(model.hidden_at(tokens,locations),candidate_t)
            target_t=torch.zeros(batch_size,dtype=torch.long,device=device)
            loss=F.cross_entropy(scores,target_t)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(),1.0)
            optimizer.step()
            total+=float(loss.detach().cpu())
        avg=total/steps_per_epoch
        if not np.isfinite(avg):
            raise FloatingPointError("Training loss is non-finite")
        losses.append(round(avg,5))
        print(f"{kind} epoch {epoch+1}/{epochs} sampled-softmax loss={avg:.4f}",flush=True)
    model.eval()
    # Avoid writing executable pickles; weights_only loading is supported.
    cfg={"kind":kind,"n_items":len(item_ids),"max_len":max_len,"dim":dim,
         "layers":layers,"heads":heads,"dropout":dropout}
    torch.save({"weights":model.cpu().state_dict(),"architecture":cfg},out/"weights.pt")
    np.save(out/"item_vectors.npy",model.item_factors())
    np.save(out/"user_ids.npy",np.asarray(user_ids))
    np.save(out/"item_ids.npy",np.asarray(item_ids))
    report={"dataset":dataset,"kind":kind,"architecture":cfg,
            "training_seconds":round(time.perf_counter()-t0,2),"epoch_losses":losses,
            "batch_size":batch_size,"steps_per_epoch":steps_per_epoch,
            "epochs":epochs,"negative_candidates":negatives,"seed":seed,
            "semantic_init":str(semantic_vectors) if semantic_vectors else None,
            "semantic_mix":semantic_mix if semantic_vectors else None,
            "training_objective":"sampled-softmax classification, NOT exact full-vocabulary cross entropy",
            "limitations":"Train histories only; rating times not necessarily viewing times; no globally chronological split"}
    store_json(out/"model.json",report)
    print(f"Saved sequential model: {out}",flush=True)
    return out


def load_model(path,device="cpu"):
    import torch
    folder=Path(path)
    # weights_only=True rejects arbitrary Python object deserialization.
    payload=torch.load(folder/"weights.pt",map_location=device,weights_only=True)
    cfg=payload["architecture"]
    model=SequentialRec(**cfg)
    model.load_state_dict(payload["weights"])
    return model.to(device).eval(),cfg


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--dataset",default="ml-1m")
    p.add_argument("--data-dir",default="data")
    p.add_argument("--kind",choices=["bert4rec","sasrec"],default="bert4rec")
    p.add_argument("--max-len",type=int,default=100)
    p.add_argument("--output-dir",default=None)
    p.add_argument("--dim",type=int,default=64)
    p.add_argument("--layers",type=int,default=2)
    p.add_argument("--heads",type=int,default=4)
    p.add_argument("--dropout",type=float,default=0.2)
    p.add_argument("--epochs",type=int,default=3)
    p.add_argument("--steps-per-epoch",type=int,default=200)
    p.add_argument("--batch-size",type=int,default=64)
    p.add_argument("--negatives",type=int,default=128)
    p.add_argument("--lr",type=float,default=0.0003)
    p.add_argument("--seed",type=int,default=42)
    p.add_argument("--semantic-vectors",default=None)
    p.add_argument("--semantic-mix",type=float,default=0.5)
    p.add_argument("--device",choices=["auto","cpu","cuda"],default="auto")
    print(run(**vars(p.parse_args())))
