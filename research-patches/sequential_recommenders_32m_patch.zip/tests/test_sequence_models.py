"""CPU-only small tests; no datasets or downloads needed."""
import numpy as np
import pytest
from scalable.sequence_data import encode_history_rows
from scalable.sequence_models import (make_batch,make_inference_batch,
                                      sample_candidate_negatives,SequentialRec,
                                      semantic_initialization)
from scalable.sequence_evaluate import fuse_dot_product, compare_ranking
from scalable.sequence_train import run as train_run,load_model
from scipy.sparse import csr_matrix


def synthetic():
    users=np.array([11,22,33,44],dtype=np.int64)
    movies=np.arange(1,17,dtype=np.int64)
    rows=[(11,[1,3,5,7]),(22,[2,4,6,8]),(33,[3,6,9,12]),(44,[4,8,12,16])]
    x,l=encode_history_rows(rows,users,movies,8)
    return x,l,users,movies


def test_sequence_uses_only_supplied_history_and_reserved_tokens():
    x,l,users,movies=synthetic()
    assert x.shape==(4,8)
    assert np.all(x[x>0]>=2)
    for kind in ("bert4rec","sasrec"):
        inp,pos,y=make_batch(x,l,[0,1,2,3],kind,np.random.default_rng(42))
        assert inp.shape==(4,8)
        for i in range(4):
            assert y[i]+2 in x[i]
            assert pos[i]<l[i]+(kind=="bert4rec")
        inf,location=make_inference_batch(x,l,[0,1],kind)
        if kind=="bert4rec":
            assert np.all(inf[np.arange(2),location]==1)
        else:
            assert np.all(inf[np.arange(2),location]>=2)


def test_negatives_do_not_equal_label():
    labels=np.array([0,1,3,7,15])
    negatives=sample_candidate_negatives(labels,16,128,np.random.default_rng(1))
    assert negatives.shape==(5,128)
    assert np.all(negatives!=labels[:,None])
    assert negatives.min()>=0 and negatives.max()<16


def test_bert_bidirectional_vs_sas_causal():
    import torch
    for kind in ("bert4rec","sasrec"):
        model=SequentialRec(16,8,kind,dim=16,layers=1,heads=4,dropout=0)
        model.eval()
        tokens=torch.tensor([[2,3,4,1,0,0,0,0],[3,5,1,0,0,0,0,0]])
        pos=torch.tensor([3,2])
        h=model.hidden_at(tokens,pos)
        assert h.shape==(2,16)
        assert torch.isfinite(h).all()
        score=model.logits(h,torch.tensor([[1,2,3],[4,5,6]]))
        assert score.shape==(2,3)


def test_semantic_init_and_fusion_exact_score():
    rng=np.random.default_rng(7)
    sem=semantic_initialization(rng.normal(size=(16,8)),dim=4)
    assert sem.shape==(16,4)
    s_u=rng.normal(size=(2,3));s_i=rng.normal(size=(6,3))
    b_u=rng.normal(size=(2,5));b_i=rng.normal(size=(6,5))
    Q,I=fuse_dot_product(s_u,s_i,b_u,b_i,0.6)
    expected=(0.6*np.asarray(s_u/np.linalg.norm(s_u,axis=1)[:,None]) @
              np.asarray(s_i/np.linalg.norm(s_i,axis=1)[:,None]).T+
              0.4*np.asarray(b_u/np.linalg.norm(b_u,axis=1)[:,None]) @
              np.asarray(b_i/np.linalg.norm(b_i,axis=1)[:,None]).T)
    np.testing.assert_allclose(Q@I.T,expected,rtol=1e-5,atol=1e-5)


def test_ranking_rejects_leakage():
    q=np.eye(2,dtype=np.float32)
    i=np.array([[1.,0.],[0.,1.],[.5,.5],[.2,.3]],dtype=np.float32)
    seen=csr_matrix(([1,1],([0,1],[0,1])),shape=(2,4))
    with pytest.raises(ValueError,match="leakage"):
        compare_ranking(q[:1],i,seen,[0],[0],{},k=2,index="numpy")
    result=compare_ranking(q,i,seen,[0,1],[1,0],{},k=2,index="numpy")
    assert 0<=result["recall_at_k"]<=1


def test_training_checkpoint_cpu(tmp_path):
    root=tmp_path/"data"/"processed"/"ml-1m"/"sequential_L8"
    root.mkdir(parents=True)
    (root/"manifest.json").write_text('{}')
    x,l,uid,mid=synthetic()
    np.save(root/"sequences.npy",x)
    np.save(root/"lengths.npy",l)
    np.save(root/"user_ids.npy",uid)
    np.save(root/"item_ids.npy",mid)
    for kind in ("bert4rec","sasrec"):
        folder=tmp_path/kind
        train_run(dataset="ml-1m",data_dir=tmp_path/"data",kind=kind,max_len=8,
                  output_dir=folder,dim=8,layers=1,heads=2,epochs=1,
                  steps_per_epoch=2,batch_size=4,negatives=3,device="cpu")
        model,cfg=load_model(folder)
        assert cfg["kind"]==kind
        assert model.item_factors().shape==(16,8)
        assert len(np.load(folder/"user_ids.npy"))==4


def test_end_to_end_sequence_benchmark_on_synthetic_data(tmp_path,monkeypatch):
    """Real train -> checkpoint -> query -> exact ranking without DuckDB/FAISS."""
    from scipy.sparse import save_npz
    from scalable import sequence_evaluate as seqeval
    folder=tmp_path/"data"/"processed"/"ml-1m"/"sequential_L8"
    folder.mkdir(parents=True)
    (folder/"manifest.json").write_text('{}')
    x,l,uid,mid=synthetic()
    for name,value in (("sequences",x),("lengths",l),("user_ids",uid),("item_ids",mid)):
        np.save(folder/f"{name}.npy",value)
    seen=csr_matrix((np.ones(np.count_nonzero(x),dtype=np.uint8),
        (np.repeat(np.arange(4),l),np.concatenate([row[:int(n)]-2 for row,n in zip(x,l)]))),
        shape=(4,16))
    save_npz(folder/"train_seen.npz",seen)
    trained=tmp_path/"models"/"ml-1m"/"bert4rec_L8"
    train_run(dataset="ml-1m",data_dir=tmp_path/"data",kind="bert4rec",max_len=8,
              output_dir=trained,dim=8,layers=1,heads=2,epochs=1,
              steps_per_epoch=2,batch_size=4,negatives=3,device="cpu")
    # Eligible users 0..3, 4 new held-out movies not in training.
    monkeypatch.setattr(seqeval,"_available_targets",
         lambda _root,_split,_uid,_mid: (np.arange(4,dtype=np.int32),
                                         np.array([14,13,12,10],dtype=np.int32)))
    monkeypatch.setattr(seqeval,"_previous_events",
         lambda *_args,**_kwargs: {})
    result=seqeval.run(dataset="ml-1m",data_dir=tmp_path/"data",model_dir=trained,
                       users=4,index="numpy",k=3)
    assert result["results"]["bert4rec"]["users_evaluated"]==4
    assert (trained/"sequence_metrics_validation_numpy_42.json").exists()
