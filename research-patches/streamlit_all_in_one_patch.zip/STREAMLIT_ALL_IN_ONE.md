# All-in-one Streamlit: models + UMAP + MovieLens 1M / 32M

This patch replaces **only** the Streamlit entry point `app.py`, adds two supporting modules, one test file, and an optional UI dependency file. It does **not** retrain, delete, or replace any recommender or any `artifacts/` or `models/` data.

## What you will see

Open the **same** Codespaces forwarded port 8501, and use the tabs:

1. **Recommendations** — Small-data SVD, genre, hybrid, two-tower, LambdaMART, and optional small BPR models.
2. **Choose favorites** — Existing cold-start recommendations.
3. **Model comparison** — One graphical viewer with a dataset selector: MovieLens Small, MovieLens 1M, and MovieLens 32M. Displays NDCG@K, Recall@K, catalog coverage, latency (when available), tabular results, and relevance-vs-coverage plots.
4. **UMAP genre map** — The existing, interactive MovieLens Small movie/genre map and semantic-neighbor explorer.
5. **Methodology** — Dataset and comparison limitations.

**IMPORTANT:** You can't simply combine metrics from separate datasets or runs. The `Model comparison` tab picks **one** consistent 1M/32M unified report at a time. Models without matching checkpoints or evaluation reports remain omitted, rather than showing invented bars. The UMAP map remains a MovieLens **Small** map for now.

## Install in GitHub Codespaces

Upload `streamlit_all_in_one_patch.zip` to your repository at `https://github.com/herberton777/Reco`, then in Codespaces:

```bash
cd /workspaces/Reco
git pull origin main
# Save the current Streamlit app, so you can undo the change:
cp app.py app_backup_before_all_in_one.py
# The ZIP contains paths relative to the repository root.
unzip -o streamlit_all_in_one_patch.zip
python -m pip install -r requirements-all-ui.txt
python -m pytest -q tests/test_streamlit_compare.py
```

To launch the single combined application:

```bash
streamlit run app.py --server.address 0.0.0.0 --server.port 8501
```

Open the **Ports** panel in Codespaces and choose **Open in Browser** for port **8501**. Do not start the old `scalable/unified_dashboard.py` separately.

## When a model doesn't appear in the graph

The UI **does not train models**. It reads existing saved result files:

- **Small:** `artifacts/metrics.json`.
- **1M:** `reports/unified/ml-1m/unified_*.json`.
- **32M:** `reports/unified/ml-32m/unified_*.json`.
- **UMAP map:** `artifacts/umap_movie_map.npz`, matched to `artifacts/recommender.joblib` and its Sentence Transformer embedding matrix.

To generate the **Small** metrics and UMAP map (only if missing):

```bash
python -m src.train
python -m src.semantic
python -m src.build_umap_map
# Optionally add semantic models to Small comparison:
python -m src.benchmark_semantic
```

CAUTION: `src.train` overwrites the **Small** trained model and its report. Don't rerun it if you have already trained and preserved the models you want.

To compare **BERT4Rec and SASRec** in the **same** 1M graphical run, first prepare/train them and the prerequisite 1M BPR model. Then run this single evaluation command:

```bash
python -m scalable.unified_benchmark \
  --dataset ml-1m --users 100 --index flat \
  --bert4rec-dir models/ml-1m/bert4rec_L100 \
  --sasrec-dir models/ml-1m/sasrec_L100
```

This requires the corresponding model checkpoints and the already prepared 1M dataset. The resulting `reports/unified/ml-1m/unified_*.json` is detected automatically by the dashboard. To include a two-tower or semantic BPR model, add its corresponding `--two-tower-dir`, `--semantic-bpr-dir`, `--umap-bpr-dir`, and/or `--semantic-vectors` argument and rerun evaluation. **Only supply paths to checkpoints that really exist and match that dataset.** To include the two-stage LambdaMART experiment, add `--train-ranker`; this computes a ranking model as part of the benchmark and uses extra CPU/RAM.

If 32M BPR training is still crashing, you can already open Streamlit and see the Small graph and UMAP map. Use MovieLens 1M for the new model comparison while fixing 32M training.

## Verification

Run:

```bash
python -m pytest -q tests/test_streamlit_compare.py
```

The integrated source was also checked against the previous small-project tests: **12 passed, 1 skipped** in the test environment. The skip was an optional test dependency. We haven't run 32M model training on your Codespace or asserted any real 32M metrics.

## Revert

```bash
cp app_backup_before_all_in_one.py app.py
```

`joblib` artifacts should be treated as trusted executable serialized files, not downloaded from unknown sources. MovieLens dataset use follows GroupLens conditions.
