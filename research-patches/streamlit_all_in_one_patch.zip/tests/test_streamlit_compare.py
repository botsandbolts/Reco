"""Check dashboard report selection without starting Streamlit or loading models."""
import json
from pathlib import Path
import pytest
from src.streamlit_compare import numeric_metrics, report_paths, read_report, sequence_report_paths


def test_separates_datasets_and_respects_report_metadata(tmp_path):
    parent=tmp_path/"reports"/"unified"
    a=parent/"ml-1m"
    b=parent/"ml-32m"
    a.mkdir(parents=True)
    b.mkdir(parents=True)
    first=a/"unified_validation_flat_seed42.json"
    second=b/"unified_validation_flat_seed42.json"
    report={"dataset":"ml-1m","split":"validation","k":10,"results":{
       "bpr_mf":{"ndcg_at_k":.07,"recall_at_k":.12},
       "bert4rec":{"ndcg_at_k":.09,"recall_at_k":.17}}}
    first.write_text(json.dumps(report))
    second.write_text(json.dumps({**report,"dataset":"ml-32m"}))
    assert report_paths("ml-1m",parent)==[first]
    assert report_paths("ml-32m",parent)==[second]
    assert read_report(first,expected_dataset="ml-1m")["results"]["bert4rec"]["ndcg_at_k"]==.09
    with pytest.raises(ValueError,match="different dataset"):
        read_report(first,expected_dataset="ml-32m")


def test_missing_reports_and_invalid_schemas(tmp_path):
    assert report_paths("ml-1m",tmp_path)==[]
    assert sequence_report_paths("ml-32m",tmp_path)==[]
    file=tmp_path/"bad.json"
    file.write_text(json.dumps({"dataset":"ml-1m","results":{}}))
    with pytest.raises(ValueError,match="split"):
        read_report(file,expected_dataset="ml-1m")


def test_metrics_do_not_invent_missing_models():
    df=numeric_metrics({"svd":{"ndcg_at_k":.3,"recall_at_k":.4},
                        "bert4rec":{"ndcg_at_k":None},
                        "bpr_mf":{"ndcg_at_k":"0.2","recall_at_k":"0.1"}})
    assert set(df.index)=={"svd","bert4rec","bpr_mf"}
    assert df.loc["bpr_mf","ndcg_at_k"]==.2
    assert df.loc["bert4rec","ndcg_at_k"]!=df.loc["bert4rec","ndcg_at_k"]
    assert "sasrec" not in df.index
