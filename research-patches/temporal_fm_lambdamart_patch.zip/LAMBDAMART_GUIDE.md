# FM → LambdaMART second-stage reranking

This patch **adds** LightGBM LambdaMART to the existing `temporal_fm` package.
It does not change `temporal_fm/rank_train.py`, `model.py`, or any existing FM checkpoints.

## Install (GitHub Codespaces)

1. Upload `temporal_fm_lambdamart_patch.zip` to the repository's `main` branch.
2. In the Codespaces terminal, run:

```bash
cd /workspaces/Reco
git fetch origin main
git show origin/main:temporal_fm_lambdamart_patch.zip > temporal_fm_lambdamart_patch.zip
unzip -o temporal_fm_lambdamart_patch.zip
python -m pip install -r requirements-lambdamart.txt
python scripts/install_lambdamart_tab.py
python -m pytest -q tests/test_temporal_lambdamart.py
```

You must have previously installed the Temporal FM, ranking, and pairwise FM patches;
`models/ml-32m/temporal_fm/fm_all_bpr/weights.pt` and the preprocessed temporal
feature caches must already exist in Codespaces.

## Baseline study: validation users kept separate

```bash
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 python -u -m temporal_fm.lambdamart \
  --dataset ml-32m \
  --backend sentence \
  --base-model fm_all_bpr \
  --train-users 700 \
  --eval-users 300 \
  --fm-candidates 500 \
  --pop-candidates 100 \
  --trees 160 \
  --leaves 15 \
  --learning-rate 0.04 \
  --k 10 \
  --run-label initial \
  --device cpu \
  --threads 2
```

This command scores the **full original warm-movie catalogue** for each user to
create actual top-500 FM retrieval candidates plus historical-popularity top-100.
LightGBM *only* reorders the resulting candidate union. It never injects held-out
relevant items into retrieval; doing so would inflate ranking metrics.

It uses up to 700 users in the **validation interval for LambdaMART fitting**
and a separate 300 validation users for reported NDCG. The original FM weights
were fitted on the earlier training interval. User IDs for LambdaMART fitting
and evaluation are disjoint and deterministically sampled. This is a valid
user-disjoint validation experiment, **not** a strictly time-separated training
experiment for the second stage (both groups' target labels are from the same
validation period). No validation events are used for the user/context features:
these are frozen at the original FM train cutoff. The base FM checkpoint itself
may already have been selected using some validation users, so validation-mode
results are exploratory. Use the untouched test period for final assessment.

The same evaluation cohort and original warm-movie catalogue are used for:
`fm_full_catalog`, `popularity_full_catalog`, and `fm_lambdamart`. Since top-10
FM and popularity candidates are guaranteed in the union, both baselines retain
their full-catalogue rankings, while LambdaMART may only change their order.

The command writes a CSV and JSON in `reports/temporal/ml-32m` and saves a
separate LightGBM `.txt` booster under `models/ml-32m/temporal_fm/lambdamart/`.
Run `python scripts/install_lambdamart_tab.py` and then
`streamlit run app.py --server.address 0.0.0.0 --server.port 8501` to view the
new Streamlit panel.

## Tune on validation, then use test only once

For a stronger chronological **validation → test** evaluation (after choosing
features and hyperparameters):

```bash
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 python -u -m temporal_fm.lambdamart \
  --dataset ml-32m \
  --backend sentence \
  --base-model fm_all_bpr \
  --train-users 1200 \
  --eval-users 400 \
  --fm-candidates 500 \
  --pop-candidates 100 \
  --trees 160 \
  --leaves 15 \
  --k 10 \
  --eval-split test \
  --run-label finaltest \
  --device cpu \
  --threads 2
```

Note: both stages use the **frozen original FM training-cutoff snapshot** for
features and retrieval; this is a long-horizon frozen-model evaluation, not
an online model periodically updated with validation interactions.

## Diagnostics

- **Candidate recall:** the maximum Recall attainable by reranking the retrieved pool.
- **Informative ranker groups:** queries with >=1 actually retrieved positive and
  >=1 negative. If too few, increase `--train-users` or `--fm-candidates` rather than
  injecting positives into candidate pools.
- **FM NDCG vs LambdaMART NDCG:** primary ranking comparison.
- **95% paired confidence interval:** bootstrap of same-user NDCG differences.
- **Feature importance:** LightGBM gain for frozen FM, title, genre, tag, historical
  popularity and time features.

All features use data available at the **original FM training cutoff**.
User-tag profiles are constructed from training-positive ratings only. This
feature-engineering choice is different from using observed user tags and does
not expose future ratings.

## Computational resources

MovieLens 32M may require significant CPU time: each fitting/evaluation query
scores the complete warm catalogue before keeping the top ~600 candidates. Start
with `--train-users 100 --eval-users 50 --fm-candidates 300 --pop-candidates 100`
for a functionality check; it may still take time on a two-core Codespace.
Training full MovieLens data or the new LambdaMART model **has not been
executed in ChatGPT**: only synthetic tests have been run.
