"""Integrate LambdaMART report panel without replacing any Streamlit code."""
from pathlib import Path
import argparse


def install(app='app.py'):
    target = Path(app)
    if not target.is_file():raise FileNotFoundError(target)
    original = target.read_text(encoding='utf-8')
    if 'render_lambdamart_dashboard()' in original:
        print('LambdaMART tab already installed')
        return False
    anchors = ('    render_shared_benchmark()', '    render_temporal_lab()')
    anchor = next((a for a in anchors if original.count(a)==1), None)
    if anchor is None:
        raise ValueError('Cannot locate one Streamlit Temporal FM call; app.py unchanged. '
                         'Install the existing Temporal FM and shared benchmark tabs first.')
    insertion = (anchor+'\n    from temporal_fm.lambdamart_dashboard import render_lambdamart_dashboard\n'
                 '    render_lambdamart_dashboard()')
    backup = target.with_name('app.before_lambdamart.py')
    if not backup.exists():backup.write_text(original, encoding='utf-8')
    target.write_text(original.replace(anchor,insertion,1), encoding='utf-8')
    print('LambdaMART tab installed; backup:', backup)
    return True

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--app',default='app.py')
    install(p.parse_args().app)
