"""LightGBM LambdaMART second-stage reranking for Temporal FM.

Frozen training-cutoff features; user-disjoint validation training/evaluation
or validation->test. Candidate lists are retrieved by the frozen FM and
training-only popularity; held-out positives are NEVER injected.

python -m temporal_fm.lambdamart --dataset ml-32m --base-model fm_all_bpr \
    --train-users 700 --eval-users 300 --fm-candidates 500 --pop-candidates 100
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
import torch

from .data import Events
from .train import FeatureProvider
from .ranking import _cohort, _model, _ranking_scores, score_candidates

FEATURE_NAMES = [
    'fm_score', 'fm_rank_percentile', 'log_train_movie_popularity',
    'genre_affinity', 'title_similarity', 'tag_similarity',
    'movie_age_years', 'log_user_history_count', 'user_positive_fraction',
    'log_user_positive_count', 'candidate_from_pop_top', 'has_historical_tags',
]


def _unit_rows(array):
    data = np.asarray(array, dtype=np.float32)
    norm = np.linalg.norm(data, axis=1, keepdims=True)
    return data / np.maximum(norm, 1e-8)


def _train_user_likes(ev, wanted, threshold, chunk_size=200_000):
    """Training-period positive movie IDs only; no held-out event in features."""
    result = {int(u): [] for u in wanted}
    wanted_array = np.asarray(list(wanted), dtype=np.int32)
    for offset in range(0, len(ev.split('train')), chunk_size):
        batch = np.asarray(ev.split('train')[offset:offset + chunk_size], dtype=np.int64)
        raw = np.asarray(ev.user_raw[batch], dtype=np.int32)
        good = np.isin(raw, wanted_array) & (np.asarray(ev.rating[batch]) >= threshold)
        for u, movie in zip(raw[good], np.asarray(ev.movie_idx[batch[good]], dtype=np.int32)):
            result[int(u)].append(int(movie))
    return {u: np.asarray(sorted(set(items)), dtype=np.int32) for u, items in result.items()}


class Snapshot:
    """Features derived exclusively from the original FM train-time snapshot."""
    def __init__(self, ev, provider, users, histories, movie_pop, positive_threshold, cutoff):
        self.ev = ev
        self.movie_pop = np.asarray(movie_pop, dtype=np.int64)
        self.cutoff = int(cutoff)
        self.histories = histories
        self.title = _unit_rows(provider.title)
        self.genre = _unit_rows(ev.genre_matrix)
        self.tag = _unit_rows(provider.tags.lookup(np.arange(len(ev.movies), dtype=np.int32),
                                                  np.full(len(ev.movies), self.cutoff, dtype=np.int64)))
        self.title_affinity = {}
        self.genre_affinity = {}
        self.tag_affinity = {}
        self.pos_rate = {}
        self.n_pos = {}
        likes = _train_user_likes(ev, users, positive_threshold)
        for u in users:
            pos = likes[int(u)]
            self.n_pos[int(u)] = len(pos)
            self.pos_rate[int(u)] = len(pos) / max(1, len(histories[int(u)]))
            for matrix, dest in ((self.title, self.title_affinity),
                                 (self.genre, self.genre_affinity),
                                 (self.tag, self.tag_affinity)):
                profile = matrix[pos].mean(0) if len(pos) else np.zeros(matrix.shape[1], np.float32)
                denom = max(float(np.linalg.norm(profile)), 1e-8)
                dest[int(u)] = profile / denom

    def features(self, user, candidates, scores, fm_order, pop_retrieved):
        candidates = np.asarray(candidates, dtype=np.int32)
        count = len(candidates)
        u = int(user)
        years = int(np.datetime64(self.cutoff, 's').astype('datetime64[Y]').astype(int) + 1970)
        ages = np.where(self.ev.release_year[candidates] > 0,
                        np.maximum(0, years - self.ev.release_year[candidates]), 0)
        fm_percentile = np.asarray(fm_order, dtype=np.float32) / max(1, count - 1)
        return np.column_stack([
            np.asarray(scores, dtype=np.float32), fm_percentile,
            np.log1p(self.movie_pop[candidates]).astype(np.float32),
            self.genre[candidates] @ self.genre_affinity[u],
            self.title[candidates] @ self.title_affinity[u],
            self.tag[candidates] @ self.tag_affinity[u],
            np.asarray(ages, dtype=np.float32),
            np.full(count, np.log1p(len(self.histories[u])), dtype=np.float32),
            np.full(count, self.pos_rate[u], dtype=np.float32),
            np.full(count, np.log1p(self.n_pos[u]), dtype=np.float32),
            np.isin(candidates, pop_retrieved).astype(np.float32),
            (np.linalg.norm(self.tag[candidates], axis=1) > 0).astype(np.float32),
        ]).astype(np.float32)


def retrieve(scores, unseen, movie_pop, fm_candidates, pop_candidates):
    """Retrieve *only* model/past-popularity candidates; never inject labels."""
    unseen = np.asarray(unseen, dtype=np.int32)
    scores = np.asarray(scores, dtype=np.float32)
    if not len(unseen):
        return np.empty(0, np.int32), np.empty(0, np.float32), np.empty(0, np.int32), np.empty(0, np.int32)
    n = min(int(fm_candidates), len(unseen))
    best = np.argsort(-scores, kind='stable')[:n]
    if pop_candidates:
        pop_best = np.argsort(-movie_pop[unseen], kind='stable')[:min(pop_candidates, len(unseen))]
    else:
        pop_best = np.empty(0, dtype=np.int64)
    # Candidate pool in sorted movie-index order; all features use this order.
    indices = np.unique(np.concatenate([best, pop_best]))
    mids = unseen[indices]
    vals = scores[indices]
    order = np.argsort(np.argsort(-vals, kind='stable'), kind='stable')
    return mids, vals, order.astype(np.int32), unseen[pop_best]


def _split_validation_users(users, train_users, eval_users, seed):
    rng = np.random.default_rng(seed + 9821)
    ids = np.asarray(users, dtype=np.int32).copy()
    rng.shuffle(ids)
    n_train = min(int(train_users), max(0, len(ids) - 1))
    a = [int(u) for u in ids[:n_train]]
    b = [int(u) for u in ids[n_train:n_train + int(eval_users)]]
    if not a or not b:
        raise ValueError('Insufficient validation users for user-disjoint LambdaMART training/evaluation')
    return a, b


def _aggregate(metrics, rankings, catalog_size):
    if not metrics:
        raise ValueError('No users were evaluated')
    result = {key: round(float(np.mean([m[key] for m in metrics])), 6)
              for key in ('ndcg_at_k', 'recall_at_k', 'precision_at_k', 'hit_rate_at_k',
                          'mrr_at_k', 'map_at_k', 'genre_diversity_at_k', 'novelty_bits_at_k')}
    result['users'] = len(metrics)
    result['catalog_coverage_at_k'] = round(len(rankings) / max(1, catalog_size), 6)
    return result


def _paired_bootstrap(a, b, seed=42, samples=500):
    x = np.asarray(a, dtype=np.float64) - np.asarray(b, dtype=np.float64)
    rng = np.random.default_rng(seed)
    means = np.asarray([x[rng.integers(0, len(x), len(x))].mean() for _ in range(samples)])
    return {'delta_ndcg_at_k': round(float(x.mean()), 6),
            'ci95_low': round(float(np.quantile(means, .025)), 6),
            'ci95_high': round(float(np.quantile(means, .975)), 6), 'users': len(x)}


def _assemble_query(user, history, truth, catalog, movie_pop, model, ev, provider, snapshot,
                    fm_candidates, pop_candidates, device, batch_size):
    unseen = np.setdiff1d(catalog, np.asarray(sorted(history), dtype=np.int32), assume_unique=True)
    if len(unseen) < 1:
        return None
    # Score EVERY warm movie before candidate selection. This preserves full-catalogue FM top-K.
    fm_scores = score_candidates(model, ev, provider, user, unseen, snapshot.cutoff,
                                 device=device, batch_size=batch_size)
    mids, vals, ranks, pop_items = retrieve(fm_scores, unseen, movie_pop, fm_candidates, pop_candidates)
    X = snapshot.features(user, mids, vals, ranks, pop_items)
    labels = np.isin(mids, np.asarray(sorted(truth), dtype=np.int32)).astype(np.int32)
    return {'user': user, 'movie_indices': mids, 'features': X, 'labels': labels,
            'fm_scores': vals, 'pop_scores': np.log1p(movie_pop[mids]),
            'relevant_total': len(truth), 'retrieved_relevant': int(labels.sum()),
            'eligible_catalog_size': len(unseen)}


def _prepare(ev, backend):
    feature_dir = ev.folder / f'features_{backend}'
    meta_path = feature_dir / 'meta.json'
    if not meta_path.exists():
        raise FileNotFoundError(f'Missing {meta_path}; train the FM model first')
    meta = json.loads(meta_path.read_text())
    tag_dir = feature_dir if (feature_dir / 'tag_keys.npy').exists() else None
    if bool(ev.meta['tags_path']) != bool(tag_dir):
        raise ValueError('Historical tag features missing: rebuild the Temporal FM features')
    provider = FeatureProvider(ev, backend, meta['model_name'], tag_dir)
    provider.model_name = meta['model_name']
    return provider


def run(dataset='ml-32m', data_dir='data', backend='sentence', base_model='fm_all_bpr',
        train_users=700, eval_users=300, fm_candidates=500, pop_candidates=100,
        threshold=4., min_history=5, k=10, seed=42, eval_split='validation',
        device='cpu', threads=2, batch_size=2048, trees=160, leaves=15,
        learning_rate=0.04, run_label='initial', force_retrain=False):
    try:
        import lightgbm as lgb
    except ImportError as exc:
        raise ImportError('LightGBM is required: pip install -r requirements-lambdamart.txt') from exc
    if train_users < 1 or eval_users < 1 or fm_candidates < k or pop_candidates < k:
        raise ValueError('Positive user counts and candidate counts >= k are required')
    if eval_split not in ('validation', 'test'):
        raise ValueError('eval_split must be validation or test')
    if not (0.5 <= threshold <= 5) or k < 1 or trees < 1:
        raise ValueError('Invalid threshold, k or trees')
    if not run_label.replace('_', '').replace('-', '').isalnum():
        raise ValueError('run-label must contain only letters, digits, hyphens, underscores')
    if device == 'cuda' and not torch.cuda.is_available():
        raise ValueError('CUDA requested but not available')
    torch.set_num_threads(max(1, threads))
    ev = Events(Path(data_dir) / 'temporal' / dataset)
    provider = _prepare(ev, backend)
    model = _model(ev, provider, base_model, backend, device, seed=seed)
    print('Loading historical cohort and frozen features...', flush=True)
    if eval_split == 'validation':
        all_users, histories, truths, popularity, stats = _cohort(
            ev, 'validation', threshold, train_users + eval_users, min_history, seed)
        train_ids, eval_ids = _split_validation_users(all_users, train_users, eval_users, seed)
        train_histories = eval_histories = histories
        train_truths = eval_truths = truths
    else:
        train_ids, train_histories, train_truths, popularity, stats = _cohort(
            ev, 'validation', threshold, train_users, min_history, seed)
        eval_ids, eval_histories, eval_truths, _, eval_stats = _cohort(
            ev, 'test', threshold, eval_users, min_history, seed + 4)
        stats['test_cohort'] = eval_stats
        print('TEST EVALUATION: only use after selecting LambdaMART configuration.', flush=True)
    if len(train_ids) < 4:
        raise ValueError('Need at least four ranker training users; increase --train-users or lower --min-history')
    catalog = np.flatnonzero(ev.movie_has_train).astype(np.int32)
    cutoff = int(ev.meta['train_cutoff']) + 1
    # Ensure model inputs and ranker features are snapshotted before validation/test events.
    all_hist = {**train_histories, **eval_histories}
    snapshot = Snapshot(ev, provider, sorted(set(train_ids + eval_ids)), all_hist, popularity,
                        threshold, cutoff)
    print(f'Building actual FM retrieval lists: {len(train_ids)} train queries; '
          f'{len(eval_ids)} held-out queries. Warm catalogue: {len(catalog):,}', flush=True)
    train_groups = []
    blocks = []
    targets = []
    train_coverage = []
    for index, u in enumerate(train_ids, 1):
        row = _assemble_query(u, train_histories[u], train_truths[u], catalog, popularity,
                              model, ev, provider, snapshot, fm_candidates, pop_candidates,
                              device, batch_size)
        if row is None:
            continue
        train_coverage.append(row['retrieved_relevant'] / max(1, row['relevant_total']))
        if row['retrieved_relevant'] == 0 or row['retrieved_relevant'] == len(row['labels']):
            continue  # No positive/negative pair in retrieval candidates for this query.
        blocks.append(row['features'])
        targets.append(row['labels'])
        train_groups.append(len(row['labels']))
        if index % 50 == 0:
            print(f'  train queries {index}/{len(train_ids)}; informative groups={len(train_groups)}', flush=True)
    if len(train_groups) < 5:
        raise ValueError(f'Only {len(train_groups)} train queries contain retrieved positives. '
                         'Increase --train-users, --fm-candidates and/or --pop-candidates; '
                         'never inject held-out positives into candidates.')
    X = np.concatenate(blocks, axis=0)
    y = np.concatenate(targets, axis=0)
    print(f'LambdaMART training on {len(train_groups)} informative user queries, '
          f'{len(y):,} actual retrieved candidates; positives={int(y.sum())}', flush=True)
    config = {'dataset': dataset, 'base_model': base_model, 'train_cutoff': ev.meta['train_cutoff'],
              'val_cutoff': ev.meta['val_cutoff'], 'sources': ev.meta['sources'],
              'backend': backend, 'seed': seed, 'train_users': train_users,
              'eval_users': eval_users, 'fm_candidates': fm_candidates,
              'pop_candidates': pop_candidates, 'threshold': threshold, 'k': k,
              'eval_split': eval_split, 'trees': trees, 'leaves': leaves,
              'learning_rate': learning_rate, 'run_label': run_label,
              'feature_names': FEATURE_NAMES}
    key = hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest()[:12]
    outdir = Path('models') / dataset / 'temporal_fm' / 'lambdamart' / f'{run_label}_{key}'
    outdir.mkdir(parents=True, exist_ok=True)
    ranker_path = outdir / 'model.txt'
    if ranker_path.exists() and not force_retrain:
        print('Reusing matching LambdaMART booster:', ranker_path, flush=True)
        ranker = lgb.Booster(model_file=str(ranker_path))
    else:
        ranker = lgb.LGBMRanker(objective='lambdarank', metric='ndcg', n_estimators=trees,
                                learning_rate=learning_rate, num_leaves=leaves,
                                min_child_samples=20, colsample_bytree=0.9,
                                reg_lambda=2.0, verbosity=-1, n_jobs=max(1, threads),
                                lambdarank_truncation_level=k+3, label_gain=[0,1], random_state=seed)
        ranker.fit(X, y, group=train_groups, feature_name=FEATURE_NAMES, eval_at=[k])
        ranker.booster_.save_model(str(ranker_path))
        ranker = ranker.booster_
    (outdir / 'metadata.json').write_text(json.dumps({**config, 'informative_groups':len(train_groups),
                                'training_positive_candidates':int(y.sum())}, indent=2))
    predictions = {'fm_full_catalog': [], 'popularity_full_catalog': [], 'fm_lambdamart': []}
    coverage = {name: set() for name in predictions}
    per_ndcg = {name: [] for name in predictions}
    examples = {name:{} for name in predictions}
    total_retrieved = 0
    total_relevant = 0
    eval_query_count = 0
    for index, u in enumerate(eval_ids, 1):
        row = _assemble_query(u, eval_histories[u], eval_truths[u], catalog, popularity,
                              model, ev, provider, snapshot, fm_candidates, pop_candidates,
                              device, batch_size)
        if row is None:continue
        total_retrieved += row['retrieved_relevant']
        total_relevant += row['relevant_total']
        eval_query_count += 1
        # pop top-k is guaranteed to be in retrieved union because pop_candidates >= k.
        scores_by_model = {'fm_full_catalog':row['fm_scores'],
                           'popularity_full_catalog':row['pop_scores'],
                           'fm_lambdamart':ranker.predict(row['features'], num_threads=max(1, threads))}
        for name, scores in scores_by_model.items():
            ordered = np.argsort(-scores, kind='stable')[:k]
            picked = row['movie_indices'][ordered]
            m = _ranking_scores(picked, eval_truths[u], k, ev.genre_matrix, popularity,
                                int(ev.meta['splits']['train']))
            predictions[name].append(m)
            coverage[name].update(map(int,picked))
            per_ndcg[name].append(m['ndcg_at_k'])
            if len(examples[name]) < 5:
                examples[name][str(u)] = {
                    'history_size':len(eval_histories[u]),
                    'positive_count':len(eval_truths[u]),
                    'recommendations':[
                        {'rank':pos+1, 'movieId':int(ev.movies.iloc[int(movie)]['movieId']),
                         'title':str(ev.movies.iloc[int(movie)]['title']),
                         'score':round(float(scores[ordered[pos]]),5),
                         'relevant':bool(movie in eval_truths[u])}
                        for pos,movie in enumerate(picked)
                    ]}
        if index % 50 == 0:
            print(f'  eval users {index}/{len(eval_ids)}', flush=True)
    if not eval_query_count:
        raise ValueError('No users could be evaluated')
    metrics = {key:_aggregate(vals, coverage[key],len(catalog)) for key,vals in predictions.items()}
    comparison = _paired_bootstrap(per_ndcg['fm_lambdamart'], per_ndcg['fm_full_catalog'], seed)
    report = {
        'dataset':dataset, 'base_model':base_model, 'split':eval_split,
        'k':k, 'positive_threshold':threshold, 'evaluated_users':eval_query_count,
        'train_ranker_users':len(train_ids), 'informative_ranker_users':len(train_groups),
        'train_cutoff':int(ev.meta['train_cutoff']), 'evaluation_timestamp':cutoff,
        'candidate_policy':'FM-top + historical-popularity-top (NO label injection)',
        'fm_candidates':fm_candidates, 'pop_candidates':pop_candidates,
        'candidate_recall':round(total_retrieved/max(1,total_relevant),6),
        'train_candidate_recall':round(float(np.mean(train_coverage)),6),
        'catalogue_size':len(catalog), 'seed':seed,
        'training_queries_and_evaluation_queries_disjoint': eval_split=='validation',
        'metrics':metrics, 'paired_delta_ndcg_vs_fm': comparison,
        'examples':examples, 'ranker_path':str(ranker_path),
        'feature_importance_gain': dict(zip(FEATURE_NAMES, map(float,ranker.feature_importance('gain')))),
        'caveats':[
            'FM and popularity baselines retain their full-catalogue top-K within the retrieved union.',
            'LambdaMART can only reorder retrieved candidates; it cannot recover missing relevant items.',
            'Unrated candidate movies are unobserved, not necessarily negative.',
            'All user profile, popularity, title, genre and tag features freeze at original FM training cutoff.',
            'Validation-mode LambdaMART fitting and evaluation queries are disjoint by user, but their target ratings come from the same validation time window.',
            'The base FM checkpoint may itself have been selected with validation metrics, so reserve test for final generalization assessment.',
            'Test mode fits on validation users and evaluates later test events; use once after selecting settings.',
            'The FM checkpoint was trained without LambdaMART; no original FM weights are modified.'
        ]
    }
    path = Path('reports') / 'temporal' / dataset / f'lambdamart_{eval_split}_{run_label}_{key}.json'
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2))
    with path.with_suffix('.csv').open('w', newline='') as fp:
        writer=csv.DictWriter(fp, fieldnames=['model',*next(iter(metrics.values())).keys()])
        writer.writeheader()
        for name, value in metrics.items():writer.writerow({'model':name,**value})
    print('Results on identical user cohort and catalogue:', flush=True)
    for name, value in metrics.items():
        print(f'  {name:24} NDCG@{k}={value["ndcg_at_k"]:.4f} '
              f'Recall@{k}={value["recall_at_k"]:.4f} '
              f'HitRate@{k}={value["hit_rate_at_k"]:.4f}', flush=True)
    print('Candidate recall:', report['candidate_recall'], flush=True)
    print('Report:', path, flush=True)
    return report


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset', default='ml-32m')
    p.add_argument('--data-dir', default='data')
    p.add_argument('--backend', choices=['sentence','hash'], default='sentence')
    p.add_argument('--base-model', default='fm_all_bpr')
    p.add_argument('--train-users', type=int, default=700)
    p.add_argument('--eval-users', type=int, default=300)
    p.add_argument('--fm-candidates', type=int, default=500)
    p.add_argument('--pop-candidates', type=int, default=100)
    p.add_argument('--threshold', type=float, default=4.)
    p.add_argument('--min-history', type=int, default=5)
    p.add_argument('--k', type=int, default=10)
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--eval-split', choices=['validation','test'], default='validation')
    p.add_argument('--device', choices=['cpu','cuda'], default='cpu')
    p.add_argument('--threads', type=int, default=2)
    p.add_argument('--batch-size', type=int, default=2048)
    p.add_argument('--trees', type=int, default=160)
    p.add_argument('--leaves', type=int, default=15)
    p.add_argument('--learning-rate', type=float, default=.04)
    p.add_argument('--run-label', default='initial')
    p.add_argument('--force-retrain', action='store_true')
    return run(**vars(p.parse_args(argv)))

if __name__ == '__main__':main()
