"""Read-only Streamlit panel for second-stage FM + LambdaMART comparisons."""
from pathlib import Path
import json


def render_lambdamart_dashboard():
    import streamlit as st
    import pandas as pd
    st.divider()
    st.subheader('LambdaMART reranking (Temporal FM)')
    st.caption('LightGBM LambdaRank learns to reorder movies retrieved by your frozen FM. '
               'FM and historical popularity are rescored for the same users and catalogue.')
    dataset = st.selectbox('LambdaMART dataset', ['ml-32m','ml-1m','ml-latest-small'], key='lm_ds')
    reports = sorted((Path('reports')/'temporal'/dataset).glob('lambdamart_*.json'),
                     key=lambda p:p.stat().st_mtime, reverse=True)
    if not reports:
        st.info('Train/evaluate LambdaMART in the terminal first.')
        st.code(f'python -m temporal_fm.lambdamart --dataset {dataset} '
                '--base-model fm_all_bpr --train-users 700 --eval-users 300 '
                '--fm-candidates 500 --pop-candidates 100 --threads 2', language='bash')
        return
    selected = st.selectbox('Evaluation report', reports, format_func=lambda p:p.name, key='lm_file')
    report = json.loads(selected.read_text())
    st.caption(f"{report['split']} · {report['evaluated_users']} held-out users · "
               f"{report['catalogue_size']:,} warm-catalogue movies · "
               f"top-{report['k']} · FM checkpoint: {report['base_model']}")
    if report['split'] == 'test':
        st.warning('Test set results: reserve this split for final model assessment.')
    frame = pd.DataFrame.from_dict(report['metrics'], orient='index')
    metric = st.selectbox('Ranking metric',
                          [key for key in ['ndcg_at_k', 'recall_at_k', 'hit_rate_at_k',
                                          'mrr_at_k', 'precision_at_k', 'catalog_coverage_at_k',
                                          'genre_diversity_at_k'] if key in frame], key='lm_metric')
    st.bar_chart(frame[[metric]].sort_values(metric,ascending=False))
    st.dataframe(frame.sort_values('ndcg_at_k',ascending=False), use_container_width=True)
    st.metric('Recall upper bound of retrieved candidates', f"{report['candidate_recall']:.2%}")
    st.caption('The ranker cannot recover relevant movies missing from the retrieved FM/popularity pool.')
    st.markdown('#### Paired NDCG@K vs. original FM')
    st.json(report['paired_delta_ndcg_vs_fm'], expanded=False)
    importances = pd.Series(report.get('feature_importance_gain', {}), name='LightGBM gain')
    if not importances.empty:
        st.markdown('#### LambdaMART feature importance')
        st.bar_chart(importances.sort_values(ascending=False))
    with st.expander('Example top-K recommendations'):
        model = st.selectbox('Model', list(report['examples']), key='lm_example_model')
        options = list(report['examples'][model])
        if options:
            uid = st.selectbox('MovieLens user', options, key='lm_example_user')
            st.dataframe(pd.DataFrame(report['examples'][model][uid]['recommendations']),
                         hide_index=True, use_container_width=True)
    with st.expander('Validity and limitations'):
        for caveat in report.get('caveats', []):st.write('•', caveat)

if __name__ == '__main__':render_lambdamart_dashboard()
