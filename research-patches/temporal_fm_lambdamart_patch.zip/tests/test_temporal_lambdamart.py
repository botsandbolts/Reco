import json
from pathlib import Path
import numpy as np
import pandas as pd
import pytest

from temporal_fm.lambdamart import retrieve, _split_validation_users, run


def test_retrieve_no_label_injection():
    mids=np.arange(20,dtype=np.int32)
    scores=np.linspace(0,1,20,dtype=np.float32)
    pop=np.arange(20,dtype=np.int64)[::-1]
    cand,s,order,pc=retrieve(scores,mids,pop,5,4)
    assert set(cand)==set(list(range(4))+list(range(15,20)))
    assert len(cand)==9 and np.all(np.isfinite(s))
    assert np.array_equal(np.sort(pc),np.arange(4))
    assert len(set(map(int,order)))==len(order)


def test_disjoint_ranker_cohorts():
    a,b=_split_validation_users(list(range(200)),60,30,42)
    assert len(a)==60 and len(b)==30 and not set(a)&set(b)
    aa,bb=_split_validation_users(list(range(200)),60,30,42)
    assert a==aa and b==bb


def test_streamlit_installer_idempotent(tmp_path):
    from scripts.install_lambdamart_tab import install
    app=tmp_path/'app.py'
    app.write_text('def run():\n    render_temporal_lab()\n')
    assert install(app)
    assert not install(app)
    assert 'render_lambdamart_dashboard()' in app.read_text()
    assert (tmp_path/'app.before_lambdamart.py').exists()


def test_end_to_end_synthetic_query_groups(tmp_path,monkeypatch):
    pytest.importorskip('lightgbm')
    from temporal_fm.data import prepare
    from temporal_fm.rank_train import train
    raw=tmp_path/'data/raw/ml-latest-small'
    raw.mkdir(parents=True)
    n_users=55;n_movies=260
    pd.DataFrame({'movieId':np.arange(1,n_movies+1),
                  'title':[f'Film {i} (2000)' for i in range(n_movies)],
                  'genres':['Action|Comedy' if i%2 else 'Drama|Romance' for i in range(n_movies)]}).to_csv(raw/'movies.csv',index=False)
    rows=[]
    # Every user has data before and after the global cutoff.
    rng=np.random.default_rng(441)
    for i in range(5500):
        user=i%n_users+1
        movie=int(rng.integers(1,n_movies+1))
        rows.append((user,movie,5. if i%5 != 0 else 2.,1_450_000_000+i*3600))
    pd.DataFrame(rows,columns=['userId','movieId','rating','timestamp']).to_csv(raw/'ratings.csv',index=False)
    pd.DataFrame({'movieId':[1,2,3,4], 'tag':['funny','romantic','dramatic','action'],
                  'timestamp':[1_450_000_000,1_450_000_300,1_450_000_600,1_450_000_900]}).to_csv(raw/'tags.csv',index=False)
    monkeypatch.chdir(tmp_path)
    train(dataset='ml-latest-small',data_dir='data',models='fm',profile='quick',
          text_backend='hash',validation_users=8,validation_candidates=30,
          tag_dims=12,threads=1,negatives=1)
    out=run(dataset='ml-latest-small', data_dir='data', backend='hash',
            train_users=20,eval_users=10, fm_candidates=140,pop_candidates=25,
            base_model='fm_all_bpr',k=5, trees=15,leaves=7,
            device='cpu',threads=1,batch_size=64,run_label='smoke')
    assert out['evaluated_users']>0
    assert 0<=out['candidate_recall']<=1
    assert out['informative_ranker_users']>=5
    assert set(out['metrics'])=={'fm_full_catalog','popularity_full_catalog','fm_lambdamart'}
    for v in out['metrics'].values():
        assert 0<=v['ndcg_at_k']<=1
    assert Path(out['ranker_path']).exists()
    assert list(Path('reports/temporal/ml-latest-small').glob('lambdamart_validation_*.json'))
