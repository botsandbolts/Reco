# Pairwise ranking upgrade for Temporal FM / DeepFM

Adds BPR (Bayesian Personalized Ranking) training to the already-installed `temporal_fm` project, preserving the title Sentence Transformer embeddings, binary genres, historical tag embeddings, and timestamp-derived features. This is a **ranking** model, rather than a rating-prediction (RMSE) model. Existing regression checkpoints remain unchanged.

## Install in GitHub Codespaces

After uploading `temporal_fm_pairwise_ranking_patch.zip` to the repository via GitHub web UI:

```bash
cd /workspaces/Reco
git fetch origin main
git show origin/main:temporal_fm_pairwise_ranking_patch.zip > temporal_fm_pairwise_ranking_patch.zip
unzip -o temporal_fm_pairwise_ranking_patch.zip
python scripts/install_pairwise_fm.py
python -m pytest -q tests/test_pairwise_fm.py
```

Prerequisites: The earlier `temporal_hybrid_fm_patch.zip`, `temporal_fm_ranking_patch.zip` and `fm_shared_comparison_patch.zip` must already have been extracted. Verify with `python -m temporal_fm.shared_benchmark --help`. No original file is replaced by the ZIP; the installer inserts a tiny idempotent loader hook into `temporal_fm/ranking.py` (with a backup).

## Prepare data

The original MovieLens 32M files must be at `data/raw/ml-32m/{ratings,movies,tags}.csv`. Run the previous ingestion preparation once if not done. The rank trainer will reuse on-disk feature and tag stores if they match input signatures.

## Run a smoke test on 1M first (1M has no native tags)

```bash
python -m temporal_fm.rank_train \
  --dataset ml-1m --text-backend sentence \
  --models fm --profile quick --device cpu --threads 2
```

## Actual MovieLens 32M training

```bash
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 \
python -u -m temporal_fm.rank_train \
  --dataset ml-32m \
  --text-backend sentence \
  --models fm \
  --ablation all \
  --profile research \
  --positive-threshold 4 \
  --negatives 2 \
  --pop-negative-share 0.6 \
  --device cpu --threads 2
```

Add `--warm-start` to **attempt** initialization from an existing `fm_all` regression checkpoint with the same dataset, metadata and dimensionality. Otherwise, the ranking model trains from scratch. Add `--force-retrain` only to replace an existing BPR ranking checkpoint; the regression model stays untouched.

The **research** preset uses up to 15 epochs × 450 steps × 256 positive samples/step × 2 negatives/positive. It samples from the full set of training-period positive events instead of making one complete pass over all 32M ratings. Validation selects the best checkpoint via NDCG@10 on a **fixed sampled candidate pool** (32 users, 512 candidates/user). That validation score is **NOT comparable** with full-catalogue NDCG@10.

For a stronger training run after validating the result, use `--profile intensive`; this uses 30 epochs, 900 steps/epoch, 384 positives/step and 60 validation users with 1024 sampled candidates. CPU training and feature generation at 32M scale can consume significant memory and time. Don't request both FM and DeepFM simultaneously in a memory-constrained Codespace; train separately.

## Fair recommendation evaluation (full warm-item catalogue)

The existing **shared chronological benchmark** will automatically accept `fm_all_bpr` after the installer runs:

```bash
python -u -m temporal_fm.shared_benchmark \
  --dataset ml-32m --backend sentence \
  --models fm_all_bpr,fm_all \
  --users 100 --k 10 \
  --positive-threshold 4 --profile quick \
  --split validation --device cpu --threads 2
```

`fm_all` is optional: omit it if you have no trained FM rating-regression checkpoint. Fresh chronological SVD/BPR baselines and popularity use the same train cutoff, users and catalogue. `--profile quick` above controls **only the newly fitted SVD/BPR baselines**, not the profile of `fm_all_bpr`. Set it to `research` to fit stronger SVD/BPR baselines. Results and example recommendations appear under **Temporal FM / DeepFM → Shared-cutoff recommendation benchmark** in Streamlit.

For DeepFM, change training to `--models deepfm`, and add `deepfm_all_bpr` to the benchmark's comma-separated `--models` argument.

### Notes on scientific validity

- BPR optimizes `mean(softplus(s(u,negative,t) - s(u,positive,t)))` with a positive defined by `rating >= 4`, not observed star-value regression.
- Sampled negatives are warm-training-catalogue movies **never rated by the same user during training**; this doesn't make them verified negative feedback. A 60% share of negative proposals comes from a smoothed popularity distribution, the other 40% uniform. A movie released after the positive event is rejected.
- Both positive and negative features use the *same historical positive-event timestamp*. Movie tags with timestamps greater than or equal to that time are excluded by `TagStore`.
- Validation/test user interactions are not used for training or negative sampling. The trainer's checkpoint selection uses validation only; use `--split test` on the full benchmark only once, after model selection.
- MovieLens 32M contains user-submitted timestamps, which are **not verified viewing times**.
- NDCG/Recall/Precision/Hit Rate measured against later observed ratings are offline proxies for recommendation quality; they are subject to missing-exposure bias.
- Unlike published BPR, this hybrid FM has a richer feature space; this is a hybrid pairwise FM experiment, not a reproduction of a specific paper.

### Streamlit

```bash
streamlit run app.py --server.address 0.0.0.0 --server.port 8501
```

Check the shared chronological benchmark comparison report. The ranking model is named `fm_all_bpr` (or `deepfm_all_bpr`), separate from `fm_all` trained using MSE.
