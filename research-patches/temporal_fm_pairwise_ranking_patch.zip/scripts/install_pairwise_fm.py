"""Idempotently allow existing ranking/shared benchmark code to load *_bpr FM models.

No source files are overwritten by the ZIP; only one explicit loader hook is inserted.
"""
from pathlib import Path
import argparse

MARK='    # PAIRWISE_FM_CHECKPOINT_LOADER_v1\n'
BLOCK=(MARK+
       '    if name.endswith("_bpr"):\n'
       '        from .rank_checkpoint import load_bpr_checkpoint\n'
       '        return load_bpr_checkpoint(ev, provider, name, backend, device, seed=seed)\n')


def install(path=Path('temporal_fm/ranking.py')):
    path=Path(path)
    if not path.is_file():raise FileNotFoundError(f'Missing {path}; install temporal_fm_ranking_patch.zip first')
    src=path.read_text()
    if MARK in src:return False
    anchor='def _model(ev, provider, name, backend, device, profile=None, seed=None):\n'
    if src.count(anchor)!=1:raise ValueError('Expected ranking._model signature not found; refusing modification')
    path.with_name('ranking.before_pairwise.py').write_text(src)
    path.write_text(src.replace(anchor,anchor+BLOCK,1))
    return True


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--path',default='temporal_fm/ranking.py')
    args=p.parse_args()
    print('Pairwise loader installed' if install(Path(args.path)) else 'Pairwise loader already installed')
