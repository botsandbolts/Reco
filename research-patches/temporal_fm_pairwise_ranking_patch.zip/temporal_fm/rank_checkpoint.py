"""Load pairwise-ranking Temporal FM checkpoints into existing top-K benchmark."""
from __future__ import annotations
import json
from pathlib import Path
import torch
from .model import TemporalFM


def load_bpr_checkpoint(ev, provider, name, backend, device='cpu', seed=None):
    root=Path('models')/ev.meta['dataset']/'temporal_fm'/name
    metadata_path=root/'metadata.json';weight_path=root/'weights.pt'
    if not metadata_path.is_file() or not weight_path.is_file():
        raise FileNotFoundError(f'Missing ranking model files for {name}: {root}')
    meta=json.loads(metadata_path.read_text())
    required={'objective':'bpr','sources':ev.meta['sources'],
              'train_cutoff':ev.meta['train_cutoff'],
              'validation_cutoff':ev.meta['val_cutoff'],
              'text_backend':backend,'text_model':provider.model_name,
              'tag_dims':provider.tags.tag_dims}
    for key,value in required.items():
        if meta.get(key)!=value:
            raise ValueError(f'Ranking checkpoint {name} mismatch for {key}; cannot compare')
    if seed is not None and meta.get('seed')!=seed:
        raise ValueError(f'Ranking checkpoint seed {meta.get("seed")} does not match {seed}')
    if not name.endswith('_bpr') or meta.get('name')!=name:
        raise ValueError(f'Not a pairwise FM checkpoint: {name}')
    model=TemporalFM(len(ev.train_users),len(ev.movies),provider.title.shape[1],
                     len(ev.genres),provider.tags.tag_dims,
                     k=int(meta['k']),deep=meta['kind']=='deepfm',
                     mean_rating=0.,ablation=meta['ablation']).to(device)
    model.load_state_dict(torch.load(weight_path,map_location=device,weights_only=True))
    model.eval()
    return model
