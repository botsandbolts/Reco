"""Train FM/DeepFM with Bayesian Personalized Ranking on the MovieLens chronology.

Output checkpoints live in models/<dataset>/temporal_fm/{fm,deepfm}_all_bpr/
so pre-existing explicit rating regression checkpoints are never overwritten.

Example: python -m temporal_fm.rank_train --dataset ml-32m --profile research \
    --text-backend sentence --models fm --device cpu
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import time

import numpy as np
import torch
import torch.nn.functional as F

from .data import Events, prepare
from .features import titles, make_tag_history
from .model import TemporalFM
from .train import FeatureProvider
from .ranking import _cohort, _candidates, score_candidates

RANK_PROFILES={
    'quick':{'epochs':2,'steps':12,'batch_size':32,'k':16,'lr':.002,'patience':2,
             'val_users':8,'val_candidates':128},
    'research':{'epochs':15,'steps':450,'batch_size':256,'k':32,'lr':.0008,'patience':4,
                'val_users':32,'val_candidates':512},
    'intensive':{'epochs':30,'steps':900,'batch_size':384,'k':64,'lr':.0004,'patience':6,
                'val_users':60,'val_candidates':1024},
}


def _build_train_lookup(ev, threshold: float):
    """On-disk sorted keys for known TRAIN ratings; bounded memory, reusable.

    Duplicates are harmless. NEVER incorporate validation/test events into this lookup.
    """
    out=ev.folder/'rank_train_index'
    out.mkdir(parents=True,exist_ok=True)
    digest=hashlib.sha256(json.dumps({'sources':ev.meta['sources'],
           'train_cutoff':ev.meta['train_cutoff'],'threshold':threshold},sort_keys=True).encode()).hexdigest()[:14]
    keys_path=out/f'known_{digest}.npy'
    pos_path=out/f'positives_{digest}.npy'
    if keys_path.exists() and pos_path.exists():
        return np.load(keys_path,mmap_mode='r'),np.load(pos_path,mmap_mode='r')
    ids=ev.split('train')
    keys=np.lib.format.open_memmap(keys_path,mode='w+',dtype=np.int64,shape=(len(ids),))
    chunks=[]; n_items=len(ev.movies)
    for start in range(0,len(ids),200_000):
        ev_idx=np.asarray(ids[start:start+200_000],dtype=np.int64)
        user=ev.user_indices(np.asarray(ev.user_raw[ev_idx],dtype=np.int32))
        if np.any(user==0):raise ValueError('Training user missing from train_users table')
        movie=np.asarray(ev.movie_idx[ev_idx],dtype=np.int64)
        keys[start:start+len(ev_idx)]=user*n_items+movie
        rating=np.asarray(ev.rating[ev_idx],dtype=np.float32)
        good=ev_idx[rating>=threshold]
        if len(good):chunks.append(good)
    keys.flush()
    keys.sort(kind='quicksort')
    keys.flush()
    positives=np.concatenate(chunks).astype(np.int32)
    if not len(positives):raise ValueError('No positive training ratings at this threshold')
    np.save(pos_path,positives)
    return np.load(keys_path,mmap_mode='r'),np.load(pos_path,mmap_mode='r')


def _draw_unrated(rng, users, known, catalog, n_items, bank, movie_years,
                  timestamps, negative_pop_share=.6, max_retries=200):
    """Reject every user/movie pair observed in TRAIN and future-release movies."""
    users=np.asarray(users,dtype=np.int64)
    ts_year=np.asarray(timestamps,dtype='datetime64[s]').astype('datetime64[Y]').astype(np.int32)+1970
    result=np.empty(len(users),dtype=np.int32)
    pending=np.arange(len(users))
    for _ in range(max_retries):
        n=len(pending)
        pop=(rng.random(n)<negative_pop_share)
        sampled=rng.choice(catalog,size=n).astype(np.int32)
        if pop.any():sampled[pop]=bank[rng.integers(0,len(bank),size=int(pop.sum()))]
        query=users[pending]*n_items+sampled.astype(np.int64)
        at=np.searchsorted(known,query)
        observed=np.zeros(n,dtype=bool)
        valid=at<len(known)
        observed[valid]=known[at[valid]]==query[valid]
        future=(movie_years[sampled]>ts_year[pending]) & (movie_years[sampled]>0)
        bad=observed|future
        result[pending[~bad]]=sampled[~bad]
        pending=pending[bad]
        if not len(pending):return result
    raise ValueError('Negative sampling exhausted; user may have rated nearly all eligible movies')


def _batch_for_movies(ev,provider,user_idx,movies,timestamps,device):
    """Positive and negative inputs share EXACT event time; no future tag leakage."""
    ui=np.asarray(user_idx,dtype=np.int64)
    mi=np.asarray(movies,dtype=np.int32)
    ts=np.asarray(timestamps,dtype=np.int64)
    cal,continuous=ev.time_fields(ui,mi,ts)
    fields={
       'user':ui,'item':ev.item_indices(mi),
       'title':np.asarray(provider.title[mi],dtype=np.float32),
       'genres':ev.genre_matrix[mi],
       'tags':provider.tags.lookup(mi,ts),
       'calendar':cal,'time':continuous,
    }
    return {k:torch.as_tensor(np.asarray(v).copy(),dtype=torch.long if k in
                 ('user','item','calendar') else torch.float32,device=device)
            for k,v in fields.items()}


def _positive_counts(ev,threshold):
    counts=np.zeros(len(ev.movies),dtype=np.int64)
    for start in range(0,len(ev.split('train')),300_000):
        idx=np.asarray(ev.split('train')[start:start+300_000],dtype=np.int64)
        pos=idx[np.asarray(ev.rating[idx]>=threshold)]
        counts+=np.bincount(np.asarray(ev.movie_idx[pos],dtype=np.int32),minlength=len(counts))
    return counts


def _fixed_validation(ev,threshold,num_users,num_candidates,seed,min_history=3):
    active,histories,truth,_,summary=_cohort(ev,'validation',threshold,num_users,min_history,seed)
    catalog=np.flatnonzero(ev.movie_has_train).astype(np.int32)
    rng=np.random.default_rng(seed+221)
    samples=[]
    for u in active:
        cand=_candidates(catalog,histories[u],truth[u],num_candidates,rng)
        samples.append((u,cand,truth[u]))
    if not samples:raise ValueError('No validation users with eligible held-out positives')
    return samples,summary


def _sampled_ndcg(model,ev,provider,samples,k,device,cutoff):
    model.eval()
    values=[]
    for user,candidates,positives in samples:
        scores=score_candidates(model,ev,provider,user,candidates,cutoff,device,batch_size=2048)
        top=candidates[np.argsort(-scores,kind='stable')[:k]]
        matches=np.array([m in positives for m in top],dtype=np.float64)
        ideal=min(k,len(positives))
        denom=np.sum(1/np.log2(np.arange(2,ideal+2)))
        dcg=np.sum(matches/np.log2(np.arange(2,len(top)+2)))
        values.append(float(dcg/max(denom,1e-12)))
    return float(np.mean(values))


def _try_warm_start(model,ev,provider,kind,ablation,profile,enabled):
    if not enabled:return None
    name=f'{kind}_{ablation}'
    folder=Path('models')/ev.meta['dataset']/'temporal_fm'/name
    meta=folder/'metadata.json'; weights=folder/'weights.pt'
    if not meta.exists() or not weights.exists():
        print(f'{name}: regression checkpoint absent; training ranking model from scratch',flush=True)
        return None
    settings=json.loads(meta.read_text())
    valid=(all(settings.get(k)==v for k,v in ev.meta['sources'].items()) and
           settings.get('train_cutoff')==ev.meta['train_cutoff'] and
           settings.get('text_backend')==provider.backend and
           settings.get('text_model')==provider.model_name and
           settings.get('tag_dims')==provider.tags.tag_dims and
           settings.get('ablation')==ablation and settings.get('kind')==kind and
           settings.get('profile')==profile)
    if not valid:
        print(f'{name}: regression checkpoint differs in configuration; training from scratch',flush=True)
        return None
    try:model.load_state_dict(torch.load(weights,map_location='cpu',weights_only=True))
    except RuntimeError:
        print(f'{name}: regression checkpoint architecture differs; training from scratch',flush=True)
        return None
    print(f'Warm-started BPR from frozen {weights}',flush=True)
    return str(weights)


def train(dataset='ml-32m',data_dir='data',ratings=None,movies=None,tags=None,
          profile='research',text_backend='sentence',
          text_model='sentence-transformers/all-MiniLM-L6-v2',models='fm',
          ablation='all',positive_threshold=4.,negatives=2,pop_negative_share=.6,
          warm_start=False,force_retrain=False,device='cpu',seed=42,threads=2,
          max_tag_vocab=20000,tag_dims=48,validation_users=None,validation_candidates=None):
    if profile not in RANK_PROFILES:raise ValueError(f'Unknown profile {profile}')
    if ablation not in ('id','content','all_no_time','all'):raise ValueError('Unknown ablation')
    if negatives<1 or not(0<=pop_negative_share<=1):raise ValueError('Bad negative sampling arguments')
    if device=='cuda' and not torch.cuda.is_available():raise ValueError('CUDA not available')
    kinds=[v.strip() for v in models.split(',') if v.strip()]
    if not kinds or any(x not in ('fm','deepfm') for x in kinds):raise ValueError('Use --models fm,deepfm')
    np.random.seed(seed);torch.manual_seed(seed);torch.set_num_threads(threads)
    cfg=RANK_PROFILES[profile]
    ev=Events(prepare(dataset,data_dir,ratings,movies,tags,seed=seed))
    titles(ev,text_backend,text_model)
    tag_dir=(make_tag_history(ev,ev.meta['tags_path'],text_backend,text_model,
                               tag_dims,max_tag_vocab) if ev.meta['tags_path'] else None)
    provider=FeatureProvider(ev,text_backend,text_model,tag_dir)
    provider.backend=text_backend
    provider.model_name=text_model
    known,positives=_build_train_lookup(ev,positive_threshold)
    catalog=np.flatnonzero(ev.movie_has_train).astype(np.int32)
    counts=_positive_counts(ev,positive_threshold)
    probs=(counts[catalog].astype(np.float64)+1)**.75
    probs/=probs.sum()
    rng_bank=np.random.default_rng(seed+317)
    bank=rng_bank.choice(catalog,size=250_000,replace=True,p=probs).astype(np.int32)
    samples,cohort=_fixed_validation(ev,positive_threshold,
                         validation_users or cfg['val_users'],
                         validation_candidates or cfg['val_candidates'],seed)
    run_reports={}
    out=Path('models')/dataset/'temporal_fm'
    out.mkdir(parents=True,exist_ok=True)
    for kind in kinds:
        name=f'{kind}_{ablation}_bpr'
        folder=out/name;folder.mkdir(parents=True,exist_ok=True)
        metadata={
           'objective':'bpr','rank_version':1,'name':name,'kind':kind,'ablation':ablation,
           'profile':profile,'k':cfg['k'],'positive_threshold':positive_threshold,
           'negatives':negatives,'pop_negative_share':pop_negative_share,
           'sources':ev.meta['sources'],'train_cutoff':ev.meta['train_cutoff'],
           'validation_cutoff':ev.meta['val_cutoff'],'text_backend':text_backend,
           'text_model':text_model,'tag_dims':provider.tags.tag_dims,
           'max_tag_vocab':max_tag_vocab,'seed':seed,'dataset':dataset,
           'validation_users_requested':validation_users or cfg['val_users'],
           'validation_candidates_requested':validation_candidates or cfg['val_candidates'],
           'warm_start_requested':bool(warm_start),
        }
        check=folder/'metadata.json';weights=folder/'weights.pt'
        if weights.exists() and not force_retrain:
            if not check.exists() or json.loads(check.read_text()) != metadata:
                raise ValueError(f'{name}: incompatible checkpoint already exists; rename it or use --force-retrain')
            print(f'Reusing frozen ranking model {name}; use --force-retrain to retrain',flush=True)
            run_reports[name]={'reused':True,'checkpoint':str(weights)}
            continue
        model=TemporalFM(len(ev.train_users),len(ev.movies),provider.title.shape[1],
                 len(ev.genres),provider.tags.tag_dims,k=cfg['k'],deep=kind=='deepfm',
                 mean_rating=0.0,ablation=ablation).to(device)
        _try_warm_start(model,ev,provider,kind,ablation,profile,warm_start)
        optimizer=torch.optim.AdamW(model.parameters(),lr=cfg['lr'],weight_decay=1e-5)
        scheduler=torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer,mode='max',factor=.5,patience=2)
        best=-1.;bad=0;history=[]
        generator=np.random.default_rng(seed)
        for epoch in range(cfg['epochs']):
            model.train();loss_total=0.;start=time.perf_counter()
            for step in range(cfg['steps']):
                idx=np.asarray(positives[generator.integers(0,len(positives),size=cfg['batch_size'])],dtype=np.int64)
                ui=ev.user_indices(np.asarray(ev.user_raw[idx],dtype=np.int32))
                mids=np.asarray(ev.movie_idx[idx],dtype=np.int32)
                stamps=np.asarray(ev.timestamp[idx],dtype=np.int64)
                neg_ui=np.repeat(ui,negatives)
                neg_ts=np.repeat(stamps,negatives)
                neg_movies=_draw_unrated(generator,neg_ui,known,catalog,len(ev.movies),bank,
                               ev.release_year,neg_ts,pop_negative_share)
                positive=_batch_for_movies(ev,provider,ui,mids,stamps,device)
                negative=_batch_for_movies(ev,provider,neg_ui,neg_movies,neg_ts,device)
                p=model(positive)
                n=model(negative).reshape(len(idx),negatives)
                loss=F.softplus(n-p[:,None]).mean()
                if not torch.isfinite(loss):raise FloatingPointError('Nonfinite BPR loss')
                optimizer.zero_grad(set_to_none=True);loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(),max_norm=1.0)
                optimizer.step();loss_total+=float(loss.detach())
            score=_sampled_ndcg(model,ev,provider,samples,10,device,
                                 int(ev.meta['train_cutoff']))
            scheduler.step(score)
            record={'epoch':epoch+1,'bpr_loss':round(loss_total/cfg['steps'],6),
                    'sampled_validation_ndcg_at_10':round(score,6),
                    'lr':optimizer.param_groups[0]['lr'],
                    'epoch_seconds':round(time.perf_counter()-start,2)}
            history.append(record)
            print(f'{name}: epoch {epoch+1}/{cfg["epochs"]}: BPR={record["bpr_loss"]:.4f}, '
                  f'sampled-val NDCG@10={score:.4f}',flush=True)
            if score>best+1e-6 or not weights.exists():
                best=score;bad=0
                torch.save(model.state_dict(),weights)
                check.write_text(json.dumps(metadata,indent=2))
                (folder/'history.json').write_text(json.dumps(history,indent=2))
            else:
                bad+=1
                if bad>=cfg['patience']:break
        run_reports[name]={'reused':False,'checkpoint':str(weights),
                           'best_sampled_validation_ndcg_at_10':best,'history':history}
    report={'dataset':dataset,'objective':'BPR pairwise softplus(score_negative - score_positive)',
        'split_policy':'Train positives only; user unrated negatives sampled from warm TRAIN catalogue',
        'positive_threshold':positive_threshold,'profile':profile,'models':run_reports,
        'train_positive_events':len(positives),'train_known_rating_events':len(known),
        'candidate_catalogue_size':len(catalog),'validation_cohort':cohort,
        'validation_policy':'FIXED SAMPLED candidate pools; validation NDCG is not full-catalogue NDCG',
        'time_policy':'Positive and negative features queried at SAME training positive event timestamp',
        'caveats':['Unobserved items are not guaranteed dislikes; offline recommendation data has exposure bias.',
                   'Tune using validation only; reserve the test split for the final selected configuration.',
                   'Full-catalogue scores must be computed with temporal_fm.shared_benchmark, not training validation scores.']}
    target=Path('reports')/'temporal'/dataset/f'pairwise_training_{profile}_{text_backend}_seed{seed}.json'
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(json.dumps(report,indent=2))
    print(f'Saved pairwise training report: {target}',flush=True)
    return report


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset',default='ml-32m')
    p.add_argument('--data-dir',default='data')
    for key in ('ratings','movies','tags'):p.add_argument('--'+key)
    p.add_argument('--profile',choices=list(RANK_PROFILES),default='research')
    p.add_argument('--text-backend',choices=['sentence','hash'],default='sentence')
    p.add_argument('--text-model',default='sentence-transformers/all-MiniLM-L6-v2')
    p.add_argument('--models',default='fm')
    p.add_argument('--ablation',choices=['id','content','all_no_time','all'],default='all')
    p.add_argument('--positive-threshold',type=float,default=4.)
    p.add_argument('--negatives',type=int,default=2)
    p.add_argument('--pop-negative-share',type=float,default=.6)
    p.add_argument('--warm-start',action='store_true')
    p.add_argument('--force-retrain',action='store_true')
    p.add_argument('--device',choices=['cpu','cuda'],default='cpu')
    p.add_argument('--seed',type=int,default=42)
    p.add_argument('--threads',type=int,default=2)
    p.add_argument('--max-tag-vocab',type=int,default=20000)
    p.add_argument('--tag-dims',type=int,default=48)
    p.add_argument('--validation-users',type=int,default=None)
    p.add_argument('--validation-candidates',type=int,default=None)
    train(**vars(p.parse_args(argv)))

if __name__=='__main__':main()
