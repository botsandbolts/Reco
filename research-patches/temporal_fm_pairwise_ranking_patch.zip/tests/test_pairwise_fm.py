from pathlib import Path
import json
import numpy as np
import pandas as pd
import pytest
import torch

from temporal_fm.data import Events, prepare
from temporal_fm.features import titles,make_tag_history
from temporal_fm.train import FeatureProvider
from temporal_fm.rank_train import (_draw_unrated,_build_train_lookup,_batch_for_movies,
                                    _sampled_ndcg, train)
from temporal_fm.rank_checkpoint import load_bpr_checkpoint
from temporal_fm.ranking import _cohort,score_candidates


def make_dataset(tmp_path):
    raw=tmp_path/'data/raw/ml-latest-small';raw.mkdir(parents=True)
    n_movies=64;n_users=15;n_events=1500
    pd.DataFrame({'movieId':np.arange(1,n_movies+1),
                  'title':[f'Movie {i} (1995)' for i in range(n_movies)],
                  'genres':['Action|Drama' if i%2 else 'Comedy|Sci-Fi' for i in range(n_movies)]}).to_csv(raw/'movies.csv',index=False)
    rng=np.random.default_rng(77)
    dates=1_100_000_000+np.arange(n_events,dtype=np.int64)*10000
    pd.DataFrame({'userId':rng.integers(1,n_users+1,size=n_events),
                  'movieId':rng.integers(1,n_movies+1,size=n_events),
                  'rating':rng.choice([1.,2.,3.,4.,4.5,5.],size=n_events),
                  'timestamp':dates}).to_csv(raw/'ratings.csv',index=False)
    pd.DataFrame({'movieId':[1,2,3,4,5], 'tag':['space','serious','fun','heart','space'],
                  'timestamp':[int(dates[0]),int(dates[40]),int(dates[80]),int(dates[-1])+10,int(dates[1])]}).to_csv(raw/'tags.csv',index=False)
    return raw


def test_negatives_exclude_train_history_and_future_releases(tmp_path):
    make_dataset(tmp_path)
    ev=Events(prepare('ml-latest-small',tmp_path/'data'))
    known,positive=_build_train_lookup(ev,4.)
    ids=np.asarray(positive[:30],dtype=np.int64)
    ui=ev.user_indices(np.asarray(ev.user_raw[ids],dtype=np.int32))
    timestamps=np.asarray(ev.timestamp[ids],dtype=np.int64)
    bank=np.flatnonzero(ev.movie_has_train).astype(np.int32)
    negatives=_draw_unrated(np.random.default_rng(23),ui,known,bank,len(ev.movies),bank,
                            ev.release_year,timestamps,negative_pop_share=.5)
    key=ui.astype(np.int64)*len(ev.movies)+negatives
    at=np.searchsorted(known,key)
    hits=(at<len(known))
    assert not np.any(known[at[hits]]==key[hits])
    assert len(negatives)==len(ids)


def test_temporal_negative_tag_features_never_look_ahead(tmp_path):
    raw=make_dataset(tmp_path)
    ev=Events(prepare('ml-latest-small',tmp_path/'data'))
    titles(ev,backend='hash')
    tag_folder=make_tag_history(ev,raw/'tags.csv',backend='hash',tag_dims=12)
    provider=FeatureProvider(ev,backend='hash',tag_dir=tag_folder)
    ui=np.array([1,1]);mi=np.array([2,2],dtype=np.int32)
    time=np.array([1_100_000_000,1_100_000_000+900_000],dtype=np.int64)
    batch=_batch_for_movies(ev,provider,ui,mi,time,'cpu')
    assert batch['tags'].shape==(2,12)
    assert torch.all(batch['tags'][0]==0)
    assert torch.linalg.vector_norm(batch['tags'][1])>0


def test_full_rank_training_loading_and_scoring(tmp_path,monkeypatch):
    make_dataset(tmp_path);monkeypatch.chdir(tmp_path)
    report=train(dataset='ml-latest-small',data_dir='data',text_backend='hash',
                 profile='quick',models='fm,deepfm',threads=1,tag_dims=12,
                 validation_users=5,validation_candidates=45,negatives=2)
    assert all(v['checkpoint'] for v in report['models'].values())
    assert report['objective'].startswith('BPR')
    ev=Events(Path('data/temporal/ml-latest-small'))
    provider=FeatureProvider(ev,backend='hash',tag_dir=ev.folder/'features_hash')
    provider.model_name='sentence-transformers/all-MiniLM-L6-v2'
    for kind in ['fm','deepfm']:
        name=f'{kind}_all_bpr'
        model=load_bpr_checkpoint(ev,provider,name,'hash','cpu',seed=42)
        users,histories,ground_truth,_,_=_cohort(ev,'validation',4.,5,3,42)
        assert users
        candidates=np.setdiff1d(np.flatnonzero(ev.movie_has_train),
                      list(histories[users[0]]),assume_unique=True)
        scores=score_candidates(model,ev,provider,users[0],candidates,
                                ev.meta['train_cutoff'],device='cpu')
        assert len(scores)==len(candidates)
        assert np.all(np.isfinite(scores))
        assert np.std(scores)>0
    again=train(dataset='ml-latest-small',data_dir='data',text_backend='hash',
                 profile='quick',models='fm,deepfm',threads=1,tag_dims=12,
                 validation_users=5,validation_candidates=45,negatives=2)
    assert again['models']['fm_all_bpr']['reused']
    from scripts.install_pairwise_fm import install
    # The installer operates on a copy: it must be repeatable and non-destructive.
    anchor='def _model(ev, provider, name, backend, device, profile=None, seed=None):\n'
    src=tmp_path/'mock_ranking.py';src.write_text(anchor+'    return None\n')
    assert install(src) is True
    assert install(src) is False
    assert 'PAIRWISE_FM_CHECKPOINT_LOADER_v1' in src.read_text()
    from temporal_fm.ranking import _model
    reloaded=_model(ev,provider,'fm_all_bpr','hash','cpu',seed=42)
    assert reloaded is not None
    with pytest.raises(ValueError):load_bpr_checkpoint(ev,provider,'fm_all_bpr','sentence')
    from temporal_fm.shared_benchmark import evaluate as compare
    benchmark=compare(dataset='ml-latest-small',data_dir='data',backend='hash',
                      models='fm_all_bpr,deepfm_all_bpr',users=5,k=5,
                      positive_threshold=4.,min_history=3,profile='quick',
                      split='validation',device='cpu',threads=1,blend_weight=0,examples=1)
    assert benchmark['same_users_and_catalogue'] is True
    assert 'fm_all_bpr' in benchmark['metrics']
    assert 'deepfm_all_bpr' in benchmark['metrics']
    assert 'popularity_all' in benchmark['metrics']
    assert all(np.isfinite(v['ndcg_at_k']) for v in benchmark['metrics'].values())
    assert list(Path('reports/temporal/ml-latest-small').glob('shared_*.json'))
