# Rating-aware BPR for Temporal FM / DeepFM (MovieLens 32M)

This patch changes **only** the pairwise FM training and checkpoint reader. It preserves the existing model, data ingestion, Sentence-Transformer title + historical tag features, binary genres, chronological splits, and Streamlit app. No existing model or checkpoint is deleted or overwritten by the recommended commands.

Files:

- `temporal_fm/rank_train.py` — replacement of serious-training runner, now with `--objective rating_aware`.
- `temporal_fm/rating_pairs.py` — cached per-user **TRAIN-only**, timestamp-sorted low-rating history and point-in-time sampler.
- `temporal_fm/rank_checkpoint.py` — accepts **both** `bpr` and `rating_aware_bpr` checkpoints in the existing top-K and shared-cutoff comparisons.
- `tests/test_rating_aware_fm.py` — historical-pair correctness and end-to-end training/reloading.

## Method

For a positive training event (user U, movie I+, rating >= 4, timestamp T), train a ranking model with TWO signals:

1. Positive-vs-unobserved BPR, as before: a sampled unobserved item must rank below I+. Its loss can be weighted upward for ratings >4.
2. **Observed-rating preference**: if the user gave movie I- a rating <=3.5 at timestamp STRICTLY BEFORE T, rank I+ above I-. Weight the preference by the star gap, capped to avoid unstable updates. If no earlier low-rated movie exists, skip only this secondary term.

`L = weighted_BPR(unobserved) + observed_pair_weight * gap_weighted_BPR(known_low)`.

All content features for both movies are queried **at the positive event timestamp T**, so later tags cannot enter the comparison. Validation and test events are never used to create observed preference pairs. An unrated candidate is **unknown**, not a confirmed dislike.

The historical low-rating index is cached on disk in `data/temporal/<dataset>/rank_train_index/` and reused. On 32M, building it the first time can require several hundred MB of transient RAM and substantial CPU. The original 32M ratings and timestamps must already be processed by `temporal_fm.run` or the prior `rank_train` pipeline.

## Install via GitHub upload → Codespaces

Upload `temporal_fm_rating_aware_patch.zip` to the `main` branch of https://github.com/herberton777/Reco, then:

```bash
cd /workspaces/Reco
git fetch origin main
git show origin/main:temporal_fm_rating_aware_patch.zip > temporal_fm_rating_aware_patch.zip
unzip -t temporal_fm_rating_aware_patch.zip
cp temporal_fm/rank_train.py temporal_fm/rank_train.before_rating_aware.py
cp temporal_fm/rank_checkpoint.py temporal_fm/rank_checkpoint.before_rating_aware.py
unzip -o temporal_fm_rating_aware_patch.zip
python -m pytest -q tests/test_rating_aware_fm.py
python -m temporal_fm.rank_train --help
```

Requires your existing `temporal_fm` installation and the pairwise and serious-training patches from our earlier work. The ZIP includes the full upgraded trainer, so installing the separate serious-training ZIP again is unnecessary.

## Quick smoke test (few mini-batches; NOT scientific training)

```bash
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 \
python -u -m temporal_fm.rank_train \
  --dataset ml-32m --text-backend sentence \
  --models fm --ablation all --objective rating_aware \
  --profile research --init-from fm_all_bpr \
  --run-label rating_smoke \
  --epochs 1 --steps-per-epoch 10 --batch-size 64 \
  --validation-mode full --validation-users 8 \
  --low-rating-max 3.5 --observed-pair-weight 0.7 \
  --device cpu --threads 2
```

Creates `models/ml-32m/temporal_fm/fm_all_rating_smoke_bpr/`. It does not overwrite `fm_all_bpr`.

## Serious training (CPU, full-catalogue validation)

```bash
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 \
python -u -m temporal_fm.rank_train \
  --dataset ml-32m \
  --text-backend sentence \
  --models fm --ablation all \
  --objective rating_aware \
  --profile research \
  --init-from fm_all_bpr \
  --epochs 15 --min-epochs 10 \
  --steps-per-epoch 1200 --batch-size 256 \
  --lr 0.00025 --patience 5 \
  --positive-sampling permuted \
  --low-rating-max 3.5 \
  --observed-pair-weight 0.7 \
  --positive-rating-weight 0.25 \
  --negatives 2 --pop-negative-share 0.6 \
  --validation-mode full --validation-users 20 \
  --validate-every 2 \
  --device cpu --threads 2
```

Creates `models/ml-32m/temporal_fm/fm_all_rating_bpr/`. Starts from `fm_all_bpr` but keeps that checkpoint frozen. If you want to fine-tune from `fm_all_strong_bpr` instead and it has the same latent dimension, replace `--init-from fm_all_bpr` with `--init-from fm_all_strong_bpr`.

The serious training budget is **4.6 million positive draws maximum** (15 × 1200 × 256), with at least **3.07 million** before early stopping; each positive is contrasted with two unobserved candidates and, when available, one previously rated-low movie. It does not guarantee one pass through all 32M ratings; use `--full-pass-epochs` for one pass over every *high-rated training event* (much more expensive).

If the chosen checkpoint already exists and has different hyperparameters, use a **different** `--run-label` (for example `--run-label rating_v2`) rather than forcing replacement of a successful experiment. If the initialization checkpoint does not exist, omit `--init-from` to train from scratch.

Watch the `observed_pairs` count in each epoch: if it stays zero, the recorded rating history is not yielding usable explicit preferences and the trainer is only using weighted positive-vs-unrated comparisons.

## Rank and compare on the same full catalogue

```bash
python -m temporal_fm.ranking \
  --dataset ml-32m --backend sentence \
  --models fm_all_bpr,fm_all_rating_bpr \
  --users 100 --k 10 --max-candidates 0 \
  --device cpu
```

This evaluates popularity and both FM ranking models over the same eligible users and candidate catalogue. Look at **NDCG@10, Recall@10, MRR@10 and Hit Rate@10**. Sampled-validation NDCG is not comparable with full-catalogue NDCG. To compare the FM variants with fresh SVD and BPR baselines on the same chronological split:

```bash
python -m temporal_fm.shared_benchmark \
  --dataset ml-32m --backend sentence \
  --models fm_all_bpr,fm_all_rating_bpr \
  --users 200 --k 10 --profile quick \
  --split validation --device cpu
```

The `--profile quick` in `shared_benchmark` trains relatively small SVD/BPR comparison baselines; it **does not** control the already-trained FM models. For a stronger comparison, use `--profile research` for the baselines. Do not tune on the test split.

View in Streamlit:

```bash
streamlit run app.py --server.address 0.0.0.0 --server.port 8501
```

## Checks and limitations

- The checkpoint loader recognizes the new objective while preserving existing BPR checkpoints.
- Low-rated movie is selected only if its rating timestamp precedes the positive rating's timestamp. Ratings after the global training cutoff never enter the index.
- Training evaluations are observational; unwatched/unrated movies are not confirmed negative, and popularity/exposure bias remains.
- Historic rating timestamps mean **rating-submission time**, not necessarily movie watch time.
- A user's later preferences may differ from earlier ones; leakage protection can reduce number of usable pairs.
- Our synthetic integration tests pass, but **no full MovieLens 32M run has been executed in this environment**.
