"""Leakage-controlled explicit preference pairs for temporal MovieLens ranking.

Only low ratings in TRAIN, observed strictly BEFORE the positive anchor's
rating timestamp, are eligible as known-dislike comparisons. Unrated items
are handled separately by the existing Bayesian Personalized Ranking sampler.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path

import numpy as np


class LowRatingHistory:
    def __init__(self, offsets, timestamps, movies, ratings):
        self.offsets = offsets
        self.timestamps = timestamps
        self.movies = movies
        self.ratings = ratings
        if len(offsets) < 2 or int(offsets[-1]) != len(timestamps):
            raise ValueError('Invalid low-rating index')
        if not (len(timestamps) == len(movies) == len(ratings)):
            raise ValueError('Mismatched low-rating arrays')

    def draw(self, rng, users, positives, stamps, positive_ratings):
        """Return negative movies and star gaps; `valid` masks unavailable pairs.

        Uses a point-in-time lookup for EACH positive to prevent pairing it
        with low ratings that happen later in the training period.
        """
        users = np.asarray(users, dtype=np.int64)
        positives = np.asarray(positives, dtype=np.int32)
        stamps = np.asarray(stamps, dtype=np.int64)
        positive_ratings = np.asarray(positive_ratings, dtype=np.float32)
        if not (len(users) == len(positives) == len(stamps) == len(positive_ratings)):
            raise ValueError('Mismatched anchor arrays')
        movies = np.zeros(len(users), dtype=np.int32)
        gaps = np.zeros(len(users), dtype=np.float32)
        valid = np.zeros(len(users), dtype=bool)
        for j, u in enumerate(users):
            if not (0 < u < len(self.offsets) - 1):
                continue
            lo = int(self.offsets[u])
            hi = int(self.offsets[u + 1])
            if lo == hi:
                continue
            # Strictly earlier than the anchor to avoid same-time ambiguity.
            end = lo + int(np.searchsorted(self.timestamps[lo:hi], stamps[j], side='left'))
            if end == lo:
                continue
            # Sample a few times: exclude an anomalous repeated rating of the
            # same movie (even though MovieLens normally has one per pair).
            for _ in range(12):
                choice = int(rng.integers(lo, end))
                gap = float(positive_ratings[j] - self.ratings[choice])
                if gap > 0 and int(self.movies[choice]) != int(positives[j]):
                    movies[j] = int(self.movies[choice])
                    gaps[j] = gap
                    valid[j] = True
                    break
        return movies, gaps, valid


def load_or_build_low_history(ev, max_rating=3.5):
    """Build a cached, timestamp-sorted per-user low-rating CSR index.

    Peak memory is proportional to TRAIN low ratings, not all MovieLens rows.
    The saved index is reused for later ranking experiments on the same input.
    """
    if not 0.5 <= max_rating < 5.0:
        raise ValueError('Low-rating threshold must be in [0.5, 5)')
    folder = ev.folder / 'rank_train_index'
    folder.mkdir(parents=True, exist_ok=True)
    signature = {'sources':ev.meta['sources'], 'train_cutoff':ev.meta['train_cutoff'],
                 'max_low_rating':float(max_rating),'version':2}
    code = hashlib.sha256(json.dumps(signature, sort_keys=True).encode()).hexdigest()[:16]
    paths = {key:folder / f'low_{key}_{code}.npy'
             for key in ('offsets','timestamps','movies','ratings')}
    if all(path.exists() for path in paths.values()):
        return LowRatingHistory(*(np.load(paths[k], mmap_mode='r') for k in
                                  ('offsets','timestamps','movies','ratings')))

    user_parts, movie_parts, time_parts, rating_parts = [], [], [], []
    ids = ev.split('train')
    for start in range(0, len(ids), 200_000):
        idx = np.asarray(ids[start:start+200_000], dtype=np.int64)
        idx = idx[np.asarray(ev.rating[idx],dtype=np.float32) <= max_rating]
        if not len(idx):
            continue
        ui = ev.user_indices(np.asarray(ev.user_raw[idx],dtype=np.int32)).astype(np.int32)
        if np.any(ui == 0):
            raise ValueError('User with low training rating missing from training user table')
        user_parts.append(ui)
        movie_parts.append(np.asarray(ev.movie_idx[idx],dtype=np.int32))
        time_parts.append(np.asarray(ev.timestamp[idx],dtype=np.int64))
        rating_parts.append(np.asarray(ev.rating[idx],dtype=np.float32))
    user = np.concatenate(user_parts) if user_parts else np.empty(0,dtype=np.int32)
    movies = np.concatenate(movie_parts) if movie_parts else np.empty(0,dtype=np.int32)
    stamps = np.concatenate(time_parts) if time_parts else np.empty(0,dtype=np.int64)
    ratings = np.concatenate(rating_parts) if rating_parts else np.empty(0,dtype=np.float32)
    order = np.lexsort((stamps,user))
    counts = np.bincount(user, minlength=len(ev.train_users)+1)
    offsets = np.concatenate([[0], np.cumsum(counts, dtype=np.int64)])
    # Atomic publish of offsets last means incomplete caches are rebuilt.
    np.save(paths['timestamps'],stamps[order])
    np.save(paths['movies'],movies[order])
    np.save(paths['ratings'],ratings[order])
    np.save(paths['offsets'],offsets)
    return LowRatingHistory(*(np.load(paths[k],mmap_mode='r') for k in
                              ('offsets','timestamps','movies','ratings')))
