"""Regression tests for explicit-rating, point-in-time ranking."""
import json
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from temporal_fm.rating_pairs import LowRatingHistory, load_or_build_low_history
from temporal_fm.rank_train import train
from temporal_fm.rank_checkpoint import load_bpr_checkpoint
from temporal_fm.data import Events
from temporal_fm.train import FeatureProvider
from temporal_fm.ranking import score_candidates


def seed_dataset(tmp_path):
    raw=tmp_path/'data'/'raw'/'ml-latest-small'
    raw.mkdir(parents=True)
    rng=np.random.default_rng(561)
    movies=48
    n=1600
    pd.DataFrame({'movieId':np.arange(1,movies+1),
                  'title':[f'Movie {i} (1994)' for i in range(movies)],
                  'genres':['Action|Drama' if i%2 else 'Comedy|Sci-Fi' for i in range(movies)]}).to_csv(raw/'movies.csv',index=False)
    times=1_100_000_000+np.arange(n,dtype=np.int64)*10000
    pd.DataFrame({'userId':rng.integers(1,17,size=n),
                  'movieId':rng.integers(1,movies+1,size=n),
                  'rating':rng.choice([1.,2.,3.,3.5,4.,4.5,5.],size=n),
                  'timestamp':times}).to_csv(raw/'ratings.csv',index=False)
    pd.DataFrame({'userId':[1,2,3], 'movieId':[2,2,3],
                  'tag':['space','dark','action'],
                  'timestamp':[int(times[2]),int(times[30]),int(times[70])]}).to_csv(raw/'tags.csv',index=False)


def test_point_in_time_low_rating_sampler():
    # User 1 has lows at t=10 and t=30. The latter is unavailable at t=20.
    h=LowRatingHistory(np.asarray([0,0,2,3],dtype=np.int64),
                       np.asarray([10,30,8],dtype=np.int64),
                       np.asarray([3,4,2],dtype=np.int32),
                       np.asarray([1.,2.,3.],dtype=np.float32))
    rng=np.random.default_rng(42)
    mids,gaps,valid=h.draw(rng,[1,1,2,1],[7,7,7,3],[20,40,10,20],[5.,5.,4.5,5.])
    assert valid[0] and mids[0]==3 and gaps[0]==4.
    assert valid[1] and mids[1] in (3,4)
    assert valid[2] and mids[2]==2
    assert not valid[3]  # The only historical low at t=20 is the anchor movie itself


def test_train_rating_aware_separate_checkpoint_and_compare(tmp_path, monkeypatch):
    seed_dataset(tmp_path)
    monkeypatch.chdir(tmp_path)
    base=train(dataset='ml-latest-small',data_dir='data',text_backend='hash',
               profile='quick',models='fm',threads=1,tag_dims=8)
    parent=Path('models/ml-latest-small/temporal_fm/fm_all_bpr/weights.pt')
    frozen=parent.read_bytes()
    report=train(dataset='ml-latest-small',data_dir='data',text_backend='hash',
                 profile='quick',models='fm',threads=1,tag_dims=8,
                 objective='rating_aware', init_from='fm_all_bpr',
                 validation_mode='full', validation_users=4,
                 epochs=2,steps_per_epoch=8,batch_size=20,min_epochs=2)
    new=Path('models/ml-latest-small/temporal_fm/fm_all_rating_bpr')
    assert (new/'weights.pt').exists()
    meta=json.loads((new/'metadata.json').read_text())
    assert meta['objective']=='rating_aware_bpr'
    assert report['models']['fm_all_rating_bpr']['historical_observed_pairs']>0
    assert parent.read_bytes()==frozen
    ev=Events('data/temporal/ml-latest-small')
    low=load_or_build_low_history(ev,3.5)
    idx=ev.split('train')[:100]
    assert len(low.timestamps)>0
    assert all(low.timestamps[lo:hi].min()<=low.timestamps[lo:hi].max()
               for lo,hi in zip(low.offsets[:-1],low.offsets[1:]) if hi>lo)
    provider=FeatureProvider(ev,backend='hash',tag_dir=ev.folder/'features_hash')
    provider.model_name='sentence-transformers/all-MiniLM-L6-v2'
    old=load_bpr_checkpoint(ev,provider,'fm_all_bpr','hash','cpu',seed=42)
    new_model=load_bpr_checkpoint(ev,provider,'fm_all_rating_bpr','hash','cpu',seed=42)
    catalog=np.flatnonzero(ev.movie_has_train)[:15]
    for m in (old,new_model):
        s=score_candidates(m,ev,provider,int(ev.train_users[0]),catalog,
                           int(ev.meta['train_cutoff']),device='cpu')
        assert len(s)==len(catalog) and np.isfinite(s).all()
    same=train(dataset='ml-latest-small',data_dir='data',text_backend='hash',
               profile='quick',models='fm',threads=1,tag_dims=8,
               objective='rating_aware',init_from='fm_all_bpr',
               validation_mode='full',validation_users=4,
               epochs=2,steps_per_epoch=8,batch_size=20,min_epochs=2)
    assert same['models']['fm_all_rating_bpr']['reused']


def test_invalid_rating_threshold(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    with pytest.raises(ValueError,match='low-rating-max'):
        train(objective='rating_aware',low_rating_max=4.,positive_threshold=4.)
    with pytest.raises(ValueError,match='nonnegative'):
        train(objective='rating_aware',observed_pair_weight=-1)
