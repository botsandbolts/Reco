# Generative Movie Recommendation Lab: semantic IDs, multimodal fusion, slate planning

This patch **replaces the legacy sequential-model implementation** with a new research track, while leaving **SVD, BPR-MF, semantic similarity, UMAP, LambdaMART, and the original MovieLens Small application** intact.

## What is actually implemented

| Research direction | Implementation in this project | Difference from the published paper |
|---|---|---|
| **TIGER-inspired generative retrieval** | Residual KMeans semantic IDs with unique collision suffix; encoder–decoder Transformer; teacher-forced next-semantic-token training; prefix-constrained beam decoding | Uses residual KMeans, **not** the TIGER RQ-VAE, and a compact PyTorch encoder/decoder instead of T5 |
| **Multimodal semantic IDs** | Late fusion of Sentence Transformer text embeddings, **optional** CLIP poster vectors, and **optional** train-only BPR item vectors prior to quantization | MovieLens does **not** include posters or plot summaries. Visual experiments require poster images you are licensed to use. |
| **OGR-inspired slate planning** | Beam-based joint selection of multiple movies with discounted relevance, semantic diversity, and novelty | **Not** the published OGR model's end-to-end learned slate policy, list-wise preference planning or policy optimization |

These are research-inspired, implementable comparisons and **not faithful published-model reproductions**. The new tests do not imply actual MovieLens performance results.

## Install safely in GitHub Codespaces

1. **Commit your current work first:** `git add -A && git commit -m "Backup before generative upgrade"` (ignore the 'nothing to commit' message if clean).
2. Download `generative_movie_recommender_patch.zip` and upload it into your GitHub repository using GitHub **Add file → Upload files**.
3. Open your Codespace and run:

```bash
cd /workspaces/Reco
git pull origin main
unzip -o generative_movie_recommender_patch.zip
python -m pip install -r requirements-generative.txt
python -m pytest -q tests/test_generative.py
```

4. Preview the **exact obsolete paths** being deleted:

```bash
python scripts/migrate_to_generative.py
```

5. Remove legacy model code, outdated documentation and dependency file:

```bash
python scripts/migrate_to_generative.py --apply
```

The migration is **idempotent**. It does not remove `src/recommender.py`, original SVD, semantic vectors, BPR, UMAP maps, model reports or data. Saved obsolete checkpoint folders are retained by default to prevent accidental loss. If you **also** want to erase the old `models/ml-1m/*_L100` and `models/ml-32m/*_L100` checkpoints for the retired architectures, use:

```bash
python scripts/migrate_to_generative.py --apply --purge-checkpoints
```

This checkpoint deletion is irreversible unless you have a backup. Run it only if you no longer need those weights.

Finally, run all tests and commit the changes:

```bash
python -m pytest -q tests
git add -A
git commit -m "Replace sequential models with TIGER-inspired generative retrieval"
git push origin main
```

> **Important:** Only run the new commands when the earlier `scalable` preparation modules are extracted. The patch does not replace `scalable.prepare`, your corrected CSV import, or `scalable.train`.

## Step 1. Start with MovieLens 1M, not 32M

```bash
python -m scalable.prepare --dataset ml-1m --memory 2GB
```

Build **generative histories using training interactions only**, ordered by *rating timestamps*:

```bash
python -m generative.histories --dataset ml-1m --max-len 60 --memory 2GB
```

The input histories are **not** verified movie-watch sequences. The preprocessing joins only `train.parquet` positives to timestamps and explicitly excludes `rank_train`, `validation` and `test`.

## Step 2. Create Semantic IDs (TIGER-style)

Quick CPU-friendly baseline — titles and genres encoded with TF-IDF, reduced using SVD, quantized with residual KMeans:

```bash
python -m generative.semantic_ids --dataset ml-1m --dim 48 --levels 3 --codebook-size 32
```

**Recommended, stronger text representation** — reuse your existing Sentence Transformers:

```bash
python -m pip install -r requirements-scale-semantic.txt
python -m scalable.semantic --dataset ml-1m --reducer raw
python -m generative.semantic_ids --dataset ml-1m \
  --text-vectors data/processed/ml-1m/semantic_raw.npy \
  --dim 48 --levels 3 --codebook-size 32
```

This produces:

```
models/ml-1m/semantic_ids/
  metadata.json
  item_ids.npy
  item_features.npy
  semantic_ids.npy
  codebooks.npy
```

The last semantic-ID token is a **collision suffix**, ensuring each movie resolves unambiguously to one catalogue entry. Without the suffix, semantic-code collisions could make some movies unreachable.

## Step 3. Train the generative Transformer

**First do a tiny memory-safe run** to verify checkpoint saving:

```bash
python -m generative.train --dataset ml-1m --max-len 60 \
  --dim 32 --layers 1 --heads 4 --batch-size 8 \
  --epochs 1 --steps-per-epoch 10 --device cpu
```

Then run a more substantial research experiment:

```bash
python -m generative.train --dataset ml-1m --max-len 60 \
  --dim 64 --layers 2 --heads 4 --batch-size 16 \
  --epochs 8 --steps-per-epoch 200 --patience 3 --device cpu
```

The training script automatically saves **best `weights.pt`** after improvements to **train-prefix validation loss**, enabling early stopping. It uses cross-entropy on the next movie's semantic-ID tokens. The last *training* movie per eligible user is withheld from optimization and used for this internal diagnostic, **not** the official MovieLens validation/test events. Training is intentionally bounded by steps per epoch.

Artifacts:

```
models/ml-1m/tiger/weights.pt
models/ml-1m/tiger/model.json
models/ml-1m/tiger/semantic_ids.npy
models/ml-1m/tiger/item_ids.npy
```

## Step 4. Evaluate TIGER + OGR-inspired slate and legacy baselines together

```bash
python -m generative.evaluate --dataset ml-1m \
  --users 20 --k 10 --pool 48 --beam 120 --slate-diversity 0.25
```

This runs on **the same selected validation users**, excluding all training and earlier held-out movies. It compares:

- `tiger`: constrained semantic-ID beam retrieval;
- `tiger_slate`: relevance/diversity-aware *joint* slate planning over TIGER candidates;
- `bpr_mf` and `svd` where compatible trained factor checkpoints are present.

The generated JSON is saved under `reports/unified/ml-1m/generative_validation_seed42.json`. The existing `Model comparison` tab reads these reports directly. Models absent from disk are listed as unavailable rather than assigned fabricated scores.

**Important:** The beam is a *candidate limit*. TIGER and slate Recall@10 may be lower than a full-catalogue ranker. Generation and rescoring are methodologically distinct; compare metrics alongside candidate budgets and latency. For final testing, freeze hyperparameters on validation and only then use `--split test --final-test`.

## Step 5. Multimodal semantic IDs

MovieLens has ratings, title, genres and user tags but **not** poster images, full plot descriptions or trailer features. The patch does **not** scrape copyrighted artwork.

If you have licensed posters named `posters/<movieId>.jpg` or `.png`, encode them with CLIP:

```bash
python -m pip install sentence-transformers pillow
python -m generative.posters --dataset ml-1m --image-dir posters
```

The encoder writes `data/processed/ml-1m/poster_vectors.npy` with zero rows for missing posters, plus an ID-alignment sidecar. Use train-only BPR factors from your existing `models/ml-1m/bpr/item_vectors.npy` if that model is available. Run a **separate** multimodal experiment:

```bash
python -m generative.semantic_ids --dataset ml-1m \
  --output-dir models/ml-1m/semantic_ids_multimodal \
  --text-vectors data/processed/ml-1m/semantic_raw.npy \
  --visual-vectors data/processed/ml-1m/poster_vectors.npy \
  --collaborative-vectors models/ml-1m/bpr/item_vectors.npy \
  --text-weight 0.7 --visual-weight 0.2 --collaborative-weight 0.1

python -m generative.train --dataset ml-1m --max-len 60 \
  --semantic-id-dir models/ml-1m/semantic_ids_multimodal \
  --output-dir models/ml-1m/tiger_multimodal \
  --epochs 8 --steps-per-epoch 200 --batch-size 16

python -m generative.evaluate --dataset ml-1m --users 20 \
  --multimodal-dir models/ml-1m/tiger_multimodal
```

You can also build **text + collaborative-only** multimodal semantic IDs: omit `--visual-vectors` and adjust weights. Never describe it as including posters unless licensed poster embeddings really exist.

This final comparison adds `tiger_multimodal` and `tiger_multimodal_slate` rows to the **same** evaluation JSON and chart.

## Step 6. Interactive Streamlit

```bash
streamlit run app.py --server.address 0.0.0.0 --server.port 8501
```

The original Streamlit features remain:

- **Recommendations** — original SVD, BPR, two-tower and hybrids;
- **Choose favorites** — cold-start semantic recommendation;
- **Model comparison** — Small/1M/32M selection; displays a full chart from **one** experiment JSON;
- **UMAP genre map** — existing 2D MovieLens Small map;
- **Generative lab** — generative-vs-slate chart, semantic-ID clusters, and similar movie explorer;
- **Methodology** — explicit limitations and data attribution.

**Do not combine metrics from different datasets, seeds, users or retrieval pools on one chart.** Use the full report rather than stitching incompatible numbers together.

## Step 7. Scaling toward 32M

Only after the 1M pipeline is stable:

```bash
python -m scalable.prepare --dataset ml-32m --memory 3GB --threads 2
python -m generative.histories --dataset ml-32m --max-len 60 --memory 3GB --threads 2
python -m scalable.semantic --dataset ml-32m --reducer raw
python -m generative.semantic_ids --dataset ml-32m --text-vectors data/processed/ml-32m/semantic_raw.npy
python -m generative.train --dataset ml-32m --max-len 60 \
  --dim 64 --layers 2 --heads 4 --batch-size 8 \
  --epochs 2 --steps-per-epoch 100 --device cpu
python -m generative.evaluate --dataset ml-32m --users 10 --pool 32 --beam 90
```

32M will consume more disk, CPU time and memory. **Do not assume Codespaces free tier can train a production-scale Transformer; use Colab or Kaggle GPU when feasible.** The code is a research prototype with bounded training, but making 32M efficient may require profiling and additional optimization.

## Reproducibility and scientific integrity

- Train-only interactions for model fitting and internal early stopping.
- User-level last-three-positive holdout inherited from the earlier project, **not a globally time-separated holdout**.
- Existing BPR/SVD checkpoints are checked for user/movie ID alignment and training-history consistency.
- Reports never invent results for untrained models.
- `--split test --final-test` explicitly unlocks final test evaluation.
- The limited beam constrains recall; do not claim it is directly equivalent to exact full-catalogue ranking.
- Text model names and vector sources are recorded. Any multimodal result requires real aligned vectors.
- Original MovieLens usage restrictions still apply. Check GroupLens terms before commercial use or redistribution.

## Research references

- Rajput et al., *Recommender Systems with Generative Retrieval* (TIGER), 2023: https://arxiv.org/abs/2305.05065
- Hu et al., *Once Generated, Ranked: End-to-End Generative Slate Recommendation with Unified Semantic-Collaborative IDs* (OGR), 2026: https://arxiv.org/abs/2608.17613
- GroupLens MovieLens datasets: https://grouplens.org/datasets/movielens/

The implementations are explicitly labelled **TIGER-inspired** and **OGR-inspired** to distinguish them from research reproductions.
