# TIGER Movie Recommender — runnable research suite

This is a **one-command experiment** for the existing `Reco` repository. It builds a **metadata-only TIGER-inspired baseline**, then an **all-MiniLM-L6-v2 Sentence Transformer version**, and optionally a **content + BPR collaborative fusion** and **real-poster + text fusion**. Each trained variant is evaluated both as constrained semantic-ID retrieval and with an **OGR-inspired diversity-aware slate planner**. It writes **one common-user comparison report** for the existing Streamlit Generative Lab.

**Scientific labeling:** residual KMeans semantic IDs are not TIGER's original RQ-VAE; the slate planner is not a reproduction of OGR's learned policy. MovieLens has titles/genres and ratings, **not posters or plots**. Do not claim a visual model without real permitted poster assets. Larger models and more features do not guarantee better accuracy.

## A. Install in GitHub Codespaces

Upload `tiger_research_suite_complete.zip` to your GitHub repository and, in Codespaces:

```bash
cd /workspaces/Reco
git pull origin main
unzip -o tiger_research_suite_complete.zip
python -m pip install -r requirements-tiger-suite.txt
python -m pytest -q tests/test_research_suite.py tests/test_generative.py
```

This ZIP includes the **full previously supplied generative patch** plus the research-suite upgrade. It **does not** include all `scalable/` preprocessing code: that must already be present from your MovieLens 32M scaling upgrade. Check with `ls scalable/prepare.py`. If missing, extract the earlier scaling ZIP and then **reapply the CSV-fix patch**; avoid overwriting the corrected `scalable/prepare.py` with older code.

`git status` should show the new files. Commit the source code after testing; trained weights and datasets stay excluded from Git by default.

## B. Recommended first run — MovieLens 1M

Run **one** command, from `/workspaces/Reco`:

```bash
python -m generative.research_suite --dataset ml-1m --profile quick --device cpu
```

The runner automatically:

1. Reuses `data/processed/ml-1m/`, or prepares it if missing.
2. Reuses or builds *training-only* chronological histories (`generative_L60/`).
3. Creates residual KMeans semantic IDs from **TF-IDF titles and genres**.
4. Fits a compact TIGER-inspired Transformer; saves `models/ml-1m/tiger/weights.pt`.
5. Downloads all-MiniLM-L6-v2 and generates **title+genre Sentence Transformer embeddings** (if they are not already cached).
6. Fits a **separate** TIGER-inspired model using those embeddings in `models/ml-1m/tiger_sentence/`.
7. If an aligned `models/ml-1m/bpr/item_vectors.npy` exists, trains `tiger_text_collab` using these **train-only** collaborative factors.
8. If `--poster-vectors` is supplied, trains an additional `tiger_visual` model. The poster-vector file must have a matching `_movie_ids.npy` sidecar.
9. Evaluates all available variants on **exactly the same validation users**, with the same seen-item exclusions, beam budget, `K=10`, and seed; slate-planning metrics are calculated for each variant.
10. Writes a consolidated JSON and CSV for Streamlit; **never fabricates missing model results**.

**Quick profile is a system check**, not a publishable accuracy result: one epoch, 12 steps, batch size 8, up to eight evaluated users. You should see `Best checkpoint saved:` for each variant and finally `Completed ... TIGER variants and slate comparisons.`

## C. Stronger experiment

After the quick run, retrain with the stronger profile:

```bash
python -m generative.research_suite --dataset ml-1m \
  --profile research --force-retrain --users 60 --device cpu
```

**Why `--force-retrain`?** The earlier quick checkpoints use fewer layers and training epochs. The runner intentionally refuses to misrepresent those checkpoints as the more heavily trained profile. Research profile: 8 epochs, up to 200 steps each, batch 16, 64-dimensional hidden states, 2 Transformer layers, early stopping on withheld *training* prefixes. You can also run on a suitable GPU with `--device cuda`.

If you must start with the cheapest step possible, run `--no-sentence --profile quick`. That builds only the metadata baseline. To add Sentence Transformers later, rerun without `--no-sentence`; existing matching checkpoints will be reused.

## D. Optional genuine multimodal features

Only use image embeddings from poster files you are entitled to use. Generate vectors from a local `posters/` folder containing files named `<movieId>.jpg` or `.png`:

```bash
python -m generative.posters --dataset ml-1m --image-dir posters
python -m generative.research_suite --dataset ml-1m --profile research \
  --poster-vectors data/processed/ml-1m/poster_vectors.npy --force-retrain
```

The `tiger_visual` experiment uses real CLIP image vectors **plus** text and optionally BPR. Without posters, text+BPR can still be a useful **semantic-collaborative fusion**, but isn't a visual multimodal experiment.

The existing `scalable.train` module can create a BPR checkpoint separately. The suite **never trains BPR automatically**, avoiding an unexpected large memory allocation. For example, on 1M:

```bash
python -m scalable.train --dataset ml-1m --factors 32 --batch-size 256 \
    --steps-per-epoch 100 --epochs 3
```

Do not start another copy of BPR training on 32M if your Codespace has memory problems.

## E. See charts in Streamlit

```bash
streamlit run app.py --server.address 0.0.0.0 --server.port 8501
```

Open **Generative lab**, choose **ml-1m**, and select:

- `ndcg_at_k` — ranking quality;
- `recall_at_k` — hit rate (one held-out positive per user);
- `catalog_coverage_at_k` — catalogue diversity;
- `query_retrieval_ms_mean` — query latency.

`Model comparison` can read the same JSON. Each variant produces a `*_slate` result (OGR-inspired planner). The **UMAP genre map** and original SVD/BPR/semantic functionality remain intact in other tabs.

Outputs:

```text
models/ml-1m/semantic_ids/                  # Metadata-only semantic IDs
models/ml-1m/semantic_ids_sentence/         # Sentence Transformer semantic IDs
models/ml-1m/tiger/weights.pt               # Metadata baseline
models/ml-1m/tiger_sentence/weights.pt      # Sentence Transformer variant
models/ml-1m/tiger_text_collab/weights.pt   # Optional BPR fusion
models/ml-1m/tiger_visual/weights.pt        # Optional genuine poster fusion
reports/unified/ml-1m/generative_validation_seed42.json
reports/unified/ml-1m/tiger_ablation_validation_seed42.csv
```

To check results in Codespaces without Streamlit:

```bash
python -m json.tool reports/unified/ml-1m/generative_validation_seed42.json
```

Do not compare scores from different datasets, user sets, `K` values, beams, or data partitions. The runner writes the **same-cohort** ablation comparison. It backs up an existing report before replacing it.

## F. MovieLens 32M and final test

Once the 1M research protocol has been validated, repeat with `--dataset ml-32m --memory 3GB --threads 2`, starting with `--profile quick` and a suitable GPU if available. 32M requires materially more compute and disk. **This upgrade does not remove the need for profiling.**

The test split is deliberately locked. Once model and hyperparameters have been selected *from validation alone*:

```bash
python -m generative.research_suite --dataset ml-1m --profile research \
  --users 60 --final-test
```

Do not tune further based on test numbers or repeatedly use the test split to choose hyperparameters.

## Reproducibility and limitations

- The evaluation `Generative Lab` report uses one identical seeded validation cohort and common movie exclusions across all variants.
- User histories come from training interactions only, and the *last training item* provides a separate early-stopping diagnostic. MovieLens rating times do not necessarily represent watch order.
- Movie titles and genres alone provide limited semantic information. Licensed plot summaries would make a stronger text experiment.
- MiniBatchKMeans generates unique semantic codes with collision suffixes, **not** an RQ-VAE codebook.
- The slate planner is relevance/diversity-aware over generated candidate lists; **not** end-to-end learned slate policy optimization.
- The beam and candidate pool impose an artificial recall ceiling; report these settings alongside NDCG/Recall.
- The optional BPR and SVD results appear only with matching, trained factor checkpoints.
- `joblib` and PyTorch checkpoints should only be loaded from trusted local sources.
- Real MovieLens runs are required before publishing numerical performance claims. The local synthetic tests only check implementation behavior.
