"""ONE Streamlit application: original recommendations, UMAP, and all benchmarks.

Run: streamlit run app.py --server.address 0.0.0.0 --server.port 8501
No large 32M checkpoints are loaded simply to draw the benchmark charts.
"""
from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st

from src.streamlit_compare import render_model_comparison

st.set_page_config(page_title="MovieLens Recommendation Research Lab", page_icon="🎬", layout="wide")
st.title("🎬 MovieLens Recommendation Research Lab")
st.caption("Classical · BPR · Semantic / UMAP · Two-Tower · TIGER · Slate generation · LambdaMART")
st.caption("GroupLens MovieLens research datasets · Historical rating sequences, not verified viewing sequences")

SMALL_MODEL = Path("artifacts/recommender.joblib")
BPR_FACTORS = Path("artifacts/bpr_models.npz")


@st.cache_resource(show_spinner="Loading MovieLens Small recommender…")
def get_small_model(path: str, modified: float):
    # joblib loads Python objects; ONLY load trusted model artifacts made locally.
    from src.recommender import HybridRecommender
    return HybridRecommender.load(path)


@st.cache_resource(show_spinner="Loading MovieLens Small BPR factors…")
def get_small_bpr(path: str, modified: float):
    with np.load(path, allow_pickle=False) as bundle:
        return {name: bundle[name].copy() for name in bundle.files}


engine = None
if SMALL_MODEL.is_file():
    try:
        engine = get_small_model(str(SMALL_MODEL), SMALL_MODEL.stat().st_mtime)
    except Exception as exc:
        st.warning(f"The original 100K recommender could not be loaded: {exc}")

bpr_factors = None
if engine is not None and BPR_FACTORS.is_file():
    try:
        raw_bpr = get_small_bpr(str(BPR_FACTORS), BPR_FACTORS.stat().st_mtime)
        if (np.array_equal(raw_bpr["movie_ids"], engine.movie_ids)
                and np.array_equal(raw_bpr["user_ids"], engine.user_ids)):
            bpr_factors = raw_bpr
        else:
            st.warning("Small BPR embeddings do not match Small recommender IDs; ignoring them.")
    except (KeyError, OSError, ValueError) as exc:
        st.warning(f"Small BPR factors unavailable: {exc}")


def bpr_recommend(user_id, model, k):
    u = engine.user_to_idx[int(user_id)]
    scores = bpr_factors[f"{model}_item"] @ bpr_factors[f"{model}_user"][u]
    scores = np.array(scores, copy=True)
    scores[list(engine.seen[int(user_id)])] = -np.inf
    winners = np.argsort(-scores, kind="stable")[:k]
    return engine._result(winners, scores)


known_tab, favorites_tab, compare_tab, map_tab, gen_tab, method_tab = st.tabs([
    "Recommendations", "Choose favorites", "Model comparison", "UMAP genre map", "Generative lab", "Methodology"
])

with known_tab:
    st.subheader("Existing user recommendations · MovieLens Small")
    if engine is None:
        st.info("No trusted MovieLens Small model. Run `python -m src.train` to enable this tab. "
                "The large-scale comparison tab remains available independently.")
    else:
        left, right = st.columns([1, 2])
        with left:
            user_id = st.selectbox("Anonymous user", engine.user_ids.tolist(), key="known_user")
            models = list(engine.models)
            if bpr_factors is not None:
                for m in ("bpr_mf", "bpr_pca", "bpr_umap", "bpr_raw"):
                    if f"{m}_user" in bpr_factors and f"{m}_item" in bpr_factors:
                        models.append(m)
            model_choice = st.selectbox("Model", models, index=models.index("hybrid") if "hybrid" in models else 0)
            count = st.slider("Number of recommendations", 5, 30, 10)
        with right:
            seen_ids = sorted(engine.seen[int(user_id)])
            st.write("**Sample of earlier rated movies**")
            st.dataframe(engine.movies.iloc[seen_ids][["title", "genres"]].head(12),
                         hide_index=True, use_container_width=True)
        try:
            if model_choice.startswith("bpr_") and bpr_factors is not None:
                table = bpr_recommend(user_id, model_choice, count)
            else:
                table = engine.recommend(user_id, k=count, model=model_choice)
            st.write("**Recommended movies**")
            st.dataframe(table, hide_index=True, use_container_width=True)
        except (KeyError, ValueError) as exc:
            st.error(f"Couldn't generate recommendations: {exc}")

with favorites_tab:
    st.subheader("Cold-start recommendations · MovieLens Small")
    if engine is None:
        st.info("Run `python -m src.train` to enable cold-start recommendations.")
    else:
        labels = {f"{row.title} (ID {row.movieId})": int(row.movieId)
                  for row in engine.movies.itertuples(index=False)}
        defaults = [name for name in labels if name.startswith("Toy Story (1995)")][:1]
        selected = st.multiselect("Choose movies you enjoyed", list(labels),
                                  default=defaults, max_selections=7)
        if selected:
            st.dataframe(engine.recommend_from_favorites([labels[s] for s in selected], k=10),
                         hide_index=True, use_container_width=True)
        st.caption("This mode combines item similarities, genre metadata, and optional "
                   "semantic embeddings. It does not create a learned user-ID vector.")

with compare_tab:
    render_model_comparison()

with map_tab:
    st.subheader("UMAP movie genres · MovieLens Small")
    if engine is None:
        st.info("The original UMAP map needs the MovieLens Small model. "
                "Run `python -m src.train`, then `python -m src.semantic`.")
    else:
        try:
            from src.bpr_semantic_ui import render_embedding_map
            render_embedding_map(engine)
        except ImportError as exc:
            st.warning(f"Missing UMAP visualization dependency: {exc}")
            st.code("python -m pip install -r requirements-all-ui.txt", language="bash")
    st.caption("This tab currently visualizes **MovieLens Small** title/genre semantics, "
               "not a 32M-trained UMAP map. Large-model scores appear in Model comparison.")

with gen_tab:
    from generative.dashboard import render_generative_lab
    render_generative_lab()

with method_tab:
    st.markdown("""
    ### Datasets and fair comparison
    - **MovieLens Small**: older full-catalogue ranking results with one held-out
      positive per user; model artifacts stored under `artifacts/`.
    - **MovieLens 1M / 32M**: unified benchmark reports in `reports/unified/<dataset>/`.
      Only compare algorithms from **the same report**, which uses the same user sample,
      split, K, exclusion rules, and retrieval index.
    - **TIGER-inspired:** autoregressive generative retrieval over residual-KMeans semantic IDs.
    - **Multimodal:** text is required; visual/poster features must be provided separately.
    - **OGR-inspired:** constrained candidate generation followed by diversity-aware slate planning;
      it is not a reproduction of OGR's learned list-level policy optimization.
    - **UMAP map**: an exploratory visualization of title/genre sentence embeddings.
      Spatial closeness in 2D is not proof of recommendation effectiveness.
    - **Limitations**: missing ratings are not dislikes; per-user chronological splitting
      is not a globally time-separated protocol. An approximate FAISS index can alter
      reported retrieval quality. Offline metrics are not causal business uplift.

    **Data attribution:** [GroupLens MovieLens](https://grouplens.org/datasets/movielens/).
    Observe the dataset's noncommercial research conditions.
    """)
