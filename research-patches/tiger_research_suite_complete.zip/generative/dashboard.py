"""Small, lazy Streamlit view for generative experiments; no checkpoints loaded."""
from __future__ import annotations
import json
from pathlib import Path
import pandas as pd


def find_reports(dataset,root='reports/unified'):
    if dataset not in ('ml-1m','ml-32m','ml-latest-small'):
        raise ValueError('Invalid dataset')
    return sorted((Path(root)/dataset).glob('generative_*.json'),
                  key=lambda x:x.stat().st_mtime,reverse=True)


def render_generative_lab():
    import streamlit as st
    st.subheader('Generative movie recommendations · TIGER-style retrieval + slate planning')
    st.caption('This lab reads evaluated experiments; opening it never starts training.')
    ds=st.selectbox('Dataset for generative research',('ml-1m','ml-32m','ml-latest-small'),key='gen_ds')
    reports=find_reports(ds)
    if not reports:
        st.info('No evaluated generative report yet. Build semantic IDs, histories, train, then evaluate.')
        st.code(f'python -m generative.evaluate --dataset {ds} --users 20 --pool 48 --beam 120',language='bash')
        return
    selected=st.selectbox('Run',reports,format_func=lambda x:x.name,key='gen_run')
    report=json.loads(selected.read_text(encoding='utf-8'))
    df=pd.DataFrame.from_dict(report['results'],orient='index')
    if df.empty:st.info('No evaluated checkpoints in this report.');return
    df.index.name='model'
    st.caption(f"{ds} · {report['split']} · K={report['k']} · {report['user_sample_size']} shared users")
    metric=st.selectbox('Metric',('ndcg_at_k','recall_at_k','catalog_coverage_at_k','query_retrieval_ms_mean'),key='gen_metric')
    st.bar_chart(df[[metric]].sort_values(metric,ascending=metric=='query_retrieval_ms_mean'))
    st.dataframe(df,use_container_width=True)
    st.markdown('#### What the methods do')
    st.write('**TIGER:** predicts unique semantic ID tokens by constrained autoregressive decoding.')
    st.write('**Multimodal:** fuses available text, visual, and collaborative movie vectors before quantization.')
    st.write('**Slate:** uses an OGR-inspired diversity/novelty-aware list planner on generated candidates.')
    st.caption('These labels denote research-inspired implementations, not exact reproductions of TIGER/OGR.')
    with st.expander('Explore semantic IDs and nearest movies'):
        root=Path('models')/ds/'semantic_ids'
        if (root/'semantic_ids.npy').is_file() and (root/'item_features.npy').is_file():
            import numpy as np
            codes=np.load(root/'semantic_ids.npy',mmap_mode='r')
            movie_ids=np.load(root/'item_ids.npy',mmap_mode='r')
            embedding=np.load(root/'item_features.npy',mmap_mode='r')
            st.caption(f'{len(codes):,} movies encoded as {codes.shape[1]} tokens (including collision suffix).')
            st.bar_chart(pd.Series(codes[:,0]).value_counts().head(25).sort_index())
            choice=st.number_input('MovieLens movie ID to inspect',min_value=int(movie_ids[0]),
                                   max_value=int(movie_ids[-1]),value=int(movie_ids[0]),step=1)
            ix=int(np.searchsorted(movie_ids,int(choice)))
            if ix>=len(movie_ids) or movie_ids[ix]!=choice:
                st.warning('That MovieLens ID is not in the selected dataset.')
            else:
                st.code(str(list(map(int,codes[ix]))))
                scores=np.asarray(embedding@embedding[ix],dtype=np.float32)
                scores[ix]=-np.inf
                neighbor=np.argsort(-scores)[:8]
                st.dataframe(pd.DataFrame({'movieId':movie_ids[neighbor],
                    'cosine_similarity':scores[neighbor],
                    'semantic_ID':[list(map(int,codes[j])) for j in neighbor]}),hide_index=True)
                st.caption('Semantic closeness is based on fused item vectors, not user preferences.')
        else:
            st.info('Build semantic IDs first: python -m generative.semantic_ids --dataset '+ds)
    with st.expander('Limitations and reproducibility'):
        for item in report.get('caveats',[]):st.write('• '+item)
        st.caption('Do not compare numeric values across different sampled-user reports.')
