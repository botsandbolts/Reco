"""Common-cohort benchmark: TIGER-style generations, multimodal and OGR-inspired slates.

No future movie is used in training. Optional baseline BPR/SVD evaluations share
identical users, targets, exclusions and sampled evaluation window.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import time
from pathlib import Path
import numpy as np
from scipy.sparse import load_npz
from scalable.common import load_model, store_json
from scalable.evaluate import _available_targets, _previous_events
from .model import build_trie
from .train import load_checkpoint, load_histories
from .slate import plan_slate


def _ranking_metrics(rows,n_items,k):
    """Rows are (target index, recommended item indices, elapsed seconds)."""
    if not rows: raise ValueError('No evaluation rows')
    coverage=set();hit=0;ndcg=0.;lat=[]
    for target,top,elapsed in rows:
        first=list(top)[:k]
        coverage.update(first);lat.append(elapsed*1000)
        if target in first:
            pos=first.index(target)
            hit+=1;ndcg+=1/np.log2(pos+2)
    n=len(rows)
    return {'users_evaluated':n,'recall_at_k':round(hit/n,6),
            'ndcg_at_k':round(ndcg/n,6),
            'catalog_coverage_at_k':round(len(coverage)/n_items,6),
            'query_retrieval_ms_mean':round(float(np.mean(lat)),3)}


def measure_generative(model,seq,lens,codes,features,users,targets,seen,previous,
                       *,k,device='cpu',pool=48,beam=120,slate_diversity=0.25,
                       slate_novelty=0.,popularity=None):
    trie=build_trie(codes)
    base=[]; slate=[]
    for uid,target in zip(users,targets):
        uid=int(uid);target=int(target)
        excluded=set(map(int,seen.indices[seen.indptr[uid]:seen.indptr[uid+1]]))
        excluded.update(previous.get(uid,()))
        if target in excluded:raise ValueError('Leakage: target in training/earlier holdout')
        n=int(lens[uid]); hist=np.asarray(seq[uid,:n],dtype=np.int64)-2
        start=time.perf_counter()
        ranked=model.decode(hist,trie,beam_width=max(pool,beam),k=pool,seen=excluded,device=device)
        delay=time.perf_counter()-start
        ids=[i for i,_ in ranked]
        base.append((target,ids,delay))
        start=time.perf_counter()
        planned=plan_slate(ranked,features,k=k,beam_width=4,
                           diversity=slate_diversity,novelty=slate_novelty,
                           popularity=popularity)
        slate.append((target,planned,delay+time.perf_counter()-start))
    return _ranking_metrics(base,len(codes),k),_ranking_metrics(slate,len(codes),k)


def measure_factor(q, items, users,targets, seen,previous, *,k):
    rows=[]
    for u,t in zip(users,targets):
        excluded=set(map(int,seen.indices[seen.indptr[int(u)]:seen.indptr[int(u)+1]]))
        excluded.update(previous.get(int(u),()))
        if int(t) in excluded:raise ValueError('Leakage in factor evaluation')
        start=time.perf_counter()
        scores=np.asarray(items @ q[int(u)],dtype=np.float32)
        if excluded:scores[list(excluded)]=-np.inf
        # n_items never materialized as an n_users * n_items matrix
        order=np.argsort(-scores,kind='stable')[:k].tolist()
        rows.append((int(t),order,time.perf_counter()-start))
    return _ranking_metrics(rows,len(items),k)


def run(dataset='ml-1m',data_dir='data',model_dir=None,multimodal_dir=None,
        bpr_dir=None,users=50,seed=42,split='validation',final_test=False,k=10,
        pool=48,beam=120,device='cpu',slate_diversity=0.25,slate_novelty=0.,
        output_dir=None,extra_model_dirs=None):
    if split=='test' and not final_test:
        raise ValueError('Unlock final test only once with --final-test')
    if split not in ('validation','test') or users<1 or pool<k:raise ValueError('Invalid evaluation settings')
    processed=Path(data_dir)/'processed'/dataset
    default=Path('models')/dataset/'tiger'
    folders=[('tiger',Path(model_dir) if model_dir else default)]
    if multimodal_dir:folders.append(('tiger_multimodal',Path(multimodal_dir)))
    for label, model_path in (extra_model_dirs or {}).items():
        if not re.fullmatch(r'tiger_[a-z][a-z0-9_]*', label):
            raise ValueError(f'Invalid or reserved model label: {label}')
        if label in (name for name, _ in folders):
            raise ValueError(f'Duplicate model label: {label}')
        folders.append((label, Path(model_path)))
    models={}; ids=None; item_ids=None; history=None; seen=None
    for name,folder in folders:
        m,cfg=load_checkpoint(folder,device=device)
        if cfg['dataset']!=dataset:raise ValueError('Model dataset mismatch')
        hist,seq,lens,hids=load_histories(processed,int(cfg['max_len']))
        model_ids=np.load(folder/'item_ids.npy')
        if not np.array_equal(hids,model_ids):raise ValueError('History semantic ID alignment mismatch')
        raw_users=np.load(hist/'user_ids.npy'); local_seen=load_npz(hist/'train_seen.npz').tocsr()
        if ids is None:
            ids=raw_users; item_ids=model_ids; history=(seq,lens);seen=local_seen
        elif (not np.array_equal(ids,raw_users) or not np.array_equal(item_ids,model_ids)
              or seen.nnz!=local_seen.nnz or not np.array_equal(seen.indptr,local_seen.indptr)
              or not np.array_equal(seen.indices,local_seen.indices)):
            raise ValueError('Models use different training histories or movie vocabularies')
        sem_dir=Path(cfg['semantic_ids'])
        features=np.load(sem_dir/'item_features.npy',mmap_mode='r')
        models[name]=(m,seq,lens,np.load(folder/'semantic_ids.npy'),features)
    raw_users,raw_targets=_available_targets(processed,split,ids,item_ids)
    lengths=history[1]
    good=np.flatnonzero(lengths[raw_users]>=3)
    if len(good)==0:raise ValueError('No eligible users with at least 3 training positives')
    rng=np.random.default_rng(seed)
    chosen=np.sort(rng.choice(good,size=min(users,len(good)),replace=False))
    u=raw_users[chosen];t=raw_targets[chosen]
    previous=_previous_events(processed,['rank_train'] if split=='validation'
                               else ['rank_train','validation'],ids,item_ids)
    results={};missing=[]
    for name,(m,seq,lens,codes,features) in models.items():
        metric,slate=measure_generative(m,seq,lens,codes,features,u,t,seen,previous,k=k,
                    device=device,pool=pool,beam=beam,
                    slate_diversity=slate_diversity,slate_novelty=slate_novelty)
        results[name]=metric
        results[name+'_slate']=slate
        print(f'{name} Recall@{k}={metric["recall_at_k"]}, slate NDCG@{k}={slate["ndcg_at_k"]}',flush=True)
    folder=Path(bpr_dir) if bpr_dir else Path('models')/dataset/'bpr'
    if (folder/'model.json').exists():
        cfg,ref_u,ref_i,uf,ifac,reference_seen=load_model(folder)
        if cfg['dataset']!=dataset or not np.array_equal(ref_u,ids) or not np.array_equal(ref_i,item_ids):
            raise ValueError('Existing BPR checkpoint ID mismatch with generative evaluation')
        if not (seen.shape==reference_seen.shape and seen.nnz==reference_seen.nnz and
                np.array_equal(seen.indptr,reference_seen.indptr) and
                np.array_equal(seen.indices,reference_seen.indices)):
            raise ValueError('BPR trained with different interaction history')
        results['bpr_mf']=measure_factor(uf,ifac,u,t,seen,previous,k=k)
        up,ip=folder/'svd_user_vectors.npy',folder/'svd_item_vectors.npy'
        if up.exists() and ip.exists():
            results['svd']=measure_factor(np.load(up,mmap_mode='r'),np.load(ip,mmap_mode='r'),
                                          u,t,seen,previous,k=k)
        else:missing.append('svd')
    else:missing.extend(['bpr_mf','svd'])
    hash_users=hashlib.sha256(np.asarray(ids[u],dtype=np.int64).tobytes()).hexdigest()
    report={'dataset':dataset,'split':split,'k':k,'seed':seed,'user_sample_size':len(u),
        'evaluated_user_ids_sha256':hash_users,'same_user_sample':True,
        'index':'exact_factor_scores / constrained generative beam',
        'results':results,'unavailable_models':missing,
        'caveats':['TIGER-inspired, not exact published TIGER. Semantic IDs use residual KMeans.',
          'Slate planner is OGR-inspired; no learned slate policy / OGR reproduction.',
          'Candidate beam limits generative recall and is not equivalent to full-catalog scoring.',
          'Training uses only early positives; last TRAIN movie reserved for internal early stopping.',
          'Only trained and aligned checkpoints appear; poster modality only when provided.',
          'Ratings are not viewing events or confirmed negative impressions.',
          'Same sample within this report; do not mix scores with old independent runs.']}
    out=Path(output_dir) if output_dir else Path('reports')/'unified'/dataset
    file=out/f'generative_{split}_seed{seed}.json'
    store_json(file,report)
    print(f'Saved unified generative report: {file}')
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for flag,default in [('dataset','ml-1m'),('data-dir','data'),('model-dir',None),
            ('multimodal-dir',None),('bpr-dir',None),('split','validation'),('device','cpu'),('output-dir',None)]:
        p.add_argument('--'+flag,default=default)
    for flag,default in [('users',50),('seed',42),('k',10),('pool',48),('beam',120)]:
        p.add_argument('--'+flag,type=int,default=default)
    for flag,default in [('slate-diversity',0.25),('slate-novelty',0.)]:
        p.add_argument('--'+flag,type=float,default=default)
    p.add_argument('--final-test',action='store_true')
    p.add_argument('--extra-model',action='append',default=[],metavar='NAME=PATH',
                   help='Additional trained TIGER variants sharing the same data protocol')
    args=vars(p.parse_args())
    extra=args.pop('extra_model')
    pairs={}
    for entry in extra:
        if '=' not in entry: raise ValueError('--extra-model requires NAME=PATH')
        name,path=entry.split('=',1)
        if name in pairs: raise ValueError('Duplicate --extra-model label: '+name)
        pairs[name]=path
    run(**args,extra_model_dirs=pairs)
