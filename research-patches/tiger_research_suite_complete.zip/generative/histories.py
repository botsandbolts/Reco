"""History preparation for large MovieLens: join TRAIN pairs to raw timestamps.

No held-out interactions enter model input or training targets. Data is disk-backed;
fixed-length input arrays occupy O(users * max_len), not O(users * movies).
"""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
from scipy.sparse import csr_matrix, save_npz
from scalable.common import load_catalog, load_interactions, encode_ids, store_json
from scalable.prepare import extract_inputs, sql_literal


def encode_history_rows(rows, user_ids, item_ids, max_len):
    """Pure testable conversion: iterable of (userId, ordered movieId list)."""
    if max_len < 4:
        raise ValueError("--max-len must be at least 4")
    user_ids = np.asarray(user_ids, dtype=np.int64)
    item_ids = np.asarray(item_ids, dtype=np.int64)
    x = np.zeros((len(user_ids), max_len), dtype=np.int32)
    lengths = np.zeros(len(user_ids), dtype=np.int32)
    seen_u = set()
    for raw_uid, movies in rows:
        loc = int(np.searchsorted(user_ids, int(raw_uid)))
        if loc >= len(user_ids) or user_ids[loc] != raw_uid:
            raise ValueError("Sequence user missing from train vocabulary")
        if loc in seen_u:
            raise ValueError("Duplicate user in sequence export")
        seen_u.add(loc)
        movies = np.asarray(movies[-max_len:], dtype=np.int64)
        if len(movies) == 0:
            continue
        indices = encode_ids(movies, item_ids)
        x[loc, :len(indices)] = indices + 2  # 0=PAD, 1=MASK
        lengths[loc] = len(indices)
    if len(seen_u) != len(user_ids):
        raise ValueError("History export missing users")
    return x, lengths


def _read_rows_in_batches(con, path, user_ids, item_ids, max_len, output):
    """Stream Arrow batches instead of materializing all Python lists."""
    import pyarrow  # noqa: F401; required by fetch_record_batch
    seq = np.lib.format.open_memmap(output / "sequences.npy", mode="w+", dtype="int32",
                                    shape=(len(user_ids), max_len))
    seq[:] = 0
    lengths = np.zeros(len(user_ids), dtype=np.int32)
    matched = 0
    cursor = con.execute("SELECT userId, movie_ids FROM read_parquet(?) ORDER BY userId",
                         [(output / "sequence_train.parquet").as_posix()])
    for batch in cursor.fetch_record_batch(rows_per_batch=2000):
        raw_users = batch.column(batch.schema.get_field_index("userId")).to_numpy().astype(np.int64)
        lists = batch.column(batch.schema.get_field_index("movie_ids")).to_pylist()
        locations = encode_ids(raw_users, user_ids)
        for u, ids in zip(locations, lists):
            ids = np.asarray(ids[-max_len:], dtype=np.int64)
            indices = encode_ids(ids, item_ids)
            seq[int(u), :len(indices)] = indices + 2
            lengths[int(u)] = len(indices)
            matched += 1
    seq.flush()
    np.save(output / "lengths.npy", lengths)
    if matched != len(user_ids):
        raise RuntimeError(f"Histories contain {matched} users; expected {len(user_ids)}")
    return lengths


def run(dataset="ml-1m", data_dir="data", max_len=100, memory="3GB", threads=2,
        force=False):
    import duckdb
    if not (4 <= max_len <= 1000):
        raise ValueError("max_len must be in [4, 1000]")
    processed = Path(data_dir) / "processed" / dataset
    if not (processed / "manifest.json").is_file():
        raise FileNotFoundError(f"Prepare dataset first: python -m scalable.prepare --dataset {dataset}")
    output = processed / f"generative_L{max_len}"
    manifest = output / "manifest.json"
    if manifest.exists() and not force:
        print(f"Reusing generative histories in {output}")
        return output
    output.mkdir(parents=True, exist_ok=True)
    catalog = load_catalog(processed)
    item_ids = np.sort(catalog.movieId.to_numpy(dtype=np.int64))
    train_path = processed / "train.parquet"
    with duckdb.connect() as con:
        con.execute(f"SET threads={int(threads)}")
        if memory not in {"1GB", "2GB", "3GB", "4GB", "6GB", "8GB"}:
            raise ValueError("memory must be one of 1GB, 2GB, 3GB, 4GB, 6GB, 8GB")
        con.execute(f"SET memory_limit={sql_literal(memory)}")
        spill = output / "spill"
        spill.mkdir(exist_ok=True)
        con.execute(f"SET temp_directory={sql_literal(spill.as_posix())}")
        raw = Path(data_dir) / "raw" / dataset / "ratings.csv"
        if not raw.exists():
            raw, _ = extract_inputs(dataset, Path(data_dir) / "raw")
        seq_parquet = output / "sequence_train.parquet"
        if not seq_parquet.exists() or force:
            print("Reconstructing chronological TRAIN-only histories from ratings CSV...", flush=True)
            types = "{'userId':'BIGINT','movieId':'BIGINT','rating':'DOUBLE','timestamp':'BIGINT'}"
            # An inner join against train.parquet prevents held-out positives from
            # entering the histories. MAX(timestamp) disambiguates repeated ratings.
            query = f"""
                COPY (
                    SELECT userId, LIST(movieId ORDER BY ts, movieId) AS movie_ids
                    FROM (
                        SELECT t.userId, t.movieId, MAX(r.timestamp) AS ts
                        FROM read_parquet({sql_literal(train_path.as_posix())}) t
                        JOIN read_csv({sql_literal(raw.as_posix())}, header=true,
                                      auto_detect=false, columns={types}) r
                          ON t.userId=r.userId AND t.movieId=r.movieId
                        GROUP BY t.userId,t.movieId
                    ) training_events
                    GROUP BY userId
                ) TO {sql_literal(seq_parquet.as_posix())} (FORMAT PARQUET, COMPRESSION ZSTD)
            """
            con.execute(query)
        user_ids = con.execute("SELECT userId FROM read_parquet(?) ORDER BY userId",
                               [seq_parquet.as_posix()]).fetchnumpy()["userId"].astype(np.int64)
        np.save(output / "user_ids.npy", user_ids)
        np.save(output / "item_ids.npy", item_ids)
        lengths = _read_rows_in_batches(con, seq_parquet, user_ids, item_ids, max_len, output)
        n_seq = int(np.sum(lengths >= 2))
        if n_seq == 0:
            raise ValueError("No eligible sequences: need users with at least 2 train positives")
        # Explicit full history exclusion matrix for fair evaluation (not just last L).
        raw_u, raw_i = load_interactions(processed, "train")
        u = encode_ids(raw_u, user_ids)
        i = encode_ids(raw_i, item_ids)
        seen = csr_matrix((np.ones(len(u), dtype=np.uint8), (u,i)),
                          shape=(len(user_ids),len(item_ids)))
        seen.data[:] = 1
        seen.sort_indices()
        save_npz(output / "train_seen.npz", seen, compressed=True)
        print(f"Created {len(user_ids):,} histories; >=2 events: {n_seq:,}; items: {len(item_ids):,}")
        store_json(manifest, {
            "dataset": dataset, "max_len": max_len, "users": len(user_ids),
            "items": len(item_ids), "eligible_users": n_seq,
            "training_pairs": int(seen.nnz),
            "source": "Only train.parquet interactions, ordered by rating timestamps",
            "limitation": "Rating timestamp is not necessarily film viewing time; histories truncated to last L events for Transformer"
        })
    return output


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--dataset", default="ml-1m")
    p.add_argument("--data-dir", default="data")
    p.add_argument("--max-len", type=int, default=100)
    p.add_argument("--memory", default="3GB")
    p.add_argument("--threads", type=int, default=2)
    p.add_argument("--force", action="store_true")
    print(run(**vars(p.parse_args())))
