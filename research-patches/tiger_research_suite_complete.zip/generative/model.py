"""Compact TIGER-inspired encoder/decoder Transformer over unique semantic IDs.

This is not an exact reproduction of TIGER's T5 backbone or RQ-VAE quantizer.
"""
from __future__ import annotations
import numpy as np
import torch
from torch import nn


class GenerativeRetriever(nn.Module):
    def __init__(self, semantic_ids, vocab_size, max_len=60, dim=64, heads=4,
                 layers=2, dropout=0.1):
        super().__init__()
        codes=torch.as_tensor(np.asarray(semantic_ids,dtype=np.int64))
        if codes.ndim!=2 or codes.shape[1]<2:
            raise ValueError('semantic_ids must have shape (movies, levels + suffix)')
        if int(codes.max())>=vocab_size or int(codes.min())<2:
            raise ValueError('semantic IDs outside vocabulary')
        if dim%heads: raise ValueError('dim must be divisible by heads')
        self.register_buffer('item_codes',codes)
        self.code_depth=codes.shape[1]; self.max_len=max_len
        self.token=nn.Embedding(vocab_size,dim,padding_idx=0)
        self.pos=nn.Embedding(max_len+1,dim)
        enc=nn.TransformerEncoderLayer(dim,heads,dim*3,dropout,batch_first=True,norm_first=False)
        dec=nn.TransformerDecoderLayer(dim,heads,dim*3,dropout,batch_first=True,norm_first=False)
        self.encoder=nn.TransformerEncoder(enc,num_layers=layers)
        self.decoder=nn.TransformerDecoder(dec,num_layers=layers)
        self.norm=nn.LayerNorm(dim)
        self.output=nn.Linear(dim,vocab_size)
        # item_history has indices in [0, n_items): PAD is encoded as -1

    def encode_history(self,history):
        if history.ndim!=2 or history.shape[1]>self.max_len:
            raise ValueError('Invalid history shape')
        pad=history<0
        if pad.all(dim=1).any(): raise ValueError('No empty histories permitted')
        safe=history.clamp(min=0)
        vectors=self.token(self.item_codes[safe]).mean(dim=2)
        vectors=vectors+self.pos(torch.arange(history.shape[1],device=history.device))[None]
        vectors=vectors.masked_fill(pad.unsqueeze(-1),0)
        return self.encoder(vectors,src_key_padding_mask=pad),pad

    def forward(self,history,target_tokens):
        """Teacher forcing: target_tokens = [B, depth], output B x depth x vocab."""
        memory,pad=self.encode_history(history)
        sos=torch.ones((len(history),1),dtype=torch.long,device=history.device)
        decoder_input=torch.cat([sos,target_tokens[:,:-1]],dim=1)
        dec_embed=self.token(decoder_input)+self.pos(torch.arange(decoder_input.shape[1],device=history.device))[None]
        causal=torch.triu(torch.ones(decoder_input.shape[1],decoder_input.shape[1],
                                    device=history.device,dtype=torch.bool),diagonal=1)
        decoded=self.decoder(dec_embed,memory,tgt_mask=causal,memory_key_padding_mask=pad)
        return self.output(self.norm(decoded))

    @torch.no_grad()
    def decode(self,history,allowed_trie,beam_width=60,k=10,seen=(),device='cpu'):
        """Constrained prefix beam search yields only real catalogue movie IDs."""
        if len(history)==0: raise ValueError('history must not be empty')
        self.eval()
        h=torch.as_tensor(history[-self.max_len:],dtype=torch.long,device=device)[None]
        memory,pad=self.encode_history(h)
        beams=[((),0.)]; excluded=set(map(int,seen))
        for depth in range(self.code_depth):
            candidates=[]
            for prefix,score in beams:
                permitted=allowed_trie.get(prefix,{})
                if not permitted:continue
                dec=torch.tensor([[1,*prefix]],dtype=torch.long,device=device)
                z=self.token(dec)+self.pos(torch.arange(dec.shape[1],device=device))[None]
                causal=torch.triu(torch.ones(dec.shape[1],dec.shape[1],device=device,dtype=torch.bool),1)
                logits=self.output(self.norm(self.decoder(z,memory,tgt_mask=causal,
                                                           memory_key_padding_mask=pad)[0,-1]))
                probs=torch.log_softmax(logits,dim=-1)
                for token in permitted:
                    candidates.append((prefix+(int(token),),score+float(probs[int(token)])))
            if not candidates:break
            candidates.sort(key=lambda x:x[1],reverse=True)
            beams=candidates[:beam_width]
        final=[]
        for code,score in beams:
            movie=allowed_trie.get(code)
            if isinstance(movie,int) and movie not in excluded:
                final.append((movie,score))
        final.sort(key=lambda x:x[1],reverse=True)
        return final[:k]


def build_trie(codes):
    root={}
    for item,row in enumerate(np.asarray(codes)):
        node=root
        for t in row: node=node.setdefault(int(t),{})
        # Code paths are unique because last suffix disambiguates collisions.
        leaf=tuple(map(int,row))
        if leaf in root: pass
        node.clear()
        # Add leaf through a separate flat-key entry to preserve all prefix nodes
        root[leaf]=int(item)
    return root
