"""Optional local image encoder for licensed movie posters (not in MovieLens).

Files must be named <movieId>.jpg/.jpeg/.png; missing posters become zeros.
Output rows follow movies.parquet sorted movieId order; a companion *_movie_ids.npy
makes alignment verifiable. This utility never scrapes or downloads artwork.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np


def run(dataset='ml-1m', image_dir='posters',data_dir='data',output=None,
        model_name='sentence-transformers/clip-ViT-B-32',batch_size=32):
    from PIL import Image
    from sentence_transformers import SentenceTransformer
    from scalable.common import load_catalog
    movie_ids=load_catalog(Path(data_dir)/'processed'/dataset).movieId.to_numpy(dtype=np.int64)
    root=Path(image_dir)
    if not root.is_dir():raise FileNotFoundError(f'Poster directory missing: {root}')
    paths=[];indices=[]
    for j,m in enumerate(movie_ids):
        for ext in ('.jpg','.jpeg','.png'):
            p=root/f'{int(m)}{ext}'
            if p.is_file():paths.append(p);indices.append(j);break
    if not paths:raise ValueError('No licensed poster files found named <movieId>.jpg/png')
    model=SentenceTransformer(model_name)
    out=Path(output) if output else Path(data_dir)/'processed'/dataset/'poster_vectors.npy'
    out.parent.mkdir(parents=True,exist_ok=True)
    result=None
    for start in range(0,len(paths),batch_size):
        chosen=paths[start:start+batch_size]
        images=[]
        for p in chosen:
            with Image.open(p) as image:images.append(image.convert('RGB').copy())
        encoded=np.asarray(model.encode(images,show_progress_bar=False,
                                  convert_to_numpy=True,normalize_embeddings=True),dtype=np.float32)
        if result is None:result=np.zeros((len(movie_ids),encoded.shape[1]),dtype=np.float32)
        result[np.asarray(indices[start:start+len(chosen)],dtype=np.int64)]=encoded
    np.save(out,result)
    np.save(out.with_name(out.stem+'_movie_ids.npy'),movie_ids)
    print(f'Saved visual embeddings for {len(paths):,}/{len(movie_ids):,} movies to {out}. Missing rows are zero.')
    return out

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset',default='ml-1m')
    p.add_argument('--image-dir',default='posters')
    p.add_argument('--data-dir',default='data')
    p.add_argument('--output',default=None)
    p.add_argument('--model-name',default='sentence-transformers/clip-ViT-B-32')
    p.add_argument('--batch-size',type=int,default=32)
    run(**vars(p.parse_args()))
