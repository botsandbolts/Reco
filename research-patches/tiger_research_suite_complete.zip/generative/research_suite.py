"""One-command, reproducible TIGER-style ablation and slate experiment.

Preserves separate model checkpoints. All variants share the same user sample,
train-only histories, movie catalogue, evaluation exclusions, and beam budget.

Example:
    python -m generative.research_suite --dataset ml-1m --profile quick
    python -m generative.research_suite --dataset ml-1m --profile research
    python -m generative.research_suite --dataset ml-1m --profile research \
        --poster-vectors data/processed/ml-1m/poster_vectors.npy

On machines without a BPR checkpoint or licensed poster vectors, the corresponding
fusion experiment is skipped rather than fabricating a visual/multimodal model.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


PROFILES = {
    'quick': dict(dim=32, layers=1, heads=4, epochs=1, steps_per_epoch=12,
                  batch_size=8, patience=2, users=8, pool=20, beam=40),
    'research': dict(dim=64, layers=2, heads=4, epochs=8, steps_per_epoch=200,
                     batch_size=16, patience=3, users=60, pool=48, beam=120),
}


def chosen_variants(dataset, root, *, text_path=None, poster_path=None,
                    bpr_path=None):
    """Return explicit, distinctly named ablations and feature provenance."""
    root = Path(root)
    models = root / 'models' / dataset
    choices = [dict(name='tiger', semantic=models/'semantic_ids',
                    output=models/'tiger', source='title+genres TF-IDF',
                    flags={})]
    if text_path is not None:
        choices.append(dict(name='tiger_sentence', semantic=models/'semantic_ids_sentence',
                            output=models/'tiger_sentence', source='Sentence Transformer titles+genres',
                            flags={'text_vectors':str(text_path), 'text_weight':1.0}))
        if bpr_path is not None:
            choices.append(dict(name='tiger_text_collab',
                                semantic=models/'semantic_ids_text_collab',
                                output=models/'tiger_text_collab',
                                source='Sentence Transformer + train-only BPR movie factors',
                                flags={'text_vectors':str(text_path),
                                       'collaborative_vectors':str(bpr_path),
                                       'text_weight':0.75,'collaborative_weight':0.25}))
        if poster_path is not None:
            visual_flags = {'text_vectors':str(text_path),
                            'visual_vectors':str(poster_path),
                            'text_weight':0.75 if bpr_path is None else 0.60,
                            'visual_weight':0.25}
            if bpr_path is not None:
                visual_flags['collaborative_vectors'] = str(bpr_path)
                visual_flags['collaborative_weight'] = 0.15
            choices.append(dict(name='tiger_visual',
                                semantic=models/'semantic_ids_visual',
                                output=models/'tiger_visual',
                                source='Sentence Transformer + real poster vectors' +
                                (' + train-only BPR factors' if bpr_path is not None else ''),
                                flags=visual_flags))
    return choices


def validate_artifacts(folder, semantic_dir, *, dataset, max_len, config=None):
    """Do not silently reuse a checkpoint trained under different conditions."""
    meta = json.loads((Path(folder)/'model.json').read_text(encoding='utf-8'))
    if meta.get('dataset') != dataset or int(meta.get('max_len',-1)) != max_len:
        raise ValueError(f'Existing checkpoint {folder} does not match dataset/max_len')
    if Path(meta.get('semantic_ids', '')).resolve() != Path(semantic_dir).resolve():
        raise ValueError(f'Existing checkpoint {folder} uses other semantic ID data')
    if config is not None:
        expected={'dim':config['dim'],'layers':config['layers'],
                  'heads':config['heads'],'epochs_requested':config['epochs']}
        for name,value in expected.items():
            if int(meta.get(name,-1)) != int(value):
                raise ValueError(
                    f'{folder} was trained with {name}={meta.get(name)} instead of {value}; '
                    'use --force-retrain to train the requested profile')
    for file in ('weights.pt','semantic_ids.npy','item_ids.npy'):
        if not (Path(folder)/file).is_file():
            raise ValueError(f'Incomplete checkpoint {folder}: missing {file}')


def write_summary(report, output_dir):
    """Export a human-readable per-run CSV without inventing missing scores."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True,exist_ok=True)
    destination = output_dir / f"tiger_ablation_{report['split']}_seed{report['seed']}.csv"
    with destination.open('w',newline='',encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=['model','users_evaluated','recall_at_k',
                                         'ndcg_at_k','catalog_coverage_at_k',
                                         'query_retrieval_ms_mean'])
        w.writeheader()
        for model,metrics in sorted(report['results'].items()):
            w.writerow({'model':model,**{k:metrics.get(k) for k in w.fieldnames[1:]}})
    return destination


def run(dataset='ml-1m', data_dir='data', profile='quick', max_len=60,
        seed=42, device='cpu', memory='2GB', threads=2,
        no_sentence=False, no_bpr_fusion=False, poster_vectors=None,
        users=None, force_retrain=False, final_test=False):
    if dataset not in ('ml-1m','ml-32m'):
        raise ValueError('Supported datasets: ml-1m or ml-32m')
    if profile not in PROFILES: raise ValueError('Unknown profile')
    config = dict(PROFILES[profile])
    if users is not None:
        if users < 1:raise ValueError('--users must be positive')
        config['users']=users
    root=Path.cwd();processed=Path(data_dir)/'processed'/dataset
    from scalable.prepare import run as prepare
    from generative.histories import run as histories
    from generative.semantic_ids import run as make_codes
    from generative.train import run as train
    from generative.evaluate import run as evaluate

    if not (processed/'manifest.json').exists():
        prepare(dataset=dataset,data_dir=data_dir,memory=memory,threads=threads)
    histories(dataset=dataset,data_dir=data_dir,max_len=max_len,memory=memory,
              threads=threads)

    text=None
    if not no_sentence:
        from scalable.semantic import run as semantic_encode
        text = processed/'semantic_raw.npy'
        if not text.exists():
            print('Creating Sentence Transformer embeddings for titles and genres...',flush=True)
            semantic_encode(dataset=dataset,data_dir=data_dir,reducer='raw',dims=48)
        if not text.exists():raise FileNotFoundError('Sentence embeddings not generated: '+str(text))

    posters=Path(poster_vectors) if poster_vectors else None
    if posters is not None and no_sentence:
        raise ValueError('Poster fusion requires Sentence Transformer embeddings; remove --no-sentence')
    if posters is not None and not posters.is_file():
        raise FileNotFoundError(f'Poster embedding file not found: {posters}')
    if posters is not None:
        ids_sidecar=posters.with_name(posters.stem+'_movie_ids.npy')
        if not ids_sidecar.is_file():
            raise ValueError(f'Poster vectors require alignment sidecar {ids_sidecar}')
    bpr=Path('models')/dataset/'bpr'/'item_vectors.npy'
    bpr=bpr if bpr.is_file() and not no_bpr_fusion else None
    if bpr is None:print('No compatible BPR item vector file selected; text+collab experiment unavailable.')
    if posters is None:print('No licensed poster embedding file given; visual experiment unavailable.')

    variants=chosen_variants(dataset,root,text_path=text,poster_path=posters,bpr_path=bpr)
    provenances={}
    for v in variants:
        sem=Path(v['semantic']);out=Path(v['output']);flags=v['flags']
        if not (sem/'metadata.json').exists():
            print(f"Creating semantic IDs: {v['name']} ({v['source']})",flush=True)
            make_codes(dataset=dataset,data_dir=data_dir,output_dir=str(sem),
                       seed=seed,dim=48,levels=3,codebook_size=32,**flags)
        elif force_retrain:
            make_codes(dataset=dataset,data_dir=data_dir,output_dir=str(sem),
                       seed=seed,dim=48,levels=3,codebook_size=32,**flags)
        else:
            current=json.loads((sem/'metadata.json').read_text(encoding='utf-8'))
            expected = {
                'text_source': flags.get('text_vectors') or 'title+genres TF-IDF fallback',
                'visual_source': flags.get('visual_vectors'),
                'collaborative_source': flags.get('collaborative_vectors'),
                'seed': seed,
                'modality_weights': {
                    'text': flags.get('text_weight',0.7),
                    'visual': flags.get('visual_weight',0.2),
                    'collaborative': flags.get('collaborative_weight',0.1),
                },
            }
            if any(current.get(k)!=val for k,val in expected.items()):
                raise ValueError(f'Semantic code provenance mismatch for {sem}; use --force-retrain deliberately')
            print(f"Reusing semantic IDs: {sem}",flush=True)
        if force_retrain or not (out/'weights.pt').is_file():
            print(f"Training: {v['name']} ({profile} profile)",flush=True)
            train(dataset=dataset,data_dir=data_dir,semantic_id_dir=str(sem),
                  output_dir=str(out),max_len=max_len,dim=config['dim'],
                  layers=config['layers'],heads=config['heads'],
                  epochs=config['epochs'],steps_per_epoch=config['steps_per_epoch'],
                  batch_size=config['batch_size'],patience=config['patience'],
                  seed=seed,device=device)
        else:
            validate_artifacts(out,sem,dataset=dataset,max_len=max_len,config=config)
            print(f'Reusing completed checkpoint: {out}',flush=True)
        provenances[v['name']]=v['source']

    first,rest=variants[0],variants[1:]
    extra={v['name']:str(v['output']) for v in rest}
    # Keep the last chart if a new suite run is interrupted mid-evaluation.
    previous_report=Path('reports')/'unified'/dataset/f"generative_{'test' if final_test else 'validation'}_seed{seed}.json"
    if previous_report.is_file():
        import shutil
        backup=previous_report.with_name(previous_report.stem+'_before_research_suite.json')
        if not backup.is_file():shutil.copy2(previous_report,backup)
    report=evaluate(dataset=dataset,data_dir=data_dir,model_dir=str(first['output']),
                    extra_model_dirs=extra,users=config['users'],k=10,seed=seed,
                    pool=config['pool'],beam=config['beam'],device=device,
                    split='test' if final_test else 'validation',final_test=final_test)
    # Never claim the same report is an independent test when test is not requested.
    report['suite']={'profile':profile,'variant_sources':provenances,
                     'dataset':dataset,'movie_metadata':'titles+genres only unless posters supplied',
                     'semantic_id_quantizer':'residual KMeans; TIGER-inspired, not RQ-VAE',
                     'slate':'OGR-inspired diversity planning, not trained OGR policy',
                     'shared_user_sample':True,
                     'note':'Comparisons are preliminary for a quick profile; choose research for tuning.'}
    from scalable.common import store_json
    dest=Path('reports')/'unified'/dataset/f"generative_{report['split']}_seed{seed}.json"
    store_json(dest,report)
    csv_path=write_summary(report,dest.parent)
    print(f'Completed {len(variants)} TIGER variants and slate comparisons.\n'
          f'Streamlit JSON: {dest}\nCSV summary: {csv_path}',flush=True)
    return report


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset',default='ml-1m',choices=['ml-1m','ml-32m'])
    p.add_argument('--data-dir',default='data')
    p.add_argument('--profile',default='quick',choices=sorted(PROFILES))
    p.add_argument('--max-len',type=int,default=60)
    p.add_argument('--seed',type=int,default=42)
    p.add_argument('--device',default='cpu',choices=['cpu','cuda'])
    p.add_argument('--memory',default='2GB')
    p.add_argument('--threads',type=int,default=2)
    p.add_argument('--no-sentence',action='store_true')
    p.add_argument('--no-bpr-fusion',action='store_true')
    p.add_argument('--poster-vectors',default=None)
    p.add_argument('--users',type=int,default=None)
    p.add_argument('--force-retrain',action='store_true')
    p.add_argument('--final-test',action='store_true')
    run(**vars(p.parse_args()))
