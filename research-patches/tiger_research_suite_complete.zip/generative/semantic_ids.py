"""Movie content -> residual KMeans semantic IDs; TIGER-inspired, not RQ-VAE.

Optional arrays must align to MovieLens sorted movieId order (see metadata.json).
No validation/test labels are used when generating item IDs.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
from sklearn.cluster import MiniBatchKMeans
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import normalize


def _as_float_matrix(arr, n, name):
    x = np.asarray(arr, dtype=np.float32)
    if x.ndim != 2 or len(x) != n or not np.isfinite(x).all():
        raise ValueError(f"{name}: expected finite matrix with {n} rows")
    return x


def _reduce(x, out_dim=48, seed=42):
    n, dim = x.shape
    if n < 2 or dim < 2:
        raise ValueError("At least 2 items and 2 dimensions required")
    k = min(out_dim, n-1, dim-1)
    result = TruncatedSVD(n_components=k, random_state=seed).fit_transform(x)
    return normalize(result.astype('float32'), axis=1)


def item_features(movies, *, text=None, visual=None, collaborative=None,
                  text_weight=0.7, visual_weight=0.2, collaborative_weight=0.1, dim=48, seed=42):
    """Concatenate weighted, independently normalized feature groups."""
    n = len(movies)
    if text is None:
        docs = [f"{t} genres {g.replace('|', ' ')}" for t,g in zip(movies.title.fillna(''),movies.genres.fillna(''))]
        raw = TfidfVectorizer(ngram_range=(1,2), min_df=1).fit_transform(docs)
        text = raw  # fallback metadata-only input, no poster/plot invented
    sources = [(text, text_weight, 'text')]
    if visual is not None: sources.append((visual, visual_weight, 'visual'))
    if collaborative is not None: sources.append((collaborative, collaborative_weight, 'collaborative'))
    active = [(x,w,name) for x,w,name in sources if w>0]
    if not active: raise ValueError("At least one positive-weight modality is required")
    sw=sum(w for _,w,_ in active)
    components=[]
    for x,w,name in active:
        if hasattr(x,'tocsr'):
            if x.shape[0]!=n: raise ValueError(f'{name} row alignment mismatch')
            z=_reduce(x, dim, seed)
        else:
            z=_reduce(_as_float_matrix(x,n,name),dim,seed)
        components.append(z*np.sqrt(w/sw))
    return normalize(np.concatenate(components,axis=1).astype('float32'))


def residual_codes(vectors, levels=3, codebook_size=32, seed=42):
    """Deterministic residual k-means; collision suffix makes item IDs unique."""
    x=np.asarray(vectors, dtype=np.float32)
    if x.ndim!=2 or not np.isfinite(x).all(): raise ValueError('invalid vectors')
    if levels<1 or codebook_size<2 or len(x)<codebook_size:
        raise ValueError('Require items >= codebook_size >= 2 and levels >= 1')
    residual=x.copy(); parts=[]; centroids=[]
    for level in range(levels):
        km=MiniBatchKMeans(n_clusters=codebook_size, random_state=seed+level,
                           batch_size=min(2048,max(64,len(x))), n_init=3,
                           max_iter=60, reassignment_ratio=0.01)
        ids=km.fit_predict(residual).astype(np.int32)
        parts.append(ids)
        centers=np.asarray(km.cluster_centers_,dtype=np.float32)
        centroids.append(centers)
        residual-=centers[ids]
    code=np.column_stack(parts)
    suffix=np.empty(len(x),dtype=np.int32)
    counts={}
    for i,raw in enumerate(code):
        key=tuple(map(int,raw))
        suffix[i]=counts.get(key,0)
        counts[key]=int(suffix[i])+1
    # Depth-specific token IDs; 0=PAD, 1=BOS, code tokens start at 2.
    offsets=np.arange(levels,dtype=np.int64)*codebook_size+2
    codes=np.column_stack([code+offsets, suffix+2+levels*codebook_size]).astype('int32')
    assert len({tuple(x) for x in codes.tolist()})==len(codes)
    return codes, np.stack(centroids), {'levels':levels,'codebook_size':codebook_size,
          'max_collision':int(suffix.max()),'vocab_size':int(codes.max()+1),
          'unique_prefixes':len(counts),'colliding_items':len(x)-len(counts)}


def run(dataset='ml-1m', data_dir='data', output_dir=None, text_vectors=None,
        visual_vectors=None, collaborative_vectors=None, dim=48, levels=3,
        codebook_size=32, text_weight=0.7, visual_weight=0.2,
        collaborative_weight=0.1, seed=42):
    from scalable.common import load_catalog, store_json
    processed=Path(data_dir)/'processed'/dataset
    if not (processed/'manifest.json').exists():
        raise FileNotFoundError(f'Run scalable.prepare --dataset {dataset} first')
    movies=load_catalog(processed)
    movie_ids=movies.movieId.to_numpy(dtype=np.int64)
    def optional(path, name):
        if not path:return None
        src=Path(path)
        sidecar=src.with_name(src.stem+'_movie_ids.npy')
        if sidecar.exists() and not np.array_equal(np.load(sidecar),movie_ids):
            raise ValueError(f'{name} feature movie ID sidecar differs from sorted MovieLens catalogue')
        if name=='collaborative' and (src.parent/'item_ids.npy').exists():
            if not np.array_equal(np.load(src.parent/'item_ids.npy'),movie_ids):
                raise ValueError('BPR/collaborative feature rows do not match MovieLens catalogue')
        return np.load(src,mmap_mode='r')
    # Explicit label when visual is absent; MovieLens does NOT provide posters.
    features=item_features(movies,text=optional(text_vectors,"text"),visual=optional(visual_vectors,"visual"),
                  collaborative=optional(collaborative_vectors,"collaborative"),dim=dim,seed=seed,
                  text_weight=text_weight,visual_weight=visual_weight,
                  collaborative_weight=collaborative_weight)
    codes,centers,metadata=residual_codes(features,levels=levels,
                                      codebook_size=codebook_size,seed=seed)
    out=Path(output_dir) if output_dir else Path('models')/dataset/'semantic_ids'
    out.mkdir(parents=True,exist_ok=True)
    np.save(out/'item_ids.npy',movie_ids)
    np.save(out/'item_features.npy',features)
    np.save(out/'semantic_ids.npy',codes)
    np.save(out/'codebooks.npy',centers)
    store_json(out/'metadata.json',{'dataset':dataset,'seed':seed,'items':len(movie_ids),
         'semantic_id_method':'residual_kmeans (TIGER-inspired; not RQ-VAE)',
         'text_source':text_vectors or 'title+genres TF-IDF fallback',
         'visual_source':visual_vectors, 'collaborative_source':collaborative_vectors,
         'modality_weights':{'text':text_weight, 'visual':visual_weight,
                             'collaborative':collaborative_weight},
         'item_alignment':'sorted movieId rows, verified during training',**metadata})
    print(f'Saved {len(movie_ids):,} unique semantic IDs in {out}; collisions resolved by suffix')
    return out

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for x,default in [('dataset','ml-1m'),('data-dir','data'),('output-dir',None),
                      ('text-vectors',None),('visual-vectors',None),('collaborative-vectors',None)]:
        p.add_argument('--'+x,default=default)
    for x,d in [('dim',48),('levels',3),('codebook-size',32),('seed',42)]:
        p.add_argument('--'+x,type=int,default=d)
    for x,d in [('text-weight',0.7),('visual-weight',0.2),('collaborative-weight',0.1)]:
        p.add_argument('--'+x,type=float,default=d)
    run(**vars(p.parse_args()))
