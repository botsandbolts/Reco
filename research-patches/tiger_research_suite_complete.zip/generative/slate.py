"""OGR-inspired list-level planner; NOT a reproduction of OGR's policy optimization."""
from __future__ import annotations
import numpy as np


def plan_slate(candidates, vectors, k=10, beam_width=4, diversity=0.25, novelty=0.0,
               popularity=None):
    """Beam-select an ordered slate maximizing discounted quality and pairwise diversity.

    candidates: [(indexed movie ID, generative log-probability), ...]
    Deterministic, no duplicate movies. Returns movie index list.
    """
    if k<=0 or beam_width<=0: raise ValueError('k and beam_width must be positive')
    if not 0<=diversity<=1 or not 0<=novelty<=1: raise ValueError('Weights must be in [0,1]')
    if not candidates:return []
    ids=np.asarray([int(i) for i,_ in candidates],dtype=np.int64)
    if len(np.unique(ids))!=len(ids): raise ValueError('Duplicate candidate IDs')
    raw=np.asarray([float(v) for _,v in candidates],dtype=np.float64)
    quality=(raw-raw.min())/max(float(np.ptp(raw)),1e-9)
    v=np.asarray(vectors[ids],dtype=np.float32)
    v=v/np.maximum(np.linalg.norm(v,axis=1,keepdims=True),1e-8)
    similarity=np.clip(v@v.T,-1,1)
    if popularity is None: pop=np.zeros(len(ids))
    else:
        p=np.asarray(popularity)[ids]
        pop=(p-p.min())/max(float(np.ptp(p)),1e-9)
    beam=[((),0.)]
    for t in range(min(k,len(ids))):
        nxt=[]
        for chosen,objective in beam:
            for pos in range(len(ids)):
                if pos in chosen:continue
                # novelty = low item popularity; diversity = dissimilarity to earlier picks
                spread=(1.0-float(np.mean(similarity[pos,list(chosen)]))) * 0.5 if chosen else 0.
                value=((1-diversity-novelty)*quality[pos]+diversity*spread+
                       novelty*(1-pop[pos])) / np.log2(t+2)
                nxt.append((chosen+(pos,),objective+value))
        nxt.sort(key=lambda x:x[1],reverse=True)
        beam=nxt[:beam_width]
    return [int(ids[i]) for i in beam[0][0]]
