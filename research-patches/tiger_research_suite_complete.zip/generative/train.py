"""Train an autoregressive semantic-ID recommender on TRAIN histories only."""
from __future__ import annotations
import argparse
import json
import time
from pathlib import Path
import numpy as np
import torch
from torch.nn import functional as F
from .model import GenerativeRetriever


def load_histories(processed, max_len):
    folder=Path(processed)/f'generative_L{max_len}'
    if not (folder/'manifest.json').exists():
        raise FileNotFoundError(f'Create histories: python -m generative.histories --dataset {Path(processed).name} --max-len {max_len}')
    return folder,np.load(folder/'sequences.npy',mmap_mode='r'),np.load(folder/'lengths.npy',mmap_mode='r'),np.load(folder/'item_ids.npy')


def sample_training_batch(sequences,lengths,codes,users,batch_size,rng,max_len):
    chosen=rng.choice(users,size=batch_size,replace=True)
    x=np.full((batch_size,max_len),-1,dtype=np.int64)
    y=np.empty((batch_size,codes.shape[1]),dtype=np.int64)
    for j,u in enumerate(chosen):
        length=int(lengths[int(u)])
        prefix_len=int(rng.integers(1,length))
        start=max(0,prefix_len-max_len)
        ids=np.asarray(sequences[int(u),start:prefix_len],dtype=np.int64)-2
        if np.any(ids<0): raise ValueError('History contains unexpected PAD')
        x[j,-len(ids):]=ids
        target=int(sequences[int(u),prefix_len])-2
        y[j]=codes[target]
    return torch.from_numpy(x),torch.from_numpy(y)


def _load_ids(folder):
    ids=np.load(Path(folder)/'semantic_ids.npy')
    item_ids=np.load(Path(folder)/'item_ids.npy')
    return ids,item_ids


def load_checkpoint(model_dir, device='cpu'):
    folder=Path(model_dir)
    config=json.loads((folder/'model.json').read_text(encoding='utf-8'))
    codes=np.load(folder/'semantic_ids.npy')
    model=GenerativeRetriever(codes,int(config['vocab_size']),max_len=int(config['max_len']),
                             dim=int(config['dim']),heads=int(config['heads']),
                             layers=int(config['layers']))
    # Load only locally created checkpoints. weights_only avoids arbitrary pickled objects.
    weights=torch.load(folder/'weights.pt',map_location=device,weights_only=True)
    model.load_state_dict(weights)
    model.to(device).eval()
    return model,config


def run(dataset='ml-1m',data_dir='data',semantic_id_dir=None,output_dir=None,
        max_len=60,dim=64,layers=2,heads=4,epochs=5,steps_per_epoch=100,
        batch_size=32,lr=0.0003,seed=42,device='cpu',patience=3):
    if min(epochs,steps_per_epoch,batch_size,max_len,patience)<1:
        raise ValueError('Training counts must be positive')
    if device=='cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA requested but no GPU is available')
    torch.manual_seed(seed); rng=np.random.default_rng(seed)
    torch.set_num_threads(min(4,torch.get_num_threads()))
    processed=Path(data_dir)/'processed'/dataset
    semantic=Path(semantic_id_dir) if semantic_id_dir else Path('models')/dataset/'semantic_ids'
    codes,item_ids=_load_ids(semantic)
    hist,seq,lens,h_ids=load_histories(processed,max_len)
    if not np.array_equal(item_ids,h_ids): raise ValueError('Semantic item IDs do not match chronological history IDs')
    eligible=np.flatnonzero(lens>=3)
    if len(eligible)==0: raise ValueError('Need histories of at least 3 movies to train + validate')
    metadata=json.loads((semantic/'metadata.json').read_text(encoding='utf-8'))
    model=GenerativeRetriever(codes,int(metadata['vocab_size']),max_len=max_len,
                             dim=dim,heads=heads,layers=layers).to(device)
    opt=torch.optim.AdamW(model.parameters(),lr=lr,weight_decay=1e-4)
    out=Path(output_dir) if output_dir else Path('models')/dataset/'tiger'
    out.mkdir(parents=True,exist_ok=True)
    np.save(out/'semantic_ids.npy',codes)
    np.save(out/'item_ids.npy',item_ids)
    best=float('inf'); bad=0; t0=time.monotonic()
    # Deterministic train-only prefix holdout for early stopping, without ever
    # exposing each user's last training movie as a training label.
    train_lens=np.asarray(lens,dtype=np.int32).copy(); train_lens[eligible]-=1
    val_users=eligible[:min(128,len(eligible))]
    val_x=np.full((len(val_users),max_len),-1,dtype=np.int64)
    val_y=np.empty((len(val_users),codes.shape[1]),dtype=np.int64)
    for row,u in enumerate(val_users):
        ln=int(lens[int(u)]); p=np.asarray(seq[int(u),max(0,ln-1-max_len):ln-1],dtype=np.int64)-2
        val_x[row,-len(p):]=p
        val_y[row]=codes[int(seq[int(u),ln-1])-2]
    for epoch in range(epochs):
        model.train(); running=[]
        for step in range(steps_per_epoch):
            history,target=sample_training_batch(seq,train_lens,codes,eligible,batch_size,rng,max_len)
            history=history.to(device);target=target.to(device)
            logits=model(history,target)
            loss=F.cross_entropy(logits.reshape(-1,logits.shape[-1]),target.reshape(-1))
            opt.zero_grad(set_to_none=True);loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(),1.0)
            opt.step();running.append(float(loss.detach().cpu()))
        model.eval(); vals=[]
        with torch.no_grad():
            for ix in range(0,len(val_users),16):
                x=torch.from_numpy(val_x[ix:ix+16]).to(device)
                y=torch.from_numpy(val_y[ix:ix+16]).to(device)
                pred=model(x,y)
                vals.append((F.cross_entropy(pred.reshape(-1,pred.shape[-1]),y.reshape(-1)).item(),len(x)))
        v=sum(loss*n for loss,n in vals)/sum(n for _,n in vals)
        print(f'epoch {epoch+1}/{epochs}: loss={np.mean(running):.4f} train-prefix validation loss={v:.4f}',flush=True)
        if v<best-1e-4:
            best=v;bad=0
            torch.save(model.state_dict(),out/'weights.pt')
        else:
            bad+=1
            if bad>=patience: print('Early stopping (train-prefix validation)',flush=True);break
    config={'dataset':dataset,'model':'TIGER-inspired autoregressive semantic-ID Transformer',
      'semantic_ids':str(semantic),'vocab_size':int(metadata['vocab_size']),
      'max_len':max_len,'dim':dim,'heads':heads,'layers':layers,'seed':seed,
      'epochs_requested':epochs,'training_seconds':round(time.monotonic()-t0,2),
      'best_train_prefix_validation_loss':best,
      'protocol':'Train-only prefixes; last TRAIN interaction reserved for early stopping; never future holdouts',
      'limitations':'Encoder-decoder Transformer + residual KMeans codes; not faithful T5/RQ-VAE TIGER reproduction'}
    (out/'model.json').write_text(json.dumps(config,indent=2),encoding='utf-8')
    print(f'Best checkpoint saved: {out}/weights.pt',flush=True)
    return out

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for arg,default in [('dataset','ml-1m'),('data-dir','data'),('semantic-id-dir',None),('output-dir',None),('device','cpu')]:
        p.add_argument('--'+arg,default=default)
    for arg,default in [('max-len',60),('dim',64),('layers',2),('heads',4),('epochs',5),
                        ('steps-per-epoch',100),('batch-size',32),('seed',42),('patience',3)]:
        p.add_argument('--'+arg,type=int,default=default)
    p.add_argument('--lr',type=float,default=0.0003)
    run(**vars(p.parse_args()))
