"""Unified, leakage-aware comparison on the same MovieLens holdout users.

Run from repository root: python -m scalable.unified_benchmark --dataset ml-1m
The benchmark NEVER trains/replaces the existing BPR/SVD model files.
"""
from __future__ import annotations

import argparse
import csv
import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import numpy as np
from scipy.sparse import csr_matrix
from .common import load_model, store_json
from .evaluate import _available_targets, _previous_events, _index, top_unseen


def normalize(x):
    arr = np.asarray(x, dtype=np.float32)
    if arr.ndim != 2:
        raise ValueError("Expected 2D factor matrix")
    if not np.isfinite(arr).all():
        raise ValueError("Non-finite embedding values")
    return arr / np.maximum(np.linalg.norm(arr, axis=1, keepdims=True), 1e-9)


@dataclass
class Source:
    name: str
    items: np.ndarray
    get_queries: Callable[[np.ndarray], np.ndarray]
    detail: str = ""

    def queries(self, user_indices):
        x = np.asarray(self.get_queries(np.asarray(user_indices, dtype=np.int32)), dtype=np.float32)
        if x.shape != (len(user_indices), self.items.shape[1]):
            raise ValueError(f"Query embedding shape mismatch for {self.name}")
        return x


def select_shared_users(available_users, targets, n_users, seed, lengths=None):
    """Deterministic, common sample for every method, optionally sequence-eligible."""
    u = np.asarray(available_users, dtype=np.int32)
    t = np.asarray(targets, dtype=np.int32)
    if len(u) != len(t):
        raise ValueError("Target/user length mismatch")
    mask = np.ones(len(u), dtype=bool)
    if lengths is not None:
        mask = np.asarray(lengths[u] >= 2)
    eligible = np.flatnonzero(mask)
    if len(eligible) == 0:
        raise ValueError("No eligible shared holdout users")
    rng = np.random.default_rng(seed)
    positions = np.sort(rng.choice(eligible, min(n_users, len(eligible)), replace=False))
    return u[positions], t[positions]


def combine_sources(sources, users, weights=None):
    """Weighted cosine fusion as one FAISS-searchable inner-product space."""
    if not sources:
        raise ValueError("Cannot fuse zero sources")
    if weights is None:
        weights = [1.0] * len(sources)
    weights = np.asarray(weights, dtype=np.float64)
    if len(weights) != len(sources) or np.any(weights < 0) or not np.any(weights > 0):
        raise ValueError("Use nonnegative weights with positive sum, one per source")
    weights /= weights.sum()
    q = np.concatenate([normalize(s.queries(users)) * np.sqrt(w) for s, w in zip(sources, weights)], axis=1)
    i = np.concatenate([normalize(s.items) * np.sqrt(w) for s, w in zip(sources, weights)], axis=1)
    return Source("hybrid_fusion", i, lambda indices: q, "fixed equal-weight cosine fusion"), q


def evaluate_rows(queries, item_vectors, seen, users, targets, previous, *,
                  k=10, index_kind="flat", candidate_window=512, threads=2,
                  collect_candidates=0):
    if len(queries) != len(users) or len(users) != len(targets):
        raise ValueError("User/target/query misalignment")
    if seen.shape[1] != len(item_vectors):
        raise ValueError("Item vocab mismatch")
    if k <= 0:
        raise ValueError("k must be positive")
    idx = _index(item_vectors, index_kind, threads=threads)
    top_list, n_hits, ndcg, coverage = [], 0, 0., set()
    start = time.perf_counter()
    for q, user, target in zip(queries, users, targets):
        user, target = int(user), int(target)
        excluded = set(map(int, seen.indices[seen.indptr[user]:seen.indptr[user+1]]))
        excluded.update(previous.get(user, ()))
        if target in excluded:
            raise ValueError("Held-out item appears in history/exclusions: leakage")
        chosen = top_unseen(q, item_vectors, idx, excluded, k=max(k, collect_candidates),
                            candidate_window=candidate_window)
        first_k = np.asarray(chosen[:k], dtype=np.int32)
        if len(first_k) != k:
            raise ValueError("Too few unseen catalogue items to evaluate")
        if len(np.unique(first_k)) != len(first_k) or set(first_k) & excluded:
            raise ValueError("Invalid retrieved items: duplicates or previously seen")
        coverage.update(map(int, first_k))
        found = np.flatnonzero(first_k == target)
        if len(found):
            n_hits += 1
            ndcg += 1. / np.log2(int(found[0]) + 2)
        if collect_candidates:
            top_list.append(np.asarray(chosen, dtype=np.int32))
    seconds = time.perf_counter() - start
    n = len(users)
    metrics = {"users_evaluated": n, "recall_at_k": round(n_hits/n, 6),
               "ndcg_at_k": round(ndcg/n, 6),
               "catalog_coverage_at_k": round(len(coverage)/len(item_vectors), 6),
               "query_retrieval_ms_mean": round(1000*seconds/n, 3),
               "index": index_kind,
               "protocol": "full catalog search, exclude train + earlier heldouts"}
    return metrics, top_list


def ranker_feature_matrix(sources, queries_per_source, user_position, candidates):
    """All features come from TRAIN-only source embeddings."""
    return np.column_stack([
        np.asarray(s.items[candidates] @ queries_per_source[s.name][user_position], dtype=np.float32)
        for s in sources
    ]).astype(np.float32)


def ranker_candidates(user, seen, previous, indices, item_vectors, queries,
                      *, per_source=120, k=10):
    excluded = set(map(int, seen.indices[seen.indptr[int(user)]:seen.indptr[int(user)+1]]))
    excluded.update(previous.get(int(user), ()))
    candidates = set()
    for s, idx in zip(item_vectors, indices):
        q = queries[s.name]
        candidates.update(map(int, top_unseen(q, s.items, idx, excluded,
                                              k=per_source, candidate_window=max(512, per_source*2))))
    return np.array(sorted(candidates), dtype=np.int32)


def ranker_fit(sources, train_users, train_targets, seen, *,
               n_items, seed=42, negatives=50):
    """Ranker training labels = rank_train positives; no validation/test labels."""
    try:
        from lightgbm import LGBMRanker
    except ImportError as exc:
        raise RuntimeError("Install lightgbm for --train-ranker") from exc
    rng = np.random.default_rng(seed)
    query_arrays = {s.name: s.queries(train_users) for s in sources}
    rows, labels, groups = [], [], []
    for pos, (u, target) in enumerate(zip(train_users, train_targets)):
        u, target = int(u), int(target)
        excluded = set(map(int, seen.indices[seen.indptr[u]:seen.indptr[u+1]]))
        if target in excluded:
            raise ValueError("Ranker label appears in early training history")
        pool = rng.choice(n_items, size=min(n_items, negatives*3), replace=False)
        alternatives = [int(x) for x in pool if int(x) not in excluded and int(x) != target][:negatives]
        if not alternatives:
            continue
        ids = np.array([target] + alternatives, dtype=np.int32)
        x = ranker_feature_matrix(sources, query_arrays, pos, ids)
        rows.append(x)
        labels.extend([1] + [0]*len(alternatives))
        groups.append(len(ids))
    if len(groups) < 10:
        raise ValueError("Insufficient eligible ranker groups")
    model = LGBMRanker(objective="lambdarank", n_estimators=90, learning_rate=0.045,
                       num_leaves=15, min_child_samples=12, random_state=seed,
                       n_jobs=2, verbosity=-1)
    model.fit(np.vstack(rows), np.asarray(labels, dtype=np.int32), group=groups)
    return model


def ranker_evaluate(model, sources, selected_users, targets, seen, previous, *,
                    k=10, index_kind="flat", threads=2, pool_per_source=100):
    # For honest two-stage ranking, target is NEVER injected into evaluation pool.
    use = sources[:min(len(sources), 3)]  # bounded retrieval budget
    indices = [_index(s.items, index_kind, threads) for s in use]
    qs = {s.name: s.queries(selected_users) for s in sources}
    ranks, covered, pool_hits = 0., set(), 0
    hits, start = 0, time.perf_counter()
    for row, (u, target) in enumerate(zip(selected_users, targets)):
        excluded = set(map(int, seen.indices[seen.indptr[int(u)]:seen.indptr[int(u)+1]]))
        excluded.update(previous.get(int(u), ()))
        if int(target) in excluded:
            raise ValueError("Ranker evaluation leakage")
        ids = set()
        for s, idx in zip(use, indices):
            ids.update(map(int, top_unseen(qs[s.name][row], s.items, idx, excluded,
                                               k=pool_per_source, candidate_window=max(512, pool_per_source*2))))
        ids = np.asarray(sorted(ids), dtype=np.int32)
        if int(target) in ids:
            pool_hits += 1
        features = ranker_feature_matrix(sources, qs, row, ids)
        output = model.predict(features)
        top = ids[np.argsort(-output, kind="stable")[:k]]
        covered.update(map(int, top))
        found = np.flatnonzero(top == target)
        if len(found):
            hits += 1
            ranks += 1./np.log2(int(found[0])+2)
    n=len(selected_users)
    return {"users_evaluated":n, "recall_at_k":round(hits/n,6),
            "ndcg_at_k":round(ranks/n,6),
            "catalog_coverage_at_k":round(len(covered)/seen.shape[1],6),
            "candidate_recall":round(pool_hits/n,6),
            "query_retrieval_ms_mean":round(1000*(time.perf_counter()-start)/n,3),
            "index":index_kind,"protocol":"two-stage ranker; pool upper-bounds achievable recall"}


def _make_sources(dataset, processed, bpr_dir, *, two_tower_dir=None,
                  semantic_path=None, umap_bpr_dir=None,
                  semantic_bpr_dir=None, device="cpu"):
    """Load classical and content-aware models only; generative models have their own evaluator."""
    config, uid, mid, ubase, ibase, seen = load_model(bpr_dir)
    if config.get("dataset") != dataset: raise ValueError("BPR dataset mismatch")
    if len(mid) != seen.shape[1] or len(uid) != seen.shape[0]:
        raise ValueError("BPR matrix shapes mismatch")
    result = [Source("bpr_mf", np.asarray(ibase,dtype=np.float32),
                     lambda users, v=ubase: np.asarray(v[users],dtype=np.float32), "BPR-MF")]
    svdu,svdi=bpr_dir/"svd_user_vectors.npy",bpr_dir/"svd_item_vectors.npy"
    if svdu.exists() and svdi.exists():
        u2,i2=np.load(svdu,mmap_mode="r"),np.load(svdi,mmap_mode="r")
        if len(u2)!=len(uid) or len(i2)!=len(mid):raise ValueError("SVD alignment mismatch")
        result.append(Source("svd",np.asarray(i2,dtype=np.float32),
                         lambda users,v=u2:np.asarray(v[users],dtype=np.float32),"TruncatedSVD"))
    def add_factor_dir(name, folder):
        if folder is None:return
        folder=Path(folder)
        if not (folder/"model.json").exists():raise FileNotFoundError(f"Missing model for {name}: {folder}")
        cfg,u2,i2,q,items,other_seen=load_model(folder)
        if cfg.get("dataset")!=dataset or not np.array_equal(u2,uid) or not np.array_equal(i2,mid):
            raise ValueError(f"{name}: IDs or dataset do not match reference")
        if (other_seen.shape!=seen.shape or other_seen.nnz!=seen.nnz or
            not np.array_equal(other_seen.indptr,seen.indptr) or
            not np.array_equal(other_seen.indices,seen.indices)):
            raise ValueError(f"{name}: training interactions differ from BPR reference")
        result.append(Source(name,np.asarray(items,dtype=np.float32),
                             lambda users,v=q:np.asarray(v[users],dtype=np.float32),str(folder)))
    add_factor_dir("semantic_bpr",semantic_bpr_dir)
    add_factor_dir("bpr_umap",umap_bpr_dir)
    add_factor_dir("two_tower",two_tower_dir)
    if semantic_path:
        vectors=np.load(semantic_path,mmap_mode="r")
        if vectors.shape[0]!=len(mid):raise ValueError("Semantic item count mismatch")
        vectors=normalize(vectors)
        def get_semantic(users,v=vectors,h=seen):
            return normalize(np.asarray(h[users].astype(np.float32)@v,dtype=np.float32))
        result.append(Source("semantic",vectors,get_semantic,Path(semantic_path).name))
    return result,uid,mid,seen,None

def run(dataset="ml-1m", data_dir="data", bpr_model_dir=None, users=500, seed=42,
        split="validation", final_test=False, k=10, index="flat", threads=2,
        semantic_vectors=None, semantic_bpr_dir=None, umap_bpr_dir=None,
        two_tower_dir=None,
        train_ranker=False, ranker_users=1500, pool_per_source=100,
        output_dir=None, device="cpu"):
    """Comparison for *one* dataset, *one* holdout sample, *one* exclusion policy."""
    if split not in ("validation","test") or (split == "test" and not final_test):
        raise ValueError("Validation is default; unlocking test requires --final-test")
    if users<1 or ranker_users<1 or k<1:
        raise ValueError("User counts and K must be positive")
    processed=Path(data_dir)/"processed"/dataset
    if not (processed/"manifest.json").exists():
        raise FileNotFoundError("Run scalable.prepare before unified benchmark")
    bpr=Path(bpr_model_dir) if bpr_model_dir else Path("models")/dataset/"bpr"
    if not (bpr/"model.json").exists():
        raise FileNotFoundError(f"Train BPR reference model first: {bpr}")
    sources, ids, item_ids, seen, lengths = _make_sources(
        dataset,processed,bpr,
        two_tower_dir=two_tower_dir, semantic_path=semantic_vectors,
        umap_bpr_dir=umap_bpr_dir, semantic_bpr_dir=semantic_bpr_dir,
        device=device)
    u0, t0=_available_targets(processed,split,ids,item_ids)
    u,t=select_shared_users(u0,t0,users,seed,lengths)
    previous=_previous_events(processed,["rank_train"] if split=="validation"
                               else ["rank_train","validation"],ids,item_ids)
    results={}
    queries={}
    for source in sources:
        print(f"Evaluating {source.name} on {len(u):,} same users ...",flush=True)
        q=source.queries(u)
        queries[source.name]=q
        metric,_=evaluate_rows(q,source.items,seen,u,t,previous,k=k,index_kind=index,threads=threads)
        results[source.name]=metric
        print(f"  NDCG@{k}={metric['ndcg_at_k']} Recall@{k}={metric['recall_at_k']}",flush=True)
    # Fixed, explicitly non-tuned blending; tune weights on validation only later.
    if len(sources)>1:
        fusion_sources=[s for s in sources if s.name in ("bpr_mf","svd","semantic")]
        if len(fusion_sources)>1:
            hybrid,hq=combine_sources(fusion_sources,u)
            metric,_=evaluate_rows(hq,hybrid.items,seen,u,t,previous,k=k,index_kind=index,threads=threads)
            results["hybrid_fusion"]=metric
    if train_ranker:
        # Exclude validation/test from ranker training labels. Only rank_train.
        rank_u,rank_t=_available_targets(processed,"rank_train",ids,item_ids)
        rank_u,rank_t=select_shared_users(rank_u,rank_t,ranker_users,seed+1,lengths)
        feature_sources=sources[:min(len(sources),5)]
        ranker=ranker_fit(feature_sources,rank_u,rank_t,seen,n_items=len(item_ids),seed=seed)
        metric=ranker_evaluate(ranker,feature_sources,u,t,seen,previous,k=k,
                               index_kind=index,threads=threads,pool_per_source=pool_per_source)
        results["lambdamart_two_stage"]=metric
    out=Path(output_dir) if output_dir else Path("reports")/"unified"/dataset
    out.mkdir(parents=True,exist_ok=True)
    # Never overwrite model artifacts; evaluation outputs are self-contained.
    report={"dataset":dataset,"split":split,"k":k,"user_sample_size":len(u),
            "seed":seed,"index":index,"same_user_sample":True,
            "model_count":len(results),"evaluated_user_ids_sha256":_hash_array(ids[u]),
            "model_sources":{s.name:s.detail for s in sources},"results":results,
            "unavailable_models": (["svd"] if not any(s.name=="svd" for s in sources) else [])
                + [x for x,p in (("two_tower",two_tower_dir),
                           ("bpr_umap",umap_bpr_dir),("semantic_bpr",semantic_bpr_dir),
                           ("semantic",semantic_vectors)) if not p]
                + ([] if train_ranker else ["lambdamart_two_stage"]),
            "caveats":["Missing ratings are NOT negative feedback.",
               "Per-user chronological split, not global temporal isolation.",
               "Hybrid weights fixed equally; do not optimize on test.",
               "Two-stage LambdaMART candidate recall upper-bounds final ranking recall.",
               "If index=hnsw, approximate recall affects ranking metrics."]}
    dest=out/f"unified_{split}_{index}_seed{seed}.json"
    store_json(dest,report)
    csv_path=dest.with_suffix(".csv")
    with csv_path.open("w",newline="",encoding="utf-8") as file:
        writer=csv.DictWriter(file,fieldnames=["model","users_evaluated","recall_at_k",
                   "ndcg_at_k","catalog_coverage_at_k","candidate_recall",
                   "query_retrieval_ms_mean","index","protocol"])
        writer.writeheader()
        for name, metric in results.items():
            writer.writerow({"model":name,**metric})
    print(f"Saved unified benchmark: {dest} and {csv_path}",flush=True)
    return report


def _hash_array(array):
    import hashlib
    return hashlib.sha256(np.ascontiguousarray(array,dtype=np.int64).tobytes()).hexdigest()


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--dataset",default="ml-1m")
    p.add_argument("--data-dir",default="data")
    p.add_argument("--bpr-model-dir",default=None)
    p.add_argument("--users",type=int,default=500)
    p.add_argument("--seed",type=int,default=42)
    p.add_argument("--split",choices=["validation","test"],default="validation")
    p.add_argument("--final-test",action="store_true")
    p.add_argument("--k",type=int,default=10)
    p.add_argument("--index",choices=["flat","hnsw","numpy"],default="flat")
    p.add_argument("--threads",type=int,default=2)
    p.add_argument("--semantic-vectors",default=None)
    p.add_argument("--semantic-bpr-dir",default=None)
    p.add_argument("--umap-bpr-dir",default=None)
    p.add_argument("--two-tower-dir",default=None)
    p.add_argument("--train-ranker",action="store_true")
    p.add_argument("--ranker-users",type=int,default=1500)
    p.add_argument("--pool-per-source",type=int,default=100)
    p.add_argument("--output-dir",default=None)
    p.add_argument("--device",choices=["cpu","cuda"],default="cpu")
    run(**vars(p.parse_args()))
