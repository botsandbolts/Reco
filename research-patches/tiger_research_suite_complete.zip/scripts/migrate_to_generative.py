"""Remove obsolete sequential recommender files after the generative patch is installed.

Default is DRY RUN. Use --apply to remove precisely enumerated obsolete files.
Never touches user data, trained checkpoints or existing BPR/SVD/UMAP modules.
"""
from __future__ import annotations
from pathlib import Path
import argparse
import shutil

OBSOLETE_FILES=(
 'scalable/sequence_models.py','scalable/sequence_train.py',
 'scalable/sequence_evaluate.py','scalable/sequence_dashboard.py',
 'scalable/sequence_data.py', 'tests/test_sequence_models.py',
 'requirements-sequential.txt','SEQUENTIAL_32M.md',
 'sequential_recommenders_32m_patch.zip',
 'STREAMLIT_ALL_IN_ONE.md','UNIFIED_BENCHMARK_GUIDE.md','START_UNIFIED.txt',
)

def run(root='.',apply=False,purge_checkpoints=False):
    root=Path(root).resolve()
    required=[root/'generative'/'model.py',root/'generative'/'train.py',
              root/'generative'/'dashboard.py',root/'scalable'/'unified_benchmark.py']
    if not all(x.is_file() for x in required):
        raise RuntimeError('Install the generative patch first: required replacements missing')
    found=[]
    for rel in OBSOLETE_FILES:
        file=root/rel
        if file.exists():
            if not file.is_file() or file.is_symlink():
                raise RuntimeError(f'Refusing to remove non-regular file: {file}')
            found.append(file)
    for file in found:
        print(('REMOVING' if apply else 'Would remove')+': '+str(file.relative_to(root)))
        if apply:file.unlink()
    print(f'{len(found)} obsolete files '+('removed' if apply else 'found (dry run)'))
    if purge_checkpoints:
        if not apply:raise ValueError('--purge-checkpoints requires --apply')
        for dataset in ('ml-1m','ml-32m'):
            for name in ('sasrec_L100','bert4rec_L100'):
                folder=root/'models'/dataset/name
                if folder.is_dir() and not folder.is_symlink():
                    # Remove only explicitly named obsolete checkpoint folders.
                    shutil.rmtree(folder)
                    print('Removed obsolete checkpoint directory: '+str(folder.relative_to(root)))
    else:
        print('Old checkpoint folders are preserved by default; use --apply --purge-checkpoints if desired.')
    return len(found)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',default='.')
    p.add_argument('--apply',action='store_true')
    p.add_argument('--purge-checkpoints',action='store_true')
    run(**vars(p.parse_args()))
