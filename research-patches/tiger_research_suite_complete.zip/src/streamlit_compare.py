"""Streamlit views for existing small and unified large-scale benchmark JSON files.

No model loading, training, or score reconstruction. Metric comparisons within
one large-scale report use the same holdout sample; never merge different datasets.
"""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

DATASET_OPTIONS = {
    "MovieLens Small (100K)": "ml-latest-small",
    "MovieLens 1M": "ml-1m",
    "MovieLens 32M": "ml-32m",
}
METRICS = {
    "NDCG@K": "ndcg_at_k",
    "Recall@K": "recall_at_k",
    "Catalog coverage@K": "catalog_coverage_at_k",
    "Mean retrieval time (ms)": "query_retrieval_ms_mean",
}


def report_paths(dataset: str, reports_root="reports/unified") -> list[Path]:
    """Unified reports for exactly one dataset, newest first."""
    if dataset not in ("ml-1m", "ml-32m", "ml-latest-small"):
        raise ValueError("Unsupported dataset")
    paths = (list((Path(reports_root) / dataset).glob("unified_*.json"))
             + list((Path(reports_root) / dataset).glob("generative_*.json")))
    return sorted(paths, key=lambda p: (p.stat().st_mtime, p.name), reverse=True)


def read_report(path: str | Path, *, expected_dataset: str | None = None) -> dict:
    """Validate essential JSON metadata; reject cross-dataset accidental mixing."""
    path = Path(path)
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict) or not isinstance(payload.get("results"), dict):
        raise ValueError("Invalid unified benchmark report")
    if expected_dataset is not None and payload.get("dataset") != expected_dataset:
        raise ValueError("Report belongs to a different dataset")
    if payload.get("split") not in ("validation", "test"):
        raise ValueError("Report is missing its evaluation split")
    if int(payload.get("k", 0)) <= 0:
        raise ValueError("Report is missing K")
    return payload


def numeric_metrics(results: dict) -> pd.DataFrame:
    """One row per measured model; drop nonnumeric/missing metric values."""
    if not isinstance(results, dict) or not results:
        return pd.DataFrame()
    df = pd.DataFrame.from_dict(results, orient="index")
    df.index.name = "model"
    for col in set(METRICS.values()) | {"users_evaluated", "candidate_recall"}:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    return df


def _plot_scores(st, df: pd.DataFrame, *, key_prefix: str):
    if df.empty:
        st.info("No models have measured results in this report.")
        return
    available = {name: col for name, col in METRICS.items() if col in df.columns and df[col].notna().any()}
    if not available:
        st.warning("There are no numeric ranking metrics in this report.")
        return
    choice = st.selectbox("Compare models by", list(available), key=f"{key_prefix}_metric")
    metric_col = available[choice]
    ranked = df.dropna(subset=[metric_col]).sort_values(metric_col, ascending=False)
    st.bar_chart(ranked[[metric_col]], use_container_width=True)
    st.dataframe(df.sort_values(metric_col, ascending=False, na_position="last"), use_container_width=True)
    if {"ndcg_at_k", "catalog_coverage_at_k"}.issubset(df.columns):
        st.subheader("Relevance versus catalogue coverage")
        scatter = df.reset_index().dropna(subset=["ndcg_at_k", "catalog_coverage_at_k"])
        if len(scatter):
            st.scatter_chart(scatter, x="catalog_coverage_at_k", y="ndcg_at_k", use_container_width=True)
    st.caption("Bigger NDCG/Recall/Coverage means more of that metric; smaller latency is better. "
               "Models may trade off relevance, diversity, and compute.")


def render_model_comparison(
    small_metrics="artifacts/metrics.json",
    reports_root="reports/unified",
    model_root="models",
):
    """One visual comparison UI; select a SINGLE report for fair sample matching."""
    import streamlit as st

    st.subheader("Model comparison · SVD / BPR / Semantic / TIGER / Slate")
    st.caption("The chosen dataset and benchmark report determine which results are displayed. "
               "Never compare raw NDCG from 100K and 32M as if they used the same task.")
    label = st.selectbox("Dataset", list(DATASET_OPTIONS), key="all_comparison_dataset")
    dataset = DATASET_OPTIONS[label]

    if dataset == "ml-latest-small":
        path = Path(small_metrics)
        if not path.exists():
            st.info("MovieLens Small benchmark is missing. Run `python -m src.train` to produce it.")
            return
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            split = st.radio("Holdout", ["validation", "test"], horizontal=True, key="small_comp_split")
            data = payload[split]
            if not isinstance(data, dict):
                raise ValueError("Metric structure is not a dictionary")
        except (ValueError, KeyError, OSError) as exc:
            st.error(f"Cannot open the Small benchmark: {exc}")
            return
        st.caption(f"MovieLens Small · {split} · K={payload.get('k','?')} · "
                   "per-user chronological holdouts. Only models present in this saved report appear.")
        _plot_scores(st, numeric_metrics(data), key_prefix="small")
        st.info("The 100K benchmark is separate from 1M/32M. "
                "Run `python -m src.benchmark_semantic` to include small-data semantic scores.")
        return

    reports = report_paths(dataset, reports_root)
    if reports:
        file = st.selectbox("Unified benchmark run", reports,
                            format_func=lambda p: ("Generative" if p.name.startswith("generative_") else "Classical")+": "+p.name,
                            key=f"unified_{dataset}_file")
        try:
            payload = read_report(file, expected_dataset=dataset)
        except (ValueError, KeyError, OSError) as exc:
            st.error(f"Cannot open benchmark: {exc}")
            return
        st.caption(f"{dataset} · {payload['split']} · K={payload['k']} · "
                   f"{payload.get('user_sample_size','?')} shared users · index {payload.get('index','?')} · "
                   f"seed {payload.get('seed','?')}")
        hash_value = payload.get("evaluated_user_ids_sha256")
        if hash_value:
            st.caption(f"Evaluation user sample SHA256: `{hash_value[:16]}...`")
        _plot_scores(st, numeric_metrics(payload["results"]), key_prefix=f"unified_{dataset}")
        missing = payload.get("unavailable_models", [])
        if missing:
            st.warning("Not included in this run (missing/not supplied checkpoint or not enabled): "
                       + ", ".join(map(str, missing)))
        with st.expander("Evaluation protocol and limitations"):
            for item in payload.get("caveats", []):
                st.write("• " + str(item))
            st.write("The unified report compares models evaluated within this single run only.")
    else:
        st.info(f"No benchmark report for {dataset} yet. The dashboard won't invent model scores.")
        st.code(f"python -m scalable.unified_benchmark --dataset {dataset} --users 100 --index flat",
                language="bash")
        st.caption("The command requires prepared data and a trained BPR reference checkpoint. "
                   "Additional model checkpoints must be provided with their respective flags.")

