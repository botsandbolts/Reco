"""Tests run without MovieLens downloads or GPU. Real 32M needs Codespaces."""
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
import torch
from scipy.sparse import csr_matrix
from generative.semantic_ids import item_features,residual_codes
from generative.model import GenerativeRetriever,build_trie
from generative.slate import plan_slate
from generative.train import sample_training_batch,load_checkpoint
from generative.evaluate import _ranking_metrics,measure_generative


def _fixture(seed=4):
    rng=np.random.default_rng(seed)
    movies=pd.DataFrame({'title':[f'Film {i}' for i in range(32)],
                         'genres':['Drama|Comedy' if i%2 else 'Adventure' for i in range(32)]})
    text=rng.normal(size=(32,20)).astype('float32')
    poster=rng.normal(size=(32,12)).astype('float32')
    fused=item_features(movies,text=text,visual=poster,dim=8)
    codes,cb,meta=residual_codes(fused,levels=2,codebook_size=4)
    return fused,codes,meta


def test_semantic_id_uniqueness_and_determinism():
    feats,ids,info=_fixture()
    assert len({tuple(c) for c in ids})==32
    assert ids.shape==(32,3)
    assert np.array_equal(ids,residual_codes(feats,levels=2,codebook_size=4)[0])
    assert max(ids.flatten())<info['vocab_size']


def test_optional_visual_vectors_are_real_and_aligned():
    x,c,meta=_fixture()
    movies=pd.DataFrame({'title':[f'x{i}' for i in range(6)],'genres':['Drama']*6})
    with pytest.raises(ValueError,match='visual'):
        item_features(movies,visual=np.ones((5,8)))


def test_training_batch_respects_history_prefix():
    _,codes,_=_fixture()
    seq=np.zeros((3,6),dtype=np.int32)
    seq[0,:4]=[2,3,4,5];seq[1,:4]=[6,7,8,9];seq[2,:4]=[10,11,12,13]
    lengths=np.array([4,4,4],dtype=np.int32)
    x,y=sample_training_batch(seq,lengths,codes,np.array([0,1,2]),8,
                              np.random.default_rng(3),6)
    for row,target in zip(x.numpy(),y.numpy()):
        kept=row[row>=0]; assert len(kept)>=1 and len(kept)<=3
        assert any(np.array_equal(codes[j],target) for j in range(32))
        assert kept[-1]+1>=1


def test_transformer_train_decode_and_slate(tmp_path):
    vectors,codes,meta=_fixture()
    model=GenerativeRetriever(codes,meta['vocab_size'],max_len=6,dim=16,heads=4,layers=1,dropout=0.)
    seq=np.array([[2,3,4,5,0,0],[6,7,8,9,0,0]],dtype=np.int32)
    x,y=sample_training_batch(seq,np.array([4,4]),codes,np.array([0,1]),4,
                              np.random.default_rng(8),6)
    logits=model(x,y)
    assert logits.shape==(4,codes.shape[1],meta['vocab_size'])
    loss=torch.nn.functional.cross_entropy(logits.reshape(-1,logits.shape[-1]),y.reshape(-1))
    loss.backward()
    result=model.decode([0,1,2],build_trie(codes),beam_width=40,k=10,seen={0,1})
    assert all(i not in {0,1} for i,_ in result)
    assert len(result)==len(set(i for i,_ in result))
    slate=plan_slate(result,vectors,k=4)
    assert set(slate).issubset({i for i,_ in result})
    assert len(slate)==len(set(slate))
    saved=tmp_path/'model';saved.mkdir()
    torch.save(model.state_dict(),saved/'weights.pt')
    np.save(saved/'semantic_ids.npy',codes)
    import json
    (saved/'model.json').write_text(json.dumps({'vocab_size':meta['vocab_size'],
        'max_len':6,'dim':16,'heads':4,'layers':1}))
    loaded,_=load_checkpoint(saved)
    assert all(torch.allclose(a,b) for a,b in zip(model.parameters(),loaded.parameters()))


def test_leakage_check_and_common_metrics():
    vectors,codes,meta=_fixture()
    model=GenerativeRetriever(codes,meta['vocab_size'],max_len=6,dim=16,heads=4,layers=1)
    seq=np.zeros((2,6),dtype=np.int32);seq[:,0:3]=[[2,3,4],[5,6,7]]
    seen=csr_matrix((np.ones(2,dtype=np.uint8),([0,1],[0,3])),shape=(2,32))
    u=np.array([0,1]);t=np.array([7,8])
    v,sl=measure_generative(model,seq,np.array([3,3]),codes,vectors,u,t,seen,{},
                             k=3,pool=12,beam=40)
    assert v['users_evaluated']==sl['users_evaluated']==2
    with pytest.raises(ValueError,match='Leakage'):
        measure_generative(model,seq,np.array([3,3]),codes,vectors,u,t,seen,{0:{7}},
                           k=3,pool=12,beam=40)


def test_training_and_generating_report_end_to_end(tmp_path,monkeypatch):
    import json
    from scipy.sparse import save_npz
    from generative import train,evaluate
    feats,codes,meta=_fixture()
    processed=tmp_path/'data'/'processed'/'ml-1m'
    hist=processed/'generative_L6';hist.mkdir(parents=True)
    (processed/'manifest.json').write_text(json.dumps({'dataset':'ml-1m'}))
    (hist/'manifest.json').write_text(json.dumps({'dataset':'ml-1m','max_len':6}))
    sem=tmp_path/'models'/'ml-1m'/'semantic_ids';sem.mkdir(parents=True)
    np.save(sem/'semantic_ids.npy',codes)
    np.save(sem/'item_ids.npy',np.arange(1,33))
    np.save(sem/'item_features.npy',feats)
    (sem/'metadata.json').write_text(json.dumps({'dataset':'ml-1m',**meta}))
    seq=np.zeros((3,6),dtype=np.int32)
    seq[:,:4]=np.array([[2,3,4,5],[8,9,10,11],[14,15,16,17]])
    np.save(hist/'sequences.npy',seq)
    np.save(hist/'lengths.npy',np.array([4,4,4],dtype=np.int32))
    np.save(hist/'user_ids.npy',np.array([1,2,3]))
    np.save(hist/'item_ids.npy',np.arange(1,33))
    rows=np.repeat(np.arange(3),4)
    cols=(seq[:,:4].ravel()-2)
    save_npz(hist/'train_seen.npz',csr_matrix((np.ones(12),(rows,cols)),shape=(3,32)))
    dest=tmp_path/'models'/'ml-1m'/'tiger'
    train.run(dataset='ml-1m',data_dir=str(tmp_path/'data'),semantic_id_dir=str(sem),
              output_dir=str(dest),max_len=6,dim=16,layers=1,heads=4,
              epochs=2,steps_per_epoch=2,batch_size=3,patience=2)
    assert (dest/'weights.pt').exists()
    monkeypatch.setattr(evaluate,'_available_targets',lambda *args: (
                        np.arange(3,dtype=np.int32),np.array([21,22,23],dtype=np.int32)))
    monkeypatch.setattr(evaluate,'_previous_events',lambda *args,**kwargs:{})
    report=evaluate.run(dataset='ml-1m',data_dir=str(tmp_path/'data'),model_dir=str(dest),
                        users=2,k=3,pool=12,beam=30,output_dir=str(tmp_path/'reports'))
    assert set(report['results'])=={'tiger','tiger_slate'}
    assert report['results']['tiger']['users_evaluated']==2
    assert (tmp_path/'reports'/'generative_validation_seed42.json').exists()
