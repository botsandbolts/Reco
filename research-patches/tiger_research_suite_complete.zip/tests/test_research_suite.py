"""Fast regression tests for the new TIGER research-suite integration."""
import json
from pathlib import Path
import numpy as np
import pytest
from scipy.sparse import csr_matrix, save_npz
from generative.research_suite import chosen_variants,write_summary,validate_artifacts
from generative.semantic_ids import residual_codes
from generative import train,evaluate


def test_choice_labels_and_true_modalities(tmp_path):
    first=chosen_variants('ml-1m',tmp_path)
    assert [c['name'] for c in first]==['tiger']
    v=chosen_variants('ml-1m',tmp_path,text_path='text.npy',bpr_path='item.npy',
                      poster_path='poster.npy')
    assert [c['name'] for c in v]==['tiger','tiger_sentence','tiger_text_collab','tiger_visual']
    assert v[-1]['flags']['visual_vectors']=='poster.npy'
    assert 'visual_vectors' not in v[2]['flags']


def test_report_csv_and_provenance_check(tmp_path):
    report={'seed':42,'split':'validation','results':{
        'tiger':{'users_evaluated':3,'recall_at_k':0.3,'ndcg_at_k':0.1,
                 'catalog_coverage_at_k':0.12,'query_retrieval_ms_mean':2.4}}}
    out=write_summary(report,tmp_path)
    contents=out.read_text()
    assert 'ndcg_at_k' in contents and 'tiger' in contents
    folder=tmp_path/'tiger';folder.mkdir()
    semantic=tmp_path/'semantic_ids';semantic.mkdir()
    (folder/'model.json').write_text(json.dumps({'dataset':'ml-1m','max_len':6,
                                                 'semantic_ids':str(semantic),'dim':32,'layers':1,'heads':4,'epochs_requested':1}))
    for f in ['weights.pt','semantic_ids.npy','item_ids.npy']:
        (folder/f).write_bytes(b'test')
    validate_artifacts(folder,semantic,dataset='ml-1m',max_len=6)
    with pytest.raises(ValueError,match='max_len'):
        validate_artifacts(folder,semantic,dataset='ml-1m',max_len=60)
    with pytest.raises(ValueError,match='force-retrain'):
        validate_artifacts(folder,semantic,dataset='ml-1m',max_len=6,
                           config={'dim':64,'layers':1,'heads':4,'epochs':8})


def test_shared_cohort_additional_variants(tmp_path,monkeypatch):
    """Train two variants on synthetic histories, run both on one cohort."""
    rng=np.random.default_rng(4)
    codes,_,meta=residual_codes(rng.normal(size=(32,8)).astype('float32'),
                                 levels=2,codebook_size=4)
    processed=tmp_path/'data'/'processed'/'ml-1m'
    hist=processed/'generative_L6';hist.mkdir(parents=True)
    (processed/'manifest.json').write_text(json.dumps({'dataset':'ml-1m'}))
    (hist/'manifest.json').write_text(json.dumps({'dataset':'ml-1m','max_len':6}))
    seq=np.zeros((3,6),dtype='int32')
    seq[:,:4]=np.array([[2,3,4,5],[8,9,10,11],[14,15,16,17]])
    np.save(hist/'sequences.npy',seq)
    np.save(hist/'lengths.npy',np.array([4,4,4],dtype='int32'))
    np.save(hist/'user_ids.npy',np.array([1,2,3]))
    np.save(hist/'item_ids.npy',np.arange(1,33))
    save_npz(hist/'train_seen.npz',csr_matrix((np.ones(12),
        (np.repeat(np.arange(3),4),seq[:,:4].ravel()-2)),shape=(3,32)))
    sem=tmp_path/'models'/'ml-1m'/'semantic_ids';sem.mkdir(parents=True)
    np.save(sem/'semantic_ids.npy',codes)
    np.save(sem/'item_ids.npy',np.arange(1,33))
    np.save(sem/'item_features.npy',rng.normal(size=(32,8)).astype('float32'))
    (sem/'metadata.json').write_text(json.dumps({'dataset':'ml-1m',**meta}))
    other=tmp_path/'models'/'ml-1m'/'semantic_ids_text';other.mkdir(parents=True)
    for file in ('semantic_ids.npy','item_ids.npy','item_features.npy','metadata.json'):
        (other/file).write_bytes((sem/file).read_bytes())
    baseline=tmp_path/'models'/'ml-1m'/'tiger'
    alternative=tmp_path/'models'/'ml-1m'/'tiger_sentence'
    for semantic,out in ((sem,baseline),(other,alternative)):
        train.run(dataset='ml-1m',data_dir=str(tmp_path/'data'),
            semantic_id_dir=str(semantic),output_dir=str(out),max_len=6,
            dim=16,layers=1,heads=4,epochs=1,steps_per_epoch=2,batch_size=3)
    monkeypatch.setattr(evaluate,'_available_targets',lambda *a: (
        np.arange(3,dtype=np.int32),np.array([21,22,23],dtype=np.int32)))
    monkeypatch.setattr(evaluate,'_previous_events',lambda *a,**k:{})
    report=evaluate.run(dataset='ml-1m',data_dir=str(tmp_path/'data'),
             model_dir=str(baseline),extra_model_dirs={'tiger_sentence':str(alternative)},
             users=2,k=3,pool=12,beam=24,output_dir=str(tmp_path/'reports'))
    assert set(report['results'])=={
        'tiger','tiger_slate','tiger_sentence','tiger_sentence_slate'}
    assert all(m['users_evaluated']==2 for m in report['results'].values())
    with pytest.raises(ValueError,match='Invalid or reserved'):
        evaluate.run(dataset='ml-1m',data_dir=str(tmp_path/'data'),
                     model_dir=str(baseline),extra_model_dirs={'bad-name':str(alternative)},
                     users=2,k=3,pool=12,beam=24)


def test_one_command_quick_run_on_synthetic_movie_histories(tmp_path,monkeypatch):
    """Test runner itself, using a toy catalogue instead of downloaded MovieLens."""
    import pandas as pd
    from generative import research_suite, histories
    from scalable import common
    from generative import evaluate
    monkeypatch.chdir(tmp_path)
    p=tmp_path/'data'/'processed'/'ml-1m'
    hist=p/'generative_L6';hist.mkdir(parents=True)
    (p/'manifest.json').write_text(json.dumps({'dataset':'ml-1m'}))
    (hist/'manifest.json').write_text(json.dumps({'dataset':'ml-1m','max_len':6}))
    np.save(hist/'user_ids.npy',np.array([1,2,3]))
    np.save(hist/'item_ids.npy',np.arange(1,33))
    seq=np.zeros((3,6),dtype='int32')
    seq[:,:4]=[[2,3,4,5],[8,9,10,11],[14,15,16,17]]
    np.save(hist/'sequences.npy',seq)
    np.save(hist/'lengths.npy',np.array([4,4,4],dtype='int32'))
    save_npz(hist/'train_seen.npz',csr_matrix((np.ones(12),
        (np.repeat(np.arange(3),4),seq[:,:4].ravel()-2)),shape=(3,32)))
    monkeypatch.setattr(histories,'run',lambda **kw:hist)
    movies=pd.DataFrame({'movieId':np.arange(1,33),
          'title':[f'FilmTitle{i:03d}' for i in range(32)],
          'genres':['Action|Adventure' if i%2 else 'Comedy|Drama' for i in range(32)]})
    monkeypatch.setattr(common,'load_catalog',lambda *a:movies)
    monkeypatch.setattr(evaluate,'_available_targets',lambda *a:(
        np.arange(3,dtype=np.int32),np.array([21,22,23],dtype=np.int32)))
    monkeypatch.setattr(evaluate,'_previous_events',lambda *a,**k:{})
    # Keep synthetic suite exceptionally small, but still execute the real
    # metadata quantizer, Transformer optimizer, constrained beam, slate, and CSV.
    monkeypatch.setitem(research_suite.PROFILES,'quick',dict(
        dim=16,layers=1,heads=4,epochs=1,steps_per_epoch=2,
        batch_size=3,patience=2,users=2,pool=12,beam=24))
    result=research_suite.run(dataset='ml-1m',data_dir='data',profile='quick',
                     max_len=6,no_sentence=True)
    assert set(result['results'])=={'tiger','tiger_slate'}
    assert (tmp_path/'reports/unified/ml-1m/tiger_ablation_validation_seed42.csv').is_file()
    assert (tmp_path/'models/ml-1m/tiger/weights.pt').is_file()
