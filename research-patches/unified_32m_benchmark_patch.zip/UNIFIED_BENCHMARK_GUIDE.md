# Unified MovieLens Benchmark — BPR, SVD, Semantics, UMAP, Two-Tower, SASRec, BERT4Rec & LambdaMART

This **additive** patch puts several existing research architectures on **one evaluation sample and one holdout protocol**. It does **not** overwrite `src/`, the original Streamlit app, or existing trained models. It includes a minimal scalable two-tower trainer and a standalone SVD fitting command.

> **Status:** Source and synthetic tests checked. The complete 32-million-rating experiment **has not been run** in the authoring environment. Numerical results must be generated in Codespaces or a suitable GPU/CPU instance. Missing checkpoints are shown as **unavailable**, not invented.

## Contents

| New file | Description |
| --- | --- |
| `scalable/unified_benchmark.py` | One shared sampled-user evaluation; optional LambdaMART training; JSON+CSV outputs |
| `scalable/unified_dashboard.py` | Streamlit model comparison dashboard |
| `scalable/fit_svd_only.py` | Sparse TruncatedSVD on the prepared training-only interaction graph, without retraining BPR |
| `scalable/train_two_tower.py` | Shallow PyTorch user-ID / movie-ID+genre two-tower optimized using BPR |
| `requirements-unified.txt` | Optional dependencies for benchmark and ranking |
| `tests/test_unified_benchmark.py` | Deterministic synthetic regressions, no MovieLens download |

### Models and artifacts

| Benchmark label | Algorithm | Required artifact |
| --- | --- | --- |
| `bpr_mf` | Pairwise BPR matrix factorization | `models/<dataset>/bpr/` |
| `svd` | Truncated sparse SVD | `svd_*.npy` in BPR model directory |
| `semantic` | Cosine on user profiles of Sentence Transformer movie embeddings | `data/processed/<dataset>/semantic_raw.npy` or a reduced embedding `.npy` |
| `semantic_bpr` | BPR+trainable semantic projection | `models/<dataset>/bpr-semantic/` |
| `bpr_umap` | BPR+UMAP semantic item projection | `models/<dataset>/bpr-umap/` |
| `two_tower` | Genre-aware learned shallow user/item towers | `models/<dataset>/two-tower/` |
| `sasrec` | SASRec-inspired causal sequential Transformer | `models/<dataset>/sasrec_L100/` |
| `bert4rec` | BERT4Rec-inspired masked-item Transformer | `models/<dataset>/bert4rec_L100/` |
| `hybrid_fusion` | Equal-weight cosine fusion of available BPR, SVD, semantic, SASRec, BERT4Rec | At least two of those sources |
| `lambdamart_two_stage` | LightGBM LambdaMART with features from trained sources | `--train-ranker` (trained on `rank_train` positives each run) |

The two-tower here is deliberately **shallow**; it is not a deep industrial user-history encoder. The original small-scale two-tower is still located in `src/` but **cannot** be scored on 32M users without retraining it for the 32M vocabulary.

## Installation

First ensure you've extracted the **scalable** and **sequential** patches and have applied the separate MovieLens 32M CSV fix. The repository must contain `scalable/common.py`, `scalable/prepare.py`, `scalable/sequence_train.py` and `scalable/sequence_evaluate.py`.

1. Upload `unified_32m_benchmark_patch.zip` via GitHub → **Add file → Upload files**.
2. In Codespaces:

```bash
cd /workspaces/Reco
git pull origin main
unzip -o unified_32m_benchmark_patch.zip
python -m pip install -r requirements-unified.txt
python -m pytest -q tests/test_unified_benchmark.py
```

**Alternative:** Drag the ZIP into Codespaces Explorer, then execute the extraction and install commands.

## Recommended first pass: MovieLens 1M

If you have not prepared 1M yet:

```bash
python -m scalable.prepare --dataset ml-1m --memory 2GB --threads 2
python -m scalable.train --dataset ml-1m --epochs 4 --steps-per-epoch 300
```

The BPR model is the *reference vocabulary and training history*. Keep its directory intact. Fit the SVD baseline **without replacing BPR**:

```bash
python -m scalable.fit_svd_only --dataset ml-1m --components 64
```

Add the shallow two-tower baseline:

```bash
python -m scalable.train_two_tower --dataset ml-1m --epochs 4 --steps-per-epoch 300
```

Prepare sequential histories and train the two Transformer models (optional; neural training can be slow on CPUs):

```bash
python -m scalable.sequence_data --dataset ml-1m --max-len 100
python -m scalable.sequence_train --dataset ml-1m --kind sasrec --epochs 3
python -m scalable.sequence_train --dataset ml-1m --kind bert4rec --epochs 3
```

For semantic models, ensure `requirements-scale-semantic.txt` is installed, then generate raw semantic movie embeddings. These are **title+genre embeddings**, not rich movie synopses:

```bash
python -m pip install -r requirements-scale-semantic.txt
python -m scalable.semantic --dataset ml-1m --reducer raw
python -m scalable.semantic --dataset ml-1m --reducer umap --dims 64
python -m scalable.train --dataset ml-1m --output-dir models/ml-1m/bpr-umap --semantic-vectors data/processed/ml-1m/semantic_umap64.npy --epochs 4 --steps-per-epoch 300
python -m scalable.train --dataset ml-1m --output-dir models/ml-1m/bpr-semantic --semantic-vectors data/processed/ml-1m/semantic_raw.npy --epochs 4 --steps-per-epoch 300
```

### All-model unified 1M comparison

```bash
python -m scalable.unified_benchmark \
  --dataset ml-1m --users 300 --seed 42 --index flat \
  --semantic-vectors data/processed/ml-1m/semantic_raw.npy \
  --semantic-bpr-dir models/ml-1m/bpr-semantic \
  --umap-bpr-dir models/ml-1m/bpr-umap \
  --two-tower-dir models/ml-1m/two-tower \
  --sasrec-dir models/ml-1m/sasrec_L100 \
  --bert4rec-dir models/ml-1m/bert4rec_L100 \
  --train-ranker --ranker-users 1000
```

This creates:

```text
reports/unified/ml-1m/unified_validation_flat_seed42.json
reports/unified/ml-1m/unified_validation_flat_seed42.csv
```

To run before all models are ready, simply **omit the flags for missing artifacts**. They will appear in the JSON as unavailable instead of causing misleading comparisons. A minimal command is:

```bash
python -m scalable.unified_benchmark --dataset ml-1m --users 100 --index flat
```

## MovieLens 32M: incremental rollout

**Prerequisite:** The CSV parser fix must be applied; `python -m scalable.prepare --dataset ml-32m --memory 3GB --threads 2` must have completed and written `data/processed/ml-32m/manifest.json` and `movies.parquet`.

### 32M base models

```bash
# Train BPR only if models/ml-32m/bpr does not already contain trained vectors.
python -m scalable.train --dataset ml-32m --epochs 3 --steps-per-epoch 300 --batch-size 4096

# Avoid retraining BPR to add SVD
python -m scalable.fit_svd_only --dataset ml-32m --components 64

# Metadata-aware two-tower
python -m scalable.train_two_tower --dataset ml-32m --epochs 3 --steps-per-epoch 300 --batch-size 4096
```

### Optional 32M semantic models

```bash
python -m scalable.semantic --dataset ml-32m --reducer raw
python -m scalable.semantic --dataset ml-32m --reducer umap --dims 64
python -m scalable.train --dataset ml-32m --output-dir models/ml-32m/bpr-umap --semantic-vectors data/processed/ml-32m/semantic_umap64.npy --epochs 3 --steps-per-epoch 300
python -m scalable.train --dataset ml-32m --output-dir models/ml-32m/bpr-semantic --semantic-vectors data/processed/ml-32m/semantic_raw.npy --epochs 3 --steps-per-epoch 300
```

If the 32M sequence models have been trained using the prior sequential patch, include their folders in the evaluation. If not, omit those flags for your first comparison, or train them separately:

```bash
python -m scalable.sequence_data --dataset ml-32m --max-len 100 --memory 3GB --threads 2
python -m scalable.sequence_train --dataset ml-32m --kind sasrec --epochs 3 --steps-per-epoch 300
python -m scalable.sequence_train --dataset ml-32m --kind bert4rec --epochs 3 --steps-per-epoch 300
```

### All-model 32M benchmark

```bash
python -m scalable.unified_benchmark \
  --dataset ml-32m --users 500 --seed 42 --index flat \
  --semantic-vectors data/processed/ml-32m/semantic_raw.npy \
  --semantic-bpr-dir models/ml-32m/bpr-semantic \
  --umap-bpr-dir models/ml-32m/bpr-umap \
  --two-tower-dir models/ml-32m/two-tower \
  --sasrec-dir models/ml-32m/sasrec_L100 \
  --bert4rec-dir models/ml-32m/bert4rec_L100 \
  --train-ranker --ranker-users 1500 --pool-per-source 100
```

**CPU/memory caution:** Building several FAISS FlatIP indices and loading 32M semantic/Transformer factor arrays can be demanding in a small Codespace. For initial diagnosis, run 100 users and include only BPR+SVD, then add each source incrementally. GPU is preferable for training sequential models, but CPU works for small smoke tests. FAISS FlatIP gives exact full-catalogue rankings; HNSW is faster but approximate and is **not an apples-to-apples measure of scoring quality** unless its retrieval recall is separately established.

### Test split: keep locked until model selection is finished

After selecting the final configurations using **validation only**:

```bash
python -m scalable.unified_benchmark --dataset ml-32m --split test --final-test \
  --users 500 --seed 42 --index flat \
  --semantic-vectors data/processed/ml-32m/semantic_raw.npy \
  --semantic-bpr-dir models/ml-32m/bpr-semantic \
  --umap-bpr-dir models/ml-32m/bpr-umap \
  --two-tower-dir models/ml-32m/two-tower \
  --sasrec-dir models/ml-32m/sasrec_L100 \
  --bert4rec-dir models/ml-32m/bert4rec_L100 \
  --train-ranker --ranker-users 1500
```

Note: identical `--seed` samples deterministic *within each split*, but the validation and test events/users can differ. The primary promise is common samples **across models inside each run**, not identical validation and test events.

## Dashboard

```bash
streamlit run scalable/unified_dashboard.py --server.address 0.0.0.0 --server.port 8501
```

The dashboard shows the rankings, NDCG/coverage comparison, missing-artifact statuses, and methodological caveats. It only reads JSON; it cannot overwrite trained models.

## Protocol details

1. All compared methods are evaluated on **the same sampled users**, with one held-out positive per user. If sequence models are included, selection is restricted to users with at least two train-sequence events; that restriction applies to *every* model.
2. All user queries come from **early training history only**. Ranker-training, validation, and test positives never enter sequence input.
3. At validation time, each user’s training and ranker-training positives are excluded from recommendations. Test excludes training, ranker-training **and validation** positives.
4. FAISS **FlatIP** considers the full catalogue for factor models. NDCG@K, Recall@K and catalogue coverage@K use the same metric definition. With one positive per user, Recall@K equals Hit Rate@K.
5. The **LambdaMART two-stage** pipeline trains labels only from `rank_train` and samples unobserved alternatives as weak negatives. At evaluation, it reranks an **honestly retrieved** candidate pool; it never injects test targets. Candidate recall is reported because it is an upper bound on final recall.
6. `hybrid_fusion` concatenates normalized representations, using **fixed equal weights** by default. It is not tuned on the final test set.
7. The output contains a SHA-256 digest of the sampled raw user IDs, allowing different method runs to check sample identity without disclosing a user list.
8. Every required external factor artifact must be from the **same dataset vocabulary**. The code checks dataset/ID alignment and rejects mismatches.

**Study limitations:** MovieLens provides ratings, not exposures or verified negatives. Rating timestamps are not necessarily watch timestamps. The holdout split is per-user chronological, not a strict global time split. More complex methods may perform worse than SVD; do not infer real-world user satisfaction or causal uplift from offline results. In sequential models, use reproducible GPU/CPU settings and report training costs.

**Model licenses:** MovieLens/GroupLens dataset terms apply independently from your source-code license. Keep raw data out of Git; ensure derived model redistribution complies with data/model license requirements.

## Troubleshooting

- `ModuleNotFoundError: scalable...` → extract the 32M and sequential patches first; check `ls scalable/`.
- `FAISS... install` → `python -m pip install -r requirements-scale.txt`.
- `Missing model for X` → train the model, or remove the corresponding `--*-dir` option.
- `BPR dataset mismatch` → model folder belongs to another dataset.
- `sequence user/item IDs do not match` → rerun sequence preparation from the same processed dataset as the BPR model; do not mix Small/1M/32M checkpoints.
- `svd` unavailable → run `python -m scalable.fit_svd_only --dataset ml-32m`.
- `Two-tower` unavailable → run `python -m scalable.train_two_tower --dataset ml-32m` and pass the resulting folder.
- `No report found` → use `--output-dir` default or configure a custom report directory in the dashboard sidebar.
- Memory errors → evaluate fewer models per run, use 100 users and more memory; `--index hnsw` trades exactness for speed and should be documented.

## Research output for a portfolio

Use `unified_validation_flat_seed42.csv` for a table in the README and figures in your LinkedIn project post. Report **actual measured results only**, plus dataset name, number of users, split, candidate protocol, training budget, checkpoint version and index type.
