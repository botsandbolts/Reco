"""Fit a sparse SVD baseline without retraining or replacing BPR artifacts."""
import argparse
from pathlib import Path
import numpy as np
from sklearn.decomposition import TruncatedSVD
from scipy.sparse import load_npz
from .common import load_model


def run(dataset="ml-1m",model_dir=None,components=64,iterations=3,seed=42):
    folder=Path(model_dir) if model_dir else Path("models")/dataset/"bpr"
    cfg,uid,iid,_,_,seen=load_model(folder)
    if cfg.get("dataset")!=dataset:
        raise ValueError("Dataset mismatch")
    n=min(components,len(uid)-1,len(iid)-1)
    if n<1:raise ValueError("Insufficient users or items")
    print(f"Fitting {n}-dimensional TruncatedSVD on {seen.nnz:,} positive training pairs")
    svd=TruncatedSVD(n_components=n,n_iter=iterations,random_state=seed)
    users=svd.fit_transform(seen.astype(np.float32))
    np.save(folder/"svd_user_vectors.npy",users.astype(np.float32))
    np.save(folder/"svd_item_vectors.npy",svd.components_.T.astype(np.float32))
    print(f"Stored standalone SVD factors in {folder}; explained_variance={svd.explained_variance_ratio_.sum():.4f}")
    return folder


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--dataset",default="ml-1m")
    p.add_argument("--model-dir",default=None)
    p.add_argument("--components",type=int,default=64)
    p.add_argument("--iterations",type=int,default=3)
    p.add_argument("--seed",type=int,default=42)
    print(run(**vars(p.parse_args())))
