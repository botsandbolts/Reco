"""Train a scalable shallow two-tower: user ID embedding + movie ID/genres tower.

The user tower is a learned lookup; the item tower adds a learned ID embedding
and trainable genre projection. The pairwise BPR objective trains both towers.
This is intentionally smaller than production deep two-tower architectures.
"""
import argparse
from pathlib import Path
import numpy as np
from scipy.sparse import csr_matrix, save_npz
from .common import load_catalog,load_interactions,encode_ids,store_json
from .bpr import train_bpr


def genre_features(catalog):
    names=sorted(set(t for genres in catalog.genres.fillna("")
                     for t in str(genres).split("|") if t and t!="(no genres listed)"))
    mapping={t:j for j,t in enumerate(names)}
    z=np.zeros((len(catalog),len(names)),dtype=np.float32)
    for r,genres in enumerate(catalog.genres.fillna("")):
        for t in str(genres).split("|"):
            if t in mapping:z[r,mapping[t]]=1.
    return z,names


def run(dataset="ml-1m", data_dir="data", output_dir=None, factors=64,
        epochs=4, steps_per_epoch=500, batch_size=4096,
        genre_weight=0.5, seed=42):
    processed=Path(data_dir)/"processed"/dataset
    if not (processed/"manifest.json").exists():
        raise FileNotFoundError("Run scalable.prepare first")
    catalog=load_catalog(processed)
    ids=np.asarray(catalog.movieId,dtype=np.int64)
    raw_u,raw_i=load_interactions(processed,"train")
    uids=np.unique(raw_u.astype(np.int64))
    ui=encode_ids(raw_u,uids);ii=encode_ids(raw_i,ids)
    if not 0<=genre_weight<=1:
        raise ValueError("genre_weight must be in [0,1]")
    features,names=genre_features(catalog)
    out=Path(output_dir) if output_dir else Path("models")/dataset/"two-tower"
    out.mkdir(parents=True,exist_ok=True)
    seen=csr_matrix((np.ones(len(ui),dtype=np.bool_), (ui,ii)),
                    shape=(len(uids),len(ids)))
    seen.data[:]=1
    seen.sum_duplicates();seen.sort_indices()
    user_vec,item_vec,losses,duration=train_bpr(ui,ii,len(uids),len(ids),
        factors=factors,epochs=epochs,steps_per_epoch=steps_per_epoch,
        batch_size=batch_size,semantic=features,semantic_weight=genre_weight,
        seed=seed)
    np.save(out/"user_ids.npy",uids);np.save(out/"item_ids.npy",ids)
    np.save(out/"user_vectors.npy",user_vec);np.save(out/"item_vectors.npy",item_vec)
    save_npz(out/"train_seen.npz",seen,compressed=True)
    store_json(out/"model.json",{"dataset":dataset,"model":"two_tower_user_ID_item_ID_plus_genres",
        "architecture":"shallow user ID lookup, item ID embedding plus trainable genre projection",
        "factors":factors,"epochs":epochs,"steps_per_epoch":steps_per_epoch,
        "genre_weight":genre_weight,"genre_classes":names,
        "training_seconds":duration,"epoch_losses":losses,"seed":seed})
    print(f"Saved shallow two-tower model: {out}")
    return out


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--dataset",default="ml-1m")
    p.add_argument("--data-dir",default="data")
    p.add_argument("--output-dir",default=None)
    p.add_argument("--factors",type=int,default=64)
    p.add_argument("--epochs",type=int,default=4)
    p.add_argument("--steps-per-epoch",type=int,default=500)
    p.add_argument("--batch-size",type=int,default=4096)
    p.add_argument("--genre-weight",type=float,default=0.5)
    p.add_argument("--seed",type=int,default=42)
    print(run(**vars(p.parse_args())))
