"""Unified results dashboard; it reads produced JSON, never loads/trains models."""
import json
from pathlib import Path
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Unified MovieLens Benchmark", layout="wide", page_icon="📊")
st.title("Unified MovieLens Recommendation Benchmark")
st.caption("Common evaluation sample • historical positive ratings • MovieLens / GroupLens")
root = Path(st.sidebar.text_input("Benchmark reports directory", "reports/unified"))
reports = sorted(root.glob("*/unified_*.json")) if root.is_dir() else []
if not reports:
    st.info("No reports found. Run python -m scalable.unified_benchmark first.")
    st.stop()
file = st.sidebar.selectbox("Report", reports, format_func=lambda x: str(x.relative_to(root)))
r = json.loads(file.read_text(encoding="utf-8"))
st.subheader(f"{r['dataset']} — {r['split']} — {r['user_sample_size']:,} users")
st.caption(f"Seed {r['seed']} · Index {r['index']} · K={r['k']} · shared user sample hash {r['evaluated_user_ids_sha256'][:14]}…")
df = pd.DataFrame(r['results']).T
columns=[c for c in ("users_evaluated","recall_at_k","ndcg_at_k","catalog_coverage_at_k",
                    "candidate_recall","query_retrieval_ms_mean") if c in df]
if not df.empty:
    st.dataframe(df[columns].sort_values("ndcg_at_k",ascending=False),use_container_width=True)
    st.bar_chart(df["ndcg_at_k"].sort_values(ascending=False))
    st.subheader("Relevance vs coverage")
    if "catalog_coverage_at_k" in df:
        st.scatter_chart(df.reset_index(),x="catalog_coverage_at_k",y="ndcg_at_k",color=None)
missing=r.get("unavailable_models",[])
if missing:
    st.warning("Not included (artifact not supplied or ranker not enabled): " + ", ".join(missing))
st.markdown("### Methodology and caveats")
for reason in r.get("caveats",[]):
    st.write("• " + reason)
st.caption("For final model selection, compare validation first and unlock test only once after choices are frozen.")
