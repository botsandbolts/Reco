import numpy as np
import pytest
from scipy.sparse import csr_matrix
from scalable.unified_benchmark import (Source, normalize, select_shared_users,
                                         combine_sources, evaluate_rows, ranker_feature_matrix,
                                         ranker_fit, ranker_evaluate)


def _fixture():
    # Four users, 14 items; targets not in training.
    items=np.eye(14,4,dtype=np.float32)
    item0=np.array([[1.,0.],[0.,1.],[1.,1.],[2.,0.],[0.,2.],[0.5,0.8]] + [[0.1,0.1]]*8,dtype=np.float32)
    users=np.array([0,1,2,3],dtype=np.int32)
    train=csr_matrix((np.ones(4,dtype=np.uint8),(users,np.array([0,1,2,3]))),shape=(4,14))
    src=Source("bpr_mf",item0,lambda u:np.stack([np.array([1.,0.])]*len(u)).astype(np.float32))
    return train,src


def test_shared_user_selection_and_eligibility():
    u=np.arange(6,dtype=np.int32); t=np.arange(6,dtype=np.int32)+10
    length=np.array([2,1,2,0,3,2])
    a,b=select_shared_users(u,t,3,42,length)
    a2,b2=select_shared_users(u,t,3,42,length)
    assert np.array_equal(a,a2) and np.array_equal(b,b2)
    assert np.all(length[a]>=2)
    assert len(a)==3


def test_equal_weight_dot_product_fusion():
    _,s=_fixture()
    users=np.array([0,1],dtype=np.int32)
    other=Source("semantic",np.ones((14,3),dtype=np.float32),
                 lambda u:np.ones((len(u),3),dtype=np.float32))
    out, q=combine_sources([s,other],users,weights=[0.25,0.75])
    expected=0.25 * (normalize(s.queries(users))@normalize(s.items).T) + 0.75 * np.ones((2,14))
    assert np.allclose(q@out.items.T,expected,atol=1e-5)


def test_unified_metrics_exclusions_and_leakage():
    seen,s=_fixture()
    users=np.array([0,1,2,3],dtype=np.int32)
    target=np.array([3,4,5,6],dtype=np.int32)
    metric,top=evaluate_rows(s.queries(users),s.items,seen,users,target,{},index_kind="numpy",k=2,collect_candidates=5)
    assert metric["users_evaluated"]==4 and len(top)==4
    assert all(int(u) not in row for u,row in zip(users,top))
    with pytest.raises(ValueError,match="leakage"):
        evaluate_rows(s.queries(users),s.items,seen,users,target,{0:{3}},index_kind="numpy",k=2)


def test_feature_columns():
    _,s=_fixture()
    q={"bpr_mf":s.queries(np.array([0,1]))}
    assert ranker_feature_matrix([s],q,0,np.array([0,2,3])).shape==(3,1)


def test_ranker_honest_pool():
    lightgbm=pytest.importorskip("lightgbm")
    rng=np.random.default_rng(7)
    n_users,n_items=20,100
    seen=csr_matrix((np.ones(n_users,dtype=np.uint8),(np.arange(n_users),np.arange(n_users))),
                    shape=(n_users,n_items))
    item=rng.normal(size=(n_items,8)).astype(np.float32)
    user=rng.normal(size=(n_users,8)).astype(np.float32)
    src=Source("bpr_mf",item,lambda idx:user[idx])
    users=np.arange(n_users,dtype=np.int32)
    rank_train=np.arange(n_users,dtype=np.int32)+40
    m=ranker_fit([src],users,rank_train,seen,n_items=n_items,negatives=15)
    metric=ranker_evaluate(m,[src],users,np.arange(n_users)+60,seen,{},
                           k=5,index_kind="numpy",pool_per_source=25)
    assert 0<=metric["recall_at_k"]<=metric["candidate_recall"]<=1


def test_no_unlocked_test_access():
    from scalable.unified_benchmark import run
    with pytest.raises(ValueError, match="--final-test"):
        run(dataset="ml-1m", split="test")


def test_full_cli_synthetic_without_duckdb(tmp_path,monkeypatch):
    import json
    from pathlib import Path
    import scipy.sparse as sparse
    from scalable import unified_benchmark as ub
    root=tmp_path/"data"/"processed"/"ml-1m"
    root.mkdir(parents=True)
    (root/"manifest.json").write_text('{"dataset":"ml-1m"}')
    folder=tmp_path/"models"/"bpr"
    folder.mkdir(parents=True)
    rng=np.random.default_rng(11)
    users=np.arange(20,dtype=np.int32)+1
    items=np.arange(100,dtype=np.int32)+1
    q=rng.normal(size=(20,8)).astype(np.float32)
    v=rng.normal(size=(100,8)).astype(np.float32)
    seen=sparse.csr_matrix((np.ones(20,dtype=np.uint8),
                            (np.arange(20),np.arange(20))),shape=(20,100))
    for name,arr in (("user_ids",users),("item_ids",items),
                     ("user_vectors",q),("item_vectors",v),
                     ("svd_user_vectors",q+0.05),("svd_item_vectors",v+0.05)):
        np.save(folder/f"{name}.npy",arr)
    sparse.save_npz(folder/"train_seen.npz",seen)
    (folder/"model.json").write_text(json.dumps({"dataset":"ml-1m"}))
    def fake_targets(processed,split,user_ids,item_ids):
        targets=np.arange(20,dtype=np.int32)+45
        if split=="rank_train":targets=targets-10
        if split=="test":targets=targets+10
        return np.arange(20,dtype=np.int32),targets
    monkeypatch.setattr(ub,"_available_targets",fake_targets)
    monkeypatch.setattr(ub,"_previous_events",lambda *a,**k:{})
    out=tmp_path/"reports"
    r=ub.run(dataset="ml-1m",data_dir=str(tmp_path/"data"),bpr_model_dir=str(folder),
             output_dir=str(out), users=12,seed=5,index="numpy",k=5,
             train_ranker=True,ranker_users=20,pool_per_source=15)
    assert {"bpr_mf","svd","hybrid_fusion","lambdamart_two_stage"}<=set(r["results"])
    assert len({x["users_evaluated"] for x in r["results"].values()})==1
    assert (out/"unified_validation_numpy_seed5.json").is_file()
    assert (out/"unified_validation_numpy_seed5.csv").is_file()


def test_genre_tower_metadata_onehot():
    import pandas as pd
    from scalable.train_two_tower import genre_features
    frame=pd.DataFrame({"genres":["Drama|Comedy","Comedy","(no genres listed)"]})
    x,names=genre_features(frame)
    assert names==["Comedy","Drama"]
    assert x.shape==(3,2)
    assert np.all(x[2]==0)
