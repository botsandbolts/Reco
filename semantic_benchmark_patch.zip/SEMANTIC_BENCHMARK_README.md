# Add Sentence Transformers to the model comparison

This patch **adds** a semantic benchmark. It does **not** overwrite your trained models, change the existing recommender, or require retraining SVD/PyTorch/LightGBM.

## Install

Extract this patch from the root of `/workspaces/Reco`, allowing the new `src/benchmark_semantic.py` and `tests/test_semantic_benchmark.py` to be created.

## Run

1. Verify you've already installed and run the Sentence Transformers integration:

   ```bash
   python -m pip install -r requirements-optional-nlp.txt
   python -m src.semantic
   ```

   **Important:** If you ran `python -m src.train` *after* generating semantic embeddings, the trained artifact was overwritten. Run `python -m src.semantic` again, then continue below.

2. Run the new tests:

   ```bash
   python -m pytest -q tests
   ```

3. Produce the semantic benchmark results:

   ```bash
   python -m src.benchmark_semantic
   ```

4. Restart or refresh your running Streamlit application and open **Benchmark**. The table and chart load the metrics file dynamically, so **`semantic`** and **`svd_semantic`** should appear automatically.

## What changes?

- `semantic`: user-profile cosine similarity to MovieLens movie title/genre Sentence Transformer embeddings.
- `svd_semantic`: 50% SVD + 40% semantic + 10% popularity score, fixed weights, not tuned to test outcomes.
- The other models and their recorded metrics stay unchanged.
- `artifacts/metrics_before_semantic.json` preserves a backup from before these two results were added.
- Both new methods use training history only, and the original project's validation and test exclusion rules.

## Important limitations

This *does not* train a text model from scratch, and it does not incorporate movie synopses. It simply evaluates pretrained sentence-transformer vectors, based on the limited textual signal in movie titles and genres. Therefore, it is possible (even likely) that the method underperforms SVD. Accurate comparison is the purpose of this experiment.

This patch adds the methods **to the Benchmark tab**, not to the **Known User** dropdown. Their semantic scores are computed inside a benchmarking adapter, leaving the production demo unchanged.
