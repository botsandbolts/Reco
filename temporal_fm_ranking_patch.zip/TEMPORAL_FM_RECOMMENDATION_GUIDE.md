# Temporal FM / DeepFM — Top-K Recommendation Simulation

This is an **add-on** for the already-installed `temporal_hybrid_fm_patch.zip` (not a replacement).
It adds `temporal_fm/ranking.py` and upgrades `temporal_fm/dashboard.py`; it does **not** retrain or delete models, change the rating-loss objective, rewrite the original MovieLens data, or change `app.py` tabs.

## Install in GitHub Codespaces

Upload `temporal_fm_ranking_patch.zip` into the **root** of your GitHub `herberton777/Reco` repository, commit the upload to `main`, then in your *existing* Codespace run:

```bash
cd /workspaces/Reco
git fetch origin main
# Copy only the uploaded archive from GitHub; preserves uncommitted local work:
git show origin/main:temporal_fm_ranking_patch.zip > temporal_fm_ranking_patch.zip
unzip -o temporal_fm_ranking_patch.zip
python -m pytest -q tests/test_temporal_ranking.py
```

The prior Temporal FM patch must already have been installed and at least one checkpoint trained (`models/ml-1m/temporal_fm/fm_all/weights.pt`, etc.).

## Run a realistic full-catalogue validation simulation (MovieLens 1M)

```bash
python -m temporal_fm.ranking \
  --dataset ml-1m \
  --backend sentence \
  --models fm_id,fm_content,fm_all_no_time,fm_all,deepfm_id,deepfm_content,deepfm_all_no_time,deepfm_all \
  --users 60 \
  --k 10 \
  --threshold 4 \
  --min-history 5 \
  --max-candidates 0 \
  --device cpu
```

Missing checkpoint names are skipped, but existing checkpoints with a mismatching text backend, seed or dataset cutoff cause an error rather than a misleading metric. To run only two trained models, replace `--models ...` with `--models fm_all,deepfm_all`.

**Importantly, this command evaluates checkpoints. It does not train them.** If you trained with `--text-backend hash`, use `--backend hash`. If you trained only one model, use its name. The existing `.json` rating reports (RMSE/MAE) remain unchanged.

The command writes:

- `reports/temporal/ml-1m/ranking_validation_...json`
- `reports/temporal/ml-1m/ranking_validation_...csv`

Each report includes model-by-model ranking metrics and sample recommendation lists with actual MovieLens movie IDs and titles.

Open the existing Streamlit app:

```bash
streamlit run app.py --server.address 0.0.0.0 --server.port 8501
```

Go to **Temporal FM / DeepFM** and scroll to **Top-K Recommendation Simulation**. It displays NDCG, Recall, Hit Rate, MRR, the comparison table and recommendations for example users.

## How the offline simulation works

1. The data pipeline already defines a **global chronological** train/validation/test split.
2. The model, metadata and genre/title features are frozen. Recommendations are generated just **after the training cutoff**. All tag features are looked up as of that cutoff, not the later rating time.
3. Each eligible evaluation user has at least five training ratings and at least one later positive rating for a movie present in the training catalogue. These criteria are chosen independently of model predictions.
4. All *previously rated* movies are excluded from candidates.
5. The model scores the remaining training-catalogue movies; a training-only movie-popularity baseline scores exactly the same candidates.
6. Ratings in the validation window of **>=4 stars** are relevance labels. Rank the highest-scored K movies. Calculate metrics per user, then macro-average.
7. Top movie titles, genres, scores and whether they match a held-out positive are stored for inspection.

### Metrics

- **NDCG@K**: Discounted gain normalized by the ideal ranking for each user.
- **Recall@K**: Held-out positively rated movies retrieved among top K / all held-out positives eligible in that catalogue.
- **Precision@K**: Held-out positive matches among top K / K (unobserved movies are treated as unknown, not proven dislikes).
- **Hit Rate@K**: Fraction of users with at least one relevant movie in top K.
- **MRR@K**: Mean reciprocal rank of the first relevant movie.
- **MAP@K**: Mean average precision truncated at K.
- **Catalogue coverage**: Distinct recommended movies across users / training-catalogue size.
- **Genre diversity**: Mean pairwise Jaccard distance between recommended movies' binary genre vectors.
- **Novelty**: Average `-log2((train_movie_rating_count+1)/(total_train_ratings+catalogue_size))` in bits.

### Larger MovieLens 32M evaluation

Full-catalogue evaluation will score many movies per user and can be slow on a CPU. For a bounded **research-only sampled candidate** experiment:

```bash
python -m temporal_fm.ranking --dataset ml-32m --backend sentence \
  --models fm_all,deepfm_all --users 60 --k 10 --max-candidates 2000 --device cpu
```

Sampling includes every held-out positive in the evaluated catalogue plus uniformly sampled additional unseen movies. **These scores are not comparable to full-catalogue metrics** and can substantially inflate apparent performance; the report and Streamlit dashboard explicitly label the difference. For defensible comparisons against TIGER/BPR/SVD, evaluate the *same* cohorts, candidate pools, target definition and chronological splits for all models. This add-on compares FM variants and popularity fairly **within its own report**, not directly to separately generated BPR/TIGER benchmark reports.

### Simulate one specific eligible user

```bash
python -m temporal_fm.ranking --dataset ml-1m --backend sentence \
  --models fm_all,deepfm_all --user-id 42 --users 1 --example-users 1 --k 10
```

If the specified user has no new positively rated movie in the validation window or insufficient training history, the evaluator explains that the user is not eligible for offline hit metrics. Use the Streamlit report dropdown to explore already evaluated eligible users.

### Test set

The default is `--split validation`. Select hyperparameters and models using validation only. For **one final evaluation** after selection, you may run the same command with `--split test`, keeping the checkpoints frozen. This remains a train-cutoff recommendation context; it does not incorporate validation events into user history or tags.

## Important limitations

- Rating timestamps represent when ratings were recorded, not necessarily when movies were watched.
- `movieId` must exist in training for the full-catalogue retrieval benchmark; cold-start films are excluded by design.
- Because feedback is sparse, unlabeled (unrated) recommendations may be good suggestions that the offline metrics cannot recognize. Precision is especially sensitive to this.
- Full-catalogue NDCG/Recall are useful offline indicators; they are not click-through rates or proof of end-user satisfaction.
- The model scores at the training cutoff; do **not** substitute each held-out rating timestamp as a temporal feature (future leakage).
- A stronger RMSE does not imply stronger NDCG, and this evaluator does not claim actual scores until it is run on your MovieLens data.
