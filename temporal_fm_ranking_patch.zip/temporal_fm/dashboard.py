"""Streamlit research dashboard; never retrains or loads a large PyTorch model."""
from __future__ import annotations
from pathlib import Path
import json
import pandas as pd


def render_temporal_lab():
    import streamlit as st
    st.subheader('Temporal Factorization Machines · Explicit ratings')
    st.caption('Chronological rating prediction: FM / DeepFM · Sentence Transformers · binary genres · '
               'historical user tags · calendar and personalized time features')
    dataset=st.selectbox('Temporal dataset',['ml-1m','ml-32m','ml-latest-small'],key='temporal_ds')
    folder=Path('reports')/'temporal'/dataset
    reports=sorted(folder.glob('validation_*.json'),key=lambda p:p.stat().st_mtime,reverse=True)
    if not reports:
        st.info('No temporal FM results yet. Run the training suite in Codespaces.')
        st.code(f'python -m temporal_fm.run --dataset {dataset} --profile quick --device cpu',language='bash')
        return
    chosen=st.selectbox('Choose a single experiment report',reports,
                       format_func=lambda p:p.name,key='temporal_report')
    try:report=json.loads(chosen.read_text(encoding='utf-8'))
    except (ValueError,OSError) as exc:
        st.error(str(exc));return
    st.caption(f"Dataset: {dataset} | split: {report.get('split')} | "
               f"train: {report.get('train_count',0):,} | validation: {report.get('validation_count',0):,} | "
               f"profile: {report.get('profile')} | text: {report.get('backend')} | "
               f"historical tags: {report.get('has_historical_tags')}")
    rows=pd.DataFrame.from_dict(report['results'],orient='index')
    rows.index.name='Model'
    col1,col2=st.columns(2)
    with col1:
        st.write('**Rating accuracy · RMSE (lower is better)**')
        st.bar_chart(rows[['rmse']].sort_values('rmse',ascending=True),use_container_width=True)
    with col2:
        st.write('**Rating accuracy · MAE (lower is better)**')
        st.bar_chart(rows[['mae']].sort_values('mae',ascending=True),use_container_width=True)
    st.dataframe(rows.sort_values('rmse'),use_container_width=True)
    st.warning('These metrics predict observed star ratings. They are NOT directly comparable to '
               'NDCG@10 or Recall@10 from the BPR/TIGER ranking evaluation.')
    curves=[]
    for model,records in report.get('history',{}).items():
        for point in records:curves.append({'Model':model,**point})
    if curves:
        st.markdown('#### Validation RMSE by training epoch')
        df=pd.DataFrame(curves)
        st.line_chart(df.pivot(index='epoch',columns='Model',values='validation_rmse'),use_container_width=True)
    by_year=sorted(folder.glob('*_by_year.csv'))
    if by_year:
        choice=st.selectbox('Temporal drift · errors by rating year',by_year,
                            format_func=lambda p:p.stem.replace('_by_year',''),key='temporal_yr')
        temp=pd.read_csv(choice)
        if not temp.empty:
            st.line_chart(temp.set_index('year')[['rmse','mae']],use_container_width=True)
    trends_path=folder/'genre_trends_train_only.csv'
    if trends_path.exists():
        trends=pd.read_csv(trends_path)
        if len(trends):
            st.markdown('#### Observed changes in genre preferences')
            st.caption('Training ratings only: mean stars given to each genre by selected active users. '
                       'These are descriptive observations, not causal preferences or model predictions.')
            user=st.selectbox('Anonymous MovieLens user',sorted(trends.userId.unique()),key='temporal_user')
            section=trends[trends.userId==user]
            options=section.groupby('genre').ratings_count.sum().nlargest(6).index.tolist()
            picks=st.multiselect('Genres to plot',sorted(section.genre.unique()),default=options,key='temporal_genres')
            sub=section[section.genre.isin(picks)]
            if len(sub):
                st.line_chart(sub.pivot(index='year',columns='genre',values='mean_rating'),use_container_width=True)
    with st.expander('Leakage controls and interpretation'):
        for warning in report.get('caveats',[]):st.write('• '+str(warning))
        st.write('This is a model ablation on a fixed validation sample; final test set remains unused.')

    st.divider()
    st.subheader('Top-K Recommendation Simulation')
    st.caption('Frozen FM/DeepFM checkpoints recommend unseen training-catalogue films at the global training cutoff. '
               'Later ratings >= 4 stars act as positive labels. No training occurs when opening this tab.')
    ranking_reports=sorted(folder.glob('ranking_*.json'),key=lambda p:p.stat().st_mtime,reverse=True)
    if not ranking_reports:
        st.info('No top-K simulation yet. Evaluate your existing checkpoints with the following command:')
        st.code(f'python -m temporal_fm.ranking --dataset {dataset} --backend sentence '
                '--models fm_all,deepfm_all --users 60 --k 10 --device cpu',language='bash')
    else:
        chosen_rank=st.selectbox('Recommendation report',ranking_reports,
                                 format_func=lambda p:p.name,key='temporal_ranking_report')
        try:rank_report=json.loads(chosen_rank.read_text(encoding='utf-8'))
        except (ValueError,OSError) as exc:
            st.error(f'Cannot read ranking report: {exc}');return
        k=rank_report['k']; policy=rank_report['candidate_policy']
        st.caption(f"{rank_report['split']} · {rank_report['evaluated_users']} users · K={k} · "
                   f"{policy} · positive threshold={rank_report['positive_threshold']} stars")
        if policy!='full_train_catalog':
            st.warning('Sampled-candidate evaluation includes all held-out positives. '
                       'Do NOT compare these scores with full-catalogue NDCG or Recall.')
        else:
            st.info('Full training-catalogue ranking with all previously rated movies excluded.')
        df=pd.DataFrame.from_dict(rank_report['metrics'],orient='index')
        if len(df):
            df.index.name='Model'
            primary=[m for m in ('ndcg_at_k','recall_at_k','hit_rate_at_k','mrr_at_k') if m in df]
            captions={'ndcg_at_k':f'NDCG@{k} (higher is better)',
                      'recall_at_k':f'Recall@{k} (higher is better)',
                      'hit_rate_at_k':f'Hit Rate@{k} (higher is better)',
                      'mrr_at_k':f'MRR@{k} (higher is better)'}
            for metric in primary:
                st.markdown('#### '+captions[metric])
                st.bar_chart(df[[metric]].sort_values(metric,ascending=False),use_container_width=True)
            st.dataframe(df.sort_values('ndcg_at_k',ascending=False),use_container_width=True)
            st.caption('Genre diversity is mean pairwise Jaccard distance; coverage is the share of '
                       'training-catalogue movies recommended across evaluated users. '
                       'Metrics compare only models in this report.')
        st.markdown('#### Example personalized movie recommendations')
        options=list(rank_report['examples'])
        if options:
            model_name=st.selectbox('Ranking model',options,key='temporal_ranking_model')
            examples=rank_report['examples'][model_name]
            user_options=list(examples)
            if user_options:
                uid=st.selectbox('User with held-out ratings',user_options,key='temporal_ranking_user')
                example=examples[uid]
                st.caption(f"Training history: {example['train_history_size']} ratings · "
                           f"Later eligible positive movies: {example['relevant_heldout_count']}")
                st.dataframe(pd.DataFrame(example['recommendations']),use_container_width=True,
                             hide_index=True)
                st.caption('Green/True in heldout_positive means the recommendation matches a later '
                           'rating of at least the positive threshold. The score is the model’s raw rating estimate.')
        with st.expander('How the recommendation benchmark works'):
            for c in rank_report.get('caveats',[]):st.write('• '+str(c))
            st.write('The popularity baseline counts ratings in the training split only.')
