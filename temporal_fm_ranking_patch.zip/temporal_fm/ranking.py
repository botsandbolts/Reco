"""Leakage-aware, frozen-checkpoint offline top-K simulation for Temporal FM.

Example:
  python -m temporal_fm.ranking --dataset ml-1m --backend sentence \
      --models fm_all,deepfm_all --users 60 --k 10 --device cpu

The evaluation moment for every recommendation is the TRAIN cutoff, not the
unknown future time at which a held-out rating will be submitted. Only movies
seen in training are eligible for collaborative ranking; previously rated
movies are excluded. Future positive ratings (>= threshold) provide relevance
labels; unobserved movies are not assumed to be genuine dislikes.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
import hashlib
from pathlib import Path
from collections import Counter

import numpy as np
import torch

from .data import Events
from .features import TagStore
from .model import TemporalFM
from .train import FeatureProvider, PROFILES


def _train_counts(ev, batch_size=400_000):
    """Streaming training-only user/movie counts, bounded intermediate memory."""
    ids = ev.split('train')
    users = Counter()
    movie_counts = np.zeros(len(ev.movies), dtype=np.int64)
    for start in range(0, len(ids), batch_size):
        chunk = np.asarray(ids[start:start+batch_size], dtype=np.int64)
        raw = np.asarray(ev.user_raw[chunk], dtype=np.int32)
        unique, counts = np.unique(raw, return_counts=True)
        users.update({int(u): int(n) for u,n in zip(unique, counts)})
        movie_counts += np.bincount(np.asarray(ev.movie_idx[chunk], dtype=np.int32),
                                    minlength=len(ev.movies))
    return users, movie_counts


def _cohort(ev, split, threshold, n_users, min_history, seed, user_filter=None):
    if split not in ('validation', 'test'):
        raise ValueError('Only held-out validation or test splits are supported')
    chosen = np.asarray(ev.split(split), dtype=np.int64)
    rating_positive = np.asarray(ev.rating[chosen] >= threshold, dtype=np.bool_)
    positives = chosen[rating_positive]
    if not len(positives):
        raise ValueError(f'No held-out ratings >= {threshold} in {split}')
    future_u = np.asarray(ev.user_raw[positives], dtype=np.int32)
    future_m = np.asarray(ev.movie_idx[positives], dtype=np.int32)
    known = np.asarray(ev.user_indices(future_u) > 0, dtype=bool)
    known &= ev.movie_has_train[future_m]
    future_u = future_u[known]
    future_m = future_m[known]
    raw_candidates = np.unique(future_u)
    users_count, movie_counts = _train_counts(ev)
    eligible = np.asarray([int(u) for u in raw_candidates if users_count.get(int(u), 0) >= min_history],
                          dtype=np.int32)
    if user_filter is not None:
        eligible = eligible[eligible == int(user_filter)]
        if len(eligible) != 1:
            raise ValueError(f'User {user_filter} has no eligible future positive rating or insufficient history')
    if not len(eligible):
        raise ValueError('No users with training history and eligible future relevant movies')
    rng = np.random.default_rng(seed)
    # Fixed cohort selection independent of model parameters and predictions.
    selected = np.sort(rng.choice(eligible, size=min(n_users, len(eligible)), replace=False))
    selected_set = set(map(int, selected))
    histories = {int(u): set() for u in selected}
    ids = ev.split('train')
    for start in range(0, len(ids), 500_000):
        chunk = np.asarray(ids[start:start+500_000], dtype=np.int64)
        raw = np.asarray(ev.user_raw[chunk], dtype=np.int32)
        yes = np.isin(raw, selected)
        for u, movie in zip(raw[yes], np.asarray(ev.movie_idx[chunk[yes]],dtype=np.int32)):
            histories[int(u)].add(int(movie))
    future = {int(u): set() for u in selected}
    yes = np.isin(future_u, selected)
    for u, movie in zip(future_u[yes], future_m[yes]):
        future[int(u)].add(int(movie))
    ground_truth = {u: future[u].difference(histories[u]) for u in histories}
    active = [u for u in map(int, selected) if ground_truth[u]]
    return active, histories, ground_truth, movie_counts, {
        'eligible_users': int(len(eligible)), 'selected_users': int(len(active)),
        'skipped_selected_without_unseen_positive': int(len(selected)-len(active)),
        'positive_event_count': int(len(positives)),
    }


def _candidates(catalog, history, positives, max_candidates, rng):
    eligible = np.setdiff1d(catalog, np.fromiter(history, dtype=np.int32), assume_unique=True)
    if max_candidates <= 0 or len(eligible) <= max_candidates:
        return eligible
    relevant = np.asarray(sorted(positives), dtype=np.int32)
    if len(relevant)>max_candidates:
        raise ValueError('max-candidates cannot be smaller than number of relevant held-out movies')
    other = np.setdiff1d(eligible, relevant, assume_unique=True)
    sample = rng.choice(other, size=max_candidates-len(relevant), replace=False)
    return np.sort(np.concatenate([relevant, sample]))


def _model(ev, provider, name, backend, device, profile=None, seed=None):
    root = Path('models') / ev.meta['dataset'] / 'temporal_fm' / name
    path=root/'weights.pt'; meta_path=root/'metadata.json'
    if not path.is_file() or not meta_path.is_file():
        raise FileNotFoundError(f'{name}: missing {path} or metadata; train the checkpoint first')
    meta=json.loads(meta_path.read_text(encoding='utf-8'))
    expected={'train_cutoff':ev.meta['train_cutoff'],'validation_cutoff':ev.meta['val_cutoff'],
              'text_backend':backend}
    for key, value in expected.items():
        if meta.get(key)!=value:
            raise ValueError(f'{name}: {key} in checkpoint does not match current data/evaluation')
    if profile is not None and meta.get('profile')!=profile:
        raise ValueError(f'{name}: checkpoint profile is {meta.get("profile")!r}, not {profile!r}')
    if seed is not None and meta.get('seed')!=seed:
        raise ValueError(f'{name}: checkpoint seed differs; supply matching --seed')
    if meta.get('text_model') != provider.model_name:
        raise ValueError(f'{name}: title model differs from requested feature configuration')
    if meta.get('sources') is not None and meta['sources'] != ev.meta['sources']:
        raise ValueError(f'{name}: training source files changed')
    # Train metadata flattens each file signature under ratings/movies/tags keys.
    for key, val in ev.meta['sources'].items():
        if meta.get(key)!=val:
            raise ValueError(f'{name}: original {key} data changed since training')
    if meta.get('tag_dims')!=provider.tags.tag_dims:
        raise ValueError(f'{name}: historical tag dimensions do not match')
    trained_profile=meta.get('profile')
    if trained_profile not in PROFILES:
        raise ValueError(f'{name}: unknown trained profile {trained_profile!r}')
    model=TemporalFM(len(ev.train_users),len(ev.movies),provider.title.shape[1],
                     len(ev.genres),provider.tags.tag_dims,k=PROFILES[trained_profile]['k'],
                     deep=meta['kind']=='deepfm',ablation=meta['ablation']).to(device)
    model.load_state_dict(torch.load(path,map_location=device,weights_only=True))
    model.eval()
    return model


def score_candidates(model, ev, provider, raw_user, candidate_movie_indices,
                     at_timestamp, device='cpu', batch_size=1024):
    """Score all eligible candidate films for a user as of one fixed timestamp."""
    candidates=np.asarray(candidate_movie_indices,dtype=np.int32)
    u_idx=int(ev.user_indices(np.array([raw_user],dtype=np.int32))[0])
    if u_idx==0:raise ValueError('User unseen at recommendation cutoff')
    scores=[]
    with torch.inference_mode():
        for start in range(0,len(candidates),batch_size):
            mids=candidates[start:start+batch_size]
            n=len(mids)
            stamps=np.full(n,at_timestamp,dtype=np.int64)
            ui=np.full(n,u_idx,dtype=np.int64)
            calendar,time_cont=ev.time_fields(ui,mids,stamps)
            fields={
                'user':ui,'item':ev.item_indices(mids),
                'title':np.asarray(provider.title[mids],dtype=np.float32),
                'genres':ev.genre_matrix[mids],
                'tags':provider.tags.lookup(mids,stamps),
                'calendar':calendar,'time':time_cont,
            }
            longs={'user','item','calendar'}
            batch={k:torch.as_tensor(np.asarray(v).copy(),
                                    dtype=torch.long if k in longs else torch.float32,
                                    device=device) for k,v in fields.items()}
            vals=model(batch).detach().cpu().numpy()
            if not np.isfinite(vals).all():
                raise ValueError('Non-finite model ranking scores')
            scores.append(vals)
    return np.concatenate(scores) if scores else np.empty(0,dtype=np.float32)


def _ranking_scores(top, positives, k, genre_matrix, popularity, n_train):
    top=list(map(int,top[:k]))
    matched=np.asarray([i in positives for i in top],dtype=np.int32)
    hits=int(matched.sum())
    ideal=min(k,len(positives))
    discounts=1/np.log2(np.arange(2,len(top)+2,dtype=np.float64))
    dcg=float((matched*discounts).sum())
    idcg=float(np.sum(1/np.log2(np.arange(2,ideal+2,dtype=np.float64))))
    precision=hits/max(1,k)
    recall=hits/len(positives)
    mrr=1.0/(np.flatnonzero(matched)[0]+1) if hits else 0.0
    ap=float(np.sum((np.cumsum(matched)/(np.arange(len(top))+1))*matched)/max(1,ideal))
    # Mean pairwise Jaccard genre distance, 0 if undefined (no shared or known genres).
    diversity_pairs=[]
    if len(top)>1:
        bits=genre_matrix[np.asarray(top,dtype=np.int32)] > 0
        for i in range(len(top)):
            for j in range(i+1,len(top)):
                union=np.logical_or(bits[i],bits[j]).sum()
                diversity_pairs.append(1-float(np.logical_and(bits[i],bits[j]).sum())/union if union else 0.0)
    novelty=float(np.mean([-math.log2((int(popularity[m])+1)/(n_train+len(popularity))) for m in top])) if top else 0.0
    return {'ndcg_at_k':dcg/idcg if idcg else 0.0,
            'recall_at_k':float(recall),'precision_at_k':float(precision),
            'hit_rate_at_k':float(hits>0),'mrr_at_k':float(mrr),'map_at_k':ap,
            'genre_diversity_at_k':float(np.mean(diversity_pairs)) if diversity_pairs else 0.0,
            'novelty_bits_at_k':novelty,'recommended_count':len(top)}


def evaluate(dataset='ml-1m',data_dir='data',models='fm_all,deepfm_all',backend='sentence',
             profile=None,split='validation',users=60,k=10,threshold=4.0,
             min_history=5,max_candidates=0,device='cpu',seed=42,
             batch_size=1024,example_users=5,user_id=None,threads=2):
    if k<1 or users<1 or min_history<0 or batch_size<1 or max_candidates<0:
        raise ValueError('K, users and batch size must be positive; history and max-candidates nonnegative')
    if not 0.5<=threshold<=5.0:raise ValueError('Threshold must be a MovieLens rating from 0.5 to 5')
    if split=='test':
        print('WARNING: Test evaluations should only be used once after model selection on validation.',flush=True)
    if device=='cuda' and not torch.cuda.is_available():raise ValueError('CUDA not available')
    torch.set_num_threads(max(1,threads))
    ev=Events(Path(data_dir)/'temporal'/dataset)
    title_meta=ev.folder/f'features_{backend}'/'meta.json'
    if not title_meta.is_file():
        raise FileNotFoundError(f'No {backend} title embeddings; train temporal FM first')
    backend_meta=json.loads(title_meta.read_text())
    tag_dir=ev.folder/f'features_{backend}'
    tag_dir=tag_dir if (tag_dir/'tag_keys.npy').exists() else None
    if bool(ev.meta['tags_path'])!=bool(tag_dir):
        raise ValueError('Tag history required by this dataset is missing')
    provider=FeatureProvider(ev,backend,backend_meta['model_name'],tag_dir)
    provider.model_name=backend_meta['model_name']
    active, histories, truths, popularity, cohort_stats=_cohort(
        ev,split,threshold,users,min_history,seed,user_filter=user_id)
    print(f'Eligible users: {cohort_stats["eligible_users"]}; evaluating {len(active)}',flush=True)
    catalog=np.flatnonzero(ev.movie_has_train).astype(np.int32)
    at_timestamp=int(ev.meta['train_cutoff'])+1
    rng=np.random.default_rng(seed+101)
    candidates_by_user={u:_candidates(catalog,histories[u],truths[u],max_candidates,rng) for u in active}
    n_train=int(ev.meta['splits']['train'])
    raw_model_names=([p.parent.name for p in sorted((Path('models')/dataset/'temporal_fm').glob('*/weights.pt'))]
                     if models=='all' else [s.strip() for s in models.split(',') if s.strip()])
    if not raw_model_names:raise ValueError('No models selected or trained')
    chosen_models={}
    for name in raw_model_names:
        try:chosen_models[name]=_model(ev,provider,name,backend,device,profile,seed)
        except FileNotFoundError as exc:print(f'Skipping unavailable model: {exc}',flush=True)
    if not chosen_models:raise FileNotFoundError('No compatible trained FM checkpoint found')
    out={'dataset':dataset,'task':'top-K offline recommendations','split':split,
         'k':k,'positive_threshold':threshold,'recommendation_timestamp':at_timestamp,
         'recommendation_context':'All recommendations made just after the GLOBAL training cutoff',
         'train_cutoff':ev.meta['train_cutoff'],'validation_cutoff':ev.meta['val_cutoff'],
         'candidate_policy':'full_train_catalog' if max_candidates==0 else f'sampled_{max_candidates}_with_all_positives',
         'max_candidates':max_candidates,'cohort':cohort_stats,'evaluated_users':len(active),
         'catalog_size':int(len(catalog)),'profile':profile,'backend':backend,'seed':seed,
         'metrics':{},'examples':{},
         'caveats':[
             'Relevant = future rating >= threshold; unobserved items are not established negatives.',
             'Only movies with training history are eligible; cold-start movies are excluded.',
             'Users are selected using a future-positive eligibility criterion, independent of model scores.',
             'Features and candidate eligibility are frozen at the global training cutoff.',
             'Model scores are unbounded predicted rating values, ranked without clipping.',
             'Genres and titles are treated as static metadata. Tags obey the train cutoff.',
             'Ratings represent submitted feedback, not necessarily viewing times.',
             'Sampled candidate pools contain all positives by construction. Metrics on sampled pools are NOT comparable with full-catalogue metrics.'
         ]}
    names=['popularity']+list(chosen_models)
    for model_name in names:
        model=chosen_models.get(model_name)
        values=[];unique=set();examples={}
        for ordinal,u in enumerate(active):
            candidates=candidates_by_user[u]
            if not len(candidates):continue
            scores=(np.log1p(popularity[candidates]).astype(np.float32) if model is None
                    else score_candidates(model,ev,provider,u,candidates,at_timestamp,device,batch_size))
            top_positions=np.argsort(-scores,kind='stable')[:k]
            top=candidates[top_positions]
            metric=_ranking_scores(top,truths[u],k,ev.genre_matrix,popularity,n_train)
            metric['candidate_count']=len(candidates)
            metric['positive_count']=len(truths[u])
            values.append(metric)
            unique.update(map(int,top))
            if ordinal<example_users:
                example_rows=[]
                for rank,(m,s) in enumerate(zip(top,scores[top_positions]),start=1):
                    movie=ev.movies.iloc[int(m)]
                    example_rows.append({'rank':rank,'movieId':int(movie['movieId']),
                                         'title':str(movie['title']),'genres':str(movie['genres']),
                                         'score':round(float(s),4),'heldout_positive':int(m) in truths[u]})
                examples[str(u)]={'train_history_size':len(histories[u]),
                                  'relevant_heldout_count':len(truths[u]),'recommendations':example_rows}
        if not values:continue
        summary={key:round(float(np.mean([row[key] for row in values])),6)
                 for key in ('ndcg_at_k','recall_at_k','precision_at_k','hit_rate_at_k',
                             'mrr_at_k','map_at_k','genre_diversity_at_k','novelty_bits_at_k',
                             'recommended_count','candidate_count','positive_count')}
        summary.update({'users':len(values),'catalog_coverage_at_k':round(len(unique)/len(catalog),6)})
        out['metrics'][model_name]=summary
        out['examples'][model_name]=examples
        print(f'{model_name:24} NDCG@{k}={summary["ndcg_at_k"]:.4f} '
              f'Recall@{k}={summary["recall_at_k"]:.4f} HR@{k}={summary["hit_rate_at_k"]:.4f}',flush=True)
    folder=Path('reports')/'temporal'/dataset;folder.mkdir(parents=True,exist_ok=True)
    label='full' if max_candidates==0 else f'sample{max_candidates}'
    config={'models':list(chosen_models),'users':active,'k':k,'threshold':threshold,
            'min_history':min_history,'max_candidates':max_candidates,'seed':seed,
            'split':split,'backend':backend,'user_id':user_id}
    fingerprint=hashlib.sha256(json.dumps(config,sort_keys=True).encode()).hexdigest()[:8]
    name=f'ranking_{split}_{backend}_{label}_k{k}_seed{seed}_{fingerprint}.json'
    path=folder/name
    path.write_text(json.dumps(out,indent=2),encoding='utf-8')
    with (folder/name.replace('.json','.csv')).open('w',newline='',encoding='utf-8') as handle:
        writer=csv.DictWriter(handle,fieldnames=['model']+list(next(iter(out['metrics'].values())).keys()))
        writer.writeheader()
        for model,metrics in out['metrics'].items():writer.writerow({'model':model,**metrics})
    print(f'Ranking report: {path}',flush=True)
    return out


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset',default='ml-1m')
    p.add_argument('--data-dir',default='data')
    p.add_argument('--models',default='fm_all,deepfm_all',help='Comma separated checkpoint names, or all')
    p.add_argument('--backend',choices=['sentence','hash'],default='sentence')
    p.add_argument('--profile',choices=sorted(PROFILES),default=None,help='Optional strict checkpoint profile check')
    p.add_argument('--split',choices=['validation','test'],default='validation')
    p.add_argument('--users',type=int,default=60)
    p.add_argument('--k',type=int,default=10)
    p.add_argument('--threshold',type=float,default=4.0)
    p.add_argument('--min-history',type=int,default=5)
    p.add_argument('--max-candidates',type=int,default=0,
                   help='0 = full training catalogue; >0 = sampled candidate evaluation (different metrics)')
    p.add_argument('--device',choices=['cpu','cuda'],default='cpu')
    p.add_argument('--seed',type=int,default=42)
    p.add_argument('--batch-size',type=int,default=1024)
    p.add_argument('--example-users',type=int,default=5)
    p.add_argument('--user-id',type=int,default=None)
    p.add_argument('--threads',type=int,default=2)
    evaluate(**vars(p.parse_args(argv)))

if __name__=='__main__':main()
