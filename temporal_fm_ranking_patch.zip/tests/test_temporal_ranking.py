from pathlib import Path
import json
import numpy as np
import pandas as pd
import pytest

from temporal_fm.data import prepare,Events
from temporal_fm.features import TagStore
from temporal_fm.train import run
from temporal_fm.ranking import _ranking_scores, _candidates, _cohort, evaluate, score_candidates, _model


def synthetic(tmp_path):
    folder=tmp_path/'raw'/'ml-latest-small'
    folder.mkdir(parents=True,exist_ok=True)
    catalog=pd.DataFrame({'movieId':np.arange(1,81),
                          'title':[f'Movie {i} ({1980+i%35})' for i in range(1,81)],
                          'genres':['Sci-Fi|Action' if i%2 else 'Drama|Comedy' for i in range(1,81)]})
    catalog.to_csv(folder/'movies.csv',index=False)
    rng=np.random.default_rng(7)
    rows=[]
    for i in range(750):
        u=i%20+1
        m=int(rng.integers(1,81))
        rows.append({'userId':u,'movieId':m,'rating':4.5 if i%3 else 2.0,
                     'timestamp':1_200_000_000+i*86400})
    pd.DataFrame(rows).to_csv(folder/'ratings.csv',index=False)
    pd.DataFrame({'movieId':[1,1,2,2],
                  'tag':['early','late','old','new'],
                  'timestamp':[1_200_000_000,1_200_000_000+730*86400,
                               1_200_000_000,1_200_000_000+720*86400]}).to_csv(folder/'tags.csv',index=False)
    return folder


def test_precision_ndcg_and_mrr():
    g=np.array([[1,0],[0,1],[1,0],[1,1]],dtype=np.float32)
    popularity=np.array([20,10,5,1])
    res=_ranking_scores([0,1,2],{1},3,g,popularity,100)
    assert res['ndcg_at_k']==pytest.approx(1/np.log2(3))
    assert res['recall_at_k']==1
    assert res['precision_at_k']==pytest.approx(1/3)
    assert res['hit_rate_at_k']==1
    assert res['mrr_at_k']==0.5
    assert res['map_at_k']==0.5
    assert 0<=res['genre_diversity_at_k']<=1
    empty=_ranking_scores([0,2],{1},2,g,popularity,100)
    assert empty['ndcg_at_k']==0 and empty['hit_rate_at_k']==0


def test_candidate_sampling_contains_all_positives_and_excludes_history():
    catalog=np.arange(100,dtype=np.int32)
    history={2,3,4};positives={5,6}
    full=_candidates(catalog,history,positives,0,np.random.default_rng(42))
    assert len(full)==97 and not set(full).intersection(history)
    sample=_candidates(catalog,history,positives,12,np.random.default_rng(42))
    assert len(sample)==12
    assert positives.issubset(set(sample))
    assert not set(sample).intersection(history)


def test_end_to_end_reuses_frozen_checkpoints_and_does_not_use_future_tags(tmp_path,monkeypatch):
    synthetic(tmp_path)
    monkeypatch.chdir(tmp_path)
    report=run(dataset='ml-latest-small',data_dir='data',profile='quick',text_backend='hash',
               models='fm',ablations='id,all',threads=1,
               ratings='raw/ml-latest-small/ratings.csv',movies='raw/ml-latest-small/movies.csv',
               tags='raw/ml-latest-small/tags.csv')
    root=Path('models/ml-latest-small/temporal_fm/fm_all/weights.pt')
    before=root.stat().st_mtime_ns
    result=evaluate(dataset='ml-latest-small',data_dir='data',models='fm_id,fm_all',backend='hash',
                    users=5,k=5,threshold=4,min_history=5,threads=1,example_users=3)
    assert root.stat().st_mtime_ns==before
    assert result['split']=='validation'
    assert result['evaluated_users']>0
    assert set(result['metrics'])=={'popularity','fm_id','fm_all'}
    assert result['candidate_policy']=='full_train_catalog'
    assert list(Path('reports/temporal/ml-latest-small').glob('ranking_validation_hash_full_k5_seed42_*.csv'))
    for name,scores in result['metrics'].items():
        assert 0<=scores['ndcg_at_k']<=1
        assert 0<=scores['recall_at_k']<=1
        assert 0<=scores['catalog_coverage_at_k']<=1
        assert 0<=scores['genre_diversity_at_k']<=1
        for u,example in result['examples'][name].items():
            assert example['train_history_size']>=5
            assert len(example['recommendations'])==5
    ev=Events('data/temporal/ml-latest-small')
    cohort,seen,relevant,pop,stats=_cohort(ev,'validation',4,5,5,42)
    uid=cohort[0]
    reported=[d['movieId'] for d in result['examples']['fm_all'][str(uid)]['recommendations']]
    raw_to_pos={int(v):j for j,v in enumerate(ev.movies.movieId)}
    assert not set(map(raw_to_pos.get,reported)).intersection(seen[uid])
    assert result['recommendation_timestamp']==ev.meta['train_cutoff']+1
    # Freeze the temporal context and tags at recommendation time, never at future feedback time.
    from temporal_fm.train import FeatureProvider
    folder=ev.folder/'features_hash'
    provider=FeatureProvider(ev,backend='hash',tag_dir=folder)
    provider.model_name='sentence-transformers/all-MiniLM-L6-v2'
    trained=_model(ev,provider,'fm_all','hash','cpu',seed=42)
    captured=[]
    original_lookup=provider.tags.lookup
    def capture_tags(movie_idx,timestamp):
        captured.extend(np.asarray(timestamp).tolist())
        return original_lookup(movie_idx,timestamp)
    provider.tags.lookup=capture_tags
    score_candidates(trained,ev,provider,uid,np.arange(7,dtype=np.int32),
                     ev.meta['train_cutoff']+1,batch_size=3)
    assert captured and set(captured)=={ev.meta['train_cutoff']+1}
    sampled=evaluate(dataset='ml-latest-small',data_dir='data',models='fm_all',backend='hash',
                     users=5,k=5,max_candidates=15,threads=1)
    assert sampled['candidate_policy']=='sampled_15_with_all_positives'
    assert 0<sampled['metrics']['fm_all']['candidate_count']<=15


def test_no_training_checkpoint_fails_clearly(tmp_path,monkeypatch):
    synthetic(tmp_path)
    monkeypatch.chdir(tmp_path)
    prepare('ml-latest-small',data_dir='data',
            ratings='raw/ml-latest-small/ratings.csv',movies='raw/ml-latest-small/movies.csv')
    with pytest.raises(FileNotFoundError):
        evaluate(dataset='ml-latest-small',data_dir='data',models='fm_all',backend='sentence')
