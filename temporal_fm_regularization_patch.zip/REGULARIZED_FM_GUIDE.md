# MovieLens 32M — Regularization for Temporal FM / DeepFM

This patch extends `temporal_fm.rank_train` from the **rating-aware pairwise patch**. It does not modify feature extraction, the pretrained sentence embeddings, chronological splits, or your ranking evaluator.

## Changes

- `--weight-decay` (default `1e-5`): configurable decoupled **AdamW** weight decay. It was already present and fixed at `1e-5`. AdamW's decay is **not mathematically the same** as adding an L2 term to an Adam loss.
- `--l2-factors` (default `0`): explicit L2 penalty on sampled user, positive-item, and negative-item embedding rows. Cost scales with minibatch rather than the whole 32M training matrix.
- `--l2-content` (default `0`): explicit L2 on active text/genre/tag/time projection **weight matrices**, excluding user/item biases and inactive ablation fields.
- `--l1-content` (default `0`): L1 on those active projection weight matrices; may encourage feature sparsity but isn't guaranteed to help dense sentence embeddings.
- Separately logged per epoch: `pairwise_loss`, `regularization_loss`, `training_loss` (their sum); the `bpr_loss` history field remains the ranking term only.
- All hyperparameters stored in checkpoint metadata; differing settings cannot accidentally reuse a checkpoint with the same name.
- No change to existing FM/DeepFM scoring or checkpoint loading. Existing checkpoints are left intact when you use new `--run-label` values.

The explicit L1/L2 matrix penalties use the **mean** square or absolute value per active projection matrix, then sum across those matrices. The factor L2 penalizes only sampled embeddings. Thus these regularization coefficients aren't identical to `torch.optim.Adam(weight_decay=...)` and cannot be compared numerically.

## Install from GitHub Codespaces

1. Download `temporal_fm_regularization_patch.zip` from ChatGPT and upload it to `herberton777/Reco` on the GitHub `main` branch (or directly to your Codespace).
2. Run:

```bash
cd /workspaces/Reco
git fetch origin main
git show origin/main:temporal_fm_regularization_patch.zip > temporal_fm_regularization_patch.zip
cp temporal_fm/rank_train.py temporal_fm/rank_train.before_regularization.py
unzip -o temporal_fm_regularization_patch.zip
python -m pytest -q tests/test_regularized_fm.py
python -m temporal_fm.rank_train --help | grep -E 'weight-decay|l1-content|l2-content|l2-factors'
```

If GitHub has not yet received the ZIP, `git show` fails; upload it to GitHub or the Codespace first. The patch should be applied on top of the **latest rating-aware FM patch**, which includes `temporal_fm/rating_pairs.py`.

## Experiment A: first test L2 against your champion

The champion (`fm_all_bpr`) remains frozen. Start from its weights (this is fine-tuning, not a from-scratch controlled comparison):

```bash
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 \
python -u -m temporal_fm.rank_train \
  --dataset ml-32m \
  --text-backend sentence \
  --models fm --ablation all --objective bpr \
  --profile research \
  --init-from fm_all_bpr \
  --run-label l2try \
  --weight-decay 0.05 \
  --l2-factors 0.005 \
  --l1-content 0 \
  --l2-content 0 \
  --epochs 10 --min-epochs 6 \
  --steps-per-epoch 800 --batch-size 256 \
  --lr 0.00015 --patience 4 \
  --positive-sampling permuted --negatives 2 \
  --validation-mode full --validation-users 100 \
  --validate-every 2 --device cpu --threads 2
```

Saves `models/ml-32m/temporal_fm/fm_all_l2try_bpr/`.

Be aware that regularization alone may not help the model that already beats popularity. The purpose is a controlled experiment. For a strict causal assessment use *separate runs with identical initialization/optimization budget*, e.g. fine-tune from the same frozen `fm_all_bpr` weights with `--run-label control` and `--weight-decay 0.00001 --l2-factors 0`, matching every other parameter in Experiment A. Without that control, any improvement could simply be additional training.

## Experiment B: try L1 only if L2 is promising

Use a distinct run label (`l1try`) and the same base checkpoint and training budget. Set `--weight-decay 0.00001 --l2-factors 0 --l1-content 0.001 --l2-content 0`. This targets semantic projections, not user/item identity embeddings.

For any new run label, do not use `--force-retrain` unless you intentionally want to replace that label's checkpoint.

## Evaluate all on the exact same user cohort

```bash
python -m temporal_fm.ranking \
  --dataset ml-32m --backend sentence \
  --models fm_all_bpr,fm_all_l2try_bpr \
  --users 300 --k 10 --threshold 4 \
  --max-candidates 0 --device cpu
```

The evaluator automatically includes popularity. Focus on **full-catalogue NDCG@10**, Recall@10 and Hit Rate@10; report confidence intervals across users where possible. The user sample must be identical across models. Avoid repeatedly tuning to the same test split; use validation for choosing hyperparameters and reserve test for final scoring.

## Important caveats

- **AdamW weight decay is not a classical L2 loss** under Adam; the patch adds explicit L2 penalties separately.
- We do **not** force dropout into your FM; DeepFM already has dropout.
- The only training change is how gradients are regularized. Sampled negatives, timestamps, history restrictions and user sampling are unchanged.
- If validation quality worsens while pairwise loss keeps falling, you may have loss/ranking mismatch, biased negatives, or feature issues; regularization isn't guaranteed to fix them.
- 32M-scale training is not executed as part of the local synthetic tests.
