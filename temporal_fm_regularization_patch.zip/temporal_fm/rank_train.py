"""Train FM/DeepFM with Bayesian Personalized Ranking on the MovieLens chronology.

Output checkpoints live in models/<dataset>/temporal_fm/{fm,deepfm}_all_bpr/
so pre-existing explicit rating regression checkpoints are never overwritten.

Example: python -m temporal_fm.rank_train --dataset ml-32m --profile research \
    --text-backend sentence --models fm --device cpu
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import re
from pathlib import Path
import time

import numpy as np
import torch
import torch.nn.functional as F

from .data import Events, prepare
from .features import titles, make_tag_history
from .model import TemporalFM
from .train import FeatureProvider
from .ranking import _cohort, _candidates, score_candidates
from .rating_pairs import load_or_build_low_history

RANK_PROFILES={
    'quick':{'epochs':2,'steps':12,'batch_size':32,'k':16,'lr':.002,'patience':2,
             'val_users':8,'val_candidates':128},
    'research':{'epochs':15,'steps':450,'batch_size':256,'k':32,'lr':.0008,'patience':4,
                'val_users':32,'val_candidates':512},
    'intensive':{'epochs':30,'steps':900,'batch_size':384,'k':64,'lr':.0004,'patience':6,
                'val_users':60,'val_candidates':1024},
    'serious':{'epochs':20,'steps':1600,'batch_size':256,'k':32,'lr':.00035,'patience':8,
               'val_users':32,'val_candidates':4096},
}



def regularization_penalty(model, positive, negative, *, l1_content=0.,
                           l2_content=0., l2_factors=0.):
    """Optional feature-group penalties, scaled by tensor mean (not catalogue size).

    Content L1/L2 apply only to the active content projection matrices, not
    user/movie identity embeddings or biases. Factor L2 applies to embeddings
    *sampled in this minibatch*, avoiding a dense scan of all user/movie rows.
    AdamW's separate weight_decay is decoupled, not equivalent to L2 under Adam.
    """
    penalty=positive['title'].new_zeros(())
    use_content=model.ablation in ('content','all_no_time','all')
    if use_content and (l1_content or l2_content):
        matrices=[model.title.weight,model.genre.weight]
        if model.ablation in ('all_no_time','all'):
            matrices.append(model.tags.weight)
        if model.ablation=='all':
            matrices.append(model.time_cont.weight)
        if l1_content:
            penalty=penalty+l1_content*sum(w.abs().mean() for w in matrices)
        if l2_content:
            penalty=penalty+l2_content*sum(w.square().mean() for w in matrices)
    if l2_factors:
        penalty=penalty+0.5*l2_factors*(
            model.user(positive['user']).square().mean()+
            model.movie(positive['item']).square().mean()+
            model.movie(negative['item']).square().mean())
    return penalty


class PositiveIndexSampler:
    """Sample positives without replacement across passes in O(batch) RAM.

    A randomized affine permutation visits each position once before restarting.
    Consecutive training epochs CONTINUE the pass, so an epoch need not load
    or shuffle all positive event IDs into memory. The mapping uses 64-bit
    integers; realistic MovieLens event counts remain safely below overflow.
    """
    def __init__(self, size, rng, method='permuted'):
        if size <= 0:
            raise ValueError('Empty positive training set')
        if method not in ('permuted', 'replacement'):
            raise ValueError('Use permuted or replacement positive sampling')
        self.size=int(size)
        self.rng=rng
        self.method=method
        self.cursor=0
        self.passes=0
        self.total=0
        self.a=1
        self.b=0
        if method=='permuted':
            self._new_pass()

    def _new_pass(self):
        n=self.size
        if n==1:
            self.a=1; self.b=0
        else:
            a=int(self.rng.integers(1,n))
            while math.gcd(a,n)!=1:
                a=(a+1)%n or 1
            self.a=a
            self.b=int(self.rng.integers(0,n))
        self.cursor=0
        self.passes+=1

    def draw(self, count):
        count=int(count)
        if count<1:raise ValueError('Batch size must be positive')
        if self.method=='replacement':
            self.total+=count
            return self.rng.integers(0,self.size,size=count,dtype=np.int64)
        result=np.empty(count,dtype=np.int64)
        written=0
        while written<count:
            if self.cursor==self.size:
                self._new_pass()
            step=min(count-written,self.size-self.cursor)
            indices=np.arange(self.cursor,self.cursor+step,dtype=np.int64)
            result[written:written+step]=(self.a*indices+self.b)%self.size
            self.cursor+=step
            written+=step
        self.total+=count
        return result


def _initialize_from_pairwise(model, ev, provider, name, kind, ablation, device):
    """Fine-tune a compatible ranking checkpoint; keep its source untouched."""
    if not re.fullmatch(r'[a-zA-Z0-9_]+_bpr',name):
        raise ValueError('The --init-from checkpoint must end in _bpr')
    folder=Path('models')/ev.meta['dataset']/'temporal_fm'/name
    meta_path=folder/'metadata.json'; weights=folder/'weights.pt'
    if not meta_path.exists() or not weights.exists():
        raise FileNotFoundError(f'Cannot fine-tune missing checkpoint {folder}')
    meta=json.loads(meta_path.read_text())
    checks={
        'sources':ev.meta['sources'],'train_cutoff':ev.meta['train_cutoff'],
        'validation_cutoff':ev.meta['val_cutoff'],
        'text_backend':provider.backend,'text_model':provider.model_name,
        'tag_dims':provider.tags.tag_dims,'kind':kind,'ablation':ablation,
        'objective':'bpr',
    }
    for key,expected in checks.items():
        if meta.get(key)!=expected:
            raise ValueError(f'{name}: incompatible checkpoint {key}')
    state=torch.load(weights,map_location='cpu',weights_only=True)
    try:
        model.load_state_dict(state,strict=True)
    except RuntimeError as ex:
        raise ValueError(f'{name}: incompatible latent size or architecture; '
                         'use the matching profile/latent-dim') from ex
    print(f'Fine-tuning from {weights} (new optimizer, existing weights)',flush=True)
    return str(weights)


def _build_train_lookup(ev, threshold: float):
    """On-disk sorted keys for known TRAIN ratings; bounded memory, reusable.

    Duplicates are harmless. NEVER incorporate validation/test events into this lookup.
    """
    out=ev.folder/'rank_train_index'
    out.mkdir(parents=True,exist_ok=True)
    digest=hashlib.sha256(json.dumps({'sources':ev.meta['sources'],
           'train_cutoff':ev.meta['train_cutoff'],'threshold':threshold},sort_keys=True).encode()).hexdigest()[:14]
    keys_path=out/f'known_{digest}.npy'
    pos_path=out/f'positives_{digest}.npy'
    if keys_path.exists() and pos_path.exists():
        return np.load(keys_path,mmap_mode='r'),np.load(pos_path,mmap_mode='r')
    ids=ev.split('train')
    keys=np.lib.format.open_memmap(keys_path,mode='w+',dtype=np.int64,shape=(len(ids),))
    chunks=[]; n_items=len(ev.movies)
    for start in range(0,len(ids),200_000):
        ev_idx=np.asarray(ids[start:start+200_000],dtype=np.int64)
        user=ev.user_indices(np.asarray(ev.user_raw[ev_idx],dtype=np.int32))
        if np.any(user==0):raise ValueError('Training user missing from train_users table')
        movie=np.asarray(ev.movie_idx[ev_idx],dtype=np.int64)
        keys[start:start+len(ev_idx)]=user*n_items+movie
        rating=np.asarray(ev.rating[ev_idx],dtype=np.float32)
        good=ev_idx[rating>=threshold]
        if len(good):chunks.append(good)
    keys.flush()
    keys.sort(kind='quicksort')
    keys.flush()
    positives=np.concatenate(chunks).astype(np.int32)
    if not len(positives):raise ValueError('No positive training ratings at this threshold')
    np.save(pos_path,positives)
    return np.load(keys_path,mmap_mode='r'),np.load(pos_path,mmap_mode='r')


def _draw_unrated(rng, users, known, catalog, n_items, bank, movie_years,
                  timestamps, negative_pop_share=.6, max_retries=200):
    """Reject every user/movie pair observed in TRAIN and future-release movies."""
    users=np.asarray(users,dtype=np.int64)
    ts_year=np.asarray(timestamps,dtype='datetime64[s]').astype('datetime64[Y]').astype(np.int32)+1970
    result=np.empty(len(users),dtype=np.int32)
    pending=np.arange(len(users))
    for _ in range(max_retries):
        n=len(pending)
        pop=(rng.random(n)<negative_pop_share)
        sampled=rng.choice(catalog,size=n).astype(np.int32)
        if pop.any():sampled[pop]=bank[rng.integers(0,len(bank),size=int(pop.sum()))]
        query=users[pending]*n_items+sampled.astype(np.int64)
        at=np.searchsorted(known,query)
        observed=np.zeros(n,dtype=bool)
        valid=at<len(known)
        observed[valid]=known[at[valid]]==query[valid]
        future=(movie_years[sampled]>ts_year[pending]) & (movie_years[sampled]>0)
        bad=observed|future
        result[pending[~bad]]=sampled[~bad]
        pending=pending[bad]
        if not len(pending):return result
    raise ValueError('Negative sampling exhausted; user may have rated nearly all eligible movies')


def _batch_for_movies(ev,provider,user_idx,movies,timestamps,device):
    """Positive and negative inputs share EXACT event time; no future tag leakage."""
    ui=np.asarray(user_idx,dtype=np.int64)
    mi=np.asarray(movies,dtype=np.int32)
    ts=np.asarray(timestamps,dtype=np.int64)
    cal,continuous=ev.time_fields(ui,mi,ts)
    fields={
       'user':ui,'item':ev.item_indices(mi),
       'title':np.asarray(provider.title[mi],dtype=np.float32),
       'genres':ev.genre_matrix[mi],
       'tags':provider.tags.lookup(mi,ts),
       'calendar':cal,'time':continuous,
    }
    return {k:torch.as_tensor(np.asarray(v).copy(),dtype=torch.long if k in
                 ('user','item','calendar') else torch.float32,device=device)
            for k,v in fields.items()}


def _positive_counts(ev,threshold):
    counts=np.zeros(len(ev.movies),dtype=np.int64)
    for start in range(0,len(ev.split('train')),300_000):
        idx=np.asarray(ev.split('train')[start:start+300_000],dtype=np.int64)
        pos=idx[np.asarray(ev.rating[idx]>=threshold)]
        counts+=np.bincount(np.asarray(ev.movie_idx[pos],dtype=np.int32),minlength=len(counts))
    return counts


def _fixed_validation(ev,threshold,num_users,num_candidates,seed,min_history=3):
    active,histories,truth,_,summary=_cohort(ev,'validation',threshold,num_users,min_history,seed)
    catalog=np.flatnonzero(ev.movie_has_train).astype(np.int32)
    rng=np.random.default_rng(seed+221)
    samples=[]
    for u in active:
        cand=_candidates(catalog,histories[u],truth[u],num_candidates,rng)
        samples.append((u,cand,truth[u]))
    if not samples:raise ValueError('No validation users with eligible held-out positives')
    return samples,summary


def _sampled_ndcg(model,ev,provider,samples,k,device,cutoff):
    model.eval()
    values=[]
    for user,candidates,positives in samples:
        scores=score_candidates(model,ev,provider,user,candidates,cutoff,device,batch_size=2048)
        top=candidates[np.argsort(-scores,kind='stable')[:k]]
        matches=np.array([m in positives for m in top],dtype=np.float64)
        ideal=min(k,len(positives))
        denom=np.sum(1/np.log2(np.arange(2,ideal+2)))
        dcg=np.sum(matches/np.log2(np.arange(2,len(top)+2)))
        values.append(float(dcg/max(denom,1e-12)))
    return float(np.mean(values))


def _try_warm_start(model,ev,provider,kind,ablation,profile,enabled):
    if not enabled:return None
    name=f'{kind}_{ablation}'
    folder=Path('models')/ev.meta['dataset']/'temporal_fm'/name
    meta=folder/'metadata.json'; weights=folder/'weights.pt'
    if not meta.exists() or not weights.exists():
        print(f'{name}: regression checkpoint absent; training ranking model from scratch',flush=True)
        return None
    settings=json.loads(meta.read_text())
    valid=(all(settings.get(k)==v for k,v in ev.meta['sources'].items()) and
           settings.get('train_cutoff')==ev.meta['train_cutoff'] and
           settings.get('text_backend')==provider.backend and
           settings.get('text_model')==provider.model_name and
           settings.get('tag_dims')==provider.tags.tag_dims and
           settings.get('ablation')==ablation and settings.get('kind')==kind and
           settings.get('profile')==profile)
    if not valid:
        print(f'{name}: regression checkpoint differs in configuration; training from scratch',flush=True)
        return None
    try:model.load_state_dict(torch.load(weights,map_location='cpu',weights_only=True))
    except RuntimeError:
        print(f'{name}: regression checkpoint architecture differs; training from scratch',flush=True)
        return None
    print(f'Warm-started BPR from frozen {weights}',flush=True)
    return str(weights)


def train(dataset='ml-32m',data_dir='data',ratings=None,movies=None,tags=None,
          profile='research',text_backend='sentence',
          text_model='sentence-transformers/all-MiniLM-L6-v2',models='fm',
          ablation='all',positive_threshold=4.,negatives=2,pop_negative_share=.6,
          warm_start=False,force_retrain=False,device='cpu',seed=42,threads=2,
          max_tag_vocab=20000,tag_dims=48,validation_users=None,validation_candidates=None,
          epochs=None,steps_per_epoch=None,batch_size=None,lr=None,patience=None,
          min_epochs=1,validation_mode='sampled',validate_every=1,
          positive_sampling='permuted',run_label='',init_from=None,latent_dim=None,
          full_pass_epochs=False, objective='bpr', low_rating_max=3.5,
          observed_pair_weight=0.7, positive_rating_weight=0.25,
          weight_decay=1e-5, l1_content=0., l2_content=0., l2_factors=0.):
    if profile not in RANK_PROFILES:raise ValueError(f'Unknown profile {profile}')
    if objective not in ('bpr','rating_aware'):raise ValueError('Unknown ranking objective')
    if not 0.5 <= low_rating_max < positive_threshold <= 5.0:
        raise ValueError('Require 0.5 <= low-rating-max < positive-threshold <= 5')
    if observed_pair_weight < 0 or positive_rating_weight < 0:
        raise ValueError('Loss weights must be nonnegative')
    for key,value in [('weight_decay',weight_decay),('l1_content',l1_content),
                      ('l2_content',l2_content),('l2_factors',l2_factors)]:
        if not math.isfinite(value) or value < 0:
            raise ValueError(f'{key} must be finite and nonnegative')
    if ablation not in ('id','content','all_no_time','all'):raise ValueError('Unknown ablation')
    if negatives<1 or not(0<=pop_negative_share<=1):raise ValueError('Bad negative sampling arguments')
    if device=='cuda' and not torch.cuda.is_available():raise ValueError('CUDA not available')
    kinds=[v.strip() for v in models.split(',') if v.strip()]
    if not kinds or any(x not in ('fm','deepfm') for x in kinds):raise ValueError('Use --models fm,deepfm')
    np.random.seed(seed);torch.manual_seed(seed);torch.set_num_threads(threads)
    cfg=dict(RANK_PROFILES[profile])
    for key,value in (('epochs',epochs),('steps',steps_per_epoch),
                      ('batch_size',batch_size),('lr',lr),('patience',patience),('k',latent_dim)):
        if value is not None:cfg[key]=value
    if (cfg['epochs']<1 or cfg['steps']<1 or cfg['batch_size']<1 or
        cfg['patience']<1 or cfg['k']<1 or cfg['lr']<=0):
        raise ValueError('Epochs, steps, batch, patience, latent dim and learning rate must be positive')
    if not (1<=min_epochs<=cfg['epochs']):
        raise ValueError('min-epochs must be in range [1,epochs]')
    if validate_every<1:raise ValueError('validate-every must be >= 1')
    if full_pass_epochs and steps_per_epoch is not None:
        raise ValueError('Choose either --full-pass-epochs or --steps-per-epoch')
    if full_pass_epochs and positive_sampling!='permuted':
        raise ValueError('Full-pass epochs require --positive-sampling permuted')
    if validation_mode not in ('sampled','full'):
        raise ValueError('validation-mode must be sampled or full')
    if run_label and not re.fullmatch(r'[a-zA-Z0-9_]+',run_label):
        raise ValueError('run-label may only contain letters, digits and underscores')
    ev=Events(prepare(dataset,data_dir,ratings,movies,tags,seed=seed))
    titles(ev,text_backend,text_model)
    tag_dir=(make_tag_history(ev,ev.meta['tags_path'],text_backend,text_model,
                               tag_dims,max_tag_vocab) if ev.meta['tags_path'] else None)
    provider=FeatureProvider(ev,text_backend,text_model,tag_dir)
    provider.backend=text_backend
    provider.model_name=text_model
    known,positives=_build_train_lookup(ev,positive_threshold)
    low_history=(load_or_build_low_history(ev,low_rating_max)
                 if objective=='rating_aware' and observed_pair_weight>0 else None)
    if low_history is not None:
        print(f'RATING AWARE: {len(low_history.timestamps):,} TRAIN low-rating events '
              f'(<= {low_rating_max} stars); historical comparisons only',flush=True)
    if full_pass_epochs:
        cfg['steps']=math.ceil(len(positives)/cfg['batch_size'])
    catalog=np.flatnonzero(ev.movie_has_train).astype(np.int32)
    counts=_positive_counts(ev,positive_threshold)
    probs=(counts[catalog].astype(np.float64)+1)**.75
    probs/=probs.sum()
    rng_bank=np.random.default_rng(seed+317)
    bank=rng_bank.choice(catalog,size=250_000,replace=True,p=probs).astype(np.int32)
    effective_candidates = (0 if validation_mode=='full' else
        (validation_candidates if validation_candidates is not None else cfg['val_candidates']))
    samples,cohort=_fixed_validation(ev,positive_threshold,
                         validation_users or cfg['val_users'],
                         effective_candidates,seed)
    print(f'TRAIN: {len(known):,} ratings, {len(positives):,} positive events; '
          f'{cfg["epochs"]} epochs x {cfg["steps"]} steps x {cfg["batch_size"]} positives '
          f'= {cfg["epochs"]*cfg["steps"]*cfg["batch_size"]:,} max positive draws, '
          f'{positive_sampling} sampler',flush=True)
    print(f'VALIDATION: {len(samples)} users, '
          f'{"full warm catalogue" if validation_mode=="full" else str(effective_candidates)+" sampled candidates"} '
          f'every {validate_every} epoch(s); minimum {min_epochs} epochs',flush=True)
    run_reports={}
    out=Path('models')/dataset/'temporal_fm'
    out.mkdir(parents=True,exist_ok=True)
    for kind in kinds:
        label=run_label or ('rating' if objective=='rating_aware' else '')
        name=f'{kind}_{ablation}_{label}_bpr' if label else f'{kind}_{ablation}_bpr' 
        folder=out/name;folder.mkdir(parents=True,exist_ok=True)
        metadata={
           'objective':('rating_aware_bpr' if objective=='rating_aware' else 'bpr'),
           'rank_version':2 if objective=='rating_aware' else 1,
           'name':name,'kind':kind,'ablation':ablation,
           'profile':profile,'k':cfg['k'],'positive_threshold':positive_threshold,
           'effective_training_config':{key:cfg[key] for key in ('epochs','steps','batch_size','k','lr','patience')},
           'min_epochs':min_epochs,'validate_every':validate_every,
           'validation_mode':validation_mode,'positive_sampling':positive_sampling,
           'run_label':run_label,'init_from':init_from,
           'full_pass_epochs':full_pass_epochs,
           'negatives':negatives,'pop_negative_share':pop_negative_share,
           'low_rating_max':low_rating_max if objective=='rating_aware' else None,
           'observed_pair_weight':observed_pair_weight if objective=='rating_aware' else None,
           'positive_rating_weight':positive_rating_weight if objective=='rating_aware' else None,
           'regularization':{'adamw_weight_decay':weight_decay,
                             'l1_content':l1_content,
                             'l2_content':l2_content,
                             'l2_factors':l2_factors},
           'sources':ev.meta['sources'],'train_cutoff':ev.meta['train_cutoff'],
           'validation_cutoff':ev.meta['val_cutoff'],'text_backend':text_backend,
           'text_model':text_model,'tag_dims':provider.tags.tag_dims,
           'max_tag_vocab':max_tag_vocab,'seed':seed,'dataset':dataset,
           'validation_users_requested':validation_users or cfg['val_users'],
           'validation_candidates_requested':effective_candidates,
           'warm_start_requested':bool(warm_start),
        }
        check=folder/'metadata.json';weights=folder/'weights.pt'
        if weights.exists() and not force_retrain:
            if not check.exists() or json.loads(check.read_text()) != metadata:
                raise ValueError(f'{name}: incompatible checkpoint already exists; rename it or use --force-retrain')
            print(f'Reusing frozen ranking model {name}; use --force-retrain to retrain',flush=True)
            run_reports[name]={'reused':True,'checkpoint':str(weights)}
            continue
        model=TemporalFM(len(ev.train_users),len(ev.movies),provider.title.shape[1],
                 len(ev.genres),provider.tags.tag_dims,k=cfg['k'],deep=kind=='deepfm',
                 mean_rating=0.0,ablation=ablation).to(device)
        if init_from:
            _initialize_from_pairwise(model,ev,provider,init_from,kind,ablation,device)
        else:
            _try_warm_start(model,ev,provider,kind,ablation,profile,warm_start)
        optimizer=torch.optim.AdamW(model.parameters(),lr=cfg['lr'],weight_decay=weight_decay)
        scheduler=torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer,mode='max',factor=.5,patience=2)
        best=-1.;bad=0;history=[]
        generator=np.random.default_rng(seed)
        explicit_pairs_seen=0
        sampler=PositiveIndexSampler(len(positives),generator,positive_sampling)
        for epoch in range(cfg['epochs']):
            model.train();loss_total=0.;ranking_loss_total=0.;regularization_total=0.;observed_pairs_epoch=0;start=time.perf_counter()
            for step in range(cfg['steps']):
                idx=np.asarray(positives[sampler.draw(cfg['batch_size'])],dtype=np.int64)
                ui=ev.user_indices(np.asarray(ev.user_raw[idx],dtype=np.int32))
                mids=np.asarray(ev.movie_idx[idx],dtype=np.int32)
                stamps=np.asarray(ev.timestamp[idx],dtype=np.int64)
                neg_ui=np.repeat(ui,negatives)
                neg_ts=np.repeat(stamps,negatives)
                neg_movies=_draw_unrated(generator,neg_ui,known,catalog,len(ev.movies),bank,
                               ev.release_year,neg_ts,pop_negative_share)
                positive=_batch_for_movies(ev,provider,ui,mids,stamps,device)
                negative=_batch_for_movies(ev,provider,neg_ui,neg_movies,neg_ts,device)
                p=model(positive)
                n=model(negative).reshape(len(idx),negatives)
                if objective=='rating_aware':
                    anchor_ratings=np.asarray(ev.rating[idx],dtype=np.float32)
                    # Stronger observed preference => stronger positive-to-unrated signal.
                    positive_importance=1.0+positive_rating_weight*np.maximum(
                        0., anchor_ratings-positive_threshold)
                    rating_weights=torch.as_tensor(positive_importance,dtype=p.dtype,device=device)
                    base=F.softplus(n-p[:,None]).mean(dim=1)
                    loss=(base*rating_weights).sum()/rating_weights.sum().clamp_min(1e-6)
                    if low_history is not None:
                        low_movies,gaps,valid=low_history.draw(
                            generator,ui,mids,stamps,anchor_ratings)
                        observed=int(valid.sum())
                        if observed:
                            low_batch=_batch_for_movies(
                                ev,provider,ui[valid],low_movies[valid],stamps[valid],device)
                            rated_negative=model(low_batch)
                            # Gap weighting emphasizes e.g. 5 vs 1 over 4 vs 3.5.
                            gap_weights=torch.as_tensor(np.clip(gaps[valid]/2.,0.5,2.0),
                                        dtype=p.dtype,device=device)
                            valid_tensor=torch.as_tensor(valid,dtype=torch.bool,device=device)
                            explicit=F.softplus(rated_negative-p[valid_tensor])
                            loss=loss+observed_pair_weight*(explicit*gap_weights).sum()/gap_weights.sum().clamp_min(1e-6)
                            observed_pairs_epoch+=observed
                            explicit_pairs_seen+=observed
                else:
                    loss=F.softplus(n-p[:,None]).mean()
                if not torch.isfinite(loss):raise FloatingPointError('Nonfinite pairwise loss')
                # Keep these values separate: a decreasing TOTAL loss does not
                # imply ranking quality is improving.
                ranking_loss_total+=float(loss.detach())
                reg=regularization_penalty(model,positive,negative,
                     l1_content=l1_content,l2_content=l2_content,
                     l2_factors=l2_factors)
                if not torch.isfinite(reg):raise FloatingPointError('Nonfinite regularization penalty')
                loss=loss+reg
                optimizer.zero_grad(set_to_none=True);loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(),max_norm=1.0)
                optimizer.step()
                regularization_total+=float(reg.detach())
                loss_total+=float(loss.detach())
            record={'epoch':epoch+1,'training_loss':round(loss_total/cfg['steps'],6),
                    'pairwise_loss':round(ranking_loss_total/cfg['steps'],6),
                    'regularization_loss':round(regularization_total/cfg['steps'],6),
                    'observed_preference_pairs':observed_pairs_epoch,
                    'positive_draws':sampler.total,
                    'positive_pools_completed':(sampler.total//len(positives) if positive_sampling=='permuted' else None),
                    'lr':optimizer.param_groups[0]['lr'],
                    'epoch_seconds':round(time.perf_counter()-start,2)}
            should_validate=((epoch+1)%validate_every==0 or epoch+1==cfg['epochs'])
            if should_validate:
                score=_sampled_ndcg(model,ev,provider,samples,10,device,
                                     int(ev.meta['train_cutoff']))
                scheduler.step(score)
                record['validation_ndcg_at_10']=round(score,6)
                record['validation_mode']=validation_mode
                if validation_mode=='sampled':
                    record['sampled_validation_ndcg_at_10']=round(score,6)
                print(f'{name}: epoch {epoch+1}/{cfg["epochs"]}: '
                      f'loss={record["training_loss"]:.4f} (rank={record["pairwise_loss"]:.4f}, '
                      f'reg={record["regularization_loss"]:.5f}), observed_pairs={observed_pairs_epoch:,}, '
                      f'{validation_mode}-val NDCG@10={score:.4f}, '
                      f'positive draws={sampler.total:,}',flush=True)
                if score>best+1e-6 or not weights.exists():
                    best=score;bad=0
                    torch.save(model.state_dict(),weights)
                    check.write_text(json.dumps(metadata,indent=2))
                else:
                    bad+=1
            else:
                print(f'{name}: epoch {epoch+1}/{cfg["epochs"]}: '
                      f'loss={record["training_loss"]:.4f} (rank={record["pairwise_loss"]:.4f}, '
                      f'reg={record["regularization_loss"]:.5f}), observed_pairs={observed_pairs_epoch:,}, '
                      f'positive draws={sampler.total:,} (no validation)',flush=True)
            if objective=='bpr':record['bpr_loss']=record['pairwise_loss']
            history.append(record)
            (folder/'history.json').write_text(json.dumps(history,indent=2))
            if should_validate and epoch+1>=min_epochs and bad>=cfg['patience']:
                print(f'{name}: stopping after {epoch+1} epochs '
                      f'({bad} validation checks without improvement)',flush=True)
                break
        run_reports[name]={'reused':False,'checkpoint':str(weights),
                           'best_validation_ndcg_at_10':best,
                           'validation_mode':validation_mode,
                           'best_sampled_validation_ndcg_at_10':best if validation_mode=='sampled' else None,
                           'positive_draws':sampler.total,'train_positive_count':len(positives),
                           'historical_observed_pairs':explicit_pairs_seen,
                           'positive_passes_completed':sampler.total//len(positives) if positive_sampling=='permuted' else None,
                           'history':history}
    report={'dataset':dataset,
        'objective': ('rating-aware BPR: weighted positive-unobserved + strictly historical observed rated pairs'
                      if objective=='rating_aware' else 'BPR pairwise softplus(score_negative - score_positive)'),
        'split_policy':'Train positives only; user unrated negatives sampled from warm TRAIN catalogue',
        'positive_threshold':positive_threshold,'profile':profile,'models':run_reports,
        'low_rating_max':low_rating_max if objective=='rating_aware' else None,
        'observed_pair_weight':observed_pair_weight if objective=='rating_aware' else None,
        'train_positive_events':len(positives),'train_known_rating_events':len(known),
        'candidate_catalogue_size':len(catalog),'validation_cohort':cohort,
        'validation_policy':('full warm-training catalogue' if validation_mode=='full' else
                             'FIXED SAMPLED candidate pools; sampled NDCG is not full-catalogue NDCG'),
        'positive_sampling':positive_sampling,'full_pass_epochs':full_pass_epochs,
        'effective_training_config':cfg,
        'regularization':{'adamw_weight_decay':weight_decay,
                          'l1_content':l1_content,'l2_content':l2_content,
                          'l2_factors':l2_factors},
        'min_epochs':min_epochs,'validate_every':validate_every,
        'time_policy':'Positive and negative features queried at SAME training positive event timestamp',
        'caveats':['Unobserved items are not guaranteed dislikes; offline recommendation data has exposure bias.',
                   'Tune using validation only; reserve the test split for the final selected configuration.',
                   'Full-catalogue scores must be computed with temporal_fm.shared_benchmark, not training validation scores.']}
    report_label=f'_{run_label or ("rating" if objective=="rating_aware" else "")}' if (run_label or objective=='rating_aware') else '' 
    target=Path('reports')/'temporal'/dataset/f'pairwise_training_{profile}_{text_backend}{report_label}_seed{seed}.json'
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(json.dumps(report,indent=2))
    print(f'Saved pairwise training report: {target}',flush=True)
    return report


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset',default='ml-32m')
    p.add_argument('--data-dir',default='data')
    for key in ('ratings','movies','tags'):p.add_argument('--'+key)
    p.add_argument('--profile',choices=list(RANK_PROFILES),default='research')
    p.add_argument('--text-backend',choices=['sentence','hash'],default='sentence')
    p.add_argument('--text-model',default='sentence-transformers/all-MiniLM-L6-v2')
    p.add_argument('--models',default='fm')
    p.add_argument('--ablation',choices=['id','content','all_no_time','all'],default='all')
    p.add_argument('--positive-threshold',type=float,default=4.)
    p.add_argument('--objective',choices=['bpr','rating_aware'],default='bpr')
    p.add_argument('--low-rating-max',type=float,default=3.5,
                   help='Previously observed ratings at or below this are explicit negatives')
    p.add_argument('--observed-pair-weight',type=float,default=.7,
                   help='Mix-in weight for high vs previously low rated movie pairs')
    p.add_argument('--positive-rating-weight',type=float,default=.25,
                   help='Extra weight given to 5 vs 4 star positives when ranking against unrated')
    p.add_argument('--weight-decay',type=float,default=1e-5,
                   help='Decoupled AdamW weight decay (existing default 1e-5)')
    p.add_argument('--l1-content',type=float,default=0.,
                   help='L1 penalty on ACTIVE title/genre/tag/time projection weights')
    p.add_argument('--l2-content',type=float,default=0.,
                   help='Explicit L2 penalty on ACTIVE content projection weights')
    p.add_argument('--l2-factors',type=float,default=0.,
                   help='Explicit minibatch L2 on sampled user/movie factor embeddings')
    p.add_argument('--negatives',type=int,default=2)
    p.add_argument('--pop-negative-share',type=float,default=.6)
    p.add_argument('--warm-start',action='store_true')
    p.add_argument('--force-retrain',action='store_true')
    p.add_argument('--device',choices=['cpu','cuda'],default='cpu')
    p.add_argument('--seed',type=int,default=42)
    p.add_argument('--threads',type=int,default=2)
    p.add_argument('--max-tag-vocab',type=int,default=20000)
    p.add_argument('--tag-dims',type=int,default=48)
    p.add_argument('--epochs',type=int)
    p.add_argument('--steps-per-epoch',type=int)
    p.add_argument('--batch-size',type=int)
    p.add_argument('--lr',type=float)
    p.add_argument('--patience',type=int)
    p.add_argument('--min-epochs',type=int,default=1)
    p.add_argument('--validate-every',type=int,default=1)
    p.add_argument('--validation-mode',choices=['sampled','full'],default='sampled')
    p.add_argument('--positive-sampling',choices=['permuted','replacement'],default='permuted')
    p.add_argument('--full-pass-epochs',action='store_true',
                   help='Each epoch visits all positive TRAIN ratings once; can be very expensive on 32M')
    p.add_argument('--latent-dim',type=int,default=None)
    p.add_argument('--run-label',default='',help='Create a separate checkpoint named fm_all_<label>_bpr')
    p.add_argument('--init-from',default=None,help='Fine-tune a compatible existing *_bpr checkpoint')
    p.add_argument('--validation-users',type=int,default=None)
    p.add_argument('--validation-candidates',type=int,default=None)
    train(**vars(p.parse_args(argv)))

if __name__=='__main__':main()
