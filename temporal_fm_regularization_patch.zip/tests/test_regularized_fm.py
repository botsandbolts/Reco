"""Tests for opt-in L1/L2 and decoupled weight decay in ranking trainer."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import pytest
import torch
from temporal_fm.model import TemporalFM
from temporal_fm.rank_train import regularization_penalty, train


def _batch(n=5, title=8, genres=4, tags=6):
    return {'user':torch.tensor([1,2,3,1,2]),
            'item':torch.tensor([1,2,3,4,5]),
            'title':torch.randn(n,title),'genres':torch.randn(n,genres),
            'tags':torch.randn(n,tags), 'calendar':torch.zeros(n,dtype=torch.long),
            'time':torch.zeros(n,4)}


def test_l1_l2_content_penalize_active_fields_and_have_gradients():
    torch.manual_seed(4)
    model=TemporalFM(8,12,8,4,6,k=8,mean_rating=0.,ablation='all')
    p=_batch();q=_batch()
    reg=regularization_penalty(model,p,q,l1_content=.001,l2_content=.002,l2_factors=.003)
    assert reg.item()>0
    reg.backward()
    for name in ('user','movie','title','genre','tags','time_cont'):
        assert getattr(model,name).weight.grad is not None, name
    # Embedding biases are not directly penalized by L1/L2.
    assert model.user_bias.weight.grad is None
    assert model.movie_bias.weight.grad is None
    assert model.title_bias.weight.grad is None
    assert regularization_penalty(model,p,q).item()==0
    id_model=TemporalFM(8,12,8,4,6,k=8,mean_rating=0.,ablation='id')
    assert regularization_penalty(id_model,p,q,l1_content=1,l2_content=1).item()==0
    expected=(id_model.user(p['user']).square().mean()+
              id_model.movie(p['item']).square().mean()+
              id_model.movie(q['item']).square().mean())*.5
    actual=regularization_penalty(id_model,p,q,l2_factors=1)
    assert torch.allclose(actual,expected)


def _seed(tmp):
    d=tmp/'data/raw/ml-latest-small';d.mkdir(parents=True)
    rng=np.random.default_rng(761)
    pd.DataFrame({'movieId':np.arange(1,41),'title':[f'Movie {i} (1995)' for i in range(1,41)],
                  'genres':['Action|Comedy' if i%2 else 'Drama|Sci-Fi' for i in range(40)]}).to_csv(d/'movies.csv',index=False)
    n=1300
    t=1_100_000_000+np.arange(n,dtype=np.int64)*4000
    pd.DataFrame({'userId':rng.integers(1,15,size=n),
                  'movieId':rng.integers(1,41,size=n),
                  'rating':rng.choice([1.,2.,3.,4.,4.5,5.],size=n),
                  'timestamp':t}).to_csv(d/'ratings.csv',index=False)
    pd.DataFrame({'userId':[1,2],'movieId':[2,3],'tag':['action','adventure'],
                  'timestamp':[int(t[0]),int(t[1])]}).to_csv(d/'tags.csv',index=False)


def test_training_separate_regularized_checkpoint(tmp_path,monkeypatch):
    _seed(tmp_path);monkeypatch.chdir(tmp_path)
    common=dict(dataset='ml-latest-small',data_dir='data',text_backend='hash',
                profile='quick',models='fm',threads=1,tag_dims=8,
                validation_users=4,validation_mode='full',
                epochs=2,steps_per_epoch=6,batch_size=16,min_epochs=2)
    train(**common)
    parent=Path('models/ml-latest-small/temporal_fm/fm_all_bpr/weights.pt')
    original=parent.read_bytes()
    result=train(**common,init_from='fm_all_bpr',run_label='regtest',
                 weight_decay=.01,l1_content=.001,l2_content=.002,l2_factors=.003)
    assert 'fm_all_regtest_bpr' in result['models']
    dest=Path('models/ml-latest-small/temporal_fm/fm_all_regtest_bpr')
    meta=json.loads((dest/'metadata.json').read_text())
    assert meta['regularization']['l1_content']==.001
    assert meta['regularization']['l2_factors']==.003
    assert meta['regularization']['adamw_weight_decay']==.01
    hist=json.loads((dest/'history.json').read_text())
    assert all(row['regularization_loss']>0 for row in hist)
    assert all(row['pairwise_loss']>0 for row in hist)
    assert parent.read_bytes()==original
    again=train(**common,init_from='fm_all_bpr',run_label='regtest',
                weight_decay=.01,l1_content=.001,l2_content=.002,l2_factors=.003)
    assert again['models']['fm_all_regtest_bpr']['reused']


def test_regularization_rejects_invalid_coefficients():
    for name,coeff in [('l1_content',-0.01),('l2_content',float('nan')),
                       ('l2_factors',float('inf')),('weight_decay',-1.)]:
        with pytest.raises(ValueError,match='nonnegative'):
            train(**{name:coeff})
