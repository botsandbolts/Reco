# MovieLens 32M: true third-order (degree-3) Temporal Factorization Machine

This is an **incremental patch**, not an all-new recommender. It adds a new
`ThirdOrderTemporalFM` with distinct factorized three-field interactions to your
current second-order `TemporalFM`, keeps the existing BPR trainer and optional
semi-hard negative mining, and adds degree-3 checkpoint loading in the
ranking evaluators.

The patch makes no changes to your existing model weights or datasets.

## Mathematical design

The new score is:

\[
 s_3(x) = s_2(x) + \lambda_3 \sum_{f=1}^{k_3}
  \sum_{a<b<c} z_{a,f}^{(3)} z_{b,f}^{(3)} z_{c,f}^{(3)} .
\]

The six fields are user ID, movie ID, title representation, genres, historical
tags, and temporal context. Here `s_2` is the **entire existing pairwise FM
score**. The cubic factors are new parameters independent of the pairwise
factors, and both sets are fine-tuned jointly with BPR.

This is a **field-level degree-3 FM**, not a fully sparse, feature-by-feature
HOFM with every raw genre or token as an independent feature. `third_order_anova`
computes the exact triple sum in O(6 × k3), not by explicitly enumerating triples.
The formulation is inspired by Blondel et al., *Higher-Order Factorization
Machines* (NeurIPS 2016), https://arxiv.org/abs/1607.07195.

### Important distinction regarding B+C+D

This implementation automatically uses the existing FM **title/genre/tag/time
fields** in third-order interactions. It **does not automatically incorporate**
the separately trained B/C/D historical-user genre drift and long/short-term
preference profiles from `temporal_fm.preference_experiment`. Integrating those
new fields into the FM remains a separate architectural extension. This patch
is for the specifically requested **third-order FM**, not a B+C+D replacement.

## Prerequisites

- The `temporal_fm` package is already installed in the Codespace.
- `python -m temporal_fm.rank_train --help` works.
- The Stage-2 semi-hard negative installer has already been run: the trainer
  supports `--hard-negative-share` and `--hard-pool`, and
  `temporal_fm/hard_negatives.py` exists.
- `models/ml-32m/temporal_fm/fm_all_semi25_bpr/weights.pt` **and**
  `metadata.json` exist.
- Your MovieLens 32M local data and historical features are available.

## Install the patch

1. Download **`temporal_fm_third_order_patch.zip`** from ChatGPT.
2. Upload it to the **root of the GitHub Reco repository** (or directly to
   Codespaces). If you uploaded to GitHub main, run:

```bash
cd /workspaces/Reco
git fetch origin main
git show origin/main:temporal_fm_third_order_patch.zip > temporal_fm_third_order_patch.zip
unzip -o temporal_fm_third_order_patch.zip
python scripts/install_hofm3.py
python -m pytest -q tests/test_hofm3.py tests/test_hofm3_installer.py
```

The installer checks all edits BEFORE modifying files, makes timestamped
`.bak` copies of `rank_train.py`, `ranking.py`, and `rank_checkpoint.py`, and
is safe to rerun. Unknown code layouts fail with a clear error; no silent
replacement of the trainer is performed.

## Check dimensions of the original FM

The fine-tuned second-order latent size must match the original checkpoint.
Run the following to see it:

```bash
python - <<'PY'
import json
from pathlib import Path
p=Path('models/ml-32m/temporal_fm/fm_all_semi25_bpr/metadata.json')
m=json.loads(p.read_text())
print('Original latent dimension k:',m['k'])
print('Original negative share:',m.get('hard_negative_share'))
print('Original profile:',m.get('profile'))
PY
```

The training command below assumes the common latent dimension **32**.
Change `--latent-dim 32` to match the checkpoint if needed.

## Training: research-level, visible progress, safe new checkpoint

```bash
cd /workspaces/Reco
set -o pipefail
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 \
python -u -m temporal_fm.rank_train \
  --dataset ml-32m \
  --text-backend sentence \
  --models fm --ablation all \
  --objective bpr \
  --profile research \
  --init-from fm_all_semi25_bpr \
  --run-label hofm3semi25 \
  --fm-order 3 --latent-dim 32 \
  --third-rank 32 --third-scale 1.0 --third-l2 0.0001 \
  --hard-negative-share 0.25 --hard-pool 8 \
  --epochs 15 --min-epochs 8 \
  --steps-per-epoch 800 --batch-size 256 \
  --lr 0.00015 --negatives 2 \
  --weight-decay 0.05 --l2-factors 0.005 \
  --validation-mode full --validation-users 100 \
  --validate-every 2 --progress-every 50 \
  --device cpu --threads 2 \
  2>&1 | tee hofm3_semi25_training.log
```

The checkpoint is **`fm_all_hofm3semi25_bpr`**, saved under
`models/ml-32m/temporal_fm/fm_all_hofm3semi25_bpr/`. The old
`fm_all_semi25_bpr` weights are NEVER overwritten.

The terminal prints `epoch X/Y step Z/800` every 50 steps and also prints
**one summary for every epoch**. Every second epoch it computes validation
NDCG@10; validation on the full warm catalogue may take a while. Learning
history is saved under the new checkpoint as `history.json`.

This is a suggested initial research configuration, *not* a guarantee of
improvement. Keep the same protocol and 300-user evaluation cohort when
comparing checkpoints. Do not use the test split to tune hyperparameters.

## Fair full-catalogue comparison

```bash
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 \
python -u -m temporal_fm.ranking \
  --dataset ml-32m --backend sentence \
  --models fm_all_semi25_bpr,fm_all_hofm3semi25_bpr \
  --users 300 --k 10 --max-candidates 0 \
  --device cpu --threads 2
```

Use the same data signature, text backend, evaluation users and K for both
models. The ranking report can feed the Model Comparison dashboard if it is
installed in your Codespace. Make claims about NDCG improvement only after
measuring the real MovieLens 32M run.

## Model variations worth testing

Train additional run labels such as `hofm3k16` (`--third-rank 16`) and
`hofm3k64` (`--third-rank 64`) with identical other settings. Use validation
for selection, and keep the 300-user final comparison holdout fixed. Third-order
interactions may overfit: watch validation NDCG, not only training BPR loss.

## Testing performed for this patch

- Direct identity against explicit triple sums and autograd gradient test.
- Strict warm-starting and preservation of the second-order weights.
- Ablation/zero-width tag tests and idempotent installer test.
- End-to-end offline synthetic training: original FM-BPR → degree-3 FM-BPR,
  using semi-hard negative mining, with both ranking checkpoint readers.
- The end-to-end test exercised **synthetic data**, not a real MovieLens 32M
  benchmark. No real-world uplift is claimed.
