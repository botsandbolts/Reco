"""Idempotent, reversible installer for third-order TemporalFM-BPR.

Supports the serious/regularized rank_train.py layout; refuses unknown versions.
Never edits existing checkpoints, weights or historical reports.
"""
from __future__ import annotations
import argparse
import ast
from datetime import datetime, timezone
from pathlib import Path
import shutil

MARKER = '# HOFM3_DEGREE3_EXTENSION_V1'


def replace_one(text, old, new, name):
    occurrences = text.count(old)
    if occurrences != 1:
        raise ValueError(f'{name}: expected exactly one compatible location, found {occurrences}; '
                         'no files changed')
    return text.replace(old, new, 1)


def modify_trainer(text):
    if MARKER in text:
        return text
    text = replace_one(text, 'from .model import TemporalFM',
                       'from .model import TemporalFM\nfrom .hofm3 import ThirdOrderTemporalFM',
                       'TemporalFM import')
    # This is deliberately surgical to preserve semi-hard sampling hooks and
    # any separate FM regularization experiments already installed.
    head = 'def train('
    start = text.index(head)
    endmarker = '):\n    if profile not in RANK_PROFILES'
    end = text.index(endmarker, start)
    signature = text[start:end]
    if 'fm_order=' in signature:
        raise ValueError('Another FM-order trainer extension exists; refusing to merge blindly')
    if not signature.rstrip().endswith(('l2_factors=0.', 'hard_pool=12', 'hard_pool=12,', 'hard_pool=8')):
        # Allow small variations from historical semi-hard hook, but only
        # if the signature is otherwise a valid Python function.
        if 'hard_pool=' not in signature and 'l2_factors=' not in signature:
            raise ValueError('Unsupported trainer function signature')
    text = text[:end] + ',fm_order=2,third_rank=None,third_scale=1.,third_l2=0.,progress_every=100' + text[end:]
    text = replace_one(text,
        "    if ablation not in ('id','content','all_no_time','all'):raise ValueError('Unknown ablation')",
        """    if ablation not in ('id','content','all_no_time','all'):raise ValueError('Unknown ablation')
    # HOFM3_DEGREE3_EXTENSION_V1
    if fm_order not in (2, 3):raise ValueError('--fm-order must be 2 or 3')
    if fm_order == 3:
        if models.strip() != 'fm' or objective != 'bpr':
            raise ValueError('Degree 3 currently supports --models fm --objective bpr')
        if not run_label or 'hofm3' not in run_label:
            raise ValueError('Degree 3 requires a distinct --run-label containing hofm3')
        if not init_from:
            raise ValueError('Degree 3 requires --init-from a compatible pairwise FM')
        if third_rank is not None and third_rank < 1:
            raise ValueError('--third-rank must be positive')
        if not math.isfinite(third_scale) or not 0 < third_scale <= 10:
            raise ValueError('--third-scale must be finite and in (0,10]')
        if not math.isfinite(third_l2) or third_l2 < 0:
            raise ValueError('--third-l2 must be finite and nonnegative')
    if progress_every < 0:raise ValueError('--progress-every must be >= 0')""",
        'training argument validation')
    text = replace_one(text,
        "    p.add_argument('--latent-dim',type=int,default=None)",
        """    p.add_argument('--latent-dim',type=int,default=None)
    p.add_argument('--fm-order',type=int,choices=(2,3),default=2,
                   help='2 = unchanged FM, 3 = original FM + learned cubic field interactions')
    p.add_argument('--third-rank',type=int,default=None,
                   help='Third-order factor dimension (default: same as pairwise rank)')
    p.add_argument('--third-scale',type=float,default=1.0)
    p.add_argument('--third-l2',type=float,default=0.0001,
                   help='Explicit L2 on third-order factors')
    p.add_argument('--progress-every',type=int,default=100,
                   help='Print training batch progress every N steps; 0 disables')""",
        'CLI options')
    # The degree-2 metadata is deliberately unchanged for historical checkpoint reuse.
    text = replace_one(text, "        check=folder/'metadata.json';weights=folder/'weights.pt'",
        """        if fm_order == 3:
            metadata.update({'fm_order':3, 'third_rank':third_rank or cfg['k'],
                             'third_scale':third_scale,'third_l2':third_l2})
        check=folder/'metadata.json';weights=folder/'weights.pt'""",
        'metadata')
    old_ctor = """        model=TemporalFM(len(ev.train_users),len(ev.movies),provider.title.shape[1],
                 len(ev.genres),provider.tags.tag_dims,k=cfg['k'],deep=kind=='deepfm',
                 mean_rating=0.0,ablation=ablation).to(device)"""
    new_ctor = """        ctor = ThirdOrderTemporalFM if fm_order == 3 else TemporalFM
        cubic_kwargs = ({'third_rank':third_rank or cfg['k'],
                         'third_scale':third_scale} if fm_order == 3 else {})
        model=ctor(len(ev.train_users),len(ev.movies),provider.title.shape[1],
                 len(ev.genres),provider.tags.tag_dims,k=cfg['k'],deep=kind=='deepfm',
                 mean_rating=0.0,ablation=ablation,**cubic_kwargs).to(device)"""
    text = replace_one(text, old_ctor, new_ctor, 'FM constructor')
    text = replace_one(text,
        '        model.load_state_dict(state,strict=True)',
        """        if isinstance(model, ThirdOrderTemporalFM):
            model.load_second_order_state(state)
        else:
            model.load_state_dict(state,strict=True)""",
        'fine-tune checkpoint strict loading')
    # Regularization applies to both positive and negative (fresh cubic factors).
    text = replace_one(text,
        "                if not torch.isfinite(reg):raise FloatingPointError('Nonfinite regularization penalty')",
        """                if fm_order == 3:
                    reg=reg+model.third_regularization(positive,negative,third_l2)
                if not torch.isfinite(reg):raise FloatingPointError('Nonfinite regularization penalty')""",
        'regularization block')
    text = replace_one(text,
        '                loss_total+=float(loss.detach())',
        """                loss_total+=float(loss.detach())
                if progress_every and ((step+1)%progress_every == 0 or step+1 == cfg['steps']):
                    print(f'{name}: epoch {epoch+1}/{cfg["epochs"]} '
                          f'step {step+1}/{cfg["steps"]} '
                          f'ranking_loss={ranking_loss_total/(step+1):.5f} '
                          f'elapsed={time.perf_counter()-start:.1f}s', flush=True)""",
        'batch progress')
    ast.parse(text)
    return text


def modify_ranking(text):
    if MARKER in text:
        return text
    text = replace_one(text, 'from .model import TemporalFM',
                       'from .model import TemporalFM\nfrom .hofm3 import ThirdOrderTemporalFM',
                       'ranking model import')
    # Allow legacy metadata with flattened signatures, and new BPR metadata
    # with a sources dictionary. BOTH are strictly checked.
    text = replace_one(text,
        """    for key, val in ev.meta['sources'].items():
        if meta.get(key)!=val:
            raise ValueError(f'{name}: original {key} data changed since training')""",
        """    if meta.get('sources') is None:
        for key, val in ev.meta['sources'].items():
            if meta.get(key)!=val:
                raise ValueError(f'{name}: original {key} data changed since training')""",
        'legacy source validation')
    text = replace_one(text,
        """    model=TemporalFM(len(ev.train_users),len(ev.movies),provider.title.shape[1],
                     len(ev.genres),provider.tags.tag_dims,k=PROFILES[trained_profile]['k'],
                     deep=meta['kind']=='deepfm',ablation=meta['ablation']).to(device)""",
        """    # HOFM3_DEGREE3_EXTENSION_V1
    order=int(meta.get('fm_order',2))
    if order not in (2,3):raise ValueError(f'{name}: unsupported FM order {order}')
    ctor=ThirdOrderTemporalFM if order==3 else TemporalFM
    options=({'third_rank':int(meta['third_rank']),
              'third_scale':float(meta['third_scale'])} if order==3 else {})
    model=ctor(len(ev.train_users),len(ev.movies),provider.title.shape[1],
               len(ev.genres),provider.tags.tag_dims,
               k=int(meta.get('k',PROFILES[trained_profile]['k'])),
               deep=meta['kind']=='deepfm',ablation=meta['ablation'],
               mean_rating=0.,**options).to(device)""",
        'ranking checkpoint constructor')
    ast.parse(text)
    return text


def modify_rank_checkpoint(text):
    if MARKER in text:
        return text
    text = replace_one(text, 'from .model import TemporalFM',
                       'from .model import TemporalFM\nfrom .hofm3 import ThirdOrderTemporalFM',
                       'BPR checkpoint import')
    text = replace_one(text,
        """    model=TemporalFM(len(ev.train_users),len(ev.movies),provider.title.shape[1],
                     len(ev.genres),provider.tags.tag_dims,
                     k=int(meta['k']),deep=meta['kind']=='deepfm',
                     mean_rating=0.,ablation=meta['ablation']).to(device)""",
        """    # HOFM3_DEGREE3_EXTENSION_V1
    order=int(meta.get('fm_order',2))
    if order not in (2,3):raise ValueError(f'{name}: unsupported FM order {order}')
    ctor=ThirdOrderTemporalFM if order==3 else TemporalFM
    extras=({'third_rank':int(meta['third_rank']),
             'third_scale':float(meta['third_scale'])} if order==3 else {})
    model=ctor(len(ev.train_users),len(ev.movies),provider.title.shape[1],
               len(ev.genres),provider.tags.tag_dims,
               k=int(meta['k']),deep=meta['kind']=='deepfm',
               mean_rating=0.,ablation=meta['ablation'],**extras).to(device)""",
        'BPR checkpoint constructor')
    ast.parse(text)
    return text


def install(root='.'):
    root = Path(root)
    candidates = {
        root / 'temporal_fm/rank_train.py': modify_trainer,
        root / 'temporal_fm/ranking.py': modify_ranking,
    }
    optional = root / 'temporal_fm/rank_checkpoint.py'
    if optional.is_file():
        candidates[optional] = modify_rank_checkpoint
    new_text = {}
    for path, update in candidates.items():
        if not path.is_file():
            raise FileNotFoundError(f'Missing required {path}; install Temporal FM-BPR first')
        current = path.read_text(encoding='utf-8')
        new_text[path] = update(current)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    changed = []
    for path, updated in new_text.items():
        current = path.read_text(encoding='utf-8')
        if current == updated:
            continue
        backup = path.with_name(path.name + '.before_hofm3_' + stamp + '.bak')
        shutil.copy2(path, backup)
        path.write_text(updated, encoding='utf-8')
        changed.append(str(path))
        print(f'Updated: {path} (backup: {backup})', flush=True)
    if not changed:
        print('Already installed; no files changed', flush=True)
    return changed


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',default='.')
    install(**vars(parser.parse_args()))
