"""Field-based degree-3 Factorization Machine extension for TemporalFM.

This is a six-field HOFM, *not* a full sparse-feature HOFM: distinct
user/item/title/genre/tag/time fields contribute cubic interactions.
Pairwise FM and bias terms are inherited unchanged from TemporalFM.
"""
from __future__ import annotations

import torch
from torch import nn
from .model import TemporalFM


def third_order_anova(fields: torch.Tensor) -> torch.Tensor:
    """Sum over distinct triples of fields, per latent channel.

    fields: [batch, number_of_fields, rank]. Exact elementary symmetric e3:
      (sum(x)^3 - 3 sum(x) sum(x^2) + 2 sum(x^3)) / 6.
    Returns a scalar per example. Computational cost O(batch * fields * rank).
    """
    if fields.ndim != 3:
        raise ValueError('Expected [batch, fields, rank]')
    if fields.shape[1] < 3:
        return fields.new_zeros(fields.shape[0])
    s1 = fields.sum(dim=1)
    s2 = fields.square().sum(dim=1)
    s3 = fields.pow(3).sum(dim=1)
    return ((s1.pow(3) - 3 * s1 * s2 + 2 * s3) / 6.0).sum(dim=-1)


class ThirdOrderTemporalFM(TemporalFM):
    """Existing 2nd-order FM plus independent learned degree-3 field factors.

    Does not modify the input batch format. Existing 2nd-order state can be
    loaded exactly using `load_second_order_state` and then fine-tuned jointly.
    """

    def __init__(self, n_users, n_items, title_dim, n_genres, tag_dim,
                 k=32, deep=False, dropout=.15, mean_rating=0., ablation='all',
                 third_rank=32, third_scale=1.):
        super().__init__(n_users, n_items, title_dim, n_genres, tag_dim,
                         k=k, deep=deep, dropout=dropout,
                         mean_rating=mean_rating, ablation=ablation)
        if not isinstance(third_rank, int) or third_rank < 1:
            raise ValueError('third_rank must be positive')
        if not 0 < float(third_scale) <= 10:
            raise ValueError('third_scale must be in (0, 10]')
        self.third_rank = third_rank
        self.third_scale = float(third_scale)
        self.third_user = nn.Embedding(n_users + 1, third_rank, padding_idx=0)
        self.third_movie = nn.Embedding(n_items + 1, third_rank, padding_idx=0)
        self.third_title = nn.Linear(title_dim, third_rank, bias=False)
        self.third_genre = nn.Linear(n_genres, third_rank, bias=False)
        self.third_tags = nn.Linear(tag_dim, third_rank, bias=False)
        self.third_calendar = nn.Embedding(70, third_rank)
        self.third_time = nn.Linear(4, third_rank, bias=False)
        self.reset_third_parameters()

    def reset_third_parameters(self):
        # Slightly larger than typical pairwise embeddings to avoid a vanishing
        # cubic term at initialization; gradient clipping remains in rank_train.
        for layer in (self.third_user, self.third_movie, self.third_calendar):
            nn.init.normal_(layer.weight, mean=0., std=.06)
        for layer in (self.third_title, self.third_genre, self.third_tags, self.third_time):
            nn.init.normal_(layer.weight, mean=0., std=.06)
        with torch.no_grad():
            self.third_user.weight[0].zero_()
            self.third_movie.weight[0].zero_()

    def load_second_order_state(self, weights: dict):
        """Strictly validate original FM weights while allowing only new cubic params."""
        expected = set(self.state_dict())
        cubic = {k for k in expected if k.startswith('third_') and k != 'third_rank'}
        if set(weights) != expected - cubic:
            missing = sorted((expected - cubic) - set(weights))
            unexpected = sorted(set(weights) - (expected - cubic))
            raise ValueError(f'Incompatible second-order checkpoint: missing={missing[:5]}, '
                             f'unexpected={unexpected[:5]}')
        result = self.load_state_dict(weights, strict=False)
        if set(result.missing_keys) != cubic or result.unexpected_keys:
            raise ValueError('Unexpected checkpoint structure when initializing cubic FM')

    def third_fields(self, batch):
        user = self.third_user(batch['user'])
        item = self.third_movie(batch['item'])
        content = self.ablation in ('content', 'all_no_time', 'all')
        tags_active = self.ablation in ('all_no_time', 'all')
        temporal = self.ablation == 'all'
        zeros = torch.zeros_like(user)
        title = self.third_title(batch['title']) if content else zeros
        genre = self.third_genre(batch['genres']) if content else zeros
        tags = self.third_tags(batch['tags']) if tags_active else zeros
        time = (self.third_calendar(batch['calendar']) +
                self.third_time(batch['time'])) if temporal else zeros
        return torch.stack([user, item, title, genre, tags, time], dim=1)

    def third_score(self, batch):
        return self.third_scale * third_order_anova(self.third_fields(batch))

    def forward(self, batch):
        return super().forward(batch) + self.third_score(batch)

    def third_regularization(self, positive, negative, coefficient=0.):
        if coefficient == 0:
            return self.third_user.weight.new_zeros(())
        # Regularize sampled ID rows rather than the full 32M training table.
        sampled = (self.third_user(positive['user']).square().mean() +
                   self.third_movie(positive['item']).square().mean() +
                   self.third_movie(negative['item']).square().mean())
        # Optional zero-width tag features (MovieLens 1M) need no penalty.
        dense = sum((p.square().mean() for p in (
            self.third_title.weight, self.third_genre.weight,
            self.third_tags.weight, self.third_time.weight,
            self.third_calendar.weight) if p.numel()), sampled.new_zeros(()))
        return coefficient * (sampled + dense)
