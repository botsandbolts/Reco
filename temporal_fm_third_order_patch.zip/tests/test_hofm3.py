"""Offline tests: cubic identity, checkpoint warm start, gradient flow, and ablations."""
from itertools import combinations

import pytest
import torch

from temporal_fm.model import TemporalFM
from temporal_fm.hofm3 import ThirdOrderTemporalFM, third_order_anova


def batch(n=4, tag_dim=3):
    torch.manual_seed(18)
    return {'user':torch.tensor([1,2,1,0][:n]),
            'item':torch.tensor([2,1,3,0][:n]),
            'title':torch.randn(n,5),
            'genres':torch.randn(n,4),
            'tags':torch.randn(n,tag_dim),
            'calendar':torch.tensor([5,6,7,8][:n]),
            'time':torch.randn(n,4)}


def test_exact_triplets_and_gradients():
    torch.manual_seed(2)
    fields=torch.randn(4,6,7,requires_grad=True)
    exact=sum((fields[:,i]*fields[:,j]*fields[:,k]).sum(-1)
              for i,j,k in combinations(range(6),3))
    fast=third_order_anova(fields)
    torch.testing.assert_close(fast,exact,atol=3e-5,rtol=2e-5)
    fast.sum().backward()
    assert fields.grad is not None and fields.grad.abs().sum()>0
    torch.testing.assert_close(third_order_anova(torch.ones(2,2,5)),torch.zeros(2))


def test_strict_warm_start_and_base_weights_unchanged():
    torch.manual_seed(5)
    baseline=TemporalFM(3,4,5,4,3,k=8,ablation='all',mean_rating=0.)
    saved={k:v.clone() for k,v in baseline.state_dict().items()}
    model=ThirdOrderTemporalFM(3,4,5,4,3,k=8,third_rank=6,ablation='all',mean_rating=0.)
    model.load_second_order_state(saved)
    for k,weight in saved.items():
        torch.testing.assert_close(model.state_dict()[k],weight)
    inputs=batch()
    base_score=baseline(inputs)
    cubic=model.third_score(inputs)
    torch.testing.assert_close(model(inputs),base_score+cubic)
    model.zero_grad()
    model(inputs).sum().backward()
    assert model.third_user.weight.grad is not None
    assert model.third_movie.weight.grad is not None
    assert model.third_user.weight.grad.abs().sum()>0
    assert model.third_movie.weight.grad.abs().sum()>0
    assert model.user.weight.grad is not None
    assert torch.isfinite(model.third_regularization(inputs,inputs,0.0001))
    with pytest.raises(ValueError,match='Incompatible'):
        model.load_second_order_state({'bad':torch.tensor(1.)})
    for k,weight in saved.items():
        torch.testing.assert_close(baseline.state_dict()[k],weight)


@pytest.mark.parametrize('ablation,active',[
    ('id',2),('content',4),('all_no_time',5),('all',6)
])
def test_ablation_active_fields(ablation,active):
    model=ThirdOrderTemporalFM(3,4,5,4,3,k=6,third_rank=5,ablation=ablation)
    fields=model.third_fields(batch())
    torch.testing.assert_close(fields[:,active:],torch.zeros_like(fields[:,active:]))
    assert torch.isfinite(model(batch())).all()


def test_zero_width_tag_inputs_dont_break_regularization():
    model=ThirdOrderTemporalFM(3,4,5,4,0,k=6,third_rank=5)
    inputs=batch(tag_dim=0)
    assert torch.isfinite(model(inputs)).all()
    assert torch.isfinite(model.third_regularization(inputs,inputs,0.01))


def test_order3_not_score_cubed():
    model=ThirdOrderTemporalFM(3,4,5,4,3,k=8,third_rank=6)
    inputs=batch()
    assert not torch.allclose(model.third_score(inputs),model(inputs).pow(3))
