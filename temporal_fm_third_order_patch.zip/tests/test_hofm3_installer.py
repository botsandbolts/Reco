"""Installer smoke; existing source modules must remain syntactically valid."""
from pathlib import Path
import ast
from scripts.install_hofm3 import install


def test_repeatable_installer(tmp_path):
    from temporal_fm import rank_train, ranking, rank_checkpoint
    sources={'rank_train.py':rank_train.__file__,
             'ranking.py':ranking.__file__,
             'rank_checkpoint.py':rank_checkpoint.__file__}
    folder=tmp_path/'temporal_fm';folder.mkdir()
    for name,original in sources.items():
        (folder/name).write_text(Path(original).read_text())
    first=install(tmp_path)
    assert all('temporal_fm' in file for file in first) or not first
    second=install(tmp_path)
    assert second==[]
    for name in sources:
        ast.parse((folder/name).read_text())
