# Temporal hybrid FM / DeepFM for MovieLens

An **independent research patch** for the existing MovieLens/TIGER repository. It adds `temporal_fm/` and a new Streamlit tab; it does **not** remove or overwrite BPR, SVD, TIGER, or your existing data pipelines.

## What's included

- Explicit 0.5–5 star rating targets, including low ratings (no positive-only filtering).
- User/movie ID latent factors, independent Sentence Transformer **movie-title vectors**, binary multi-hot genres, and historical Sentence Transformer **tag vectors**.
- True second-order FM interaction formula and an optional DeepFM neural layer.
- Calendar-year embedding, normalized user tenure from the **first training rating**, movie release-age features, cyclic calendar-month features, and user/movie embedding biases.
- Ratings globally split by timestamp: approximately 80% training, 10% validation, 10% test using bounded-memory, sampled timestamp quantiles. Only training history defines user membership/tenure; evaluation cold-start IDs map to a zero embedding.
- A **point-in-time tag index**. For every rating event at time `t`, only tags where `tag.timestamp < t` contribute; the queried prefix is selected by binary search. Unlike naive global tag averaging, this does not leak future user tags into early ratings.
- `quick`, `research`, and `intensive` training profiles and model ablations. `id` = user/movie IDs, `content` = IDs + title/genres, `all_no_time` = IDs + title/genres/tags, `all` = every feature including time. Validation RMSE chooses the best checkpoint, with an LR scheduler and early stopping.
- Separate JSON training reports and Streamlit visualizations (RMSE/MAE, learning curves, error by year, and observed per-user genre trends from training-only ratings).

### Important distinctions

**Rating timestamps indicate the time ratings were submitted, not necessarily when movies were watched.** The tag Genome vectors are retroactively compiled and cannot be assumed to have been available at the original rating time; they're intentionally not included in this strict point-in-time experiment.

MovieLens **1M does not include `tags.csv`**. On 1M, tag vectors are zero unless you supply a legitimate, timestamped, compatible tag CSV. If you want native user tags, use MovieLens 32M (or the smaller `ml-latest-small`). Tags on 32M can be numerous and expensive to embed on CPU; `--max-tag-vocab` limits tag vocabulary, with all other tags excluded.

**Data licenses:** Check GroupLens MovieLens usage conditions. The source files are not included in this patch.

## Install

From your existing `/workspaces/Reco` directory, upload the ZIP and run:

```bash
unzip -o temporal_hybrid_fm_patch.zip
python -m pip install -r requirements-temporal-fm.txt
python -m pytest -q tests/test_temporal_fm.py
python scripts/install_temporal_tab.py
```

You need the **original ratings and movies files**, not `data/processed/ml-1m/train.parquet` (that file only has positive user/movie pairs). For 1M, your existing `scalable.prepare` command can download/unpack the original files:

```bash
python -m scalable.prepare --dataset ml-1m --memory 2GB
# This will usually leave data/raw/ml-1m/ratings.dat and movies.dat, or converted .csv files.
```

Alternatively supply `--ratings /path/to/ratings.csv --movies /path/to/movies.csv --tags /path/to/tags.csv` explicitly; paths to original MovieLens 1M `.dat` files are supported for ratings and movies.

## Train the actual Sentence Transformer hybrid

First run the low-cost check (uses deterministic **hashed words**, not Sentence Transformers, and so is not a production-quality semantic test):

```bash
python -m temporal_fm.run --dataset ml-1m --profile quick --text-backend hash --models fm --ablations id,all --device cpu
```

Then train Sentence Transformer models and DeepFM:

```bash
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 python -m temporal_fm.run \
  --dataset ml-1m --profile research \
  --text-backend sentence \
  --models fm,deepfm \
  --ablations id,content,all_no_time,all \
  --device cpu --threads 2
```

For native timestamped tags, use MovieLens 32M:

```bash
python -m temporal_fm.run --dataset ml-32m --profile research \
  --text-backend sentence --max-tag-vocab 20000 \
  --models fm,deepfm --ablations id,all_no_time,all \
  --device cpu --threads 2
```

You can pass an explicit tag source with `--tags path/to/tags.csv`. The CSV must contain **movieId, tag, timestamp**. The tag vocabulary is selected only from tag events up to the training cutoff (avoiding vocabulary look-ahead); later events with known tags may contribute at their actual event time. Even if you attach a 25M `tags.csv` to a different MovieLens variant, validate the movie IDs and title identity first; IDs from different dataset versions must not be blindly assumed equivalent.

An `intensive` preset is included, but `ml-32m` text/tag encoding and CPU training may be slow. Choose `--models fm --ablations all` to train only one candidate. For any change of dataset, feature backend/model, tag dimensions, or profile against existing checkpoint names, add `--force-retrain` intentionally. Change feature inputs with `--force-features`, and changed raw ratings with `--force-data`. These commands overwrite the corresponding temporal FM artifacts, not TIGER artifacts.

| Parameter | quick | research | intensive |
|---|---:|---:|---:|
| Epochs | 2 | 15 | 35 |
| Sampled steps/epoch | 25 | 350 | 900 |
| Batch size | 64 | 256 | 512 |
| FM embedding rank | 16 | 32 | 64 |
| Validation rating sample | 1,500 | 30,000 | 75,000 |
| Early stopping patience | 2 | 4 | 7 |

Every epoch samples training rating events with replacement; `research` has 1.34 million sampled exposures before early stopping. These are *not* unique ratings. Check against baseline RMSE for overfitting.

## View graphs

```bash
streamlit run app.py --server.address 0.0.0.0 --server.port 8501
```

Open the **Temporal FM / DeepFM** tab. It reads `reports/temporal/<dataset>/validation_...json` and never loads a large checkpoint into the web process.

When you've chosen one model **only using validation**, assess its frozen checkpoint on the untouched test split:

```bash
python -m temporal_fm.final_evaluate --dataset ml-1m --profile research \
  --text-backend sentence --model fm_all
```

The existing Model Comparison tab shows **NDCG / Recall** and is based on a different ranking protocol. Do not compare these values numerically to RMSE / MAE. Ranking comparisons would require a new, consistent held-out candidate-ranking benchmark.

## Architecture and evaluation restrictions

- The label `rating` is not in the input vector for the same event. It is used only as a supervised regression target.
- Training and model selection use globally earlier timestamps; the last 10% remain untouched as a **test** set. The patch intentionally forbids `--final-test` during training. After selecting hyperparameters on validation, a separate frozen-model test evaluator can be added; do not treat repeated validation searches as test accuracy.
- Global time cutoffs are chosen from a bounded random sample, so proportions are approximate. No future rating labels are used as inputs.
- Some users and movies in the holdout are cold start. Their train-only ID embedding is zero; title/genre content and global biases remain available.
- Original MovieLens tags can be sparse. Temporal historical tags may be mostly absent in early periods, which is a real limitation, not a reason to use future tags.
- Title-only Sentence Transformer features may have weak semantics. You can later add plot summaries with provenance and a known information-availability date.
- The tag history uses an on-disk `(movie_index*4e9 + timestamp)` index and a float32 cumulative prefix feature. Two million events × 48D needs roughly **384 MB** for the prefix file, plus keys and metadata. Be mindful of Codespaces disk/RAM.
- `.pt` checkpoints should be loaded only from a trusted, locally trained source.

## File layout

```
temporal_fm/{data,features,model,train,run,dashboard}.py
scripts/install_temporal_tab.py
requirements-temporal-fm.txt
tests/test_temporal_fm.py
```
