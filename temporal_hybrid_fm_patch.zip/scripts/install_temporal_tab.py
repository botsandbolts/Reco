"""Safely insert a new Streamlit tab without overwriting the existing application.

Usage: python scripts/install_temporal_tab.py
"""
from pathlib import Path
import shutil
import re
import sys


def install(path='app.py'):
    path=Path(path)
    text=path.read_text(encoding='utf-8')
    marker='from temporal_fm.dashboard import render_temporal_lab'
    if marker in text:
        print('Temporal tab already installed.');return
    # Known app from TIGER suite. Refuse to replace or guess alternative apps.
    pattern=r'(?m)^(known_tab, favorites_tab, compare_tab, map_tab, gen_tab, method_tab = st\.tabs\(\[)'
    match=re.search(pattern,text)
    if not match:raise RuntimeError(
        'Could not locate the expected tabs in app.py. Nothing changed. '
        'Manually add a new tab and call temporal_fm.dashboard.render_temporal_lab().')
    text=text[:match.start()]+text[match.start():].replace(
        match.group(1),'known_tab, favorites_tab, compare_tab, map_tab, gen_tab, temporal_tab, method_tab = st.tabs([',1)
    text=text.replace('"Generative lab", "Methodology"','"Generative lab", "Temporal FM / DeepFM", "Methodology"',1)
    anchor='with method_tab:'
    if anchor not in text:raise RuntimeError('Missing methodology tab; nothing changed')
    text=text.replace(anchor, 'with temporal_tab:\n    '+marker+'\n    render_temporal_lab()\n\n'+anchor,1)
    backup=path.with_name('app.before_temporal_fm.py')
    if not backup.exists():shutil.copy2(path,backup)
    path.write_text(text,encoding='utf-8')
    print(f'Added Temporal FM / DeepFM tab to {path}; backup: {backup}')

if __name__=='__main__':install(sys.argv[1] if len(sys.argv)>1 else 'app.py')
