"""Independent, disk-backed MovieLens ingestion with GLOBAL chronological splits.

We do not reuse scalable/prepare.py because it discards rating values and timestamps.
No validation/test ratings are used to build user-history statistics.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import re

import numpy as np
import pandas as pd


def find_sources(dataset: str, data_dir='data', ratings=None, movies=None, tags=None):
    root = Path(data_dir)
    def locate(override, kind):
        if override is not None:
            p = Path(override)
            if not p.is_file(): raise FileNotFoundError(str(p))
            return p
        candidates = [root/'raw'/dataset/f'{kind}.csv', root/'raw'/dataset/f'{kind}.dat',
                      root/dataset/f'{kind}.csv', root/dataset/f'{kind}.dat']
        return next((p for p in candidates if p.exists()), None)
    rating_path=locate(ratings,'ratings'); movie_path=locate(movies,'movies')
    if rating_path is None or movie_path is None:
        raise FileNotFoundError(
            f'Missing original MovieLens rating/movie files under {root}/raw/{dataset}/. '
            f'The existing positive-only processed Parquet files cannot train a rating FM. '
            f'Download originals with `python -m scalable.prepare --dataset {dataset}` '
            f'or supply --ratings and --movies explicitly.')
    tag_path=locate(tags,'tags')
    return rating_path, movie_path, tag_path


def ratings_chunks(path: Path, chunksize=150_000):
    path=Path(path)
    if path.suffix=='.dat':
        # MovieLens 1M uses ::, which pandas' C parser cannot handle.
        buffer=[]
        with path.open('r',encoding='latin-1') as stream:
            for line in stream:
                fields=line.rstrip('\r\n').split('::')
                if len(fields)!=4:raise ValueError(f'Bad MovieLens ratings.dat record: {line[:100]}')
                buffer.append((int(fields[0]),int(fields[1]),float(fields[2]),int(fields[3])))
                if len(buffer)>=chunksize:
                    yield pd.DataFrame.from_records(buffer, columns=['userId','movieId','rating','timestamp'])
                    buffer.clear()
        if buffer:yield pd.DataFrame.from_records(buffer,columns=['userId','movieId','rating','timestamp'])
    else:
        for chunk in pd.read_csv(path,usecols=['userId','movieId','rating','timestamp'],chunksize=chunksize):
            yield chunk


def movies_table(path):
    path=Path(path)
    if path.suffix=='.dat':
        records=[]
        for line in path.read_text(encoding='latin-1').splitlines():
            mid,title,genres=line.split('::',2)
            records.append((int(mid),title,genres))
        movies=pd.DataFrame(records, columns=['movieId','title','genres'])
    else:
        movies=pd.read_csv(path,usecols=['movieId','title','genres'],encoding='utf-8')
    movies['movieId']=movies['movieId'].astype(np.int32)
    if movies.movieId.duplicated().any():raise ValueError('Duplicate movieId in movies file')
    return movies.sort_values('movieId').reset_index(drop=True).fillna({'title':'','genres':''})


def _source_sig(path):
    p=Path(path);s=p.stat()
    return {'path':str(p.resolve()),'size':s.st_size,'modified_ns':s.st_mtime_ns}


def prepare(dataset='ml-1m',data_dir='data',ratings=None,movies=None,tags=None,
            seed=42,sample_size=200_000,force=False):
    rp,mp,tp=find_sources(dataset,data_dir,ratings,movies,tags)
    out=Path(data_dir)/'temporal'/dataset
    manifest_path=out/'manifest.json'
    sources={'ratings':_source_sig(rp),'movies':_source_sig(mp),
             'tags':_source_sig(tp) if tp else None}
    if manifest_path.exists() and not force:
        prev=json.loads(manifest_path.read_text())
        if prev['sources']==sources and prev['seed']==seed:
            return out
        raise ValueError('Input data changed; rerun prepare with --force')
    out.mkdir(parents=True,exist_ok=True)
    catalog=movies_table(mp)
    catalog.to_csv(out/'movies.csv',index=False)
    all_movie_ids=catalog.movieId.to_numpy(dtype=np.int32)
    rng=np.random.default_rng(seed)
    # First pass: sample timestamps to choose cutoffs; count valid rows.
    timestamps=[]; count=0; discarded=0
    for chunk in ratings_chunks(rp):
        valid=(chunk['rating'].between(0.5,5.) & chunk['timestamp'].notna() &
               chunk['movieId'].isin(all_movie_ids))
        discarded+=int((~valid).sum())
        chunk=chunk.loc[valid]
        n=len(chunk);count+=n
        # ~200K uniform timestamp sample by unbiased per-row random keys.
        # Keep top-priority rows; chunks are never held together in RAM.
        times=chunk['timestamp'].to_numpy(dtype=np.int64)
        if n:
            keys=rng.random(n)
            timestamps.extend(zip(keys.tolist(),times.tolist()))
            if len(timestamps)>sample_size*2:
                timestamps=sorted(timestamps)[:sample_size]
    if count<20:raise ValueError('Too few valid ratings')
    times=np.asarray([x[1] for x in sorted(timestamps)[:sample_size]],dtype=np.int64)
    if len(times)<5:raise ValueError('No timestamps sampled')
    cut_train,cut_val=np.quantile(times,[.8,.9]).astype(np.int64)
    if cut_train>=cut_val:raise ValueError('Insufficient distinct timestamps for chronological split')
    # Second pass: use .npy memory maps for large datasets, no giant DataFrame.
    arrays={k:np.lib.format.open_memmap(out/f'{k}.npy',mode='w+',dtype=d,shape=(count,))
            for k,d in [('user_raw',np.int32),('movie_idx',np.int32),('rating',np.float32),('timestamp',np.int64)]}
    off=0
    for chunk in ratings_chunks(rp):
        valid=(chunk['rating'].between(0.5,5.) & chunk['timestamp'].notna() &
               chunk['movieId'].isin(all_movie_ids))
        chunk=chunk.loc[valid]
        n=len(chunk)
        midx=np.searchsorted(all_movie_ids,chunk.movieId.to_numpy(dtype=np.int32))
        arrays['user_raw'][off:off+n]=chunk.userId.to_numpy(dtype=np.int32)
        arrays['movie_idx'][off:off+n]=midx.astype(np.int32)
        arrays['rating'][off:off+n]=chunk.rating.to_numpy(dtype=np.float32)
        arrays['timestamp'][off:off+n]=chunk.timestamp.to_numpy(dtype=np.int64)
        off+=n
    if off!=count:raise RuntimeError('Rating input changed between ingestion passes')
    for arr in arrays.values():arr.flush()
    stamp=arrays['timestamp']
    train=np.flatnonzero(stamp<=cut_train).astype(np.int32)
    val=np.flatnonzero((stamp>cut_train)&(stamp<=cut_val)).astype(np.int32)
    test=np.flatnonzero(stamp>cut_val).astype(np.int32)
    if not len(train) or not len(val) or not len(test):
        raise ValueError('Chronological split yielded empty partition')
    np.save(out/'train_index.npy',train);np.save(out/'validation_index.npy',val);np.save(out/'test_index.npy',test)
    training_users=np.unique(arrays['user_raw'][train]).astype(np.int32)
    np.save(out/'train_users.npy',training_users)
    movie_has_train=np.zeros(len(all_movie_ids),dtype=np.bool_)
    movie_has_train[arrays['movie_idx'][train]]=True
    np.save(out/'movie_has_train.npy',movie_has_train)
    first=np.full(len(training_users),np.iinfo(np.int64).max,dtype=np.int64)
    user_index=np.searchsorted(training_users,arrays['user_raw'][train])
    np.minimum.at(first,user_index,stamp[train])
    np.save(out/'user_first_train.npy',first)
    manifest={'dataset':dataset,'sources':sources,'seed':seed,'total_ratings':int(count),
              'excluded_rows':discarded,'train_cutoff':int(cut_train), 'val_cutoff':int(cut_val),
              'splits':{'train':len(train),'validation':len(val),'test':len(test)},
              'movie_count':len(catalog),'train_user_count':len(training_users),
              'chronology':'global cutoff by observed rating timestamps; cutoffs approximated from a bounded sample',
              'data_warning':'Rating timestamp = time of rating, not verified watch time.',
              'tags_path':str(tp.resolve()) if tp else None}
    manifest_path.write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    return out


class Events:
    def __init__(self,folder):
        self.folder=Path(folder)
        self.meta=json.loads((self.folder/'manifest.json').read_text())
        self.user_raw=np.load(self.folder/'user_raw.npy',mmap_mode='r')
        self.movie_idx=np.load(self.folder/'movie_idx.npy',mmap_mode='r')
        self.rating=np.load(self.folder/'rating.npy',mmap_mode='r')
        self.timestamp=np.load(self.folder/'timestamp.npy',mmap_mode='r')
        self.train_users=np.load(self.folder/'train_users.npy')
        self.user_first=np.load(self.folder/'user_first_train.npy')
        self.movie_has_train=np.load(self.folder/'movie_has_train.npy')
        self.movies=pd.read_csv(self.folder/'movies.csv').fillna('')
        years=self.movies['title'].astype(str).str.extract(r'\((\d{4})\)\s*$')[0]
        self.release_year=pd.to_numeric(years,errors='coerce').fillna(0).to_numpy(dtype=np.int32)
        self.genres=sorted({g for values in self.movies['genres'].astype(str) for g in values.split('|') if g and g!='(no genres listed)'})
        genre_to_index={g:i for i,g in enumerate(self.genres)}
        self.genre_matrix=np.zeros((len(self.movies),len(self.genres)),dtype=np.float32)
        for j,values in enumerate(self.movies['genres'].astype(str)):
            for g in values.split('|'):
                if g in genre_to_index:self.genre_matrix[j,genre_to_index[g]]=1

    def user_indices(self, raw):
        raw=np.asarray(raw,dtype=np.int32)
        positions=np.searchsorted(self.train_users,raw)
        good=positions<len(self.train_users)
        good[good]&=self.train_users[positions[good]]==raw[good]
        return np.where(good,positions+1,0).astype(np.int64)

    def item_indices(self,idx):
        idx=np.asarray(idx,dtype=np.int32)
        return np.where(self.movie_has_train[idx],idx+1,0).astype(np.int64)

    def time_fields(self,user_index,movie_idx,timestamp):
        timestamp=np.asarray(timestamp,dtype=np.int64)
        years=timestamp.astype('datetime64[s]').astype('datetime64[Y]').astype(np.int32)+1970
        months=timestamp.astype('datetime64[s]').astype('datetime64[M]').astype(np.int32)
        mon=(months%12).astype(np.float32)
        prior=np.zeros(len(timestamp),dtype=np.int64)
        good=user_index>0
        prior[good]=self.user_first[user_index[good]-1]
        tenure=np.where(good,np.maximum(0,(timestamp-prior)/86400./365.25),0)
        age=np.where(self.release_year[movie_idx]>0,
                     np.maximum(0,years-self.release_year[movie_idx]),0)
        continuum=np.column_stack([np.clip(tenure/15.,0,3),np.clip(age/50.,0,3),
                                   np.sin(2*np.pi*mon/12),np.cos(2*np.pi*mon/12)]).astype(np.float32)
        return np.clip(years-1990,0,69).astype(np.int64),continuum

    def split(self,name):return np.load(self.folder/f'{name}_index.npy',mmap_mode='r')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset',default='ml-1m')
    p.add_argument('--data-dir',default='data')
    for key in ('ratings','movies','tags'):p.add_argument('--'+key)
    p.add_argument('--seed',type=int,default=42)
    p.add_argument('--force',action='store_true')
    print(prepare(**vars(p.parse_args())))
