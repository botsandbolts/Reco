"""Sentence-Transformer title/tag encodings and AS-OF movie tag histories.

Tag relevance at rating time t uses only tag records with timestamp < t.
No future-tag aggregation, no target rating in content features.
"""
from __future__ import annotations
from collections import Counter
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd

BASE=4_000_000_000 # index * BASE + Unix seconds fits signed int64


def hashed_embeddings(texts,dim=96):
    """Explicit offline/smoke-test substitute; NOT Sentence Transformers."""
    out=np.zeros((len(texts),dim),dtype=np.float32)
    import re
    for i,t in enumerate(texts):
        toks=re.findall(r'[a-z0-9]+',str(t).lower())
        for token in toks:
            h=hashlib.blake2b(token.encode(),digest_size=8).digest()
            idx=int.from_bytes(h[:4],'little')%dim
            sign=1 if h[4]%2 else -1
            out[i,idx]+=sign
        norm=np.linalg.norm(out[i]);
        if norm:out[i]/=norm
    return out


def encode(texts,backend='sentence',model_name='sentence-transformers/all-MiniLM-L6-v2',batch_size=96):
    if backend=='hash':return hashed_embeddings(texts)
    if backend!='sentence':raise ValueError('backend must be sentence or hash')
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError as exc:
        raise ImportError('Install sentence-transformers with: pip install -r requirements-temporal-fm.txt') from exc
    model=SentenceTransformer(model_name,device='cpu')
    vectors=model.encode(list(texts),batch_size=batch_size,show_progress_bar=True,
                         convert_to_numpy=True,normalize_embeddings=True)
    return np.asarray(vectors,dtype=np.float32)


def titles(events,backend='sentence',model_name='sentence-transformers/all-MiniLM-L6-v2',force=False):
    folder=events.folder/f'features_{backend}'
    folder.mkdir(exist_ok=True)
    path=folder/'titles.npy'
    meta_path=folder/'meta.json'
    desired={'backend':backend,'model_name':model_name,'catalog_size':len(events.movies)}
    if path.exists() and meta_path.exists() and not force:
        if json.loads(meta_path.read_text())==desired:return path
        raise ValueError('Title encoding settings changed; pass --force-features')
    # Embedding titles alone is deliberately a separate ablation from title+genres.
    data=encode(events.movies.title.astype(str).tolist(),backend,model_name)
    np.save(path,data)
    meta_path.write_text(json.dumps(desired,indent=2))
    return path


def _tag_chunks(path,chunksize=100_000):
    path=Path(path)
    if path.suffix=='.dat':
        raise ValueError('Tags DAT not supported (MovieLens 1M does not include tags); supply tags.csv')
    for chunk in pd.read_csv(path,usecols=['movieId','tag','timestamp'],chunksize=chunksize,
                             dtype={'movieId':np.int32,'tag':str,'timestamp':np.int64}):
        yield chunk.dropna(subset=['tag','timestamp'])


def make_tag_history(events,tag_path,backend='sentence',model_name='sentence-transformers/all-MiniLM-L6-v2',
                     tag_dims=48,max_tag_vocab=20000,force=False):
    """Construct searchable time-ordered cumulative tag embeddings (disk-backed).

    Sentence-transformer vectors are reduced by a seeded random projection.
    This is different from user-provided Tag Genome (which has no event times).
    """
    folder=events.folder/f'features_{backend}'
    folder.mkdir(exist_ok=True)
    key_path=folder/'tag_keys.npy'; vector_path=folder/'tag_prefix.npy'; count_path=folder/'tag_count.npy'
    meta_path=folder/'tag_meta.json'
    if not tag_path:return None
    tag_path=Path(tag_path)
    stat=tag_path.stat()
    config={'path':str(tag_path.resolve()),'size':stat.st_size,'mtime_ns':stat.st_mtime_ns,
            'backend':backend,'model_name':model_name,'tag_dims':tag_dims,'max_tag_vocab':max_tag_vocab,
            'train_cutoff':events.meta['train_cutoff']}
    if key_path.exists() and vector_path.exists() and count_path.exists() and meta_path.exists() and not force:
        if json.loads(meta_path.read_text())==config:return folder
        raise ValueError('Tag history settings/input changed; rerun --force-features')
    if max_tag_vocab<1 or tag_dims<1:raise ValueError('tag dimensions and vocabulary must be positive')
    print('Counting tag vocabulary...',flush=True)
    counts=Counter()
    cutoff=events.meta['train_cutoff']
    for chunk in _tag_chunks(tag_path):
        historical=chunk.loc[chunk['timestamp']<=cutoff]
        counts.update(historical['tag'].astype(str).str.strip().str.lower().tolist())
    vocabulary=[x for x,_ in counts.most_common(max_tag_vocab)]
    text_to_id={x:i for i,x in enumerate(vocabulary)}
    if not vocabulary:raise ValueError('No valid movie tags')
    print(f'Embedding {len(vocabulary):,} distinct tag strings with {backend}...',flush=True)
    vectors=encode(vocabulary,backend,model_name)
    if vectors.shape[1]!=tag_dims:
        rng=np.random.default_rng(13)
        projection=rng.standard_normal((vectors.shape[1],tag_dims)).astype(np.float32)
        projection/=np.sqrt(tag_dims)
        vectors=(vectors@projection).astype(np.float32)
    norm=np.linalg.norm(vectors,axis=1,keepdims=True)
    vectors=vectors/np.maximum(norm,1e-8)
    np.save(folder/'tag_vocabulary_vectors.npy',vectors)
    catalog=events.movies.movieId.to_numpy(np.int32)
    pieces_keys=[];pieces_ids=[]
    for chunk in _tag_chunks(tag_path):
        raw=chunk.movieId.to_numpy(np.int32)
        movie_pos=np.searchsorted(catalog,raw)
        valid=movie_pos<len(catalog)
        valid[valid] &= catalog[movie_pos[valid]]==raw[valid]
        mids=movie_pos[valid]
        tags=chunk['tag'].astype(str).str.strip().str.lower().map(text_to_id).to_numpy()[valid]
        ts=chunk.timestamp.to_numpy(np.int64)[valid]
        keep=pd.notna(tags)&(ts>=0)&(ts<BASE)
        if np.any(keep):
            pieces_keys.append(mids[keep].astype(np.int64)*BASE+ts[keep])
            pieces_ids.append(tags[keep].astype(np.int32))
    if not pieces_keys:raise ValueError('No selected movie tags match the catalog')
    keys=np.concatenate(pieces_keys);ids=np.concatenate(pieces_ids)
    del pieces_keys,pieces_ids
    order=np.argsort(keys,kind='stable')
    keys=keys[order];ids=ids[order]
    np.save(key_path,keys)
    prefix=np.lib.format.open_memmap(vector_path,mode='w+',dtype=np.float32,shape=(len(keys),tag_dims))
    per_movie_count=np.lib.format.open_memmap(count_path,mode='w+',dtype=np.int32,shape=(len(keys),))
    running=np.zeros(tag_dims,dtype=np.float32)
    previous_movie=-1;n=0
    # All tag aggregates use historical records only. At query t, searchsorted(...,left)
    # excludes same-timestamp tags as well.
    for j in range(len(keys)):
        movie=int(keys[j]//BASE)
        if movie!=previous_movie:
            running.fill(0);n=0;previous_movie=movie
        running+=vectors[ids[j]];n+=1
        prefix[j]=running/n
        per_movie_count[j]=n
    prefix.flush();per_movie_count.flush()
    meta_path.write_text(json.dumps(config,indent=2))
    print(f'Indexed {len(keys):,} historical tag records. Each rating queries strictly earlier tags.',flush=True)
    return folder


class TagStore:
    def __init__(self,folder,tag_dims=48):
        self.folder=Path(folder) if folder is not None else None
        self.tag_dims=int(tag_dims)
        if self.folder is not None:
            self.keys=np.load(self.folder/'tag_keys.npy',mmap_mode='r')
            self.prefix=np.load(self.folder/'tag_prefix.npy',mmap_mode='r')
            self.tag_dims=self.prefix.shape[1]

    def lookup(self,movie_idx,timestamp):
        movie_idx=np.asarray(movie_idx,dtype=np.int64)
        timestamp=np.asarray(timestamp,dtype=np.int64)
        out=np.zeros((len(timestamp),self.tag_dims),dtype=np.float32)
        if self.folder is None:return out
        query=movie_idx*BASE+timestamp
        indices=np.searchsorted(self.keys,query,side='left')-1
        valid=indices>=0
        valid[valid]&=(self.keys[indices[valid]]//BASE==movie_idx[valid])
        if valid.any():out[valid]=self.prefix[indices[valid]]
        return out
