"""One-time FINAL test evaluation of a frozen, selected temporal FM checkpoint.

Do not use this script to choose models/hyperparameters; choose them on validation.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
import torch
from .data import Events
from .features import TagStore
from .train import PROFILES, FeatureProvider, _evaluate
from .model import TemporalFM


def evaluate(dataset='ml-1m',data_dir='data',text_backend='sentence',
             profile='research',model='fm_all',device='cpu',seed=42):
    root=Path(data_dir)/'temporal'/dataset
    events=Events(root)
    meta_path=Path('models')/dataset/'temporal_fm'/model/'metadata.json'
    weights=meta_path.with_name('weights.pt')
    if not meta_path.is_file() or not weights.is_file():
        raise FileNotFoundError(f'Missing trained model {model}; run training first')
    meta=json.loads(meta_path.read_text())
    if meta['profile']!=profile or meta['text_backend']!=text_backend or meta['seed']!=seed:
        raise ValueError('Frozen checkpoint profile/backend/seed does not match the requested evaluation')
    source=events.meta
    if meta['train_cutoff']!=source['train_cutoff'] or meta['validation_cutoff']!=source['val_cutoff']:
        raise ValueError('Split cutoffs changed since the checkpoint was trained')
    tag_dir=events.folder/f'features_{text_backend}'
    tag_dir=tag_dir if (tag_dir/'tag_keys.npy').exists() else None
    if bool(source.get('tags_path'))!=bool(tag_dir):
        raise ValueError('Historical tags missing or have changed')
    provider=FeatureProvider(events,text_backend,meta['text_model'],tag_dir)
    rank=PROFILES[profile]['k']
    kind=meta['kind'];abl=meta['ablation']
    model_obj=TemporalFM(len(events.train_users),len(events.movies),provider.title.shape[1],
                         len(events.genres),provider.tags.tag_dims,k=rank,
                         deep=kind=='deepfm',ablation=abl).to(device)
    model_obj.load_state_dict(torch.load(weights,map_location=device,weights_only=True))
    test=np.asarray(events.split('test'),dtype=np.int64)
    scores,errors_by_year=_evaluate(model_obj,provider,test,1024,device,with_years=True)
    payload={'dataset':dataset,'model':model,'split':'test','text_backend':text_backend,
             'checkpoint':str(weights),'test_metrics':scores,'errors_by_year':errors_by_year,
             'warning':'Frozen test set. Do not use test results to tune the model.'}
    destination=Path('reports')/'temporal'/dataset/f'final_test_{model}_{profile}_{text_backend}_seed{seed}.json'
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_text(json.dumps(payload,indent=2))
    print(f'Test RMSE={scores["rmse"]:.4f} MAE={scores["mae"]:.4f} | {destination}')
    return payload


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset',default='ml-1m')
    p.add_argument('--data-dir',default='data')
    p.add_argument('--text-backend',choices=['hash','sentence'],default='sentence')
    p.add_argument('--profile',choices=sorted(PROFILES),default='research')
    p.add_argument('--model',default='fm_all')
    p.add_argument('--device',choices=['cpu','cuda'],default='cpu')
    p.add_argument('--seed',type=int,default=42)
    evaluate(**vars(p.parse_args()))


if __name__=='__main__':main()
