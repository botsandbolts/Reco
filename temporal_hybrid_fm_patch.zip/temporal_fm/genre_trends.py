"""Observed training-rating genre trends for a few high-activity anonymous users.

Used only for visualization. NEVER derives features from validation/test labels.
"""
from pathlib import Path
import numpy as np
import pandas as pd


def export(events,output_path,max_users=20,min_cell_ratings=3):
    train=events.split('train')
    users=np.asarray(events.user_raw[train],dtype=np.int32)
    user_pos=np.searchsorted(events.train_users,users)
    counts=np.bincount(user_pos,minlength=len(events.train_users))
    chosen=np.argsort(-counts,kind='stable')[:min(max_users,len(counts))]
    rows=[]
    for pos in chosen:
        uid=int(events.train_users[pos])
        selected=train[user_pos==pos]
        if len(selected)==0:continue
        movie=np.asarray(events.movie_idx[selected],dtype=np.int32)
        years=np.asarray(events.timestamp[selected]).astype('datetime64[s]').astype('datetime64[Y]').astype(int)+1970
        ratings=np.asarray(events.rating[selected],dtype=np.float32)
        for yr in np.unique(years):
            sel=(years==yr)
            if not np.any(sel):continue
            g=events.genre_matrix[movie[sel]]
            r=ratings[sel]
            totals=g.sum(axis=0)
            sums=g.T@r
            for j,n in enumerate(totals):
                if n>=min_cell_ratings:
                    rows.append({'userId':uid,'year':int(yr),'genre':events.genres[j],
                                 'ratings_count':int(n),'mean_rating':float(sums[j]/n)})
    p=Path(output_path);p.parent.mkdir(parents=True,exist_ok=True)
    pd.DataFrame(rows,columns=['userId','year','genre','ratings_count','mean_rating']).to_csv(p,index=False)
    return p
