"""True second-order field-based FM, with optional DeepFM MLP.

The six learned k-dimensional fields are user, item, title, genres, tags,
and temporal context. They interact via standard FM sum-of-pairs identity.
"""
from __future__ import annotations
import torch
from torch import nn


class TemporalFM(nn.Module):
    def __init__(self,n_users,n_items,title_dim,n_genres,tag_dim,k=32,deep=False,
                 dropout=.15,mean_rating=3.5,ablation='all'):
        super().__init__()
        if ablation not in ('id','content','all','all_no_time'):
            raise ValueError('Unknown feature ablation')
        self.deep=bool(deep);self.ablation=ablation
        self.mu=nn.Parameter(torch.tensor(float(mean_rating),dtype=torch.float32))
        self.user=nn.Embedding(n_users+1,k,padding_idx=0)
        self.movie=nn.Embedding(n_items+1,k,padding_idx=0)
        self.user_bias=nn.Embedding(n_users+1,1,padding_idx=0)
        self.movie_bias=nn.Embedding(n_items+1,1,padding_idx=0)
        self.title=nn.Linear(title_dim,k,bias=False)
        self.genre=nn.Linear(n_genres,k,bias=False)
        self.tags=nn.Linear(tag_dim,k,bias=False)
        self.title_bias=nn.Linear(title_dim,1,bias=False)
        self.genre_bias=nn.Linear(n_genres,1,bias=False)
        self.tags_bias=nn.Linear(tag_dim,1,bias=False)
        self.calendar=nn.Embedding(70,k)
        self.calendar_bias=nn.Embedding(70,1)
        self.time_cont=nn.Linear(4,k,bias=False)
        self.time_bias=nn.Linear(4,1,bias=False)
        if deep:
            self.mlp=nn.Sequential(nn.Linear(k*6,128),nn.ReLU(),nn.Dropout(dropout),
                                   nn.Linear(128,64),nn.ReLU(),nn.Dropout(dropout),nn.Linear(64,1))
        self.reset_parameters()

    def reset_parameters(self):
        for mod in (self.user,self.movie,self.calendar):nn.init.normal_(mod.weight,std=.025)
        with torch.no_grad():
            self.user.weight[0].zero_()
            self.movie.weight[0].zero_()
        for mod in (self.user_bias,self.movie_bias,self.calendar_bias):nn.init.zeros_(mod.weight)
        for mod in (self.title,self.genre,self.tags,self.title_bias,self.genre_bias,self.tags_bias,
                    self.time_cont,self.time_bias):
            nn.init.normal_(mod.weight,std=.02)
        if self.deep:
            nn.init.zeros_(self.mlp[-1].weight);nn.init.zeros_(self.mlp[-1].bias)

    def forward(self,b):
        u=self.user(b['user']);i=self.movie(b['item'])
        all_on=self.ablation in ('content','all','all_no_time')
        tagged=self.ablation in ('all','all_no_time')
        temporal=self.ablation=='all'
        genre=self.genre(b['genres']) if all_on else torch.zeros_like(u)
        title=self.title(b['title']) if all_on else torch.zeros_like(u)
        tags=self.tags(b['tags']) if tagged else torch.zeros_like(u)
        when=(self.calendar(b['calendar'])+self.time_cont(b['time'])) if temporal else torch.zeros_like(u)
        fields=torch.stack([u,i,title,genre,tags,when],dim=1)
        cross=.5*((fields.sum(1).square()-fields.square().sum(1)).sum(-1))
        pred=self.mu+self.user_bias(b['user']).flatten()+self.movie_bias(b['item']).flatten()+cross
        if all_on:
            pred=pred+self.title_bias(b['title']).flatten()+self.genre_bias(b['genres']).flatten()
        if tagged:
            pred=pred+self.tags_bias(b['tags']).flatten()
        if temporal:
            pred=pred+self.calendar_bias(b['calendar']).flatten()+self.time_bias(b['time']).flatten()
        if self.deep:pred=pred+self.mlp(fields.flatten(1)).flatten()
        return pred
