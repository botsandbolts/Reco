"""Command: python -m temporal_fm.run --dataset ml-1m --profile research"""
from .train import main, run
if __name__=='__main__':
    main()
