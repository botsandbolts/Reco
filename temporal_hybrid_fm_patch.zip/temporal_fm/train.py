"""Train temporal FM/DeepFM with fixed global chronological holdouts.

Run via `python -m temporal_fm.run --dataset ml-1m --profile quick --text-backend hash`
for an offline smoke test, or omit --text-backend for Sentence Transformers.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
from pathlib import Path
import random
import time

import numpy as np
import pandas as pd
import torch
from torch import nn
from .data import Events, prepare, find_sources
from .features import titles, make_tag_history, TagStore
from .model import TemporalFM

PROFILES={
    'quick':{'epochs':2,'steps':25,'batch_size':64,'k':16,'validation_events':1500,'patience':2,'lr':0.002},
    'research':{'epochs':15,'steps':350,'batch_size':256,'k':32,'validation_events':30000,'patience':4,'lr':0.001},
    'intensive':{'epochs':35,'steps':900,'batch_size':512,'k':64,'validation_events':75000,'patience':7,'lr':0.0006},
}


class FeatureProvider:
    def __init__(self,events,backend='sentence',model_name='sentence-transformers/all-MiniLM-L6-v2',
                 tag_dir=None):
        self.events=events
        self.title=np.load(events.folder/f'features_{backend}'/'titles.npy',mmap_mode='r')
        self.tags=TagStore(tag_dir)

    def batch(self,event_indices,device='cpu'):
        ev=self.events
        idx=np.asarray(event_indices,dtype=np.int64)
        movies=np.asarray(ev.movie_idx[idx],dtype=np.int32)
        timestamps=np.asarray(ev.timestamp[idx],dtype=np.int64)
        user=ev.user_indices(ev.user_raw[idx])
        cal,cont=ev.time_fields(user,movies,timestamps)
        fields={'user':user,'item':ev.item_indices(movies),'title':np.asarray(self.title[movies]),
                'genres':ev.genre_matrix[movies],'tags':self.tags.lookup(movies,timestamps),
                'calendar':cal,'time':cont,'rating':np.asarray(ev.rating[idx],dtype=np.float32)}
        dtypes={'user':torch.long,'item':torch.long,'calendar':torch.long}
        return {key:torch.as_tensor(np.array(val,copy=True),dtype=dtypes.get(key,torch.float32),device=device)
                for key,val in fields.items()}


def _evaluate(model,provider,indices,batch_size,device,with_years=False):
    model.eval();residuals=[];targets=[];predictions=[];years=[]
    with torch.inference_mode():
        for start in range(0,len(indices),batch_size):
            ids=indices[start:start+batch_size]
            b=provider.batch(ids,device)
            yp=model(b).cpu().numpy(); yt=b['rating'].cpu().numpy()
            predictions.append(np.clip(yp,0.5,5.0));targets.append(yt)
            if with_years:
                ts=np.asarray(provider.events.timestamp[np.asarray(ids,dtype=np.int64)],dtype=np.int64)
                years.append(ts.astype('datetime64[s]').astype('datetime64[Y]').astype(int)+1970)
    pred=np.concatenate(predictions);truth=np.concatenate(targets)
    error=pred-truth
    scores={'rmse':float(np.sqrt(np.mean(error**2))),'mae':float(np.mean(np.abs(error))),
            'n_events':int(len(indices)),'prediction_mean':float(np.mean(pred))}
    if with_years:
        years=np.concatenate(years)
        table=[]
        for year in np.unique(years):
            m=years==year
            if m.sum()>=5:
                table.append({'year':int(year),'events':int(m.sum()),'rmse':float(np.sqrt(np.mean(error[m]**2))),
                              'mae':float(np.mean(np.abs(error[m])) )})
        return scores,table
    return scores


def _rating_baseline(provider,train_idx,val_idx):
    ev=provider.events
    target=np.asarray(ev.rating[train_idx],dtype=np.float32)
    mean=float(target.mean());valid=np.asarray(ev.rating[val_idx],dtype=np.float32)
    return {'rmse':float(np.sqrt(np.mean((valid-mean)**2))),
            'mae':float(np.mean(np.abs(valid-mean))),'n_events':len(val_idx)},mean


def run(dataset='ml-1m',data_dir='data',ratings=None,movies=None,tags=None,
        profile='research',text_backend='sentence',text_model='sentence-transformers/all-MiniLM-L6-v2',
        device='cpu',seed=42,force_data=False,force_features=False,force_retrain=False,
        max_tag_vocab=20000,tag_dims=48,models='fm,deepfm',ablations='id,content,all_no_time,all',
        final_test=False,threads=2):
    if profile not in PROFILES:raise ValueError(f'Choose profile from {list(PROFILES)}')
    if device=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA was requested but not available')
    torch.set_num_threads(threads)
    random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)
    cfg=PROFILES[profile]
    start_time=time.time()
    path=prepare(dataset,data_dir,ratings,movies,tags,seed=seed,force=force_data)
    ev=Events(path)
    source=json.loads((path/'manifest.json').read_text())
    tag_source=source['tags_path']
    title_path=titles(ev,text_backend,text_model,force=force_features)
    tag_dir=(make_tag_history(ev,tag_source,text_backend,text_model,tag_dims,max_tag_vocab,force_features)
             if tag_source else None)
    provider=FeatureProvider(ev,text_backend,text_model,tag_dir)
    eval_split='test' if final_test else 'validation'
    train_indices=ev.split('train');validation_indices=ev.split('validation')
    if final_test:
        raise ValueError('Final test evaluation requires a frozen model-selection run; '
                         'do not tune/force-retrain with test data. Use temporal_fm.evaluate_final.')
    rng=np.random.default_rng(seed)
    selection=lambda a,n:np.asarray(a if len(a)<=n else rng.choice(a,size=n,replace=False),dtype=np.int64)
    val_ids=selection(validation_indices,cfg['validation_events'])
    val_ids.sort()
    baseline,mean_rating=_rating_baseline(provider,train_indices,val_ids)
    report={'dataset':dataset,'task':'explicit rating prediction', 'split':eval_split,
            'protocol':'Global chronological cutoff; validation sample fixed across all variants',
            'train_cutoff':source['train_cutoff'],'val_cutoff':source['val_cutoff'],
            'profile':profile,'backend':text_backend,'text_model':text_model,
            'train_count':len(train_indices),'validation_count':len(val_ids),
            'has_historical_tags':bool(tag_dir),'tag_dims':provider.tags.tag_dims,
            'prediction_bounds':'Clipped to 0.5–5.0 stars for evaluation; training loss uses unconstrained prediction',
            'caveats':['Do not compare RMSE/MAE against NDCG from a different benchmark.',
                        'Ratings timestamps are submission times, not verified watch times.',
                        'Tag lookup excludes tags at or after the rating timestamp.',
                        'MovieLens 1M has no native tags; without --tags, the tag field is zero.',
                        'Cold-start user/movie IDs map to zero embedding, but side content still contributes.'],
            'results':{'global_mean':baseline}, 'history':{}}
    selected_models=[s.strip() for s in models.split(',') if s.strip()]
    selected_ablations=[s.strip() for s in ablations.split(',') if s.strip()]
    if any(m not in ('fm','deepfm') for m in selected_models):raise ValueError('models: fm,deepfm')
    if any(a not in ('id','content','all','all_no_time') for a in selected_ablations):
        raise ValueError('ablations: id,content,all_no_time,all')
    report_dir=Path('reports')/'temporal'/dataset;report_dir.mkdir(parents=True,exist_ok=True)
    out_root=Path('models')/dataset/'temporal_fm';out_root.mkdir(parents=True,exist_ok=True)
    for kind in selected_models:
        for abl in selected_ablations:
            name=f'{kind}_{abl}'
            target_dir=out_root/name;target_dir.mkdir(parents=True,exist_ok=True)
            best_path=target_dir/'weights.pt'
            check={**source['sources'],'profile':profile,'text_backend':text_backend,
                   'text_model':text_model,'tag_dims':provider.tags.tag_dims,
                   'max_tag_vocab':max_tag_vocab,'ablation':abl,
                   'kind':kind,'seed':seed,'train_cutoff':source['train_cutoff'],'validation_cutoff':source['val_cutoff']}
            meta_path=target_dir/'metadata.json'
            previous=json.loads(meta_path.read_text()) if meta_path.exists() else None
            if best_path.exists() and not force_retrain and previous!=check:
                raise ValueError(f'Existing {name} trained with other settings; use --force-retrain')
            model=TemporalFM(len(ev.train_users),len(ev.movies),provider.title.shape[1],len(ev.genres),
                             provider.tags.tag_dims,k=cfg['k'],deep=(kind=='deepfm'),
                             mean_rating=mean_rating,ablation=abl).to(device)
            history=[]
            if best_path.exists() and not force_retrain:
                model.load_state_dict(torch.load(best_path,map_location=device,weights_only=True))
                hp=target_dir/'history.json'
                if hp.is_file():history=json.loads(hp.read_text())
                print(f'Reusing {name}',flush=True)
            else:
                # Same random draw policy for each ablation; shuffled seed to avoid ordering advantage.
                generator=np.random.default_rng(seed)
                optimizer=torch.optim.AdamW(model.parameters(),lr=cfg['lr'],weight_decay=1e-5)
                scheduler=torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer,factor=.5,patience=2)
                best_rmse=float('inf');bad=0
                for epoch in range(cfg['epochs']):
                    model.train();epoch_loss=0.
                    for step in range(cfg['steps']):
                        picks=train_indices[generator.integers(0,len(train_indices),size=cfg['batch_size'])]
                        batch=provider.batch(picks,device)
                        pred=model(batch)
                        loss=nn.functional.mse_loss(pred,batch['rating'])
                        optimizer.zero_grad(set_to_none=True);loss.backward()
                        nn.utils.clip_grad_norm_(model.parameters(),1.0)
                        optimizer.step();epoch_loss+=loss.item()
                    metrics=_evaluate(model,provider,val_ids,1024,device)
                    scheduler.step(metrics['rmse'])
                    record={'epoch':epoch+1,'train_mse':epoch_loss/cfg['steps'],
                            'validation_rmse':metrics['rmse'],'validation_mae':metrics['mae'],
                            'lr':optimizer.param_groups[0]['lr']}
                    history.append(record)
                    print(f'{name}: epoch {epoch+1}/{cfg["epochs"]} '
                          f'loss={record["train_mse"]:.4f} val_rmse={record["validation_rmse"]:.4f}',flush=True)
                    if metrics['rmse']<best_rmse-1e-4:
                        best_rmse=metrics['rmse'];bad=0
                        torch.save(model.state_dict(),best_path)
                    else:
                        bad+=1
                        if bad>=cfg['patience']:break
                meta_path.write_text(json.dumps(check,indent=2))
                (target_dir/'history.json').write_text(json.dumps(history,indent=2))
            model.load_state_dict(torch.load(best_path,map_location=device,weights_only=True))
            final,by_year=_evaluate(model,provider,val_ids,1024,device,with_years=True)
            report['results'][name]=final
            report['history'][name]=history
            (report_dir/f'{name}_by_year.csv').write_text('year,events,rmse,mae\n'+''.join(
                f'{r["year"]},{r["events"]},{r["rmse"]},{r["mae"]}\n' for r in by_year))
    from .genre_trends import export as export_genre_trends
    report['genre_trends_file']=str(export_genre_trends(ev,report_dir/'genre_trends_train_only.csv'))
    report['elapsed_seconds']=round(time.time()-start_time,2)
    path=report_dir/f'validation_{profile}_{text_backend}_seed{seed}.json'
    path.write_text(json.dumps(report,indent=2))
    print(f'Report: {path}',flush=True)
    return report


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset',choices=['ml-1m','ml-32m','ml-latest-small'],default='ml-1m')
    p.add_argument('--data-dir',default='data')
    for s in ('ratings','movies','tags'):p.add_argument('--'+s,default=None)
    p.add_argument('--profile',choices=sorted(PROFILES),default='quick')
    p.add_argument('--text-backend',choices=['sentence','hash'],default='sentence')
    p.add_argument('--text-model',default='sentence-transformers/all-MiniLM-L6-v2')
    p.add_argument('--device',choices=['cpu','cuda'],default='cpu')
    p.add_argument('--seed',type=int,default=42)
    for f in ('force-data','force-features','force-retrain','final-test'):p.add_argument('--'+f,action='store_true')
    p.add_argument('--max-tag-vocab',type=int,default=20000)
    p.add_argument('--tag-dims',type=int,default=48)
    p.add_argument('--models',default='fm,deepfm')
    p.add_argument('--ablations',default='id,content,all_no_time,all')
    p.add_argument('--threads',type=int,default=2)
    run(**{k.replace('-','_'):v for k,v in vars(p.parse_args(argv)).items()})


if __name__=='__main__':
    main()
