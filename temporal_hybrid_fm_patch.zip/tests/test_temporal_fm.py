from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
import torch

from temporal_fm.data import prepare, Events
from temporal_fm.features import make_tag_history, TagStore, titles
from temporal_fm.model import TemporalFM
from temporal_fm.train import run, FeatureProvider


def fake_data(tmp_path):
    raw=tmp_path/'raw'/'ml-latest-small';raw.mkdir(parents=True)
    pd.DataFrame({'movieId':[1,2,3,4,5],
                  'title':['Alpha (1999)','Beta (2000)','Gamma (2005)','Delta (2010)','Epsilon (2017)'],
                  'genres':['Action|Drama','Comedy','Action|Sci-Fi','Romance','Sci-Fi']}).to_csv(raw/'movies.csv',index=False)
    rng=np.random.default_rng(11)
    n=250
    stamps=900_000_000+np.arange(n,dtype=np.int64)*86400
    pd.DataFrame({'userId':rng.integers(1,14,size=n),'movieId':rng.integers(1,6,size=n),
                  'rating':rng.choice(np.arange(.5,5.5,.5),size=n),
                  'timestamp':stamps}).to_csv(raw/'ratings.csv',index=False)
    pd.DataFrame({'movieId':[1,1,1,2,2,5],
                  'tag':['action','first','future','romantic','surprise','space'],
                  'timestamp':[stamps[0],stamps[45],stamps[-1]+10,
                               stamps[2],stamps[100],stamps[7]]}).to_csv(raw/'tags.csv',index=False)
    return raw,stamps


def test_global_split_and_explicit_low_ratings(tmp_path):
    raw,stamps=fake_data(tmp_path)
    folder=prepare('ml-latest-small',data_dir=tmp_path,sample_size=1000)
    ev=Events(folder)
    assert len(ev.train_users)>0
    assert float(np.min(ev.rating))==.5
    train=ev.split('train');validation=ev.split('validation');test=ev.split('test')
    assert max(ev.timestamp[train])<min(ev.timestamp[validation])
    assert max(ev.timestamp[validation])<min(ev.timestamp[test])
    assert len(train)+len(validation)+len(test)==len(stamps)
    assert ev.genre_matrix.shape==(5,5)
    assert ev.user_indices(np.array([999],dtype=np.int32))[0]==0
    assert np.all(ev.item_indices(np.array([0]))>=0)
    assert prepare('ml-latest-small',data_dir=tmp_path)==folder


def test_asof_tag_lookup_prevents_future_leakage(tmp_path):
    raw,stamps=fake_data(tmp_path)
    ev=Events(prepare('ml-latest-small',data_dir=tmp_path))
    path=make_tag_history(ev,raw/'tags.csv',backend='hash',tag_dims=16,max_tag_vocab=20)
    tags=TagStore(path)
    # The first tag should be excluded at exactly its own timestamp.
    empty=tags.lookup([0],[stamps[0]])
    assert np.allclose(empty,0.)
    first=tags.lookup([0],[stamps[0]+1])
    assert np.linalg.norm(first)>0
    before_second=tags.lookup([0],[stamps[45]])
    assert np.allclose(before_second,first)
    after_second=tags.lookup([0],[stamps[45]+1])
    assert not np.allclose(after_second,first)
    # Future tag must not enter early recommendations.
    assert np.allclose(tags.lookup([0],[stamps[100]]),after_second)
    assert np.allclose(tags.lookup([3],[stamps[100]]),0)


def test_temporal_feature_generation_is_finite(tmp_path):
    raw,_=fake_data(tmp_path)
    ev=Events(prepare('ml-latest-small',data_dir=tmp_path))
    titles(ev,backend='hash')
    tag_dir=make_tag_history(ev,raw/'tags.csv',backend='hash',tag_dims=16)
    features=FeatureProvider(ev,backend='hash',tag_dir=tag_dir)
    b=features.batch(ev.split('validation')[:12])
    assert b['rating'].shape==(12,)
    assert b['genres'].shape==(12,len(ev.genres))
    assert b['tags'].shape==(12,16)
    assert torch.isfinite(b['time']).all()
    assert b['calendar'].min()>=0
    assert b['calendar'].max()<70


@pytest.mark.parametrize('deep',[False,True])
def test_fm_forward_gradient(tmp_path,deep):
    raw,_=fake_data(tmp_path)
    ev=Events(prepare('ml-latest-small',data_dir=tmp_path))
    titles(ev,backend='hash')
    features=FeatureProvider(ev,backend='hash')
    b=features.batch(ev.split('train')[:24])
    model=TemporalFM(len(ev.train_users),len(ev.movies),96,len(ev.genres),48,k=12,deep=deep)
    pred=model(b)
    assert pred.shape==(24,)
    loss=((pred-b['rating'])**2).mean();loss.backward()
    assert torch.isfinite(loss)
    assert model.user.weight.grad is not None


def test_smoke_full_training_and_reports(tmp_path,monkeypatch):
    fake_data(tmp_path)
    monkeypatch.chdir(tmp_path)
    # Fast exact end-to-end, without network access or downloading embeddings.
    report=run(dataset='ml-latest-small',data_dir='raw-or-data',profile='quick',text_backend='hash',
               models='fm',ablations='id,all',threads=1,
               ratings='raw/ml-latest-small/ratings.csv',movies='raw/ml-latest-small/movies.csv',
               tags='raw/ml-latest-small/tags.csv')
    assert 'fm_id' in report['results'] and 'fm_all' in report['results']
    assert report['has_historical_tags']
    assert report['results']['fm_all']['n_events']>0
    assert np.isfinite(report['results']['fm_all']['rmse'])
    path=Path('reports/temporal/ml-latest-small/validation_quick_hash_seed42.json')
    assert path.exists()
    assert (Path('models/ml-latest-small/temporal_fm/fm_all/weights.pt')).exists()
    reused=run(dataset='ml-latest-small',data_dir='raw-or-data',profile='quick',text_backend='hash',
               models='fm',ablations='id,all',threads=1,
               ratings='raw/ml-latest-small/ratings.csv',movies='raw/ml-latest-small/movies.csv',
               tags='raw/ml-latest-small/tags.csv')
    assert reused['results']['fm_all']['rmse']==pytest.approx(report['results']['fm_all']['rmse'],abs=1e-5)


def test_installer_preserves_original(tmp_path):
    # Simulates the app's known tab declaration, rejects surprising contents.
    from scripts.install_temporal_tab import install
    source='''known_tab, favorites_tab, compare_tab, map_tab, gen_tab, method_tab = st.tabs([
    "Recommendations", "Choose favorites", "Model comparison", "UMAP genre map", "Generative lab", "Methodology"
])
with method_tab:
    pass
'''
    path=tmp_path/'app.py';path.write_text(source)
    install(path)
    content=path.read_text()
    assert 'render_temporal_lab()' in content
    assert '"Temporal FM / DeepFM"' in content
    assert (tmp_path/'app.before_temporal_fm.py').read_text()==source
    install(path)
    assert path.read_text()==content


def test_frozen_final_test_and_genre_trends(tmp_path,monkeypatch):
    fake_data(tmp_path)
    monkeypatch.chdir(tmp_path)
    report=run(dataset='ml-latest-small',data_dir='data',profile='quick',text_backend='hash',
               models='fm',ablations='all',threads=1,
               ratings='raw/ml-latest-small/ratings.csv',movies='raw/ml-latest-small/movies.csv',
               tags='raw/ml-latest-small/tags.csv')
    assert Path(report['genre_trends_file']).exists()
    from temporal_fm.final_evaluate import evaluate
    result=evaluate(dataset='ml-latest-small',data_dir='data',text_backend='hash',
                    profile='quick',model='fm_all')
    assert result['test_metrics']['n_events']>0
    assert np.isfinite(result['test_metrics']['rmse'])
    assert Path('reports/temporal/ml-latest-small/final_test_fm_all_quick_hash_seed42.json').exists()
