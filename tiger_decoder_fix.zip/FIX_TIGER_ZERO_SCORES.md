# TIGER decoding bug fix — MovieLens

This patch corrects a critical error in `generative/model.py` that made **every TIGER-style decoder return an empty list**. The previous beam search called `allowed_trie.get(())` on a nested trie that has token keys, not an empty tuple key. Therefore all TIGER variants and slate variants reported Recall@10 and NDCG@10 equal to zero irrespective of training.

## Apply in GitHub Codespaces

Upload `tiger_decoder_fix.zip` to your GitHub repository (Add file → Upload files). Open Codespaces and enter:

```bash
cd /workspaces/Reco
git pull origin main
unzip -o tiger_decoder_fix.zip
python -m pytest -q tests/test_tiger_decoder_regression.py
```

**IMPORTANT:** Do **not** click `Datei erstellen` for old missing editor tabs. Those are unrelated.

## Re-evaluate the existing trained TIGER models

The saved `weights.pt` files are unaffected by the bug, so **do not retrain yet**. Rerun the suite with the previously used research profile and *without* `--force-retrain`:

```bash
python -m generative.research_suite --dataset ml-1m --profile research --users 60 --device cpu
```

If the suite reports that a checkpoint was trained with different parameters, run direct evaluation instead to reuse the existing checkpoint **without training**:

```bash
python -m generative.evaluate --dataset ml-1m --users 60 --pool 48 --beam 120 \
  --extra-model tiger_sentence=models/ml-1m/tiger_sentence \
  --extra-model tiger_text_collab=models/ml-1m/tiger_text_collab
```

Omit `--extra-model` entries for checkpoint folders that do not exist. The `generative.evaluate` command expects the baseline `models/ml-1m/tiger/weights.pt`. Both commands will rewrite the existing validation report; back up `reports/unified/ml-1m/generative_validation_seed42.json` first if you want to retain the original zero-score evidence.

## View in Streamlit

```bash
streamlit run app.py --server.address 0.0.0.0 --server.port 8501
```

Open the **Generative Lab**, select `ml-1m`, and select the refreshed validation report. New diagnostic fields `generated_candidates_mean` and `empty_recommendation_fraction` will be added to the report so that an empty result cannot be mistaken for a poor learned ranking.

## Notes

- This change corrects **retrieval**, not training. It does **not** guarantee TIGER will beat SVD or BPR.
- TIGER beam retrieval considers a limited candidate beam; SVD/BPR currently score the full catalogue. Their outputs share held-out users but are not equivalent retrieval protocols. Future experiments should report candidate coverage and budget explicitly.
- If many queries remain empty or TIGER still underperforms, check constrained beam candidate recall, collisions in suffix codes, training exposure, and model calibration before expanding to 32M.
- This patch replaces only `generative/model.py` and `generative/evaluate.py`; it leaves BPR, SVD, semantics, UMAP, trained checkpoints, and the Streamlit interface intact.
