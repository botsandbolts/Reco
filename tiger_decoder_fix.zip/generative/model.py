"""Compact TIGER-inspired encoder/decoder Transformer over unique semantic IDs.

This is not an exact reproduction of TIGER's T5 backbone or RQ-VAE quantizer.
"""
from __future__ import annotations
import numpy as np
import torch
from torch import nn


class GenerativeRetriever(nn.Module):
    def __init__(self, semantic_ids, vocab_size, max_len=60, dim=64, heads=4,
                 layers=2, dropout=0.1):
        super().__init__()
        codes=torch.as_tensor(np.asarray(semantic_ids,dtype=np.int64))
        if codes.ndim!=2 or codes.shape[1]<2:
            raise ValueError('semantic_ids must have shape (movies, levels + suffix)')
        if int(codes.max())>=vocab_size or int(codes.min())<2:
            raise ValueError('semantic IDs outside vocabulary')
        if dim%heads: raise ValueError('dim must be divisible by heads')
        self.register_buffer('item_codes',codes)
        self.code_depth=codes.shape[1]; self.max_len=max_len
        self.token=nn.Embedding(vocab_size,dim,padding_idx=0)
        self.pos=nn.Embedding(max_len+1,dim)
        enc=nn.TransformerEncoderLayer(dim,heads,dim*3,dropout,batch_first=True,norm_first=False)
        dec=nn.TransformerDecoderLayer(dim,heads,dim*3,dropout,batch_first=True,norm_first=False)
        self.encoder=nn.TransformerEncoder(enc,num_layers=layers)
        self.decoder=nn.TransformerDecoder(dec,num_layers=layers)
        self.norm=nn.LayerNorm(dim)
        self.output=nn.Linear(dim,vocab_size)
        # item_history has indices in [0, n_items): PAD is encoded as -1

    def encode_history(self,history):
        if history.ndim!=2 or history.shape[1]>self.max_len:
            raise ValueError('Invalid history shape')
        pad=history<0
        if pad.all(dim=1).any(): raise ValueError('No empty histories permitted')
        safe=history.clamp(min=0)
        vectors=self.token(self.item_codes[safe]).mean(dim=2)
        vectors=vectors+self.pos(torch.arange(history.shape[1],device=history.device))[None]
        vectors=vectors.masked_fill(pad.unsqueeze(-1),0)
        return self.encoder(vectors,src_key_padding_mask=pad),pad

    def forward(self,history,target_tokens):
        """Teacher forcing: target_tokens = [B, depth], output B x depth x vocab."""
        memory,pad=self.encode_history(history)
        sos=torch.ones((len(history),1),dtype=torch.long,device=history.device)
        decoder_input=torch.cat([sos,target_tokens[:,:-1]],dim=1)
        dec_embed=self.token(decoder_input)+self.pos(torch.arange(decoder_input.shape[1],device=history.device))[None]
        causal=torch.triu(torch.ones(decoder_input.shape[1],decoder_input.shape[1],
                                    device=history.device,dtype=torch.bool),diagonal=1)
        decoded=self.decoder(dec_embed,memory,tgt_mask=causal,memory_key_padding_mask=pad)
        return self.output(self.norm(decoded))

    @torch.no_grad()
    def decode(self, history, allowed_trie, beam_width=60, k=10, seen=(),
               device='cpu', decode_batch_size=64):
        """Generate *existing*, unseen movie IDs by traversing the semantic-ID trie.

        Previous versions erroneously used ``allowed_trie.get(prefix)`` on a
        nested dictionary; its empty-root prefix is not a key. That caused
        every query to return an empty list (and every Recall@K to be zero).

        A beam now carries its trie node explicitly. Decoder forward passes at
        each depth are batched, reducing per-prefix CPU overhead. This is still
        constrained generative retrieval, not exhaustive catalogue scoring.
        """
        if len(history) == 0:
            raise ValueError('history must not be empty')
        if beam_width < 1 or k < 1 or decode_batch_size < 1:
            raise ValueError('beam_width, k and decode_batch_size must be positive')
        self.eval()
        hist = torch.as_tensor(history[-self.max_len:], dtype=torch.long, device=device)[None]
        memory, pad = self.encode_history(hist)
        excluded = set(map(int, seen))
        # (prefix, log probability, corresponding nested trie node)
        beams = [((), 0.0, allowed_trie)]
        for depth in range(self.code_depth):
            next_beams = []
            for start in range(0, len(beams), decode_batch_size):
                batch = beams[start:start + decode_batch_size]
                bsz = len(batch)
                dec = torch.tensor([[1, *prefix] for prefix, _, _ in batch],
                                   dtype=torch.long, device=device)
                positions = torch.arange(dec.shape[1], device=device)
                z = self.token(dec) + self.pos(positions)[None]
                mask = torch.triu(torch.ones(dec.shape[1], dec.shape[1],
                               device=device, dtype=torch.bool), diagonal=1)
                mem = memory.expand(bsz, -1, -1)
                key_padding = pad.expand(bsz, -1)
                last_hidden = self.decoder(z, mem, tgt_mask=mask,
                                           memory_key_padding_mask=key_padding)[:, -1]
                logp = torch.log_softmax(self.output(self.norm(last_hidden)), dim=-1)
                for row, (prefix, log_score, node) in enumerate(batch):
                    for token, child in node.items():
                        if token == '_item':
                            continue
                        if depth == self.code_depth - 1:
                            movie = child.get('_item')
                            if movie is None or movie in excluded:
                                continue
                        next_beams.append((prefix + (int(token),),
                                           log_score + float(logp[row, int(token)]),
                                           child))
            if not next_beams:
                return []
            next_beams.sort(key=lambda b: b[1], reverse=True)
            beams = next_beams[:beam_width]
        final = [(int(node['_item']), float(score)) for _, score, node in beams
                 if '_item' in node and int(node['_item']) not in excluded]
        final.sort(key=lambda pair: pair[1], reverse=True)
        return final[:k]


def build_trie(codes):
    """Create a nested prefix trie with a movie index stored at each leaf."""
    array = np.asarray(codes)
    if array.ndim != 2 or array.shape[0] == 0 or array.shape[1] < 2:
        raise ValueError('Expected nonempty 2D movie semantic IDs')
    root = {}
    for movie_index, row in enumerate(array):
        node = root
        for token in row:
            node = node.setdefault(int(token), {})
        if '_item' in node:
            raise ValueError('Duplicate semantic-ID path: movie codes must be unique')
        node['_item'] = int(movie_index)
    return root
