"""Regression tests: a non-empty valid catalogue must generate real movie IDs."""
import numpy as np
import pytest
from generative.model import GenerativeRetriever, build_trie


def test_decode_returns_real_movies_and_filters_seen():
    codes = np.array([[2, 5, 8], [3, 6, 9], [2, 6, 10], [4, 5, 11]], dtype=np.int64)
    model = GenerativeRetriever(codes, 12, max_len=5, dim=8, heads=2, layers=1, dropout=0.)
    trie = build_trie(codes)
    assert isinstance(trie[2][5][8]['_item'], int)
    result = model.decode([0, 1], trie, beam_width=12, k=10, seen={1}, device='cpu')
    indices = [i for i, _ in result]
    assert len(indices) == 3, f'Expected 3 unseen movies; got {indices}'
    assert set(indices) == {0, 2, 3}
    assert all(np.isfinite(score) for _, score in result)
    assert len(indices) == len(set(indices))


def test_decode_excludes_seen_movies_before_final_pruning():
    codes = np.array([[2, 5, 8], [2, 5, 9], [3, 6, 10]], dtype=np.int64)
    model = GenerativeRetriever(codes, 11, max_len=4, dim=8, heads=2, layers=1, dropout=0.)
    got = model.decode([0], build_trie(codes), beam_width=10, k=10, seen={0, 1})
    assert [i for i, _ in got] == [2]


def test_build_trie_rejects_collisions():
    with pytest.raises(ValueError, match='Duplicate'):
        build_trie(np.array([[2, 5, 8], [2, 5, 8]]))


def test_decoder_rejects_invalid_options():
    codes = np.array([[2, 5, 8], [2, 5, 9]], dtype=np.int64)
    model = GenerativeRetriever(codes, 10, max_len=4, dim=8, heads=2, layers=1)
    with pytest.raises(ValueError, match='positive'):
        model.decode([0], build_trie(codes), beam_width=0)
