# Two-tower evaluation patch

This patch replaces **only** `src/neural.py` and `src/recommender.py` in the existing repository.

## Why?

The original neural model used one fixed, uniformly sampled negative per positive event for all training epochs. The new experimental trainer resamples negatives **every epoch**, mixes popularity-biased and uniform items, and uses a **Bayesian personalized ranking (BPR) pairwise objective**. It is a research hypothesis, **not a guarantee of higher Recall/NDCG**.

The original `hybrid` score had its weights changed when the neural model existed, making model comparisons harder. The patched code keeps `hybrid` fixed as a classical baseline and adds a separately evaluated `hybrid_neural` method.

## Applying in GitHub Codespaces

1. Upload `two_tower_improvement.zip` to your GitHub repository (via GitHub's **Add file > Upload files**).
2. Return to Codespaces and pull it with `git pull origin main`.
3. From the repository root (the folder containing `app.py`), make a backup:

   ```bash
   mkdir -p reports/backup_original
   cp src/neural.py src/recommender.py reports/backup_original/
   cp artifacts/metrics.json reports/metrics_before_bpr.json
   ```

4. Apply the patch:

   ```bash
   unzip -o two_tower_improvement.zip
   ```

5. Verify the tests:

   ```bash
   python -m pytest -q tests
   ```

6. Train a new model:

   ```bash
   python -m src.train --neural --epochs 15
   ```

7. Compare **validation** metrics first (avoid choosing hyperparameters using the held-out final test):

   ```bash
   python -m json.tool artifacts/metrics.json
   ```

8. Launch UI:

   ```bash
   streamlit run app.py
   ```

## Expected changes

- A new `hybrid_neural` model will appear alongside `hybrid`.
- The `hybrid` method will continue to use the non-neural baseline weighting, whether or not the neural model is present.
- `two_tower` uses learned BPR embeddings and newly sampled negatives per epoch.
- Model training now takes longer. Codespaces CPU is sufficient for MovieLens Small, but timings vary.

## Caveats

- The uploaded patch does not contain or require any MovieLens ratings or trained model files.
- Negative items are still *unobserved*, not confirmed disliked or exposed movies.
- The new model is **untested against the real MovieLens download in this environment**; synthetic tests passed. Do not assume an improvement until you compare validation scores.
- If PyTorch is absent, run `python -m pip install -r requirements-neural.txt` first.
